import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        long long1 = org.apache.commons.math.util.FastMath.abs(1452076054732987038L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1452076054732987038L + "'", long1 == 1452076054732987038L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
//        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
//        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
//        double double4 = dfp3.toDouble();
//        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
//        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
//        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
//        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
//        double double10 = dfp9.toDouble();
//        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
//        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean14 = dfp9.equals((java.lang.Object) mersenneTwister13);
//        double double15 = mersenneTwister13.nextDouble();
//        org.junit.Assert.assertNotNull(dfpArray2);
//        org.junit.Assert.assertNotNull(dfp3);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
//        org.junit.Assert.assertNotNull(dfp5);
//        org.junit.Assert.assertNotNull(dfpArray8);
//        org.junit.Assert.assertNotNull(dfp9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
//        org.junit.Assert.assertNotNull(dfp11);
//        org.junit.Assert.assertNotNull(dfp12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.46956301811856016d + "'", double15 == 0.46956301811856016d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int[] intArray6 = new int[] { 52, (short) 1, (-32767), 32768, '#', 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        boolean boolean8 = mersenneTwister7.nextBoolean();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.3978952727983707d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number4, (java.lang.Number) (-1.5574077246549023d), false);
        boolean boolean8 = numberIsTooSmallException7.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.10916097497109696d, (java.lang.Number) 4.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        double double9 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.9160797831d + "'", double9 == 5.9160797831d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2780242596957121269L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.780242596957121E18d + "'", double1 == 2.780242596957121E18d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn5();
        double double11 = dfp10.toDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.DfpField.computeExp(dfp10, dfp16);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp5.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getESplit();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getLn5();
        boolean boolean37 = dfp31.greaterThan(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp36);
        int int39 = dfp38.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.71828182846d + "'", double6 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.609437912434d + "'", double11 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2780242596957121269L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2780242596957121024L + "'", long1 == 2780242596957121024L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlags((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        dfpField1.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.power10(16);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn5();
        boolean boolean12 = dfp6.greaterThan(dfp11);
        boolean boolean13 = dfp11.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1972245773362196d + "'", double1 == 2.1972245773362196d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-3007850007146714717L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField8.newDfp(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn5();
        double double24 = dfp23.toDouble();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.Dfp.copysign(dfp19, dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp6.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.ceil();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getE();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.getTwo();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField30.newDfp(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp26.divide(dfp48);
        int int50 = dfp49.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.609437912434d + "'", double24 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 23568.39729090051d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray5);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100.0f);
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 100.0f);
        java.lang.Number number16 = notStrictlyPositiveException15.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException23);
        java.lang.Throwable[] throwableArray25 = mathRuntimeException24.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable17, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100.0f);
        java.lang.Number number30 = notStrictlyPositiveException29.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 100.0f);
        java.lang.Number number35 = notStrictlyPositiveException34.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray41);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException42);
        java.lang.Throwable[] throwableArray44 = mathRuntimeException43.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable36, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField49.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 100.0f);
        java.lang.Number number54 = notStrictlyPositiveException53.getArgument();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 0.0f, 100.0d, dfpField49, number54, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable12, localizable36, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField60.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField60.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable12, localizable58, (java.lang.Object[]) dfpArray65);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0f + "'", number11.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100.0f + "'", number30.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100.0f + "'", number35.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 100.0f + "'", number54.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfpArray65);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.newInstance();
        boolean boolean19 = dfp17.isInfinite();
        int int20 = dfp17.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3.264877E7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8706367272933366E9d + "'", double1 == 1.8706367272933366E9d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0L);
        dfpField1.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.power10(16);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.71828182846d + "'", double8 == 2.71828182846d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn5();
        double double9 = dfp8.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn5();
        double double15 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField22.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp20, dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp4.newInstance((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.609437912434d + "'", double9 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.609437912434d + "'", double15 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.3978952727983707d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        int int13 = dfp12.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((-1));
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField10.newDfp(1.2679114584199251d);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField10.newDfp((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.newDfp(dfp21);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.10916097497109696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10916097497109696d + "'", double1 == 0.10916097497109696d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5.891636580713727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8061146554967942d + "'", double1 == 1.8061146554967942d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.6795226183513794d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.807872122398715d) + "'", double1 == (-0.807872122398715d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1, (byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray4 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister1.setSeed(intArray4);
        int[] intArray7 = new int[] { (byte) 0 };
        mersenneTwister1.setSeed(intArray7);
        double double9 = mersenneTwister1.nextDouble();
        byte[] byteArray12 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister1.nextBytes(byteArray12);
        long long14 = mersenneTwister1.nextLong();
        float float15 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8444218543953492d + "'", double9 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2024642350257892267L) + "'", long14 == (-2024642350257892267L));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.04048431f + "'", float15 == 0.04048431f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6081778099169377d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2681395072770731d + "'", double1 == 1.2681395072770731d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long2 = org.apache.commons.math.util.FastMath.max(1739865540426371694L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1739865540426371694L + "'", long2 == 1739865540426371694L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags(3);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
        long long2 = mersenneTwister1.nextLong();
        try {
            int int4 = mersenneTwister1.nextInt((-1508994432));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,508,994,432 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3007850007146714717L) + "'", long2 == (-3007850007146714717L));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5873157706131079d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp29);
        java.lang.Class<?> wildcardClass32 = dfp31.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math.util.FastMath.atan2(180.99723754798032d, (double) 13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4990951526940777d + "'", double2 == 1.4990951526940777d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.cosh(571.9094892935019d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.191531018558788E248d + "'", double1 == 1.191531018558788E248d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        boolean boolean3 = mersenneTwister0.nextBoolean();
        int int4 = mersenneTwister0.nextInt();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1966463646 + "'", int4 == 1966463646);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(3.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int[] intArray6 = new int[] { 52, (short) 1, (-32767), 32768, '#', 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        try {
            int int9 = mersenneTwister7.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        int int2 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(23568.39729090051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 411.3461321443257d + "'", double1 == 411.3461321443257d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn5();
        double double14 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getESplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.ceil();
        boolean boolean26 = dfp20.lessThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.sqrt();
        try {
            org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp9, dfp24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.609437912434d + "'", double14 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(36);
        java.lang.Class<?> wildcardClass12 = dfp9.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 1452076054732987038L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.divide(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp8.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn5();
        double double34 = dfp33.toDouble();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.rint();
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        org.apache.commons.math.dfp.Dfp dfp38 = new org.apache.commons.math.dfp.Dfp(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getTwo();
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp38, dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp52);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.609437912434d + "'", double34 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        mersenneTwister0.setSeed((long) (byte) 1);
        long long5 = mersenneTwister0.nextLong();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2084377003539008444L + "'", long5 == 2084377003539008444L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode7);
        dfpField1.setIEEEFlags(1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 3);
        dfpField1.setIEEEFlagsBits((int) '#');
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.cos(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7336545584598283d + "'", double1 == 0.7336545584598283d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1877410.8073051684d) + "'", double1 == (-1877410.8073051684d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(97);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.FastMath.min(93740670, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.multiply(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        java.lang.Throwable[] throwableArray7 = mathRuntimeException6.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathRuntimeException6.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5708860293959651d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance(0.20794165181485275d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.negate();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField9.newDfp(dfp19);
        int int21 = dfp20.getRadixDigits();
        boolean boolean22 = dfp6.lessThan(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getLn5();
        double double27 = dfp26.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.rint();
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        java.lang.Class<?> wildcardClass32 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.floor();
        boolean boolean34 = dfp6.lessThan(dfp33);
        int int35 = dfp33.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.609437912434d + "'", double27 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((double) 2);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn5();
        double double19 = dfp18.toDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = dfp23.getField();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.609437912434d + "'", double19 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpField24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.3978952727983707d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.3978952727983707d + "'", number5.equals(2.3978952727983707d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getESplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        int int6 = dfp5.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        double double3 = mersenneTwister0.nextDouble();
        mersenneTwister0.setSeed((long) 0);
        long long6 = mersenneTwister0.nextLong();
        boolean boolean7 = mersenneTwister0.nextBoolean();
        double double8 = mersenneTwister0.nextGaussian();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0787171938695459d + "'", double3 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2780242596957121269L + "'", long6 == 2780242596957121269L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7949034000231544d + "'", double8 == 0.7949034000231544d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.4298353261402452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4443103872152795d + "'", double1 == 0.4443103872152795d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0000000000003513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed((int) '#');
//        mersenneTwister0.setSeed(10);
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.5656742f + "'", float1 == 0.5656742f);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn5();
        double double23 = dfp22.toDouble();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.newInstance((-32767.0d));
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField28.getLn5Split();
        java.lang.Class<?> wildcardClass33 = dfpField28.getClass();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp34);
        boolean boolean36 = dfp18.unequal(dfp34);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.609437912434d + "'", double23 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 10.067661995777765d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException6.getSuppressed();
        boolean boolean9 = notStrictlyPositiveException6.getBoundIsAllowed();
        java.lang.String str10 = notStrictlyPositiveException6.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0f + "'", number3.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10.068 is smaller than, or equal to, the minimum (0): 10.068 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10.068 is smaller than, or equal to, the minimum (0): 10.068 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 1452076054732987038L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.divide(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp8.newInstance(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp8.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray4 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister1.setSeed(intArray4);
        int[] intArray7 = new int[] { (byte) 0 };
        mersenneTwister1.setSeed(intArray7);
        double double9 = mersenneTwister1.nextDouble();
        byte[] byteArray12 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister1.nextBytes(byteArray12);
        long long14 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister15.setSeed((long) (byte) 100);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray22 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister19.setSeed(intArray22);
        int[] intArray25 = new int[] { (byte) 0 };
        mersenneTwister19.setSeed(intArray25);
        mersenneTwister15.setSeed(intArray25);
        mersenneTwister1.setSeed(intArray25);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8444218543953492d + "'", double9 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2024642350257892267L) + "'", long14 == (-2024642350257892267L));
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8444218543953492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3266322934200647d + "'", double1 == 2.3266322934200647d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2679114584199251d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getLn5();
        double double27 = dfp26.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getLn5();
        double double33 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeExp(dfp26, dfp32);
        int int36 = dfp32.intValue();
        java.lang.String str37 = dfp32.toString();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp32.newInstance((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp40 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp41 = dfp20.dotrap((int) (short) 1, "1.732050807569", dfp32, dfp40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.609437912434d + "'", double27 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.609437912434d + "'", double33 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1.609437912434" + "'", str37.equals("1.609437912434"));
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getLn5Split();
        dfpField16.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 52);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.floor();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.multiply(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp12, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        boolean boolean31 = dfp30.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp25.subtract(dfp30);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.3978952727983707d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number4, (java.lang.Number) (-1.5574077246549023d), false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.apache.commons.math.util.FastMath.min((-1044846940), (int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1044846940) + "'", int2 == (-1044846940));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.757456677636331d, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.27747362070435855d + "'", double2 == 0.27747362070435855d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 97, (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.210340371976184d + "'", double1 == 9.210340371976184d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField14.newDfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn5();
        double double30 = dfp29.toDouble();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance();
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        boolean boolean33 = dfp12.lessThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn5();
        double double38 = dfp37.toDouble();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn5();
        double double44 = dfp43.toDouble();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeExp(dfp37, dfp43);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.newInstance((byte) 0);
        double double49 = dfp43.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.ceil();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField59.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getLn5();
        double double62 = dfp61.toDouble();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.rint();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp57.add(dfp64);
        boolean boolean66 = dfp43.unequal(dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp25.newInstance(dfp64);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.609437912434d + "'", double30 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.609437912434d + "'", double38 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.609437912434d + "'", double44 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.609437912434d + "'", double49 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.609437912434d + "'", double62 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 442412.3920089205d + "'", double1 == 442412.3920089205d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((double) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        double[] doubleArray20 = dfp12.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        double[] doubleArray19 = dfp18.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getTwo();
        boolean boolean33 = dfp18.lessThan(dfp32);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2Reciprocal();
        double double6 = dfp5.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7071067811865d + "'", double6 == 0.7071067811865d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8808370627487303d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8808370627487303d + "'", double1 == 0.8808370627487303d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8444218543953492d, 4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.15912713462618d + "'", double2 == 4.15912713462618d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0000000000003513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.295779513102445d + "'", double1 == 57.295779513102445d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) 1L);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04211928877437304d) + "'", double1 == (-0.04211928877437304d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance("Infinity");
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField26.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp34 = dfp24.divide(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField37.getESplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.Dfp.copysign(dfp34, dfp39);
        boolean boolean41 = dfp11.unequal(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField42 = dfp40.getField();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dfpField42);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        long long3 = mersenneTwister0.nextLong();
        mersenneTwister0.setSeed((int) (byte) 1);
        mersenneTwister0.setSeed(52);
        float float8 = mersenneTwister0.nextFloat();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1452076054732987038L + "'", long3 == 1452076054732987038L);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8231102f + "'", float8 == 0.8231102f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.FastMath.max(23568.397290900513d, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23568.397290900513d + "'", double2 == 23568.397290900513d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(8);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getESplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.ceil();
        boolean boolean16 = dfp10.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp14.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.791345759174642d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.791345759174642d + "'", double2 == 1.791345759174642d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField7.setRoundingMode(roundingMode13);
        dfpField1.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray16);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        double double3 = mersenneTwister0.nextDouble();
        mersenneTwister0.setSeed(1452076054732987038L);
        double double6 = mersenneTwister0.nextDouble();
        double double7 = mersenneTwister0.nextDouble();
        boolean boolean8 = mersenneTwister0.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister9.setSeed((long) (byte) 100);
        double double12 = mersenneTwister9.nextDouble();
        mersenneTwister9.setSeed((long) 0);
        mersenneTwister9.setSeed((int) (byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister17.setSeed((long) (byte) 100);
        long long20 = mersenneTwister17.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray25 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister22.setSeed(intArray25);
        int[] intArray28 = new int[] { (byte) 0 };
        mersenneTwister22.setSeed(intArray28);
        double double30 = mersenneTwister22.nextDouble();
        byte[] byteArray33 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister22.nextBytes(byteArray33);
        mersenneTwister17.nextBytes(byteArray33);
        mersenneTwister9.nextBytes(byteArray33);
        mersenneTwister0.nextBytes(byteArray33);
        double double38 = mersenneTwister0.nextGaussian();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0787171938695459d + "'", double3 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.757456677636331d + "'", double6 == 0.757456677636331d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8808370627487303d + "'", double7 == 0.8808370627487303d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0787171938695459d + "'", double12 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1452076054732987038L + "'", long20 == 1452076054732987038L);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.8444218543953492d + "'", double30 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0048440763214685d + "'", double38 == 1.0048440763214685d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 16, 1452076054732987038L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1452076054732987038L + "'", long2 == 1452076054732987038L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.6795226183513794d), (double) 32760);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32760.0d + "'", double2 == 32760.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.000000000000002d, (java.lang.Number) (short) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 100.0f);
        java.lang.Number number20 = notStrictlyPositiveException19.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray26);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException27);
        java.lang.Throwable[] throwableArray29 = mathRuntimeException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable21, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100.0f);
        java.lang.Number number34 = notStrictlyPositiveException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 100.0f);
        java.lang.Number number39 = notStrictlyPositiveException38.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray45);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException46);
        java.lang.Throwable[] throwableArray48 = mathRuntimeException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable40, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField53.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 100.0f);
        java.lang.Number number58 = notStrictlyPositiveException57.getArgument();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 0.0f, 100.0d, dfpField53, number58, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11, localizable16, localizable40, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 2.3978952727983707d);
        java.lang.Number number65 = notStrictlyPositiveException64.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException64.getSpecificPattern();
        java.lang.Number number67 = notStrictlyPositiveException64.getArgument();
        java.lang.Object[] objArray68 = notStrictlyPositiveException64.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable40, objArray68);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100.0f + "'", number20.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 100.0f + "'", number39.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 100.0f + "'", number58.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 2.3978952727983707d + "'", number65.equals(2.3978952727983707d));
        org.junit.Assert.assertNull(localizable66);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 2.3978952727983707d + "'", number67.equals(2.3978952727983707d));
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray4 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister1.setSeed(intArray4);
        double double6 = mersenneTwister1.nextDouble();
        boolean boolean7 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5181394699352195d + "'", double6 == 0.5181394699352195d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.negate();
        boolean boolean16 = dfp8.unequal(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.power10(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(36);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.rint();
        int int13 = dfp12.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36 + "'", int13 == 36);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 10.067661995777765d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException6.getSuppressed();
        boolean boolean9 = notStrictlyPositiveException6.getBoundIsAllowed();
        java.lang.Object[] objArray10 = notStrictlyPositiveException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.String str12 = notStrictlyPositiveException6.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0f + "'", number3.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10.068 is smaller than, or equal to, the minimum (0): 10.068 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10.068 is smaller than, or equal to, the minimum (0): 10.068 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.sqrt();
        java.lang.String str8 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.316074012952" + "'", str8.equals("1.316074012952"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.expm1(571.9094892935019d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.383062037117576E248d + "'", double1 == 2.383062037117576E248d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn5();
        double double12 = dfp11.toDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.add(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.getZero();
        int int17 = dfp16.classify();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.negate();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField19.newDfp(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField32.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp29.multiply(dfp38);
        double[] doubleArray40 = dfp38.toSplitDouble();
        boolean boolean41 = dfp16.equals((java.lang.Object) doubleArray40);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.609437912434d + "'", double12 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893713d) + "'", double1 == (-0.5440211108893713d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.61512051684126d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '#');
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        long long3 = mersenneTwister0.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray8 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister5.setSeed(intArray8);
        int[] intArray11 = new int[] { (byte) 0 };
        mersenneTwister5.setSeed(intArray11);
        double double13 = mersenneTwister5.nextDouble();
        byte[] byteArray16 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister5.nextBytes(byteArray16);
        mersenneTwister0.nextBytes(byteArray16);
        double double19 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1452076054732987038L + "'", long3 == 1452076054732987038L);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8444218543953492d + "'", double13 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.4248668217171372d + "'", double19 == 0.4248668217171372d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0048440763214685d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField1.setRoundingMode(roundingMode10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.Throwable[] throwableArray24 = mathRuntimeException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100.0f);
        java.lang.Number number29 = notStrictlyPositiveException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100.0f);
        java.lang.Number number34 = notStrictlyPositiveException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Throwable[] throwableArray43 = mathRuntimeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable35, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0f);
        java.lang.Number number53 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0.0f, 100.0d, dfpField48, number53, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable11, localizable35, objArray55);
        java.lang.Object[] objArray57 = mathRuntimeException56.getArguments();
        java.lang.String str58 = mathRuntimeException56.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0f + "'", number29.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 100.0f + "'", number53.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: 0 is smaller than, or equal to, the minimum (100): 0 is smaller than, or equal to, the minimum (100)" + "'", str58.equals("org.apache.commons.math.exception.MathRuntimeException: 0 is smaller than, or equal to, the minimum (100): 0 is smaller than, or equal to, the minimum (100)"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0000000000000002d, (java.lang.Number) 57.0d, true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp("1.609437912434");
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570765809216781d + "'", double1 == 1.570765809216781d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn5();
        double double11 = dfp10.toDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.DfpField.computeExp(dfp10, dfp16);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp5.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.ceil();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.negate();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField26.newDfp(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField39.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getLn5();
        double double42 = dfp41.toDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance();
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp37, dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp37.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn5();
        double double51 = dfp50.toDouble();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField54.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn5();
        double double57 = dfp56.toDouble();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance();
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.DfpField.computeExp(dfp50, dfp56);
        int int60 = dfp56.intValue();
        boolean boolean61 = dfp46.unequal(dfp56);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp21.multiply(dfp56);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp56.divide(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.71828182846d + "'", double6 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.609437912434d + "'", double11 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.609437912434d + "'", double42 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.609437912434d + "'", double51 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.609437912434d + "'", double57 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(51.99999999999999d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.71828182846d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance("Infinity");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.791345759174642d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.187108158670599d + "'", double1 == 1.187108158670599d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.multiply(dfp20);
        double[] doubleArray22 = dfp20.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = dfp20.getField();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(dfpField23);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        double[] doubleArray19 = dfp18.toSplitDouble();
        int int20 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.divide((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        boolean boolean24 = dfp22.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        int int13 = dfp12.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-0.3900637759820599d));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.divide(dfp13);
        int int16 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080634815244d + "'", double1 == 1.543080634815244d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0000000000000002d, (java.lang.Number) 100.0d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100.0f);
        java.lang.Number number8 = notStrictlyPositiveException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable[] throwableArray10 = notStrictlyPositiveException7.getSuppressed();
        java.lang.Number number11 = notStrictlyPositiveException7.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0000000000000002d + "'", number4.equals(1.0000000000000002d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0f + "'", number8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0f + "'", number11.equals(100.0f));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.629391499997093E20d + "'", double1 == 2.629391499997093E20d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 1452076054732987038L);
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister2.setSeed((long) (byte) 100);
        double double5 = mersenneTwister2.nextDouble();
        mersenneTwister2.setSeed((long) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister8.setSeed((long) (byte) 100);
        long long11 = mersenneTwister8.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray16 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister13.setSeed(intArray16);
        int[] intArray19 = new int[] { (byte) 0 };
        mersenneTwister13.setSeed(intArray19);
        double double21 = mersenneTwister13.nextDouble();
        byte[] byteArray24 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister13.nextBytes(byteArray24);
        mersenneTwister8.nextBytes(byteArray24);
        mersenneTwister2.nextBytes(byteArray24);
        mersenneTwister1.nextBytes(byteArray24);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0787171938695459d + "'", double5 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1452076054732987038L + "'", long11 == 1452076054732987038L);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.8444218543953492d + "'", double21 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.Throwable[] throwableArray24 = mathRuntimeException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100.0f);
        java.lang.Number number29 = notStrictlyPositiveException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100.0f);
        java.lang.Number number34 = notStrictlyPositiveException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Throwable[] throwableArray43 = mathRuntimeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable35, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0f);
        java.lang.Number number53 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0.0f, 100.0d, dfpField48, number53, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable11, localizable35, objArray55);
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, number57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-1), (java.lang.Number) 0.51813936f, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 3.141592653589793d, (java.lang.Number) 1.5707963267948966d, false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0f + "'", number29.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 100.0f + "'", number53.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.multiply(dfp20);
        int int22 = dfp20.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.3978952727983707d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number4, (java.lang.Number) (-1.5574077246549023d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 0.2965040421714372d, (java.lang.Number) 0.5181394699352195d, false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5605656875042625d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5605656875042625d + "'", double1 == 0.5605656875042625d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("Infinity");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.69314718055995d + "'", double1 == 97.69314718055995d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.Throwable[] throwableArray24 = mathRuntimeException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100.0f);
        java.lang.Number number29 = notStrictlyPositiveException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100.0f);
        java.lang.Number number34 = notStrictlyPositiveException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Throwable[] throwableArray43 = mathRuntimeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable35, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0f);
        java.lang.Number number53 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0.0f, 100.0d, dfpField48, number53, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable11, localizable35, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) (-0.5440211108893698d));
        java.lang.Throwable[] throwableArray59 = notStrictlyPositiveException58.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0f + "'", number29.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 100.0f + "'", number53.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray59);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.3978952727983707d);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField7.setRoundingMode(roundingMode13);
        dfpField1.setRoundingMode(roundingMode13);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean14 = dfp9.equals((java.lang.Object) mersenneTwister13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister15.setSeed((long) (byte) 100);
        double double18 = mersenneTwister15.nextDouble();
        mersenneTwister15.setSeed((long) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister21.setSeed((long) (byte) 100);
        long long24 = mersenneTwister21.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray29 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister26.setSeed(intArray29);
        int[] intArray32 = new int[] { (byte) 0 };
        mersenneTwister26.setSeed(intArray32);
        double double34 = mersenneTwister26.nextDouble();
        byte[] byteArray37 = new byte[] { (byte) 100, (byte) 3 };
        mersenneTwister26.nextBytes(byteArray37);
        mersenneTwister21.nextBytes(byteArray37);
        mersenneTwister15.nextBytes(byteArray37);
        mersenneTwister13.nextBytes(byteArray37);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0787171938695459d + "'", double18 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1452076054732987038L + "'", long24 == 1452076054732987038L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.8444218543953492d + "'", double34 == 0.8444218543953492d);
        org.junit.Assert.assertNotNull(byteArray37);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2617009747675998d, 1.160387258364981d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.309629849175895d + "'", double2 == 1.309629849175895d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        double double15 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn5();
        double double28 = dfp27.toDouble();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.rint();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.add(dfp30);
        boolean boolean32 = dfp9.unequal(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.rint();
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp9.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.609437912434d + "'", double15 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.609437912434d + "'", double28 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance((byte) 1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp18);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.divide(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.9786576f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5183485688820613d + "'", double1 == 1.5183485688820613d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn5();
        double double13 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn5();
        double double19 = dfp18.toDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp18);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp23.getField();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        double double32 = dfp31.toDouble();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn5();
        double double38 = dfp37.toDouble();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance();
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp27, dfp37);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((byte) 3);
        boolean boolean44 = dfp3.lessThan(dfp43);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.609437912434d + "'", double13 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.609437912434d + "'", double19 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.609437912434d + "'", double32 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.609437912434d + "'", double38 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.sqrt();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.rint();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("Infinity");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        int int12 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.power10(0);
        int int22 = dfp12.classify();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        boolean boolean3 = mersenneTwister0.nextBoolean();
        boolean boolean4 = mersenneTwister0.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray9 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister6.setSeed(intArray9);
        int[] intArray12 = new int[] { (byte) 0 };
        mersenneTwister6.setSeed(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        mersenneTwister0.setSeed(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray20 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister17.setSeed(intArray20);
        int[] intArray23 = new int[] { (byte) 0 };
        mersenneTwister17.setSeed(intArray23);
        mersenneTwister0.setSeed(intArray23);
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.ceil();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.negate();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn5();
        double double26 = dfp25.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        double double32 = dfp31.toDouble();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.DfpField.computeExp(dfp25, dfp31);
        int int35 = dfp31.intValue();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp31.power10K(1);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.ceil();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.negate();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField39.newDfp(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.getLn5();
        double double55 = dfp54.toDouble();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.Dfp.copysign(dfp50, dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp50.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField61.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.getLn5();
        double double64 = dfp63.toDouble();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.newInstance();
        boolean boolean66 = dfp59.equals((java.lang.Object) dfp63);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp59);
        org.apache.commons.math.dfp.Dfp dfp68 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp21, dfp31);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.609437912434d + "'", double26 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.609437912434d + "'", double32 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.609437912434d + "'", double55 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.609437912434d + "'", double64 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1877410.8073051684d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1877411.0d) + "'", double1 == (-1877411.0d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn5();
        double double23 = dfp22.toDouble();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp22);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp27.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable11, localizable12, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathRuntimeException32.getGeneralPattern();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.609437912434d + "'", double23 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNull(localizable33);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        double double15 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn5();
        double double28 = dfp27.toDouble();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.rint();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.add(dfp30);
        boolean boolean32 = dfp9.unequal(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField37.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getLn5();
        double double40 = dfp39.toDouble();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.rint();
        org.apache.commons.math.dfp.DfpField dfpField43 = dfp42.getField();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getLn5();
        java.lang.Class<?> wildcardClass45 = dfp44.getClass();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance((double) ' ');
        int int49 = dfp48.log10K();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp35.multiply(dfp48);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.609437912434d + "'", double15 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.609437912434d + "'", double28 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.609437912434d + "'", double40 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpField43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(8449622380353275151L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.2414468098677504d, (java.lang.Number) 57.29577951308233d, false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        int int8 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn5();
        double double14 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance((-32767.0d));
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp9, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.609437912434d + "'", double14 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(1.2679114584199251d);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((double) 2);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn5();
        double double19 = dfp18.toDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp4.newInstance("Infinity");
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn5();
        double double30 = dfp29.toDouble();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getLn5();
        double double36 = dfp35.toDouble();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp35);
        boolean boolean39 = dfp4.lessThan(dfp35);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.609437912434d + "'", double19 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.609437912434d + "'", double30 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.609437912434d + "'", double36 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.10916097497109696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4614173851450052d + "'", double1 == 1.4614173851450052d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        int[] intArray7 = new int[] { (byte) 10, (short) 100 };
        mersenneTwister4.setSeed(intArray7);
        int[] intArray10 = new int[] { (byte) 0 };
        mersenneTwister4.setSeed(intArray10);
        mersenneTwister0.setSeed(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.Throwable[] throwableArray24 = mathRuntimeException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100.0f);
        java.lang.Number number29 = notStrictlyPositiveException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100.0f);
        java.lang.Number number34 = notStrictlyPositiveException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Throwable[] throwableArray43 = mathRuntimeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable35, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0f);
        java.lang.Number number53 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0.0f, 100.0d, dfpField48, number53, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable11, localizable35, objArray55);
        java.lang.Object[] objArray57 = mathRuntimeException56.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException56);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0f + "'", number29.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 100.0f + "'", number53.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 4 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 4 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        boolean boolean12 = dfp11.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfp8.remainder(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance(100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((-1044846940));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getLn5();
        double double27 = dfp26.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getLn5();
        double double33 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeExp(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField39 = dfp37.getField();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.getLn5();
        double double46 = dfp45.toDouble();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField49.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getLn5();
        double double52 = dfp51.toDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance();
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeExp(dfp45, dfp51);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp41, dfp51);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp18.subtract(dfp41);
        int int57 = dfp56.classify();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.609437912434d + "'", double27 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.609437912434d + "'", double33 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpField39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.609437912434d + "'", double46 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.609437912434d + "'", double52 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        boolean boolean4 = dfp3.isInfinite();
        boolean boolean5 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.power10K((int) (short) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.power10(0);
        java.lang.String str22 = dfp12.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Infinity" + "'", str22.equals("Infinity"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.115280183261812E-57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(0.0d);
        boolean boolean15 = dfp4.greaterThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 1452076054732987038L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3, (byte) 10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlags((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 1452076054732987038L);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((-1L));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.divide(dfp17);
        double[] doubleArray19 = dfp18.toSplitDouble();
        int int20 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.divide((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        int int9 = dfp8.log10();
        int int10 = dfp8.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((byte) 0);
        double double15 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn5();
        double double28 = dfp27.toDouble();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.rint();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.add(dfp30);
        boolean boolean32 = dfp9.unequal(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.rint();
        double[] doubleArray34 = dfp33.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.609437912434d + "'", double4 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.609437912434d + "'", double10 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.609437912434d + "'", double15 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.609437912434d + "'", double28 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long2 = org.apache.commons.math.util.FastMath.min(8449622380353275151L, (-3007850007146714717L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3007850007146714717L) + "'", long2 == (-3007850007146714717L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.2617009747675998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0805681095334052d + "'", double1 == 1.0805681095334052d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-32767.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.Throwable[] throwableArray24 = mathRuntimeException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100.0f);
        java.lang.Number number29 = notStrictlyPositiveException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) (-0.807872122398715d));
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField35.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField35.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable16, localizable31, (java.lang.Object[]) dfpArray41);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0f + "'", number29.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfpArray41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01d + "'", double2 == 0.01d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32768);
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp16.divide(dfp25);
        double[] doubleArray27 = dfp26.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.sqrt();
        boolean boolean29 = dfp6.unequal(dfp26);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32768 + "'", int7 == 32768);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn5();
        boolean boolean12 = dfp6.greaterThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.power10(32648770);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.2617009747675998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) 100);
        double double3 = mersenneTwister0.nextGaussian();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9086743489308475d + "'", double3 == 0.9086743489308475d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.000000000000002d, (java.lang.Number) (short) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.115280183261812E-57d, (java.lang.Number) (-0.017453292519943295d), false);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100.0f);
        java.lang.Number number22 = notStrictlyPositiveException21.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 100.0f);
        java.lang.Number number27 = notStrictlyPositiveException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable28 = notStrictlyPositiveException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray33);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException34);
        java.lang.Throwable[] throwableArray36 = mathRuntimeException35.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable28, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 100.0f);
        java.lang.Number number41 = notStrictlyPositiveException40.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable43, (java.lang.Number) 100.0f);
        java.lang.Number number46 = notStrictlyPositiveException45.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { false, 1.0d, (short) 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray52);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException53);
        java.lang.Throwable[] throwableArray55 = mathRuntimeException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable47, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField60.getLn2Split();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 100.0f);
        java.lang.Number number65 = notStrictlyPositiveException64.getArgument();
        java.lang.Object[] objArray67 = new java.lang.Object[] { 0.0f, 100.0d, dfpField60, number65, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException68 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException18, localizable23, localizable47, objArray67);
        java.lang.Number number69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, number69);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) (-1), (java.lang.Number) 0.51813936f, false);
        java.lang.Object[] objArray75 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable47, objArray75);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 100.0f + "'", number22.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 100.0f + "'", number27.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 100.0f + "'", number41.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 100.0f + "'", number46.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 100.0f + "'", number65.equals(100.0f));
        org.junit.Assert.assertNotNull(objArray67);
    }
}

