import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray8);
        java.util.NoSuchElementException noSuchElementException10 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray8);
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("convergence failed", objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(noSuchElementException9);
        org.junit.Assert.assertNotNull(noSuchElementException10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6388442233489334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException(throwable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) (-1L), "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 22026.465794806718d, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray25);
        double[] doubleArray37 = new double[] { 0.9997891493170082d, (-1L), 0.9443607442279424d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException33, doubleArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(illegalArgumentException16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException12);
        double[] doubleArray18 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException12, doubleArray18, "{0}", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 1, "4d61c775125975818464fbceb6875563404c4881e25ccff8104e5a0c468b3a01fcc9938c33edd32a4220fefcf9663066afb7", objArray25);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException29);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double[] doubleArray3 = new double[] { 0.9997891493170082d, (-1L), 0.9443607442279424d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException16);
        double[] doubleArray22 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException30 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException16, doubleArray22, "{0}", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException(localizable6, objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, "org.apache.commons.math.MathRuntimeException: -1 is larger than the maximum (10): vector must have at least one element", objArray29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(noSuchElementException30);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0E-12d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray21);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, "", objArray27);
        java.lang.String str29 = convergenceException25.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "numerator" + "'", str29.equals("numerator"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0E-12d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException32);
        java.lang.Object[] objArray34 = mathRuntimeException33.getArguments();
        java.util.ConcurrentModificationException concurrentModificationException35 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException3, "5d7fb76d30", objArray34);
        boolean boolean37 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(concurrentModificationException35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray8);
        java.util.NoSuchElementException noSuchElementException10 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray8);
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.util.NoSuchElementException noSuchElementException12 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException23 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray22);
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(1385.4557313670107d, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(noSuchElementException9);
        org.junit.Assert.assertNotNull(noSuchElementException10);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(noSuchElementException12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(noSuchElementException23);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.7714284935985605d, (double) ' ');
//        randomDataImpl0.reSeed((long) 1);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(80);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.08983425844813d + "'", double3 == 22.08983425844813d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "80a3a73cf1468c94c89d8d14a6f606034f18b17e43e53b6c28ba3971e16d2cf81b7801c65bba7ba0" + "'", str7.equals("80a3a73cf1468c94c89d8d14a6f606034f18b17e43e53b6c28ba3971e16d2cf81b7801c65bba7ba0"));
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 1385.4557313670107d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1, (double) 10);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (-1));
        double double8 = normalDistributionImpl2.density((java.lang.Double) 0.0d);
        double double10 = normalDistributionImpl2.cumulativeProbability(0.05734311894903636d);
        normalDistributionImpl2.reseedRandomGenerator((long) 100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.039695254747701185d + "'", double8 == 0.039695254747701185d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.46244905271869846d + "'", double10 == 0.46244905271869846d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-3.5678430532082297d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9841932790063541d) + "'", double1 == (-1.9841932790063541d));
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(100);
//        double double5 = randomDataImpl0.nextBeta((double) 100L, 0.7714284935985605d);
//        long long7 = randomDataImpl0.nextPoisson(2.675640048483193E7d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "54b119556b8b0f9ef625813a77a8b5edb6cddb22ad71d4c8fd61b1adea3ebcac6a2a626513f66f32fa7469a0aaa27733707a" + "'", str2.equals("54b119556b8b0f9ef625813a77a8b5edb6cddb22ad71d4c8fd61b1adea3ebcac6a2a626513f66f32fa7469a0aaa27733707a"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9976142105742521d + "'", double5 == 0.9976142105742521d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 26751139L + "'", long7 == 26751139L);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(22026.465794806718d, (double) 10L);
//        int int6 = randomDataImpl0.nextSecureInt((int) '4', (int) 'a');
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1, (double) 10);
//        normalDistributionImpl11.reseedRandomGenerator((long) (byte) 1);
//        normalDistributionImpl11.reseedRandomGenerator((long) (-1));
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        int int19 = randomDataImpl0.nextZipf(93, 0.9996787836720634d);
//        int[] intArray22 = randomDataImpl0.nextPermutation((int) '#', (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9996801921860535d + "'", double3 == 0.9996801921860535d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e537a5bbdb" + "'", str8.equals("e537a5bbdb"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-3.0912272726473984d) + "'", double16 == (-3.0912272726473984d));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException5);
        java.lang.Object[] objArray7 = mathRuntimeException6.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException8);
        java.lang.String str10 = mathRuntimeException8.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "no data" + "'", str10.equals("no data"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 81);
//        double double4 = randomDataImpl0.nextT((double) 100);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 79L + "'", long2 == 79L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4054035607664936d + "'", double4 == 1.4054035607664936d);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException12);
        double[] doubleArray18 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException12, doubleArray18, "{0}", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 1, "4d61c775125975818464fbceb6875563404c4881e25ccff8104e5a0c468b3a01fcc9938c33edd32a4220fefcf9663066afb7", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException29);
        java.lang.IllegalArgumentException illegalArgumentException31 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) convergenceException30);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(illegalArgumentException31);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException7 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray6);
        java.util.NoSuchElementException noSuchElementException8 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException15);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException16, "hi!", objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException28, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray35);
        java.lang.Object[] objArray44 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException45 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray44);
        java.lang.IllegalArgumentException illegalArgumentException46 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray44);
        java.lang.Class<?> wildcardClass47 = objArray44.getClass();
        java.text.ParseException parseException48 = org.apache.commons.math.MathRuntimeException.createParseException(1, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray44);
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray58);
        java.lang.IllegalArgumentException illegalArgumentException60 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException59);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray69 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException70 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray69);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException59, (org.apache.commons.math.exception.util.Localizable) localizedFormats61, objArray69);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException(throwable51, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((double) (-1L), "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray69);
        java.util.ConcurrentModificationException concurrentModificationException75 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray69);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) noSuchElementException8, "", objArray69);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(noSuchElementException7);
        org.junit.Assert.assertNotNull(noSuchElementException8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(noSuchElementException36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(noSuchElementException45);
        org.junit.Assert.assertNotNull(illegalArgumentException46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(parseException48);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertNotNull(illegalArgumentException60);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(noSuchElementException70);
        org.junit.Assert.assertNotNull(concurrentModificationException75);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalArgumentException illegalArgumentException2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("8076fe736d62b848abdbcc7c40dd4373330b1a5402c66f9b9149f1e613205b63edec25a304f7edc42f4330d66f2b053e849e", objArray1);
        org.junit.Assert.assertNotNull(illegalArgumentException2);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray10);
        java.util.NoSuchElementException noSuchElementException13 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((double) (-1L), (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException18 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertNotNull(noSuchElementException13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException18);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalArgumentException illegalArgumentException2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(illegalArgumentException2);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1, (double) 10);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (-1));
        double double8 = normalDistributionImpl2.density((java.lang.Double) 1.5707963267948966d);
        double double10 = normalDistributionImpl2.density((java.lang.Double) 11013.232874703393d);
        normalDistributionImpl2.setStandardDeviation((double) 3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0398292915642879d + "'", double8 == 0.0398292915642879d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.05734311894903636d, 93);
        poissonDistributionImpl2.reseedRandomGenerator((long) 0);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) 26751139L);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9996834789455704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02516099177041384d + "'", double1 == 0.02516099177041384d);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test33");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1, (double) 10);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.inverseCumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.94988362376606d) + "'", double3 == (-1.94988362376606d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9969976792911474d, (java.lang.Number) 0.7714284935985605d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException10);
        java.lang.Object[] objArray12 = mathRuntimeException11.getArguments();
        java.util.ConcurrentModificationException concurrentModificationException13 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray12);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray21);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException22, 0.9996834789455704d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException31);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException42 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException32, "hi!", objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException52 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray51);
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException44, (org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, "54b119556b8b0f9ef625813a77a8b5edb6cddb22ad71d4c8fd61b1adea3ebcac6a2a626513f66f32fa7469a0aaa27733707a", objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(concurrentModificationException13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(noSuchElementException42);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(noSuchElementException52);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.026608524989875485d, 0.0d, (int) (byte) 1);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(10.0d);
        double double4 = poissonDistributionImpl1.cumulativeProbability(0.0d, 1.1102230246251565E-16d);
        double double6 = poissonDistributionImpl1.cumulativeProbability((int) (short) 1);
        int[] intArray8 = poissonDistributionImpl1.sample(93);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.539992976248491E-5d + "'", double4 == 4.539992976248491E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.993992273873336E-4d + "'", double6 == 4.993992273873336E-4d);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(22026.465794806718d, (double) 10L);
//        int int6 = randomDataImpl0.nextSecureInt((int) '4', (int) 'a');
//        int int9 = randomDataImpl0.nextBinomial(10, 0.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("54238ae3d8a398417ab4621830f8b68361c8efe7c73f5cf8c8d68ce6fb4fe07633995b008e1feb9c5abfe1e09415706b1144", "maximal count ({0}) exceeded");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: maximal count ({0}) exceeded");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9994985458450494d + "'", double3 == 0.9994985458450494d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58 + "'", int6 == 58);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        java.lang.Object[] objArray1 = null;
        java.lang.UnsupportedOperationException unsupportedOperationException2 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertNotNull(unsupportedOperationException2);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(10.0d);
        double double4 = poissonDistributionImpl1.cumulativeProbability(0.0d, 1.1102230246251565E-16d);
        double double6 = poissonDistributionImpl1.cumulativeProbability((int) (short) 1);
        poissonDistributionImpl1.reseedRandomGenerator((long) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.539992976248491E-5d + "'", double4 == 4.539992976248491E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.993992273873336E-4d + "'", double6 == 4.993992273873336E-4d);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1, (double) 10);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (-1));
        double double8 = normalDistributionImpl2.density((double) 32L);
        double double10 = normalDistributionImpl2.density((double) 0L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.266819056199922E-4d + "'", double8 == 3.266819056199922E-4d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.039695254747701185d + "'", double10 == 0.039695254747701185d);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException10 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray9);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray9);
        java.io.EOFException eOFException12 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.util.ConcurrentModificationException concurrentModificationException13 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray9);
        java.io.EOFException eOFException14 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray23);
        java.lang.IllegalArgumentException illegalArgumentException25 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray23);
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray35);
        java.lang.IllegalArgumentException illegalArgumentException37 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray35);
        java.io.EOFException eOFException38 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException26, "6b1a9589f1", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException14, "no data", objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(noSuchElementException10);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(eOFException12);
        org.junit.Assert.assertNotNull(concurrentModificationException13);
        org.junit.Assert.assertNotNull(eOFException14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertNotNull(illegalArgumentException25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(noSuchElementException36);
        org.junit.Assert.assertNotNull(illegalArgumentException37);
        org.junit.Assert.assertNotNull(eOFException38);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException12 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException13);
        double[] doubleArray19 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray26 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException27 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException13, doubleArray19, "{0}", objArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException(localizable3, objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) 1, "4d61c775125975818464fbceb6875563404c4881e25ccff8104e5a0c468b3a01fcc9938c33edd32a4220fefcf9663066afb7", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("numerator", objArray26);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(noSuchElementException12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(noSuchElementException27);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException10 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException11);
        double[] doubleArray17 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException11, doubleArray17, "{0}", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException(localizable1, objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(noSuchElementException10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException25);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray8);
        java.util.NoSuchElementException noSuchElementException10 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray8);
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(noSuchElementException9);
        org.junit.Assert.assertNotNull(noSuchElementException10);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4588222.192811185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test48");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString(100);
//        double double5 = randomDataImpl0.nextBeta((double) 100L, 0.7714284935985605d);
//        double double8 = randomDataImpl0.nextGaussian(1.9155040003582885E22d, (double) 10L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
//        double double12 = randomDataImpl9.nextBeta(22026.465794806718d, (double) 10L);
//        java.lang.String str14 = randomDataImpl9.nextSecureHexString((int) (byte) 10);
//        double double17 = randomDataImpl9.nextGaussian((double) 100.0f, (double) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double19 = randomDataImpl9.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        try {
//            int int24 = randomDataImpl0.nextHypergeometric(61, 0, 73);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "988ef28c6dd10a207570edf92ecd02f775ccfb353413f811d512abd18a40f5b3e26eda315a224c66c910383e3b228d57551b" + "'", str2.equals("988ef28c6dd10a207570edf92ecd02f775ccfb353413f811d512abd18a40f5b3e26eda315a224c66c910383e3b228d57551b"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9914041443915046d + "'", double5 == 0.9914041443915046d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9994898473034407d + "'", double12 == 0.9994898473034407d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "33abd15719" + "'", str14.equals("33abd15719"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 123.07837261554754d + "'", double17 == 123.07837261554754d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.9926392304571535d) + "'", double19 == (-0.9926392304571535d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5625444281942257d + "'", double20 == 0.5625444281942257d);
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException7);
        java.lang.Object[] objArray9 = mathRuntimeException8.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.util.ConcurrentModificationException concurrentModificationException11 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        java.lang.UnsupportedOperationException unsupportedOperationException12 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(concurrentModificationException11);
        org.junit.Assert.assertNotNull(unsupportedOperationException12);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double3 = randomDataImpl0.nextExponential(0.9243273846599229d);
//        randomDataImpl0.reSeed((long) 24);
//        double double8 = randomDataImpl0.nextUniform((-1.94988362376606d), (double) 79L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0321522036140467d + "'", double3 == 1.0321522036140467d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 57.27988676937452d + "'", double8 == 57.27988676937452d);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        double[] doubleArray3 = new double[] { 0.05727881536571999d, 81L, 0.026608524989875485d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(10.0d);
        double double4 = poissonDistributionImpl1.cumulativeProbability(0.0d, 1.1102230246251565E-16d);
        double double7 = poissonDistributionImpl1.cumulativeProbability((double) 10.0f, 24.73133596697138d);
        try {
            int int9 = poissonDistributionImpl1.inverseCumulativeProbability((-3.0912272726473984d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.539992976248491E-5d + "'", double4 == 4.539992976248491E-5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5420233361466815d + "'", double7 == 0.5420233361466815d);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (byte) 100);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException12);
        double[] doubleArray18 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException12, doubleArray18, "{0}", objArray25);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException35 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, "", objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9969976792911474d, (java.lang.Number) 0.7714284935985605d, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException48);
        java.lang.Object[] objArray50 = mathRuntimeException49.getArguments();
        java.util.ConcurrentModificationException concurrentModificationException51 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException41, localizable42, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray18, "", objArray50);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException61 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray60);
        java.lang.IllegalArgumentException illegalArgumentException62 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException61);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException67 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats65, objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats64, objArray66);
        java.lang.Object[] objArray69 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) noSuchElementException61, "8076fe736d62b848abdbcc7c40dd4373330b1a5402c66f9b9149f1e613205b63edec25a304f7edc42f4330d66f2b053e849e", objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, (org.apache.commons.math.exception.util.Localizable) localizedFormats54, objArray66);
        double[] doubleArray72 = functionEvaluationException71.getArgument();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(noSuchElementException35);
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(concurrentModificationException51);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(noSuchElementException61);
        org.junit.Assert.assertNotNull(illegalArgumentException62);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException67);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), (float) 73);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 73.0f + "'", float2 == 73.0f);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test59");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        java.lang.Object[] objArray1 = null;
//        try {
//            java.util.NoSuchElementException noSuchElementException2 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable0, objArray1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.05727881536571999d, 0.9996886138169563d);
        double double4 = poissonDistributionImpl2.probability(0.9995549157312197d);
        double double5 = poissonDistributionImpl2.getMean();
        try {
            int int7 = poissonDistributionImpl2.inverseCumulativeProbability(2.718281828459045d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05727881536571999d + "'", double5 == 0.05727881536571999d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0E-12d, true);
        java.lang.RuntimeException runtimeException6 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) numberIsTooLargeException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException16 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray15);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray15);
        java.util.NoSuchElementException noSuchElementException18 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, "", objArray15);
        java.util.ConcurrentModificationException concurrentModificationException20 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("5d7fb76d30", objArray15);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(noSuchElementException16);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertNotNull(noSuchElementException18);
        org.junit.Assert.assertNotNull(concurrentModificationException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
    }

//    @Test
//    public void test62() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test62");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double3 = randomDataImpl0.nextExponential(0.9243273846599229d);
//        randomDataImpl0.reSeed((long) 24);
//        randomDataImpl0.reSeedSecure(32L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7536391162562546d + "'", double3 == 2.7536391162562546d);
//    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0E-12d, true);
        java.lang.RuntimeException runtimeException4 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException12);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException23 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException13, "hi!", objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException("", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) numberIsTooLargeException3, (double) 100, "6b1a9589f1", objArray32);
        java.lang.Throwable[] throwableArray37 = functionEvaluationException36.getSuppressed();
        java.lang.Object[] objArray38 = functionEvaluationException36.getArguments();
        org.junit.Assert.assertNotNull(runtimeException4);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(noSuchElementException23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        double double1 = org.apache.commons.math.util.FastMath.abs(29.4139292200598d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.4139292200598d + "'", double1 == 29.4139292200598d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException10);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException10, doubleArray16, "{0}", objArray23);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, "", objArray32);
        java.lang.IllegalStateException illegalStateException35 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray32);
        java.lang.String str36 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(noSuchElementException9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertNotNull(illegalStateException35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "the bandwidth must be large enough to accomodate at least 2 points. There are {0}  data points, and bandwidth must be at least {1}  but it is only {2}" + "'", str36.equals("the bandwidth must be large enough to accomodate at least 2 points. There are {0}  data points, and bandwidth must be at least {1}  but it is only {2}"));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.09962764685497985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09995924757110687d + "'", double1 == 0.09995924757110687d);
    }

//    @Test
//    public void test67() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test67");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextWeibull((double) 1.0f, 0.9995858447725977d);
//        int int7 = randomDataImpl0.nextSecureInt(19, (int) ' ');
//        double double10 = randomDataImpl0.nextCauchy(0.0d, 0.9996787836720634d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09062317002954891d + "'", double4 == 0.09062317002954891d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-3.7705895809969787d) + "'", double10 == (-3.7705895809969787d));
//    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), (long) 43);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException8 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException9);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray22 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException23 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException9, doubleArray15, "{0}", objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0E-12d, true);
        java.lang.RuntimeException runtimeException30 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) numberIsTooLargeException29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException38);
        java.lang.Object[] objArray48 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException49 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray48);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException39, "hi!", objArray48);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException51, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException("", objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) numberIsTooLargeException29, (double) 100, "6b1a9589f1", objArray58);
        java.lang.Object[] objArray63 = functionEvaluationException62.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, "maximal count ({0}) exceeded", objArray63);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(noSuchElementException8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(noSuchElementException23);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(noSuchElementException49);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (byte) 100);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException11 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException12);
        double[] doubleArray18 = new double[] { 1.1102230246251565E-16d, (-1.0f), '#', 0.9995858447725977d };
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException12, doubleArray18, "{0}", objArray25);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException35 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, "", objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9969976792911474d, (java.lang.Number) 0.7714284935985605d, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException48);
        java.lang.Object[] objArray50 = mathRuntimeException49.getArguments();
        java.util.ConcurrentModificationException concurrentModificationException51 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException41, localizable42, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray18, "", objArray50);
        double[] doubleArray54 = functionEvaluationException2.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Object[] objArray57 = new java.lang.Object[] { localizedFormats56 };
        java.util.ConcurrentModificationException concurrentModificationException58 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray57);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, (java.lang.Number) (-1), (java.lang.Number) (short) 10, true);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException64);
        java.lang.Object[] objArray74 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException75 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "c6a799d98d90b3f0e7baae1bdc988561d02927fe644ad7f4ea4dd82e91d4954f6596b250e65177dee2eb2bb5aa8f24eaa893", objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException65, "hi!", objArray74);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats78 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Object[] objArray84 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException85 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray84);
        org.apache.commons.math.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException77, (org.apache.commons.math.exception.util.Localizable) localizedFormats78, objArray84);
        java.lang.Object[] objArray93 = new java.lang.Object[] { 1.0d, 1, 22026.465794806718d, (-1) };
        java.util.NoSuchElementException noSuchElementException94 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray93);
        java.lang.IllegalArgumentException illegalArgumentException95 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray93);
        java.lang.Class<?> wildcardClass96 = objArray93.getClass();
        java.text.ParseException parseException97 = org.apache.commons.math.MathRuntimeException.createParseException(1, (org.apache.commons.math.exception.util.Localizable) localizedFormats78, objArray93);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException98 = new org.apache.commons.math.FunctionEvaluationException(doubleArray54, (org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray93);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(noSuchElementException35);
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(concurrentModificationException51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(concurrentModificationException58);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(noSuchElementException75);
        org.junit.Assert.assertTrue("'" + localizedFormats78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats78.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(noSuchElementException85);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(noSuchElementException94);
        org.junit.Assert.assertNotNull(illegalArgumentException95);
        org.junit.Assert.assertNotNull(wildcardClass96);
        org.junit.Assert.assertNotNull(parseException97);
    }
}

