import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 110 + "'", number8.equals(110));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 49, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1102230246251565E-16d, (double) 0.0f, (double) 578208967);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.cos((-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-3.59585858512137d), (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2355276019309692E11d) + "'", double2 == (-1.2355276019309692E11d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 289104520L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1739668322);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.5663706143591725d), (java.lang.Number) 97.0f, 0, orderDirection3, true);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (97 <= -2.566)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (97 <= -2.566)"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.204943839514398E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 11052.086448219503d + "'", double38 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152699841 + "'", int39 == 152699841);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10670L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.242602359374761d + "'", double1 == 2.242602359374761d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.022316386793011404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 101.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.657009507803836d + "'", double1 == 4.657009507803836d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.FastMath.abs((-447361998));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 447361998 + "'", int1 == 447361998);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 110.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.229687871848033d, (int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.02825964930351743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02825213011419899d + "'", double1 == 0.02825213011419899d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray30 = new double[] { '4', 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 3.948148009134034E13d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray36 = null;
        try {
            double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 289104423 + "'", int33 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 152699841 + "'", int35 == 152699841);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.508367956048816E20d + "'", double1 == 3.508367956048816E20d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray25 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray28 = new double[] { '4', 10L };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 3.948148009134034E13d);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray35 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray38 = new double[] { '4', 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.948148009134034E13d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray45 = new double[] { '4', 10L };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 3.948148009134034E13d);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray47);
        double[] doubleArray53 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray56 = new double[] { '4', 10L };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 3.948148009134034E13d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        double[] doubleArray63 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray66 = new double[] { '4', 10L };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.948148009134034E13d);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray66);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        java.lang.Class<?> wildcardClass72 = doubleArray56.getClass();
        double[] doubleArray79 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray56);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray56);
        double[] doubleArray84 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, 4.605170185988092d);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray84);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException92 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 11013.232874703393d, 867313214);
        java.lang.String str93 = nonMonotonousSequenceException92.toString();
        java.lang.Throwable[] throwableArray94 = nonMonotonousSequenceException92.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection95 = nonMonotonousSequenceException92.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray84, orderDirection95, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.952809179494906d + "'", double21 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 289104423 + "'", int48 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 52.952809179494906d + "'", double71 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)" + "'", str93.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)"));
        org.junit.Assert.assertNotNull(throwableArray94);
        org.junit.Assert.assertTrue("'" + orderDirection95 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection95.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-447361995), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.185039863261519d) + "'", double1 == (-2.185039863261519d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 152699840);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 97.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.2639223226749517d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2670864591432632d + "'", double1 == 0.2670864591432632d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-52537947));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.308243189099001d + "'", double1 == 5.308243189099001d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 99, (-52537947));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.02825213011419899d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02825964930351743d + "'", double1 == 0.02825964930351743d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.0d, 0.20574676135134087d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.502321296703048d + "'", double2 == 1.502321296703048d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.17364817766693033d, (double) 110.0f, 7.860264168920489E13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 289104416);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.89104416E8f + "'", float1 == 2.89104416E8f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.974074004567017E13d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.948148009134034E13d + "'", double2 == 3.948148009134034E13d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 5655L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706194921371466d + "'", double1 == 1.5706194921371466d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray25);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (33,113,499,431,446.742 >= 6,367,980,659,893.604)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.3720246474153055E13d + "'", double26 == 3.3720246474153055E13d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-52537947), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double2 = org.apache.commons.math.util.FastMath.min((-2.566370614359172d), (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.566370614359172d) + "'", double2 == (-2.566370614359172d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, true);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1464264838909353d + "'", double6 == 3.1464264838909353d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 32);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 289104416, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-289104416L) + "'", long2 == (-289104416L));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-52537947));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1543799838), 152699841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection11, false);
        int int14 = nonMonotonousSequenceException13.getIndex();
        int int15 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.String str17 = nonMonotonousSequenceException5.toString();
        java.lang.String str18 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        int int14 = nonMonotonousSequenceException12.getIndex();
        int int15 = nonMonotonousSequenceException12.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int17 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100L + "'", number13.equals(100L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-3) + "'", int14 == (-3));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3) + "'", int15 == (-3));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-3) + "'", int17 == (-3));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.tan(87.71886064272135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2508023334244301d) + "'", double1 == (-0.2508023334244301d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int1 = org.apache.commons.math.util.MathUtils.hash(19.48229885196969d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1338548026) + "'", int1 == (-1338548026));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-278037183), (-1599473663));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-2423676232151907455L), (-1250228635));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.signum(15.253697336417389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 289104513);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 289104533);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-100));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-72925498), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 97L, 99);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.26061319933956d + "'", double2 == 62.26061319933956d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3392087361528309011L, 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3663606780860997635L + "'", long2 == 3663606780860997635L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1543799838), 490);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1543799348) + "'", int2 == (-1543799348));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1543799838), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.exp((-15.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.059023205018258E-7d + "'", double1 == 3.059023205018258E-7d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double[] doubleArray2 = new double[] { '4', 10L };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.948148009134034E13d);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 4.19505952E8d);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 152699841 + "'", int5 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 938696934 + "'", int8 == 938696934);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.signum(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6360918665423811d, 1.035806227917042d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', 289104533);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-787473074880L), 20, 20);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 111L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-943995978), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (-447361995));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1599473663), 0.022316386793011404d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        int[] intArray24 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray25 = new int[] {};
        int[] intArray32 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray41 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray41);
        int[] intArray46 = new int[] {};
        int[] intArray53 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray53);
        int[] intArray56 = null;
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray56);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 867313214 + "'", int44 == 867313214);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, true);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray10 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray13 = new double[] { '4', 10L };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 3.948148009134034E13d);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray20 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray23);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray30 = new double[] { '4', 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 3.948148009134034E13d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray32);
        double[] doubleArray38 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray41 = new double[] { '4', 10L };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 3.948148009134034E13d);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray41);
        double[] doubleArray48 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray51 = new double[] { '4', 10L };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 3.948148009134034E13d);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray51);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray51);
        double[] doubleArray58 = new double[] { '4', 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 3.948148009134034E13d);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray60);
        double[] doubleArray66 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray69 = new double[] { '4', 10L };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 3.948148009134034E13d);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray69);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray66);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray66);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1464264838909353d + "'", double6 == 3.1464264838909353d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 289104423 + "'", int33 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 289104423 + "'", int61 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 11052.086448219503d + "'", double73 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, true);
        double[] doubleArray9 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray12 = new double[] { '4', 10L };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 3.948148009134034E13d);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray12);
        double[] doubleArray19 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray22 = new double[] { '4', 10L };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 3.948148009134034E13d);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray22);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray22);
        double[] doubleArray30 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray33 = new double[] { '4', 10L };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 3.948148009134034E13d);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray33);
        double[] doubleArray40 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray43 = new double[] { '4', 10L };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 3.948148009134034E13d);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray43);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray33);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray51);
        try {
            double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.952809179494906d + "'", double48 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 52.952809179494906d + "'", double50 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 4.19505952E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.sin(363.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9893538601694428d) + "'", double1 == (-0.9893538601694428d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long2 = org.apache.commons.math.util.FastMath.min((-6308058222390167141L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6308058222390167141L) + "'", long2 == (-6308058222390167141L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        int[] intArray24 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray25 = new int[] {};
        int[] intArray32 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray41 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray41);
        int[] intArray46 = new int[] {};
        int[] intArray53 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray53);
        int[] intArray61 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray62 = new int[] {};
        int[] intArray69 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray78 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray78);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray78);
        try {
            int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 867313214 + "'", int44 == 867313214);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 867313214 + "'", int81 == 867313214);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9878096570731362d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.59732431255587d + "'", double1 == 56.59732431255587d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.00000000000001d, (java.lang.Number) 6.283185307179587d, 10, orderDirection3, true);
        java.lang.Throwable throwable7 = null;
        try {
            nonMonotonousSequenceException6.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(83172630476L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9906444414790561d + "'", double1 == 0.9906444414790561d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9377047211159066E-18d + "'", double1 == 1.9377047211159066E-18d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.math.util.FastMath.min(99, (-436893566));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-436893566) + "'", int2 == (-436893566));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(110, 152699841);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-152699731) + "'", int2 == (-152699731));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-578208966));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.7820896E8f + "'", float1 == 5.7820896E8f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection12, false);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number17 = nonMonotonousSequenceException14.getArgument();
        boolean boolean18 = nonMonotonousSequenceException14.getStrict();
        boolean boolean19 = nonMonotonousSequenceException14.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        boolean boolean21 = nonMonotonousSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3) + "'", int7 == (-3));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-3) + "'", int8 == (-3));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100L + "'", number15.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (byte) 0 + "'", number17.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(76.19646713778184d, 3.059023205018258E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 76.19646713778182d + "'", double2 == 76.19646713778182d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-3L), (double) (-1543799838L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1543799348), 2.4709206391501777d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.41078129050290885d, (double) 9.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-3), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-3), (-436893566), 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.5596856728972892d), (double) 101.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-278037196));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7321760.181379754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.19505957E8d + "'", double1 == 4.19505957E8d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52537947L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8595678267228592071L) + "'", long2 == (-8595678267228592071L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3) + "'", int2 == (-3));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 458099520L, (double) 49L, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', (-578208966));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 578208967, 289104523L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 289104444L + "'", long2 == 289104444L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.math.util.FastMath.max((-419505958), 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 419495287L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.19495287E8d + "'", double1 == 4.19495287E8d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963202461013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2334031139943222d + "'", double1 == 1.2334031139943222d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-1599473663));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1599473663L) + "'", long2 == (-1599473663L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 1.1240464525123868E78d);
        double[] doubleArray23 = null;
        try {
            double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int2 = org.apache.commons.math.util.MathUtils.pow(289104544, 111L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.log1p(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9855683087099187d + "'", double1 == 1.9855683087099187d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9893538601694428d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (-8595678267228592071L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-289104416L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7785140872001648d + "'", double2 == 0.7785140872001648d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection12, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.String str16 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 0 + "'", number8.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1285638400));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray28 = new double[] { '4', 10L };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 3.948148009134034E13d);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray35 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray38 = new double[] { '4', 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.948148009134034E13d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray28);
        double[] doubleArray47 = new double[] { '4', 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 3.948148009134034E13d);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray47);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.970291913552122d);
        try {
            double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.952809179494906d + "'", double43 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 32);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 111L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection24, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134298E15d, (java.lang.Number) bigInteger19, (-72925498), orderDirection24, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1599473763L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10670L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 611345.9674045884d + "'", double1 == 611345.9674045884d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.61512051684126d, (java.lang.Number) (-3.5664533737832502d), (-278037183));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 100, (int) '#');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (100 >= 1)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (100 >= 1)"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 32L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6360918665423811d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8044235460283945d + "'", double1 == 0.8044235460283945d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-578208966), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 341642467, (long) (-72925498));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.sinh(76.19646713778182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.175544034661543E32d + "'", double1 == 6.175544034661543E32d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 9.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4051.54190208279d + "'", double1 == 4051.54190208279d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.2355276019309692E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.rint(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-419505958), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-3.949294159611454E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3405.439436073658d) + "'", double1 == (-3405.439436073658d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.math.util.FastMath.round(13.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-278037196));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-419505957), (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.6823473264159639d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7760945954418687d + "'", double1 == 0.7760945954418687d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(419505957, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 419505957 + "'", int2 == 419505957);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 48);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.508367956048816E20d + "'", double1 == 3.508367956048816E20d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.abs(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.89104423E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963233359388d + "'", double1 == 1.5707963233359388d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-100.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3440585709080678E43d) + "'", double1 == (-1.3440585709080678E43d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(20, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 119 + "'", int2 == 119);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.5987800259384346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.18468939937899d + "'", double1 == 1.18468939937899d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        long long2 = org.apache.commons.math.util.FastMath.min(419495287L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.4111587134698587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6671929332759571d + "'", double1 == 0.6671929332759571d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.22095801078935992d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1543799348));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 419505957);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152442d + "'", double1 == 1.5430806348152442d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        long long2 = org.apache.commons.math.util.FastMath.min((-1599473663L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1599473663L) + "'", long2 == (-1599473663L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 101.0f, 15.253697336417389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.253697336417389d + "'", double2 == 15.253697336417389d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-8595678267228592071L), 0.0d, (-0.7581226324091722d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(35, 1739668322);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5430806348152436d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7213014037550114d + "'", double1 == 1.7213014037550114d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 152699840L, 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5269984E8f + "'", float2 == 1.5269984E8f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-3L), 4.668932711709396E-5d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(35L, 289104444L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.015625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998779321710066d + "'", double1 == 0.9998779321710066d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 5558L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.316140782769518d + "'", double1 == 9.316140782769518d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 20);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 263.856815596594d + "'", double1 == 263.856815596594d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        java.lang.Class<?> wildcardClass22 = doubleArray6.getClass();
        double[] doubleArray29 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly increasing (0.998 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.952809179494906d + "'", double21 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.log10(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9867717342662448d + "'", double1 == 1.9867717342662448d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(62.26061319933956d, 0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.571239872456303d) + "'", double2 == (-0.571239872456303d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-152699731), 289104416);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray45);
        double[] doubleArray50 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray53 = new double[] { '4', 10L };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 3.948148009134034E13d);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray53);
        double[] doubleArray60 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray63 = new double[] { '4', 10L };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 3.948148009134034E13d);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray63);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 1.1240464525123868E78d);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 52.952809179494906d + "'", double44 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5430806348152436d, 5.480656284001007d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09876801575277527d + "'", double2 == 0.09876801575277527d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (short) 10, (double) (-5157L), 12.504671216011047d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2180280666000018d) + "'", double1 == (-1.2180280666000018d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707963202461013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.81047734946252d + "'", double1 == 3.81047734946252d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        java.lang.Class<?> wildcardClass23 = doubleArray7.getClass();
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 6.283185307179586d);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray52 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray55 = new double[] { '4', 10L };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 3.948148009134034E13d);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray55);
        double[] doubleArray62 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray65 = new double[] { '4', 10L };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 3.948148009134034E13d);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray55);
        double[] doubleArray74 = new double[] { '4', 10L };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 3.948148009134034E13d);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray74);
        java.lang.Class<?> wildcardClass78 = doubleArray74.getClass();
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.952809179494906d + "'", double22 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.952809179494906d + "'", double25 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 52.952809179494906d + "'", double70 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-436893566), 2.1556540241753093E235d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-436893566));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(20, (-436893566));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.FastMath.log(6.234292007626759E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 87.0257134621614d + "'", double1 == 87.0257134621614d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-5157L), (long) 152699840);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-152704997L) + "'", long2 == (-152704997L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.atanh(48.853573516109066d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int1 = org.apache.commons.math.util.FastMath.abs((-419505957));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 419505957 + "'", int1 == 419505957);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int1 = org.apache.commons.math.util.FastMath.abs(49);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-447361998), (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 111L, (float) 101L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101.0f + "'", float2 == 101.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.229687871848033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.22095801078935992d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray51 = new double[] { '4', 10L };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 3.948148009134034E13d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray53);
        double[] doubleArray59 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray62 = new double[] { '4', 10L };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 3.948148009134034E13d);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray59);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray59);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 289104423 + "'", int54 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 11052.086448219503d + "'", double66 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.952809179494906d + "'", double68 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 52.952809179494906d + "'", double69 == 52.952809179494906d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10670L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10670.0f + "'", float1 == 10670.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 289104533);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 100);
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.015625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015625d + "'", double1 == 0.015625d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9073831389134585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9525666060247223d + "'", double1 == 0.9525666060247223d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-517311488));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-5.782089659999999E8d), 1.5707963278304737d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-436893566));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0000000000000002d, (double) 289104568L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.89104568E8d + "'", double2 == 2.89104568E8d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-3L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(76.19646713778184d, 1.974074004567017E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.97407400456676E13d + "'", double2 == 1.97407400456676E13d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number14 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 3.1464264838909353d + "'", number14.equals(3.1464264838909353d));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.146 >= 39,481,480,091,340.34)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.146 >= 39,481,480,091,340.34)"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.035806227917042d, (double) (-1543799838L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.151348409062848d, 15.253697336417389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1513484090628483d + "'", double2 == 1.1513484090628483d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 289104513);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.17544599794007d + "'", double1 == 20.17544599794007d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.20574676135134087d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8518598887744717E-34d + "'", double1 == 3.8518598887744717E-34d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041914822473389d + "'", double1 == 4.041914822473389d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 48);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 48.0d + "'", double2 == 48.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 447361998);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 111L, 0, 289104523);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1543799838), (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.54379981E9f) + "'", float2 == (-1.54379981E9f));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        int int11 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 0 + "'", number13.equals((byte) 0));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.571239872456303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 289104520L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.89104512E8f + "'", float1 == 2.89104512E8f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double2 = org.apache.commons.math.util.FastMath.min(7.105427357601002E-15d, 0.8561207486756054d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.105427357601002E-15d + "'", double2 == 7.105427357601002E-15d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-99), 447361998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int2 = org.apache.commons.math.util.MathUtils.pow(13, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(13, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130 + "'", int2 == 130);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.473814720414451d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47381472041445105d + "'", double2 == 0.47381472041445105d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(410.32277652693745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3663606780860997635L, (long) (-52537947));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1250228635));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.250228636E9d) + "'", double1 == (-1.250228636E9d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-89.99999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-89.0d) + "'", double1 == (-89.0d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math.util.FastMath.abs((-2.185039863261519d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.185039863261519d + "'", double1 == 2.185039863261519d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 48);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5707963233359388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.log(2.8910452299999994E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.48229885196969d + "'", double1 == 19.48229885196969d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 341642467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-341642467L) + "'", long2 == (-341642467L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5707963202461013d, (double) 1.0f, 5.2983423656d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, true);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = null;
        double[] doubleArray11 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray14 = new double[] { '4', 10L };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 3.948148009134034E13d);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double[] doubleArray21 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray24 = new double[] { '4', 10L };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.948148009134034E13d);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray24);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        java.lang.Class<?> wildcardClass30 = doubleArray14.getClass();
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1464264838909353d + "'", double6 == 3.1464264838909353d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 52.952809179494906d + "'", double29 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection11, false);
        int int14 = nonMonotonousSequenceException13.getIndex();
        int int15 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number17 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 52.952809179494906d + "'", number17.equals(52.952809179494906d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1285638445), (double) (-1599473663L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.285638445E9d) + "'", double2 == (-1.285638445E9d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-3.59585858512137d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10.0f, 1.9855683087099187d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9855683087099187d + "'", double2 == 1.9855683087099187d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.8518598887744717E-34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.72276373846171E-36d + "'", double1 == 6.72276373846171E-36d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', 289104544);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2246467991473532E-16d) + "'", double1 == (-1.2246467991473532E-16d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 32);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger25);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger26, (java.lang.Number) 15.253697336417389d, (-447361995));
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray10 = new double[] { '4', 10L };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 3.948148009134034E13d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray17 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray20 = new double[] { '4', 10L };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 3.948148009134034E13d);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray20);
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray29);
        double[] doubleArray35 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray38 = new double[] { '4', 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.948148009134034E13d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray38);
        double[] doubleArray45 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray48 = new double[] { '4', 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 3.948148009134034E13d);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray48);
        double[] doubleArray55 = new double[] { '4', 10L };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 3.948148009134034E13d);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray57);
        double[] doubleArray63 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray66 = new double[] { '4', 10L };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.948148009134034E13d);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray66);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray63);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray63);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 289104423 + "'", int30 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 289104423 + "'", int58 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11052.086448219503d + "'", double70 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 48.853573516109066d + "'", double72 == 48.853573516109066d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 3.1464264838909353d + "'", double73 == 3.1464264838909353d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(22.27484844063331d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.35946623802073E9d + "'", double1 == 2.35946623802073E9d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1L, (-943995978), 48);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int1 = org.apache.commons.math.util.FastMath.abs(1739668322);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1739668322 + "'", int1 == 1739668322);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 289104416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.81047734946252d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7904404332429841d + "'", double1 == 0.7904404332429841d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.NaN, (-0.22095801078935992d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.5663706143591725d), (java.lang.Number) 1L, 35, orderDirection9, true);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 21, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-447361998));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.61512051684126d + "'", double2 == 4.61512051684126d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        long long1 = org.apache.commons.math.util.MathUtils.sign(867313214L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(130, (-1543799348));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        java.lang.Class<?> wildcardClass50 = doubleArray46.getClass();
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.8561207486756054d);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 'a');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.566370614359172d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3691145670784182d) + "'", double1 == (-1.3691145670784182d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '#', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray51 = new double[] { '4', 10L };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 3.948148009134034E13d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray53);
        double[] doubleArray59 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray62 = new double[] { '4', 10L };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 3.948148009134034E13d);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray59);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray59);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (-14.19646713778183d));
        double[] doubleArray71 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        try {
            double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray71);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 289104423 + "'", int54 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 11052.086448219503d + "'", double66 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 3.1464264838909353d + "'", double74 == 3.1464264838909353d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 152699840);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = null;
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray9);
        int[] intArray16 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray17 = new int[] {};
        int[] intArray24 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray33 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray33);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray33);
        int[] intArray42 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray43 = new int[] {};
        int[] intArray50 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray59 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray59);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray59);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray59);
        int[] intArray70 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray71 = new int[] {};
        int[] intArray78 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray78);
        int[] intArray80 = new int[] {};
        int[] intArray87 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray87);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray87);
        try {
            int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 867313214 + "'", int36 == 867313214);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 867313214 + "'", int62 == 867313214);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 867313214 + "'", int90 == 867313214);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-419505957));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.log(20.17544599794007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0044663203770994d + "'", double1 == 3.0044663203770994d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-72925498));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int[] intArray5 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray6 = new int[] {};
        int[] intArray13 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray22 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray22);
        int[] intArray26 = null;
        try {
            int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 867313214 + "'", int25 == 867313214);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int2 = org.apache.commons.math.util.FastMath.max(13, (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.6329612535670134d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass29 = orderDirection28.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection28, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (33,113,499,431,446.742 >= 6,367,980,659,893.604)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.FastMath.expm1(19.028157807631057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8357939500000003E8d + "'", double1 == 1.8357939500000003E8d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8841859566269614d), (double) 132);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.006698278280432074d) + "'", double2 == (-0.006698278280432074d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.math.util.FastMath.min(938696934, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 289104422L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6564463219169106E10d + "'", double1 == 1.6564463219169106E10d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(76.19646713778182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.175544034661543E32d + "'", double1 == 6.175544034661543E32d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.009999500044161986d, 15.10441284864867d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.62024977965696E-4d + "'", double2 == 6.62024977965696E-4d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-419505957));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 3, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 10670.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 110 + "'", number8.equals(110));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (110 > 52.953)"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1250228635));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-447361998), (-52537947));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.6329612535670134d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7336600367786069d) + "'", double1 == (-0.7336600367786069d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 119, 0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 130, 5157L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 130L + "'", long2 == 130L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-3.59585858512137d), 1.18468939937899d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection10, false);
        int int13 = nonMonotonousSequenceException12.getIndex();
        int int14 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection18, false);
        int int21 = nonMonotonousSequenceException20.getIndex();
        int int22 = nonMonotonousSequenceException20.getIndex();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean25 = nonMonotonousSequenceException12.getStrict();
        boolean boolean26 = nonMonotonousSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.19505957E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 289104520);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 289104520L + "'", long1 == 289104520L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(289104523, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 289104575 + "'", int2 == 289104575);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.2334031139943222d, 5557.690612768985d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        int int11 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str13 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 1.5707963267948966d, 0.35657406485167054d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double[] doubleArray2 = new double[] { '4', 10L };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.948148009134034E13d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(490);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1), (long) 289104520);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-289104520L) + "'", long2 == (-289104520L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int2 = org.apache.commons.math.util.MathUtils.pow(13, 289104534L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1906701049 + "'", int2 == 1906701049);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6227020800L + "'", long1 == 6227020800L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-90L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5430806348152442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1883886210341887d + "'", double1 == 0.1883886210341887d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-419505957));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.316140782769518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 21L, (double) 35L, (double) (-100L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001523125762564d + "'", double1 == 1.0001523125762564d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.47381472041445105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6061093801777693d + "'", double1 == 1.6061093801777693d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.exp((-3405.439436073658d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2423676232151907455L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.4236763E18f + "'", float1 == 2.4236763E18f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        java.lang.Class<?> wildcardClass50 = doubleArray34.getClass();
        double[] doubleArray57 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray34);
        double[] doubleArray61 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.952809179494906d + "'", double49 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1285638400L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(52.00000000000001d, 0.009999500044161986d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7345175425633172d + "'", double2 == 1.7345175425633172d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 289104444L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796323335939d + "'", double1 == 1.570796323335939d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-52537947));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(9.848857801796104d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7175128125630685d) + "'", double2 == (-2.7175128125630685d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.05235987755982989d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.052383831720077566d) + "'", double1 == (-0.052383831720077566d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 4.605170185988092d);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(419505957);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1139433523068367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0463475618296068d + "'", double1 == 2.0463475618296068d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (-447362047));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447362047) + "'", int2 == (-447362047));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 490);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 490.0d + "'", double1 == 490.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(32, (-983791262));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-943995978), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.4399597E8f) + "'", float2 == (-9.4399597E8f));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 419505957);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.19505957E8d + "'", double1 == 4.19505957E8d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.17453292519943295d, number1, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 52.952809179494906d + "'", double50 == 52.952809179494906d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3279842425886166d + "'", double1 == 1.3279842425886166d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int1 = org.apache.commons.math.util.FastMath.round(2.78037184E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 278037184 + "'", int1 == 278037184);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        boolean boolean17 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean19 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100L + "'", number14.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) 0 + "'", number16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int int1 = org.apache.commons.math.util.MathUtils.sign(110);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int1 = org.apache.commons.math.util.MathUtils.sign(152699841);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (-578208966));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(32, (-72925498));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.749056364322948E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.2180280666000018d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        int int15 = nonMonotonousSequenceException13.getIndex();
        int int16 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 100, (int) '#');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number24 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100L + "'", number14.equals(100L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3) + "'", int15 == (-3));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-3) + "'", int16 == (-3));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7904404332429841d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-152699841L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 152699840, 111L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long long1 = org.apache.commons.math.util.FastMath.abs(101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 101L + "'", long1 == 101L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double2 = org.apache.commons.math.util.MathUtils.log(48.853573516109066d, 0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.19207303831325734d) + "'", double2 == (-0.19207303831325734d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7904404332429841d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        float float2 = org.apache.commons.math.util.FastMath.min(99.0f, (float) 289104513);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.0f + "'", float2 == 99.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float2 = org.apache.commons.math.util.MathUtils.round((-0.1f), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long1 = org.apache.commons.math.util.MathUtils.sign(3628800L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1906701049);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8044235460283945d, (double) 289104520L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 32);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 289104533);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger25);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int[] intArray5 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray6 = new int[] {};
        int[] intArray13 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray22 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray22);
        int[] intArray26 = null;
        try {
            double double27 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 867313214 + "'", int25 == 867313214);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5045826.175276818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5045827.0d + "'", double1 == 5045827.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079754752, (-419505958));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 21403.25956484199d, (java.lang.Number) 0.8561207486756054d, (-72925498));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8561207486756054d + "'", number4.equals(0.8561207486756054d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-72925498) + "'", int5 == (-72925498));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        int[] intArray24 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray25 = new int[] {};
        int[] intArray32 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray41 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray41);
        int[] intArray46 = new int[] {};
        int[] intArray53 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray53);
        int[] intArray61 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray62 = new int[] {};
        int[] intArray69 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray78 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray78);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray61);
        int[] intArray83 = new int[] {};
        int[] intArray90 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray83, intArray90);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray90);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 867313214 + "'", int44 == 867313214);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 867313214 + "'", int81 == 867313214);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection13, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection13, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        int int19 = nonMonotonousSequenceException17.getIndex();
        java.lang.Number number20 = nonMonotonousSequenceException17.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.1752011936438014d) + "'", number20.equals((-1.1752011936438014d)));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1285638400), (-447361995));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-838276405) + "'", int2 == (-838276405));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection17, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException19.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection25, false);
        java.lang.Number number28 = nonMonotonousSequenceException27.getPrevious();
        int int29 = nonMonotonousSequenceException27.getIndex();
        int int30 = nonMonotonousSequenceException27.getIndex();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 100, (int) '#');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException35.getDirection();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Number number39 = nonMonotonousSequenceException35.getPrevious();
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100L + "'", number20.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 100L + "'", number28.equals(100L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-3) + "'", int29 == (-3));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-3) + "'", int30 == (-3));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 100 + "'", number39.equals(100));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-3.141592653589793d), 49, 289104513);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1543799838L), (-0.1f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.54379981E9f) + "'", float2 == (-1.54379981E9f));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-52), (-100));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1300 + "'", int2 == 1300);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 5655L, (double) (-90L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5654.999999999999d + "'", double2 == 5654.999999999999d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-100));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 289104533, (-1338548026));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1599473663));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        java.lang.Class<?> wildcardClass19 = intArray0.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray27 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        int[] intArray29 = null;
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray29);
        int[] intArray31 = new int[] {};
        int[] intArray38 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray47 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray57 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray57);
        int[] intArray59 = new int[] {};
        int[] intArray66 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray66);
        int[] intArray74 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray75 = new int[] {};
        int[] intArray82 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray82);
        int[] intArray84 = new int[] {};
        int[] intArray91 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray91);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray91);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray91);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray91);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray91);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray91);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 867313214 + "'", int94 == 867313214);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.871201010907891d + "'", double1 == 3.871201010907891d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(130, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 32624096271648510L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2624096271648512E16d + "'", double2 == 3.2624096271648512E16d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.log(6.3611093629270335E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32.68857360463629d) + "'", double1 == (-32.68857360463629d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(20.17544599794007d, (-89.99999999999999d), 0.9073831389134586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 289104534L, 9.10884815767817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8910453399999994E8d + "'", double2 == 2.8910453399999994E8d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-278037196), 289104422L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 40190891422040356L + "'", long2 == 40190891422040356L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(52, (long) (-838276405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-99));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double2 = org.apache.commons.math.util.MathUtils.round(11052.086448219503d, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11052.086448219503d + "'", double2 == 11052.086448219503d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double[] doubleArray2 = new double[] { '4', 10L };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.948148009134034E13d);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 4.19505952E8d);
        double[] doubleArray10 = new double[] { '4', 10L };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 3.948148009134034E13d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 152699841 + "'", int5 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(289104520, (-99));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1285638400L), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16713299200L + "'", long2 == 16713299200L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int1 = org.apache.commons.math.util.FastMath.abs(289104544);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 289104544 + "'", int1 == 289104544);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10670L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.9980971963589435d, (-99), orderDirection3, false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 21L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 289104534L, (double) 120L, 119);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.6061093801777693d, (-2.566370614359172d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35L, (java.lang.Number) Double.POSITIVE_INFINITY, (-1));
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 35L + "'", number5.equals(35L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 35L + "'", number6.equals(35L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52L, (float) (-278037196));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.78037184E8f) + "'", float2 == (-2.78037184E8f));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1718949962020731d + "'", double1 == 0.1718949962020731d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 11013.232874703393d, 867313214);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 11013.232874703393d + "'", number7.equals(11013.232874703393d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-447362047), 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447362050) + "'", int2 == (-447362050));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(567.2281953229096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        int int11 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertNull(orderDirection13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray8 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray17 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray17);
        java.lang.Class<?> wildcardClass20 = intArray1.getClass();
        try {
            double double21 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.17453292519943295d, number1, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.17453292519943295d + "'", number4.equals(0.17453292519943295d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 10, (long) (-578208966));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 578208976L + "'", long2 == 578208976L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(114.59155902616465d, (-0.19207303831325734d), (double) (-447362047));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        int int15 = nonMonotonousSequenceException13.getIndex();
        int int16 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number18 = nonMonotonousSequenceException13.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException13.toString();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100L + "'", number14.equals(100L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3) + "'", int15 == (-3));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-3) + "'", int16 == (-3));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100L + "'", number18.equals(100L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(263.25696924845715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0715663607404479E114d + "'", double1 == 1.0715663607404479E114d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 1.1240464525123868E78d);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 417116247 + "'", int23 == 417116247);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 11052.086448219503d + "'", double38 == 11052.086448219503d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-983791262), 419505957);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1403297219) + "'", int2 == (-1403297219));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 101L, (-0.6912431464778742d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1285638400), (-1285638400));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray25 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray28 = new double[] { '4', 10L };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 3.948148009134034E13d);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray35 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray38 = new double[] { '4', 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.948148009134034E13d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray45 = new double[] { '4', 10L };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 3.948148009134034E13d);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray47);
        double[] doubleArray53 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray56 = new double[] { '4', 10L };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 3.948148009134034E13d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        double[] doubleArray63 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray66 = new double[] { '4', 10L };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.948148009134034E13d);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray66);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        java.lang.Class<?> wildcardClass72 = doubleArray56.getClass();
        double[] doubleArray79 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray56);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray56);
        double[] doubleArray86 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray89 = new double[] { '4', 10L };
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, 3.948148009134034E13d);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray89);
        double[] doubleArray93 = null;
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray89, doubleArray93);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.952809179494906d + "'", double21 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 289104423 + "'", int48 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 52.952809179494906d + "'", double71 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1285638400), 289104575);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 490, 5558L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3279842425886166d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.0d, 9.10884815767817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.000000000000001d + "'", double2 == 7.000000000000001d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-341642467L), (-838276405), (-838276405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 130L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.065797019100886d + "'", double1 == 5.065797019100886d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(567.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.789036002598174E245d + "'", double1 == 8.789036002598174E245d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-419505958), (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 5157L, 0.24385075226030534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.16508899199422392d) + "'", double2 == (-0.16508899199422392d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.3440585709080678E43d, (double) (-99));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        int[] intArray24 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray25 = new int[] {};
        int[] intArray32 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray41 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        int[] intArray50 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray51 = new int[] {};
        int[] intArray58 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray58);
        int[] intArray60 = new int[] {};
        int[] intArray67 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray67);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray67);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray41);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 867313214 + "'", int44 == 867313214);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 867313214 + "'", int70 == 867313214);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        float float2 = org.apache.commons.math.util.MathUtils.round(5.7820896E8f, 1300);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 6227020800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1839.7554810547122d + "'", double1 == 1839.7554810547122d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray51 = new double[] { '4', 10L };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 3.948148009134034E13d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray53);
        double[] doubleArray59 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray62 = new double[] { '4', 10L };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 3.948148009134034E13d);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray59);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray59);
        double[] doubleArray71 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray74 = new double[] { '4', 10L };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 3.948148009134034E13d);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray74);
        double[] doubleArray81 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray84 = new double[] { '4', 10L };
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, 3.948148009134034E13d);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray84);
        double[] doubleArray91 = new double[] { '4', 10L };
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, 3.948148009134034E13d);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray93);
        int int96 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 289104423 + "'", int54 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 11052.086448219503d + "'", double66 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 289104423 + "'", int94 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 289104423 + "'", int96 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 289104544);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, (float) (-1599473663L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.59947366E9f) + "'", float2 == (-1.59947366E9f));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-99));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 0L, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 49);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1543799348), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1543799251) + "'", int2 == (-1543799251));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-5157L), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2822951781804850639L) + "'", long2 == (-2822951781804850639L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.MathUtils.log((-2.566370614359172d), 97.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.2639223226749517d, (double) 5655L, (double) (-419505957));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.502321296703048d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0684215313427223d + "'", double1 == 0.0684215313427223d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 867313214);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.151348409062848d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9830700822184464d + "'", double1 == 2.9830700822184464d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-517311488));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-983791262));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11.833336070820506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-9.4399597E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1543799838), (long) 490);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-419505957), 0.0d, (double) (-100));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.2639223226749517d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3020270543940027d + "'", double1 == 1.3020270543940027d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-3L), 7.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str14 = nonMonotonousSequenceException9.toString();
        java.lang.Number number15 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100L + "'", number15.equals(100L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1285638400L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1285638400) + "'", int1 == (-1285638400));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection6, false);
        java.lang.Throwable throwable11 = null;
        try {
            nonMonotonousSequenceException10.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(289104423, (-838276405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }
}

