import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, 289104523);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray54 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray57 = new double[] { '4', 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 3.948148009134034E13d);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray57);
        double[] doubleArray64 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray67 = new double[] { '4', 10L };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 3.948148009134034E13d);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray67);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray67);
        double[] doubleArray75 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray78 = new double[] { '4', 10L };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 3.948148009134034E13d);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray78);
        double[] doubleArray85 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray88 = new double[] { '4', 10L };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, 3.948148009134034E13d);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray88);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray78);
        double double95 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 152699841 + "'", int50 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 52.952809179494906d + "'", double93 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 52.952809179494906d + "'", double95 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1285638400), (long) (-99));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-99L) + "'", long2 == (-99L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection23, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection23, false);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean30 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 0 + "'", number9.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-436893566) + "'", int4 == (-436893566));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.831008000716577E22d, 6.3611093629270335E-15d, 1300);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 490);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 16713299200L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 11013.232874703393d, 867313214);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 867,313,213 and 867,313,214 are not strictly increasing (11,013.233 >= -0.881)"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        int int11 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable throwable12 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.FastMath.asin(52.952809179494906d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.math.util.FastMath.min((-278037196), 289104544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-278037196) + "'", int2 == (-278037196));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.4337808304830271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 289104575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', (long) (-943995978));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(8.317263048E10d, 2.89104423E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.317263047999998E10d + "'", double2 == 8.317263047999998E10d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(7.307059979368067E43d, 0.0d, (double) 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 289104533);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-52537947), 2.8910453399999994E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.891045363792605E8d + "'", double2 == 2.891045363792605E8d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.MathUtils.sign(6.72276373846171E-36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 119);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 119L + "'", long1 == 119L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2.78037184E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.78037184E8d + "'", double1 == 2.78037184E8d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 458099520L, 2.185039863261519d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5809951999999994E8d + "'", double2 == 4.5809951999999994E8d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1599473663), (-983791262));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 13.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1139433523068367d + "'", double1 == 1.1139433523068367d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection10, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number17 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90.0f), (java.lang.Number) 2.204943839514398E10d, (-419505958), orderDirection18, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException20.getDirection();
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 3.1464264838909353d + "'", number17.equals(3.1464264838909353d));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.853988047997524d + "'", double1 == 0.853988047997524d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 100, (int) '#');
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(341642467, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341642457 + "'", int2 == 341642457);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(130);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 506.132825342035d + "'", double1 == 506.132825342035d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 341642457);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 341642457L + "'", long1 == 341642457L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-983791262));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.6367087234449005E10d) + "'", double1 == (-5.6367087234449005E10d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 289104533, (-152699731));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 111L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double[] doubleArray1 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, true);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray8 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, true);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1464264838909353d + "'", double6 == 3.1464264838909353d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1513484090628483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.162454318046564d + "'", double1 == 3.162454318046564d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-447362047));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 447362047L + "'", long1 == 447362047L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.1408855402054063E32d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 0, 867313214);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 447361998);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-419505958));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1250228635), (-99), 289104423);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7453292519943298d, (-3.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7453292519943298d + "'", double2 == 1.7453292519943298d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-90L), (-2423676232151907455L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        java.lang.Class<?> wildcardClass19 = intArray0.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray27 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray20);
        int[] intArray30 = new int[] {};
        int[] intArray37 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray37);
        int[] intArray40 = new int[] {};
        int[] intArray47 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray56 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray56);
        java.lang.Class<?> wildcardClass59 = intArray40.getClass();
        int[] intArray60 = new int[] {};
        int[] intArray67 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray60);
        try {
            int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-787473074880L), (double) (-1599473663L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5994736637193604E9d) + "'", double2 == (-1.5994736637193604E9d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = null;
        try {
            double double10 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) 1.7763568394002505E-15d, 578208967);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.String str16 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number20 = nonMonotonousSequenceException13.getPrevious();
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100L + "'", number20.equals(100L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.283185307179586d, 0.1883886210341887d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4137349828356829d + "'", double2 == 1.4137349828356829d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double[] doubleArray2 = new double[] { '4', 10L };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.948148009134034E13d);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray8 = new double[] { '4', 10L };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 3.948148009134034E13d);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 4.19505952E8d);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 289104423 + "'", int5 == 289104423);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 152699841 + "'", int11 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.3720246474153055E13d + "'", double14 == 3.3720246474153055E13d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.FastMath.min((-1285638445), (-943995978));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1285638445) + "'", int2 == (-1285638445));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 447362047L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.918878773292388d + "'", double1 == 19.918878773292388d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.995592469141833E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1285638445), (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        int[] intArray24 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray25 = new int[] {};
        int[] intArray32 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray41 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray41);
        int[] intArray51 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray52 = new int[] {};
        int[] intArray59 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        int[] intArray61 = new int[] {};
        int[] intArray68 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray68);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray68);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray68);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 867313214 + "'", int44 == 867313214);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 867313214 + "'", int71 == 867313214);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 417116247);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 289104534L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.89104534E8d + "'", double2 == 2.89104534E8d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.MathUtils.sign(11.833336070820506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.1883886210341887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-278037183));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.041914822473389d, 67.90664839220477d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        java.lang.Class<?> wildcardClass22 = doubleArray6.getClass();
        double[] doubleArray29 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray29.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.952809179494906d + "'", double21 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, 14L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83L + "'", long2 == 83L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-2.7175128125630685d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.717512812563068d) + "'", double1 == (-2.717512812563068d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-436893566), (-341642467L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 119);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 119L + "'", long1 == 119L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double1 = org.apache.commons.math.util.FastMath.atanh(49.54305402019461d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number14 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException3.getDirection();
        boolean boolean17 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable throwable18 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 3.1464264838909353d + "'", number14.equals(3.1464264838909353d));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9966947341008581d, (-15.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-17.852861187437902d) + "'", double2 == (-17.852861187437902d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        java.lang.Class<?> wildcardClass23 = doubleArray7.getClass();
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 6.283185307179586d);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray50 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray50);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray50);
        double[] doubleArray58 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray61 = new double[] { '4', 10L };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 3.948148009134034E13d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray61);
        double[] doubleArray68 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray71 = new double[] { '4', 10L };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, 3.948148009134034E13d);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray71);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray71);
        double[] doubleArray78 = new double[] { '4', 10L };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 3.948148009134034E13d);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray80);
        double[] doubleArray86 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray89 = new double[] { '4', 10L };
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, 3.948148009134034E13d);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray89);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray86);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.952809179494906d + "'", double22 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.952809179494906d + "'", double25 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.1464264838909353d + "'", double52 == 3.1464264838909353d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 289104423 + "'", int81 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 11052.086448219503d + "'", double93 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-99L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 8.317263048E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.19495287E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.54771002956503d + "'", double1 == 20.54771002956503d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(19.028157807631057d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 608.9010498441938d + "'", double2 == 608.9010498441938d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1079754752);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 119);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.6882538673612966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06437217363486886d + "'", double1 == 0.06437217363486886d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 99.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-52), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5720) + "'", int2 == (-5720));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 289104533);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 289104533L + "'", long1 == 289104533L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1906701049, (double) (-152699731), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 152699840);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5269984E8d + "'", double1 == 1.5269984E8d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-100), (float) (-1599473663));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.59947366E9f) + "'", float2 == (-1.59947366E9f));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1403297219));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1324029657) + "'", int1 == (-1324029657));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1324029657), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.3240297E9f) + "'", float2 == (-1.3240297E9f));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        java.lang.Class<?> wildcardClass50 = doubleArray46.getClass();
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 52.952809179494906d + "'", double51 == 52.952809179494906d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection11, false);
        int int14 = nonMonotonousSequenceException13.getIndex();
        int int15 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Class<?> wildcardClass18 = throwableArray17.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0980937031185544E196d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9073831389134586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4407044293644984d + "'", double1 == 1.4407044293644984d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.math.util.FastMath.min((-578208966), 289104423);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-578208966) + "'", int2 == (-578208966));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.000000000000001d, (-0.5361808918716008d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3522691238126129d + "'", double2 == 0.3522691238126129d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int[] intArray0 = null;
        int[] intArray7 = new int[] { 417116247, 130, 289104520, (-838276405), 5, 0 };
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        long long2 = org.apache.commons.math.util.FastMath.min((-152699841L), 83L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-152699841L) + "'", long2 == (-152699841L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-3.681820098973295E-90d), 4.951760157141521E27d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1338548026), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.285638445E9d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1970067374) + "'", int1 == (-1970067374));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-447362047));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double[] doubleArray51 = new double[] { '4', 10L };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 3.948148009134034E13d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray53);
        double[] doubleArray59 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray62 = new double[] { '4', 10L };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 3.948148009134034E13d);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray59);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray59);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (-14.19646713778183d));
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 289104423 + "'", int54 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 11052.086448219503d + "'", double66 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 12.124884118869863d + "'", double70 == 12.124884118869863d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 289104533);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (-72925498));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) (-447362047), 32);
        java.lang.Class<?> wildcardClass14 = bigInteger6.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-578208966));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.022316386793011404d, (double) (-90.0f), (double) 10670.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 32);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 32);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger29);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) (byte) 0);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger36);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 48);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger39);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.5663706143591725d), (java.lang.Number) 97.0f, 0, orderDirection46, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.970291913552122d, (java.lang.Number) bigInteger40, 419505957, orderDirection46, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray24 = new double[] { '4', 10L };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.948148009134034E13d);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray26);
        double[] doubleArray31 = new double[] { '4', 10L };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 3.948148009134034E13d);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        try {
            double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 289104423 + "'", int27 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 289104423 + "'", int34 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int2 = org.apache.commons.math.util.FastMath.min((-1285638445), (-278037196));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1285638445) + "'", int2 == (-1285638445));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.951760157141521E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8371495816524647E29d + "'", double1 == 2.8371495816524647E29d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(110, 419505957);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.6564463219169106E10d, (-1324029657), 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1599473663));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(130, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 130 + "'", int2 == 130);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.5707963278304737d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (short) 10, 447361998);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5966722476277758E294d + "'", double2 == 1.5966722476277758E294d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6853169696133173d) + "'", double1 == (-0.6853169696133173d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.662459134365786d, (double) 417116247);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.171162481816375E8d + "'", double2 == 4.171162481816375E8d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-517311488));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 3.1464264838909353d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection10, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number17 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 48, (java.lang.Number) 1.6929693744344998d, (-838276405), orderDirection18, true);
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 3.1464264838909353d + "'", number17.equals(3.1464264838909353d));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double2 = org.apache.commons.math.util.FastMath.min(2.6881171418161737E43d, (double) 289104423);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.89104423E8d + "'", double2 == 2.89104423E8d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(419505957, (-943995978));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (-89.99999999999999d), 13, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9645439376170786d) + "'", double1 == (-0.9645439376170786d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 289104533, (long) (-578208966));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1285638400), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.054785091899668265d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05475769062549771d) + "'", double1 == (-0.05475769062549771d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9906444414790561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(289104416, (-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) (-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        float float2 = org.apache.commons.math.util.FastMath.min(2.89104416E8f, (float) 152699840);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5269984E8f + "'", float2 == 1.5269984E8f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(120L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double2 = org.apache.commons.math.util.MathUtils.log((-3.59585858512137d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 32624096271648510L, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        long long1 = org.apache.commons.math.util.FastMath.round((-3.949294159611454E10d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-39492941596L) + "'", long1 == (-39492941596L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-3) + "'", int10 == (-3));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', (-8595678267228592071L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8595678267228592168L + "'", long2 == 8595678267228592168L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.0d), (-278037183));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1324029657), (-578208966));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-745820691) + "'", int2 == (-745820691));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.942254455405101E48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 111.88108103305997d + "'", double1 == 111.88108103305997d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1300);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.170119543449628d + "'", double1 == 7.170119543449628d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-99), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.log10(48.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6812412373755872d + "'", double1 == 1.6812412373755872d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7213014037550114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.62330570510622d + "'", double1 == 98.62330570510622d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2, 341642457);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1543799838L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 289104533);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-983791262));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.math.util.FastMath.max((-52), (-52537947));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double2 = org.apache.commons.math.util.FastMath.max(0.24385075226030534d, 0.3490658503988659d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3490658503988659d + "'", double2 == 0.3490658503988659d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-447361995), (-447361995));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-894723990) + "'", int2 == (-894723990));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray30 = new double[] { '4', 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 3.948148009134034E13d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 289104423 + "'", int33 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 152699841 + "'", int35 == 152699841);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 52.952809179494906d + "'", double36 == 52.952809179494906d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(6.0d, (int) (short) 100, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1543799838));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.543799838E9d) + "'", double1 == (-1.543799838E9d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        java.lang.Class<?> wildcardClass22 = doubleArray6.getClass();
        double[] doubleArray24 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double[] doubleArray29 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray32 = new double[] { '4', 10L };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 3.948148009134034E13d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray32);
        double[] doubleArray39 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray42 = new double[] { '4', 10L };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 3.948148009134034E13d);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray42);
        double[] doubleArray49 = new double[] { '4', 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 3.948148009134034E13d);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray51);
        double[] doubleArray57 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray60 = new double[] { '4', 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 3.948148009134034E13d);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray32);
        double[] doubleArray67 = null;
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.952809179494906d + "'", double21 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 289104423 + "'", int52 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 11052.086448219503d + "'", double64 == 11052.086448219503d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 48.853573516109066d + "'", double65 == 48.853573516109066d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray24 = new double[] { '4', 10L };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.948148009134034E13d);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray26);
        double[] doubleArray32 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray35 = new double[] { '4', 10L };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 3.948148009134034E13d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray35);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray32);
        try {
            double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 289104423 + "'", int27 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 11052.086448219503d + "'", double39 == 11052.086448219503d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.022316386793011404d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 5157L, 0.06437217363486886d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4951371944398488d) + "'", double2 == (-1.4951371944398488d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-838276405), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.38276405E8d) + "'", double2 == (-8.38276405E8d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 52);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 447361998);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, 152699841);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8044235460283945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(92.13617560368711d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.543799838E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-3L), (-1970067374), 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int int2 = org.apache.commons.math.util.FastMath.min(1739668322, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.6929693744344998d, (double) 419495287L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 32, 410.32277652693745d, 0.47381472041445105d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-787473074880L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 32);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger14);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (byte) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 32);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger28);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (byte) 0);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) (byte) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 48);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger38);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger39);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 0);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) (byte) 0);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) (byte) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 289104533);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 100);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double2 = org.apache.commons.math.util.FastMath.min(0.35657406485167054d, (double) (-3L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0d) + "'", double2 == (-3.0d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.285638445E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.3691145670784182d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.4502967847254d + "'", double1 == 98.4502967847254d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5430806348152436d, (java.lang.Number) 289104520L, 1906701049);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 119, 0, 1079754752);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.307059979368067E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.307059979368067E43d + "'", double1 == 7.307059979368067E43d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) (-152699841L), 110);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 16713299200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 289104533);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-447361998), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-447361998L) + "'", long2 == (-447361998L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(289104520, (-894723990));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        long long2 = org.apache.commons.math.util.FastMath.min((-6308058222390167141L), 289104422L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6308058222390167141L) + "'", long2 == (-6308058222390167141L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7904404332429841d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.23516497843811765d) + "'", double1 == (-0.23516497843811765d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-99.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.6608809845051002E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.516147068567531E8d + "'", double1 == 9.516147068567531E8d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 152699840L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.5269984E8f + "'", float1 == 1.5269984E8f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-436893566), (java.lang.Number) (-99), 2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1024.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7321760.181379754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.499508499528222d + "'", double1 == 16.499508499528222d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1338548026), (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.570796254328315d) + "'", double2 == (-1.570796254328315d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-272913405926038848L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-72925498));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.2925498E7d) + "'", double1 == (-7.2925498E7d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int2 = org.apache.commons.math.util.FastMath.min((-447361995), (-419505958));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447361995) + "'", int2 == (-447361995));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 100, (long) 119);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11900L + "'", long2 == 11900L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-3L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3279842425886166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.773429397893732d + "'", double1 == 2.773429397893732d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException15.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection21, false);
        java.lang.Number number24 = nonMonotonousSequenceException23.getPrevious();
        int int25 = nonMonotonousSequenceException23.getIndex();
        int int26 = nonMonotonousSequenceException23.getIndex();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException15.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3) + "'", int7 == (-3));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100L + "'", number16.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 100L + "'", number24.equals(100L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-3) + "'", int25 == (-3));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-3) + "'", int26 == (-3));
        org.junit.Assert.assertNull(orderDirection29);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52537947L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) (-447362047), 32);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 32);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (byte) 0);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (byte) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger28);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger25);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) (byte) 0);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger36);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 32);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger39);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) (byte) 0);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) (byte) 0);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 48);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger49);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger40);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) (byte) 0);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (long) (byte) 0);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, bigInteger57);
        java.math.BigInteger bigInteger59 = null;
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, (long) (byte) 0);
        java.math.BigInteger bigInteger62 = null;
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 0);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, bigInteger64);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, 289104533);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, bigInteger67);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) 289104523);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger67);
        try {
            java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (-100));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 132);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 132L + "'", long1 == 132L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-447361998));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-52), (-278037183));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.4414062014936177E-4d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 289104533);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 100);
        double[] doubleArray19 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 4.605170185988092d);
        double[] doubleArray24 = new double[] { 3.1464264838909353d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection26, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.7760945954418687d, 289104423, orderDirection26, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 100.0d, 289104513, orderDirection26, true);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 120L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 120.0f + "'", float2 == 120.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger13, (java.lang.Number) (-447362047), 32);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 32);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (byte) 0);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) (byte) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger32);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (byte) 0);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) (byte) 0);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger43);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 32);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger46);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, (long) (byte) 0);
        java.math.BigInteger bigInteger51 = null;
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) (byte) 0);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, bigInteger53);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) 48);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger56);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger47);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray30 = new double[] { '4', 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 3.948148009134034E13d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 4.19505952E8d);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 152699841 + "'", int33 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.3113499431394742E13d + "'", double36 == 3.3113499431394742E13d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0950671531879624E27d, (-1250228635));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(341642457, (-447362050));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-447361995));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-4.47361998E8d), 867313214, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double[] doubleArray2 = new double[] { '4', 10L };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 3.948148009134034E13d);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 4.19505952E8d);
        double[] doubleArray11 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray14 = new double[] { '4', 10L };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 3.948148009134034E13d);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 152699841 + "'", int5 == 152699841);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.582885402517583E8d + "'", double18 == 3.582885402517583E8d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 289104416);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 289104533);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 100);
        java.lang.Class<?> wildcardClass13 = bigInteger10.getClass();
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1079754752);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.749056364322948E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 93536.39058849207d + "'", double1 == 93536.39058849207d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1.3240297E9f), 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11014.9336643219d + "'", double2 == 11014.9336643219d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-152704997L), 119, (-1285638400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-289104520L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        float float1 = org.apache.commons.math.util.FastMath.abs(120.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 120.0f + "'", float1 == 120.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-152699841L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-19.537131909490896d) + "'", double1 == (-19.537131909490896d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 16713299200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray24 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray27 = new double[] { '4', 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.948148009134034E13d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray37 = new double[] { '4', 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.948148009134034E13d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray27);
        double[] doubleArray46 = new double[] { '4', 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 3.948148009134034E13d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray54 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray57 = new double[] { '4', 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 3.948148009134034E13d);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray57);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.952809179494906d + "'", double42 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 52.952809179494906d + "'", double50 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-447362047));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 447362047L + "'", long2 == 447362047L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.89104534E8d, 867313214);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.943902420725335E-128d) + "'", double2 == (-9.943902420725335E-128d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1513484090628483d, 1.502321296703048d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (-1543799838));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.00000000000001d, (java.lang.Number) 6.283185307179587d, 10, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.789036002598174E245d, (java.lang.Number) 0.473814720414451d, (-578208966), orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1543799838));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.84532151303802E10d) + "'", double1 == (-8.84532151303802E10d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        java.lang.Class<?> wildcardClass23 = doubleArray7.getClass();
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 6.283185307179586d);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray34);
        double[] doubleArray42 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray45 = new double[] { '4', 10L };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 3.948148009134034E13d);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray52 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray55 = new double[] { '4', 10L };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 3.948148009134034E13d);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray55);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray55);
        double[] doubleArray62 = new double[] { '4', 10L };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 3.948148009134034E13d);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray64);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.952809179494906d + "'", double22 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.952809179494906d + "'", double25 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 47.58648155674512d + "'", double38 == 47.58648155674512d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 289104423 + "'", int65 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 289104423 + "'", int67 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.185039863261519d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8172096612475641d) + "'", double1 == (-0.8172096612475641d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        java.lang.Class<?> wildcardClass23 = doubleArray7.getClass();
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 6.283185307179586d);
        double[] doubleArray28 = null;
        try {
            double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.952809179494906d + "'", double22 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.952809179494906d + "'", double25 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100.0f, (double) 48L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1543799251), 83172630476L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83172630476L + "'", long2 == 83172630476L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707963233359388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8104773643261134d + "'", double1 == 3.8104773643261134d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-278037183));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 289104533);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.952809179494906d, (java.lang.Number) 110, (int) (byte) 100, orderDirection23, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-1.1752011936438014d), 10, orderDirection23, false);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.String str30 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 0 + "'", number9.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray8 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray10 = null;
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray10);
        int[] intArray17 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray18 = new int[] {};
        int[] intArray25 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray25);
        int[] intArray27 = new int[] {};
        int[] intArray34 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray34);
        int[] intArray43 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray44 = new int[] {};
        int[] intArray51 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray60 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray60);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray60);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray60);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 867313214 + "'", int37 == 867313214);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 867313214 + "'", int63 == 867313214);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 289104533);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (-99));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.960486013832335E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 48, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.4137349828356829d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7785140872001648d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        java.lang.Class<?> wildcardClass50 = doubleArray34.getClass();
        double[] doubleArray57 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray34);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.952809179494906d + "'", double49 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 52.952809179494906d + "'", double60 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152699841 + "'", int61 == 152699841);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.3240297E9f), 447361998);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1250228635));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1250228635 + "'", int2 == 1250228635);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        boolean boolean17 = nonMonotonousSequenceException13.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.String str19 = nonMonotonousSequenceException5.toString();
        boolean boolean20 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100L + "'", number14.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) 0 + "'", number16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -4 and -3 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.570796323335939d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double[] doubleArray2 = new double[] { (-983791262), 5.0513867799955375E165d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0513867799955375E165d + "'", double3 == 5.0513867799955375E165d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10670L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.96833852265985d + "'", double1 == 9.96833852265985d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double1 = org.apache.commons.math.util.MathUtils.sign(111.88108103305997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-447361998));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        java.lang.Class<?> wildcardClass19 = intArray0.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray27 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray20);
        int[] intArray30 = new int[] {};
        int[] intArray37 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray37);
        int[] intArray40 = new int[] {};
        int[] intArray47 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray56 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray56);
        int[] intArray64 = new int[] { 289104423, (short) 0, (byte) 10, 289104423, 10 };
        int[] intArray65 = new int[] {};
        int[] intArray72 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray72);
        int[] intArray74 = new int[] {};
        int[] intArray81 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray81);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray81);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray81);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray81);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 867313214 + "'", int84 == 867313214);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5.7820896E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray16);
        java.lang.Class<?> wildcardClass19 = intArray0.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray27 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray36 = new int[] { 'a', 289104423, 52, (byte) 0, (byte) 10, (byte) 1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray36);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.295779513082316d) + "'", double1 == (-57.295779513082316d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1285638400), 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1285638532) + "'", int2 == (-1285638532));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963233359388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2334031156536556d + "'", double1 == 1.2334031156536556d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.17364817766693033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0030307324403760195d + "'", double1 == 0.0030307324403760195d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.303834612632515d + "'", double1 == 2.303834612632515d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 10670L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5655L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long2 = org.apache.commons.math.util.FastMath.max(48L, 3392087361528309011L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3392087361528309011L + "'", long2 == 3392087361528309011L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(417116247, 289104520);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) (-1543799348));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 289104533);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 0);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (byte) 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 32);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger33, (java.lang.Number) (-447362047), 32);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) (byte) 0);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) (byte) 0);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 32);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) (byte) 0);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (long) (byte) 0);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger55);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger52);
        java.math.BigInteger bigInteger58 = null;
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) (byte) 0);
        java.math.BigInteger bigInteger61 = null;
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, (long) (byte) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger63);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 32);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, bigInteger66);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, (long) (byte) 0);
        java.math.BigInteger bigInteger71 = null;
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, (long) (byte) 0);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, bigInteger73);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 48);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, bigInteger76);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger67);
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger79);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        long long2 = org.apache.commons.math.util.FastMath.min(48L, (-39492941596L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-39492941596L) + "'", long2 == (-39492941596L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double[] doubleArray3 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray6 = new double[] { '4', 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 3.948148009134034E13d);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray16 = new double[] { '4', 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 3.948148009134034E13d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray23 = new double[] { '4', 10L };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 3.948148009134034E13d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray25);
        double[] doubleArray31 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray34 = new double[] { '4', 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 3.948148009134034E13d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray44 = new double[] { '4', 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 3.948148009134034E13d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        java.lang.Class<?> wildcardClass50 = doubleArray34.getClass();
        double[] doubleArray57 = new double[] { 0.0f, 0.473814720414451d, 0.9980971963589435d, 2.5328331098188354E-14d, 1.0d, 9.9f };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray34);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 289104423 + "'", int26 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.952809179494906d + "'", double49 == 52.952809179494906d);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 52.952809179494906d + "'", double60 == 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 100L, (-3), orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        int int15 = nonMonotonousSequenceException13.getIndex();
        int int16 = nonMonotonousSequenceException13.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 100, (int) '#');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number24 = nonMonotonousSequenceException21.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100L + "'", number14.equals(100L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3) + "'", int15 == (-3));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-3) + "'", int16 == (-3));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 1 + "'", number24.equals((byte) 1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray7 = new double[] { '4', 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 3.948148009134034E13d);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray14 = new double[] { 3.1464264838909353d, 11013.232874703393d, (byte) 100 };
        double[] doubleArray17 = new double[] { '4', 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 3.948148009134034E13d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray24 = new double[] { '4', 10L };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.948148009134034E13d);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray26);
        double[] doubleArray31 = new double[] { '4', 10L };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 3.948148009134034E13d);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 289104423 + "'", int27 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 289104423 + "'", int34 == 289104423);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 152699841 + "'", int36 == 152699841);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.952809179494906d + "'", double38 == 52.952809179494906d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }
}

