import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = lUDecompositionImpl2.getL();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = lUDecompositionImpl2.getP();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.scalarAdd((double) 100L);
        double[][] doubleArray14 = blockRealMatrix13.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.add(blockRealMatrix13);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 10);
        int int18 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        org.apache.commons.math.exception.Localizable localizable20 = matrixIndexException19.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable21 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable21, objArray26);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable20, objArray26);
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable30, objArray35);
        org.apache.commons.math.optimization.OptimizationException optimizationException37 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { convergenceException36, (byte) 100 };
        java.io.EOFException eOFException40 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException14, (double) (byte) 0, localizable20, objArray39);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable42, objArray47);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException49 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException2, (double) 1L, "maximal number of evaluations ({0}) exceeded", objArray47);
        org.apache.commons.math.exception.Localizable localizable51 = invalidMatrixException2.getLocalizablePattern();
        java.lang.Class<?> wildcardClass52 = localizable51.getClass();
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException55 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        java.lang.Object[] objArray56 = nonSquareMatrixException55.getArguments();
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException(localizable51, objArray56);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(eOFException40);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        double[][] doubleArray10 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = blockRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor11, (int) '4', (int) (byte) -1, (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.getColumnMatrix((int) (byte) 1);
        int int13 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.subtract(blockRealMatrix12);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix20.scalarAdd((double) 100L);
        double[][] doubleArray25 = blockRealMatrix24.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.transpose();
        try {
            blockRealMatrix12.setColumnMatrix((int) (byte) 10, (org.apache.commons.math.linear.RealMatrix) blockRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(6);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.IllegalStateException illegalStateException12 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalStateException12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException12);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        org.apache.commons.math.exception.Localizable localizable19 = matrixIndexException18.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable20 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable20, objArray25);
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable19, objArray25);
        java.lang.Object[] objArray28 = null;
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException29 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable19, objArray28);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException14, localizable19, objArray30);
        java.lang.Object[] objArray40 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("", objArray40);
        java.lang.Object[] objArray46 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException47 = new org.apache.commons.math.linear.MatrixIndexException("", objArray46);
        org.apache.commons.math.exception.Localizable localizable48 = matrixIndexException47.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable49 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable49, objArray54);
        java.lang.NullPointerException nullPointerException56 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable48, objArray54);
        org.apache.commons.math.exception.Localizable localizable58 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable58, objArray63);
        org.apache.commons.math.optimization.OptimizationException optimizationException65 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { convergenceException64, (byte) 100 };
        java.io.EOFException eOFException68 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException42, (double) (byte) 0, localizable48, objArray67);
        org.apache.commons.math.exception.Localizable localizable70 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable70, objArray75);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException77 = new org.apache.commons.math.linear.InvalidMatrixException(localizable48, objArray75);
        java.util.ConcurrentModificationException concurrentModificationException78 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray75);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException79 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable19, objArray75);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(illegalStateException12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(nullPointerException27);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException29);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(nullPointerException41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(nullPointerException56);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(eOFException68);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(concurrentModificationException78);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException79);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix2.scalarMultiply(100.0d);
        try {
            blockRealMatrix2.setEntry((int) (byte) 1, (int) (byte) 100, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (1, 100) in a 35x52 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        double[] doubleArray9 = blockRealMatrix4.getRow((int) (short) 10);
        try {
            blockRealMatrix4.setEntry(100, (int) (byte) 1, (double) 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, 1) in a 35x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        java.lang.String str4 = array2DRowRealMatrix0.toString();
        boolean boolean5 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix6.luDecompose();
        java.lang.Object obj11 = null;
        boolean boolean12 = array2DRowRealMatrix6.equals(obj11);
        int int13 = array2DRowRealMatrix6.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix0.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{}" + "'", str4.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.scalarAdd((double) 100L);
        double[][] doubleArray14 = blockRealMatrix13.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.add(blockRealMatrix13);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix15.transpose();
        try {
            org.apache.commons.math.linear.RealVector realVector18 = blockRealMatrix15.getRowVector(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = invalidMatrixException3.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable10, objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { convergenceException16, (byte) 100 };
        java.io.EOFException eOFException20 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException7, "", objArray19);
        java.util.ConcurrentModificationException concurrentModificationException22 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray19);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable4, objArray19);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable27, objArray32);
        org.apache.commons.math.optimization.OptimizationException optimizationException34 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException33);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException38 = new org.apache.commons.math.linear.MatrixIndexException("", objArray37);
        org.apache.commons.math.exception.Localizable localizable39 = matrixIndexException38.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable40, objArray45);
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable39, objArray45);
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException51 = new org.apache.commons.math.linear.MatrixIndexException("", objArray50);
        org.apache.commons.math.exception.Localizable localizable52 = matrixIndexException51.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable53, objArray58);
        java.lang.IllegalStateException illegalStateException60 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable52, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException33, localizable39, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable4, objArray58);
        java.lang.Throwable throwable65 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException66 = new org.apache.commons.math.optimization.OptimizationException(throwable65);
        try {
            maxEvaluationsExceededException64.addSuppressed(throwable65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(eOFException20);
        org.junit.Assert.assertNotNull(concurrentModificationException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(illegalStateException60);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Object[] objArray5 = null;
        java.lang.IllegalStateException illegalStateException6 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, objArray5);
        double[] doubleArray11 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray13 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray13);
        double[] doubleArray22 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray29 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray36 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray43 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray44 = new double[][] { doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", (java.lang.Object[]) doubleArray44);
        java.lang.ArithmeticException arithmeticException47 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable4, (java.lang.Object[]) doubleArray44);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(illegalStateException6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(arithmeticException47);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException4 = new org.apache.commons.math.linear.MatrixIndexException("", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = matrixIndexException4.getLocalizablePattern();
        double[] doubleArray12 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray19 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray26 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray33 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33 };
        org.apache.commons.math.linear.RealMatrix realMatrix35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable0, localizable5, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException38 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable41 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable41, objArray46);
        org.apache.commons.math.optimization.OptimizationException optimizationException48 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException47);
        java.lang.Object[] objArray50 = new java.lang.Object[] { convergenceException47, (byte) 100 };
        java.io.EOFException eOFException51 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException38, "", objArray50);
        double[] doubleArray59 = new double[] { 100.0d, 0.0d, (-1.0d), (short) 10, 0.0f, 0.0d };
        double[] doubleArray67 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray74 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray81 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray88 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray89 = new double[][] { doubleArray67, doubleArray74, doubleArray81, doubleArray88 };
        org.apache.commons.math.linear.RealMatrix realMatrix90 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray89);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException91 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException38, doubleArray59, "hi!", (java.lang.Object[]) doubleArray89);
        java.util.NoSuchElementException noSuchElementException92 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable5, (java.lang.Object[]) doubleArray89);
        double[][] doubleArray93 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray89);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(eOFException51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(realMatrix90);
        org.junit.Assert.assertNotNull(noSuchElementException92);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        int int5 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        java.lang.String str4 = array2DRowRealMatrix0.toString();
        boolean boolean5 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable10, objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { convergenceException16, (byte) 100 };
        java.io.EOFException eOFException20 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException7, "", objArray19);
        double[] doubleArray28 = new double[] { 100.0d, 0.0d, (-1.0d), (short) 10, 0.0f, 0.0d };
        double[] doubleArray36 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray43 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray50 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray57 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray58 = new double[][] { doubleArray36, doubleArray43, doubleArray50, doubleArray57 };
        org.apache.commons.math.linear.RealMatrix realMatrix59 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException7, doubleArray28, "hi!", (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.linear.BigMatrix bigMatrix61 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray58);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{}" + "'", str4.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(eOFException20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(bigMatrix61);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix4.luDecompose();
        java.lang.Object obj9 = null;
        boolean boolean10 = array2DRowRealMatrix4.equals(obj9);
        java.lang.String str11 = array2DRowRealMatrix4.toString();
        double[][] doubleArray12 = array2DRowRealMatrix4.getData();
        boolean boolean13 = array2DRowRealMatrix0.equals((java.lang.Object) array2DRowRealMatrix4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix14.createMatrix((int) (short) 1, 36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix18.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix18.luDecompose();
        java.lang.Object obj23 = null;
        boolean boolean24 = array2DRowRealMatrix18.equals(obj23);
        java.lang.String str25 = array2DRowRealMatrix18.toString();
        double[][] doubleArray26 = array2DRowRealMatrix18.getData();
        boolean boolean27 = array2DRowRealMatrix14.equals((java.lang.Object) array2DRowRealMatrix18);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix4.multiply(array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{}" + "'", str11.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Array2DRowRealMatrix{}" + "'", str25.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        try {
            double double46 = blockRealMatrix43.getEntry(6, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (6, 36) in a 4x6 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        double[] doubleArray15 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray17 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException10, doubleArray17, "Array2DRowRealMatrix{}", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.Localizable localizable26 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable27, objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable26, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable24, "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, "Array2DRowRealMatrix{}", objArray32);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable38, objArray43);
        org.apache.commons.math.optimization.OptimizationException optimizationException45 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException44);
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException49 = new org.apache.commons.math.linear.MatrixIndexException("", objArray48);
        org.apache.commons.math.exception.Localizable localizable50 = matrixIndexException49.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable51 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable51, objArray56);
        java.lang.NullPointerException nullPointerException58 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable50, objArray56);
        java.lang.Object[] objArray61 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException62 = new org.apache.commons.math.linear.MatrixIndexException("", objArray61);
        org.apache.commons.math.exception.Localizable localizable63 = matrixIndexException62.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable64 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable64, objArray69);
        java.lang.IllegalStateException illegalStateException71 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable63, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, localizable50, objArray69);
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((double) 36, localizable50, objArray73);
        java.lang.Object[] objArray83 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException84 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray83);
        org.apache.commons.math.optimization.OptimizationException optimizationException85 = new org.apache.commons.math.optimization.OptimizationException("", objArray83);
        java.util.NoSuchElementException noSuchElementException86 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray83);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, localizable50, objArray83);
        try {
            blockRealMatrix8.setColumn((int) 'a', doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(nullPointerException58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(illegalStateException71);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(nullPointerException84);
        org.junit.Assert.assertNotNull(noSuchElementException86);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) '#');
        double double7 = blockRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray4);
        org.apache.commons.math.linear.AnyMatrix anyMatrix11 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix10, anyMatrix11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable1, objArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException7);
        java.lang.Object[] objArray10 = new java.lang.Object[] { convergenceException7, (byte) 100 };
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) eOFException11);
        java.lang.String str13 = eOFException11.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.MathRuntimeException$3: " + "'", str13.equals("org.apache.commons.math.MathRuntimeException$3: "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        double[][] doubleArray10 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = blockRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) (byte) 100, 52, 36, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix((int) (short) 1, 36);
        int int48 = array2DRowRealMatrix44.getColumnDimension();
        double double49 = array2DRowRealMatrix44.getTrace();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix43.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = lUDecompositionImpl2.getL();
        double double4 = lUDecompositionImpl2.getDeterminant();
        double double5 = lUDecompositionImpl2.getDeterminant();
        double double6 = lUDecompositionImpl2.getDeterminant();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix43.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix48.getColumnMatrix((int) (byte) 1);
        double double51 = blockRealMatrix50.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.transpose();
        double double53 = blockRealMatrix52.getFrobeniusNorm();
        try {
            blockRealMatrix44.setRowMatrix((int) (byte) 0, blockRealMatrix52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x35 but expected 1x6");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        int int5 = blockRealMatrix4.getColumnDimension();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        double[] doubleArray12 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray14 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException7, doubleArray14, "Array2DRowRealMatrix{}", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable24, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable21, "", objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, "Array2DRowRealMatrix{}", objArray29);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable35, objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException41);
        java.lang.Object[] objArray45 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray45);
        org.apache.commons.math.exception.Localizable localizable47 = matrixIndexException46.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable48 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable48, objArray53);
        java.lang.NullPointerException nullPointerException55 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable47, objArray53);
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException59 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.exception.Localizable localizable60 = matrixIndexException59.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable61 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable61, objArray66);
        java.lang.IllegalStateException illegalStateException68 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable60, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, localizable47, objArray66);
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((double) 36, localizable47, objArray70);
        java.lang.Object[] objArray80 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException81 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray80);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException("", objArray80);
        java.util.NoSuchElementException noSuchElementException83 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray80);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, localizable47, objArray80);
        try {
            blockRealMatrix4.setColumn((int) (short) 0, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(nullPointerException55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(illegalStateException68);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(nullPointerException81);
        org.junit.Assert.assertNotNull(noSuchElementException83);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = invalidMatrixException3.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable10, objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { convergenceException16, (byte) 100 };
        java.io.EOFException eOFException20 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException7, "", objArray19);
        java.util.ConcurrentModificationException concurrentModificationException22 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray19);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable4, objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException(localizable0, objArray19);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(eOFException20);
        org.junit.Assert.assertNotNull(concurrentModificationException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String[][] strArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker10 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) (byte) -1);
        double[] doubleArray16 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray18 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getPoint();
        double[] doubleArray21 = vectorialPointValuePair19.getValue();
        double[] doubleArray22 = vectorialPointValuePair19.getPointRef();
        double[] doubleArray27 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray29 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray29);
        double[] doubleArray31 = vectorialPointValuePair30.getValueRef();
        double[] doubleArray32 = vectorialPointValuePair30.getPoint();
        boolean boolean33 = simpleVectorialValueChecker10.converged((int) (short) 10, vectorialPointValuePair19, vectorialPointValuePair30);
        double[] doubleArray39 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray41 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray41);
        double[] doubleArray43 = vectorialPointValuePair42.getPoint();
        double[] doubleArray48 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray50 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair51 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray50);
        double[] doubleArray52 = vectorialPointValuePair51.getPoint();
        double[] doubleArray53 = vectorialPointValuePair51.getPointRef();
        double[] doubleArray54 = vectorialPointValuePair51.getPointRef();
        boolean boolean55 = simpleVectorialValueChecker10.converged((int) (byte) 10, vectorialPointValuePair42, vectorialPointValuePair51);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker10);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker57 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker57);
        double double59 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 0);
        int int62 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        boolean boolean9 = blockRealMatrix8.isSquare();
        java.io.ObjectInputStream objectInputStream11 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) blockRealMatrix8, "", objectInputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.createMatrix(0, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        int int7 = array2DRowRealMatrix0.getRowDimension();
        int int8 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor9, (int) 'a', 52, 6, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockRealMatrix6.equals(obj7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.getColumnMatrix((int) (byte) 1);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix18.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector23 = blockRealMatrix14.preMultiply(realVector22);
        blockRealMatrix6.setColumnVector(0, realVector23);
        double double25 = blockRealMatrix6.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MathRuntimeException: hi!", objArray1);
        java.lang.Object[] objArray3 = matrixIndexException2.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector12 = blockRealMatrix8.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector13 = blockRealMatrix4.preMultiply(realVector12);
        double[] doubleArray18 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray20 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray20);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        try {
            double[] doubleArray24 = blockRealMatrix4.preMultiply(doubleArray18);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver3 = lUDecompositionImpl2.getSolver();
        double double4 = lUDecompositionImpl2.getDeterminant();
        int[] intArray5 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver6 = lUDecompositionImpl2.getSolver();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = lUDecompositionImpl2.getU();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(decompositionSolver3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(decompositionSolver6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) (byte) 100);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker9 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        int int10 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(vectorialConvergenceChecker9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray27 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray34 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray41 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray42 = new double[][] { doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable8, localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable13, objArray45);
        java.io.IOException iOException47 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException46);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException48 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) iOException47);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(iOException47);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.RealMatrix realMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray5 = blockRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl8 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix2, (double) 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x52 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockRealMatrix6.equals(obj7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix6.subtract(blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray9 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray9);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException2, doubleArray9, "Array2DRowRealMatrix{}", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable19, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable18, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable16, "", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "Array2DRowRealMatrix{}", objArray24);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException29 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray24);
        java.lang.IllegalArgumentException illegalArgumentException30 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MathRuntimeException$3: ", objArray24);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException29);
        org.junit.Assert.assertNotNull(illegalArgumentException30);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.getColumnMatrix((int) (byte) 1);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector13 = blockRealMatrix9.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector14 = blockRealMatrix5.preMultiply(realVector13);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '#');
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix43.copy();
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix44, 4);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray14 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray16 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        double[] doubleArray18 = vectorialPointValuePair17.getPoint();
        double[] doubleArray19 = vectorialPointValuePair17.getPointRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        double double11 = blockRealMatrix10.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix10.multiply(blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix9.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        int int3 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, 10.0d);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker6);
        double double8 = levenbergMarquardtOptimizer0.getRMS();
        int int9 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker10 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(vectorialConvergenceChecker10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.RealMatrix realMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray5 = blockRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.createMatrix(100, 52);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9, (int) (short) -1, 100, (int) 'a', 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 99]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray8 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray10 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray19 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray26 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray33 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray40 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray41 = new double[][] { doubleArray19, doubleArray26, doubleArray33, doubleArray40 };
        org.apache.commons.math.linear.RealMatrix realMatrix42 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", (java.lang.Object[]) doubleArray41);
        java.io.EOFException eOFException44 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray41);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        java.lang.IllegalStateException illegalStateException46 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45, true);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.MathRuntimeException(throwable0, "maximal number of evaluations ({0}) exceeded", (java.lang.Object[]) doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(eOFException44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(illegalStateException46);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) (byte) 1);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray27 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray34 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray41 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray42 = new double[][] { doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable8, localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable13, objArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException46);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException51 = new org.apache.commons.math.optimization.OptimizationException("", objArray50);
        org.apache.commons.math.exception.Localizable localizable52 = optimizationException51.getLocalizablePattern();
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException61 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray60);
        org.apache.commons.math.optimization.OptimizationException optimizationException62 = new org.apache.commons.math.optimization.OptimizationException("", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException47, (double) '#', localizable52, objArray60);
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException68 = new org.apache.commons.math.linear.MatrixIndexException("", objArray67);
        org.apache.commons.math.exception.Localizable localizable69 = matrixIndexException68.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable70 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable70, objArray75);
        java.lang.NullPointerException nullPointerException77 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable69, objArray75);
        java.lang.ArithmeticException arithmeticException78 = org.apache.commons.math.MathRuntimeException.createArithmeticException("maximal number of evaluations ({0}) exceeded", objArray75);
        java.lang.IllegalArgumentException illegalArgumentException79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable52, objArray75);
        double[][] doubleArray83 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 100, 10);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException84 = new org.apache.commons.math.linear.MatrixIndexException("Array2DRowRealMatrix{}", (java.lang.Object[]) doubleArray83);
        java.lang.Object[] objArray85 = matrixIndexException84.getArguments();
        java.lang.NullPointerException nullPointerException86 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable52, objArray85);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(nullPointerException61);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(nullPointerException77);
        org.junit.Assert.assertNotNull(arithmeticException78);
        org.junit.Assert.assertNotNull(illegalArgumentException79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(nullPointerException86);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable3, objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException9);
        java.lang.Object[] objArray12 = new java.lang.Object[] { convergenceException9, (byte) 100 };
        java.io.EOFException eOFException13 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray12);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException14 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray12);
        java.lang.Class<?> wildcardClass15 = objArray12.getClass();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathRuntimeException$7: ", objArray12);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(eOFException13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        java.lang.String str7 = array2DRowRealMatrix0.toString();
        double[][] doubleArray8 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor9, (int) 'a', (-1), (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{}" + "'", str7.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray8 = vectorialPointValuePair7.getPoint();
        double[] doubleArray9 = vectorialPointValuePair7.getPointRef();
        double[] doubleArray10 = vectorialPointValuePair7.getPointRef();
        double[] doubleArray11 = vectorialPointValuePair7.getValueRef();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable17 = matrixIndexException16.getLocalizablePattern();
        java.lang.Object[] objArray18 = null;
        java.lang.IllegalStateException illegalStateException19 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable17, objArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException24 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        maxEvaluationsExceededException21.addSuppressed((java.lang.Throwable) nonSquareMatrixException24);
        java.lang.Object[] objArray26 = maxEvaluationsExceededException21.getArguments();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException27 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable17, objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "Array2DRowRealMatrix{}", objArray26);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(illegalStateException19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException27);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.getColumnMatrix((int) (byte) 1);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.transpose();
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        double[][] doubleArray17 = blockRealMatrix15.getData();
        try {
            blockRealMatrix7.setRowMatrix(6, blockRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x35 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Object[] objArray1 = null;
        java.io.EOFException eOFException2 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.linear.MatrixIndexException: ", objArray1);
        org.junit.Assert.assertNotNull(eOFException2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        levenbergMarquardtOptimizer0.setQRRankingThreshold(Double.NaN);
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray13);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException("", objArray13);
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray19);
        org.apache.commons.math.exception.Localizable localizable21 = matrixIndexException20.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable22 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable22, objArray27);
        java.lang.NullPointerException nullPointerException29 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable21, objArray27);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable31, objArray36);
        org.apache.commons.math.optimization.OptimizationException optimizationException38 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { convergenceException37, (byte) 100 };
        java.io.EOFException eOFException41 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException15, (double) (byte) 0, localizable21, objArray40);
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable43, objArray48);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException50 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException3, (double) 1L, "maximal number of evaluations ({0}) exceeded", objArray48);
        org.apache.commons.math.exception.Localizable localizable52 = invalidMatrixException3.getLocalizablePattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException54 = new org.apache.commons.math.linear.MatrixIndexException(localizable52, objArray53);
        java.lang.Throwable throwable55 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException();
        double[] doubleArray62 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray64 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair65 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray64);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException57, doubleArray64, "Array2DRowRealMatrix{}", objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(doubleArray64);
        java.lang.Throwable throwable71 = null;
        org.apache.commons.math.exception.Localizable localizable73 = null;
        org.apache.commons.math.exception.Localizable localizable74 = null;
        java.lang.Object[] objArray79 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable74, objArray79);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable73, objArray79);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(throwable71, "", objArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException(doubleArray64, "Array2DRowRealMatrix{}", objArray79);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(throwable55, "", objArray79);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException85 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) -1, localizable52, objArray79);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix90 = array2DRowRealMatrix87.createMatrix((int) (short) 1, 36);
        double[][] doubleArray91 = array2DRowRealMatrix87.getDataRef();
        double[][] doubleArray92 = array2DRowRealMatrix87.getData();
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException93 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException94 = new org.apache.commons.math.linear.MatrixIndexException(localizable52, (java.lang.Object[]) doubleArray92);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(nullPointerException29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(eOFException41);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(realMatrix90);
        org.junit.Assert.assertNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        double double5 = blockRealMatrix2.getEntry((int) (byte) 1, (int) (short) 10);
        org.apache.commons.math.linear.RealVector realVector7 = blockRealMatrix2.getColumnVector(0);
        int int8 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.getRowMatrix((int) (byte) 1);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix2.subtract(blockRealMatrix15);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        try {
            blockRealMatrix43.setEntry((int) (byte) 10, 36, (double) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (10, 36) in a 4x6 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        blockRealMatrix2.multiplyEntry((int) (short) 1, (int) (byte) -1, 0.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl9 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver10 = lUDecompositionImpl9.getSolver();
        double double11 = lUDecompositionImpl9.getDeterminant();
        int[] intArray12 = lUDecompositionImpl9.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl15 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix14);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = lUDecompositionImpl15.getL();
        double double17 = lUDecompositionImpl15.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix18 = lUDecompositionImpl15.getU();
        int[] intArray19 = lUDecompositionImpl15.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix20 = blockRealMatrix2.getSubMatrix(intArray12, intArray19);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(decompositionSolver10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        blockRealMatrix2.multiplyEntry((int) (short) 1, (int) (byte) -1, 0.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix2.scalarMultiply((double) 36);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.getColumnMatrix((int) (byte) 1);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix17.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector21 = blockRealMatrix17.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix13.preMultiply(realVector21);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.getColumnMatrix((int) (byte) 1);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix8.subtract(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.transpose();
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        double[][] doubleArray8 = blockRealMatrix6.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(100, 52);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = blockRealMatrix6.preMultiply(realMatrix11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix6.getRowVector(0);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable4, objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { convergenceException10, (byte) 100 };
        java.io.EOFException eOFException14 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray13);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException16 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 10, "maximal number of evaluations ({0}) exceeded", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException16);
        java.lang.String str18 = maxEvaluationsExceededException16.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(eOFException14);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "maximal number of evaluations ({0}) exceeded" + "'", str18.equals("maximal number of evaluations ({0}) exceeded"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray8 = vectorialPointValuePair7.getPoint();
        double[] doubleArray9 = vectorialPointValuePair7.getValue();
        double[] doubleArray10 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray10, false);
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(bigMatrix13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix19.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.add(blockRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = blockRealMatrix10.transpose();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix0.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray6 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray8 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray8);
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", (java.lang.Object[]) doubleArray39);
        java.io.EOFException eOFException42 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray39);
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        java.lang.IllegalStateException illegalStateException44 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(eOFException42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(illegalStateException44);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = invalidMatrixException9.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable16, objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { convergenceException22, (byte) 100 };
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException13, "", objArray25);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray25);
        java.lang.IllegalArgumentException illegalArgumentException29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable10, objArray25);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException44 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = matrixIndexException44.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable46, objArray51);
        java.lang.NullPointerException nullPointerException53 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable45, objArray51);
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray56);
        org.apache.commons.math.exception.Localizable localizable58 = matrixIndexException57.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable59, objArray64);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable58, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, localizable45, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray64);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable10, objArray64);
        boolean boolean71 = array2DRowRealMatrix0.equals((java.lang.Object) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix72.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix72.luDecompose();
        java.lang.Object obj77 = null;
        boolean boolean78 = array2DRowRealMatrix72.equals(obj77);
        int int79 = array2DRowRealMatrix72.getRowDimension();
        double[][] doubleArray80 = array2DRowRealMatrix72.getData();
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix72);
        double[][] doubleArray82 = array2DRowRealMatrix72.getData();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(illegalArgumentException29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(nullPointerException53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) 2147483647);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = blockRealMatrix8.walkInOptimizedOrder(realMatrixPreservingVisitor11, (int) (short) 1, 0, (int) (short) -1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) (byte) -1);
        double[] doubleArray8 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray10 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray12 = vectorialPointValuePair11.getPoint();
        double[] doubleArray13 = vectorialPointValuePair11.getValue();
        double[] doubleArray14 = vectorialPointValuePair11.getPointRef();
        double[] doubleArray19 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray21 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray21);
        double[] doubleArray23 = vectorialPointValuePair22.getValueRef();
        double[] doubleArray24 = vectorialPointValuePair22.getPoint();
        boolean boolean25 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair11, vectorialPointValuePair22);
        double[] doubleArray26 = vectorialPointValuePair11.getPointRef();
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver3 = lUDecompositionImpl2.getSolver();
        double double4 = lUDecompositionImpl2.getDeterminant();
        int[] intArray5 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = lUDecompositionImpl2.getL();
        double double7 = lUDecompositionImpl2.getDeterminant();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(decompositionSolver3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1L), (double) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix((int) (short) 1, 36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix8.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix8.luDecompose();
        java.lang.Object obj13 = null;
        boolean boolean14 = array2DRowRealMatrix8.equals(obj13);
        java.lang.String str15 = array2DRowRealMatrix8.toString();
        double[][] doubleArray16 = array2DRowRealMatrix8.getData();
        boolean boolean17 = array2DRowRealMatrix4.equals((java.lang.Object) array2DRowRealMatrix8);
        double[] doubleArray18 = null;
        double[] doubleArray24 = new double[] { ' ', 0L, 1, (-1), '4' };
        org.apache.commons.math.linear.RealMatrix realMatrix25 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector26 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray24, false);
        boolean boolean30 = array2DRowRealMatrix4.equals((java.lang.Object) vectorialPointValuePair29);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = null;
        try {
            boolean boolean32 = simpleVectorialValueChecker2.converged((int) (byte) 10, vectorialPointValuePair29, vectorialPointValuePair31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Array2DRowRealMatrix{}" + "'", str15.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker3 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) (byte) -1);
        double[] doubleArray9 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray11 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray11);
        double[] doubleArray13 = vectorialPointValuePair12.getPoint();
        double[] doubleArray14 = vectorialPointValuePair12.getValue();
        double[] doubleArray15 = vectorialPointValuePair12.getPointRef();
        double[] doubleArray20 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray22 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray22);
        double[] doubleArray24 = vectorialPointValuePair23.getValueRef();
        double[] doubleArray25 = vectorialPointValuePair23.getPoint();
        boolean boolean26 = simpleVectorialValueChecker3.converged((int) (short) 10, vectorialPointValuePair12, vectorialPointValuePair23);
        double[] doubleArray27 = vectorialPointValuePair12.getPointRef();
        double[] doubleArray28 = vectorialPointValuePair12.getValueRef();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray28);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { convergenceException39, (byte) 100 };
        java.io.EOFException eOFException43 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray42);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray28, "", objArray42);
        org.apache.commons.math.linear.BigMatrix bigMatrix46 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(eOFException43);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
        org.junit.Assert.assertNotNull(bigMatrix46);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        blockRealMatrix2.multiplyEntry((int) (short) 1, (int) (byte) -1, 0.0d);
        try {
            double[] doubleArray8 = blockRealMatrix2.getRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        org.apache.commons.math.exception.Localizable localizable20 = matrixIndexException19.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable21 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable21, objArray26);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable20, objArray26);
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable30, objArray35);
        org.apache.commons.math.optimization.OptimizationException optimizationException37 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { convergenceException36, (byte) 100 };
        java.io.EOFException eOFException40 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException14, (double) (byte) 0, localizable20, objArray39);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable42, objArray47);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException49 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException2, (double) 1L, "maximal number of evaluations ({0}) exceeded", objArray47);
        org.apache.commons.math.exception.Localizable localizable51 = invalidMatrixException2.getLocalizablePattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException56 = new org.apache.commons.math.linear.MatrixIndexException("", objArray55);
        org.apache.commons.math.exception.Localizable localizable57 = matrixIndexException56.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable58 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable58, objArray63);
        java.lang.NullPointerException nullPointerException65 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable57, objArray63);
        double[] doubleArray72 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray79 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray86 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray93 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray94 = new double[][] { doubleArray72, doubleArray79, doubleArray86, doubleArray93 };
        org.apache.commons.math.linear.RealMatrix realMatrix95 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray94);
        java.text.ParseException parseException96 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, localizable57, (java.lang.Object[]) doubleArray94);
        java.util.NoSuchElementException noSuchElementException97 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable51, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.BigMatrix bigMatrix98 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray94);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(nullPointerException28);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(eOFException40);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable57);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(nullPointerException65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(realMatrix95);
        org.junit.Assert.assertNotNull(parseException96);
        org.junit.Assert.assertNotNull(noSuchElementException97);
        org.junit.Assert.assertNotNull(bigMatrix98);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = blockRealMatrix4.getData();
        double[] doubleArray8 = blockRealMatrix4.getRow((int) (short) 1);
        double[] doubleArray14 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray16 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.linear.RealVector realVector18 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray16);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray21);
        org.apache.commons.math.exception.Localizable localizable23 = invalidMatrixException22.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable25 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable25, objArray30);
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { convergenceException31, (byte) 100 };
        java.io.EOFException eOFException35 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray34);
        java.lang.IllegalStateException illegalStateException36 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable23, objArray34);
        java.lang.Object[] objArray39 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException40 = new org.apache.commons.math.linear.MatrixIndexException("", objArray39);
        org.apache.commons.math.exception.Localizable localizable41 = matrixIndexException40.getLocalizablePattern();
        java.lang.Throwable throwable42 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray45);
        org.apache.commons.math.exception.Localizable localizable47 = matrixIndexException46.getLocalizablePattern();
        double[] doubleArray54 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray61 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray68 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray75 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray76 = new double[][] { doubleArray54, doubleArray61, doubleArray68, doubleArray75 };
        org.apache.commons.math.linear.RealMatrix realMatrix77 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable42, localizable47, (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable41, (java.lang.Object[]) doubleArray76);
        java.util.ConcurrentModificationException concurrentModificationException80 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable23, (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException82 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable85 = null;
        java.lang.Object[] objArray90 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable85, objArray90);
        org.apache.commons.math.optimization.OptimizationException optimizationException92 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException91);
        java.lang.Object[] objArray94 = new java.lang.Object[] { convergenceException91, (byte) 100 };
        java.io.EOFException eOFException95 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray94);
        org.apache.commons.math.MathRuntimeException mathRuntimeException96 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException82, "", objArray94);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException97 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, localizable23, objArray94);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix98 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        try {
            blockRealMatrix4.setColumn((int) (short) 0, doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(eOFException35);
        org.junit.Assert.assertNotNull(illegalStateException36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(concurrentModificationException80);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNotNull(eOFException95);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(localizable0, objArray5);
        org.apache.commons.math.optimization.OptimizationException optimizationException7 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) optimizationException7);
        double[] doubleArray11 = new double[] { 10.0d, 100 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 100, 10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException7, doubleArray11, "", (java.lang.Object[]) doubleArray15);
        double[] doubleArray21 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray23 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray23);
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException29 = new org.apache.commons.math.linear.MatrixIndexException("", objArray28);
        org.apache.commons.math.exception.Localizable localizable30 = matrixIndexException29.getLocalizablePattern();
        double[] doubleArray37 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray44 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray51 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray58 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray59 = new double[][] { doubleArray37, doubleArray44, doubleArray51, doubleArray58 };
        org.apache.commons.math.linear.RealMatrix realMatrix60 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(throwable25, localizable30, (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable30, objArray62);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair64 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray23);
        java.lang.Class<?> wildcardClass65 = doubleArray23.getClass();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setMaxIterations((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix1.createMatrix((int) (short) 1, 36);
        double[][] doubleArray5 = array2DRowRealMatrix1.getData();
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MathRuntimeException$7: ", (java.lang.Object[]) doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.getColumnMatrix((int) (byte) 1);
        int int13 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.subtract(blockRealMatrix12);
        try {
            boolean boolean15 = blockRealMatrix4.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(1000, (int) (byte) 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        java.lang.String str4 = array2DRowRealMatrix0.toString();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix19.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.add(blockRealMatrix19);
        org.apache.commons.math.linear.RealVector realVector23 = blockRealMatrix21.getRowVector((int) (byte) 10);
        try {
            array2DRowRealMatrix0.setColumnVector((int) (short) 0, realVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{}" + "'", str4.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.scalarAdd((double) 100L);
        double[][] doubleArray14 = blockRealMatrix13.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.add(blockRealMatrix13);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix15.transpose();
        double[] doubleArray22 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray24 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray24);
        double[] doubleArray26 = vectorialPointValuePair25.getPoint();
        double[] doubleArray27 = vectorialPointValuePair25.getPointRef();
        double[] doubleArray28 = vectorialPointValuePair25.getPointRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        try {
            blockRealMatrix15.setRow((int) (byte) 10, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x4 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray8 = vectorialPointValuePair7.getPoint();
        double[] doubleArray9 = vectorialPointValuePair7.getPointRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix10, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        try {
            array2DRowRealMatrix0.setEntry((int) 'a', 0, 400.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix44.copy();
        org.apache.commons.math.linear.RealVector realVector47 = null;
        try {
            array2DRowRealMatrix44.setColumnVector((int) 'a', realVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.RealMatrix realMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray5 = blockRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.createMatrix(100, 52);
        double[] doubleArray10 = blockRealMatrix2.getColumn(35);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker10 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) (byte) -1);
        double[] doubleArray16 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray18 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getPoint();
        double[] doubleArray21 = vectorialPointValuePair19.getValue();
        double[] doubleArray22 = vectorialPointValuePair19.getPointRef();
        double[] doubleArray27 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray29 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray29);
        double[] doubleArray31 = vectorialPointValuePair30.getValueRef();
        double[] doubleArray32 = vectorialPointValuePair30.getPoint();
        boolean boolean33 = simpleVectorialValueChecker10.converged((int) (short) 10, vectorialPointValuePair19, vectorialPointValuePair30);
        double[] doubleArray39 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray41 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray41);
        double[] doubleArray43 = vectorialPointValuePair42.getPoint();
        double[] doubleArray48 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray50 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair51 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray50);
        double[] doubleArray52 = vectorialPointValuePair51.getPoint();
        double[] doubleArray53 = vectorialPointValuePair51.getPointRef();
        double[] doubleArray54 = vectorialPointValuePair51.getPointRef();
        boolean boolean55 = simpleVectorialValueChecker10.converged((int) (byte) 10, vectorialPointValuePair42, vectorialPointValuePair51);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker10);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker57 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker57);
        double double59 = levenbergMarquardtOptimizer0.getChiSquare();
        int int60 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) '#');
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable4, objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { convergenceException10, (byte) 100 };
        java.io.EOFException eOFException14 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException1, "", objArray13);
        double[] doubleArray22 = new double[] { 100.0d, 0.0d, (-1.0d), (short) 10, 0.0f, 0.0d };
        double[] doubleArray30 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray37 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray44 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray51 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray52 = new double[][] { doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.apache.commons.math.linear.RealMatrix realMatrix53 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException1, doubleArray22, "hi!", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.linear.BigMatrix bigMatrix55 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray52);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        try {
            array2DRowRealMatrix56.multiplyEntry((int) '#', (int) (byte) 0, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (35, 0) in a 4x6 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(eOFException14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(bigMatrix55);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix8.scalarMultiply((double) 2147483647);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix20.scalarAdd((double) 100L);
        double[][] doubleArray25 = blockRealMatrix24.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix15.add(blockRealMatrix24);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = blockRealMatrix15.transpose();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix8.subtract(realMatrix27);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = invalidMatrixException9.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable16, objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { convergenceException22, (byte) 100 };
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException13, "", objArray25);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray25);
        java.lang.IllegalArgumentException illegalArgumentException29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable10, objArray25);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException44 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = matrixIndexException44.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable46, objArray51);
        java.lang.NullPointerException nullPointerException53 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable45, objArray51);
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray56);
        org.apache.commons.math.exception.Localizable localizable58 = matrixIndexException57.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable59, objArray64);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable58, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, localizable45, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray64);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable10, objArray64);
        boolean boolean71 = array2DRowRealMatrix0.equals((java.lang.Object) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix72.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix72.luDecompose();
        java.lang.Object obj77 = null;
        boolean boolean78 = array2DRowRealMatrix72.equals(obj77);
        int int79 = array2DRowRealMatrix72.getRowDimension();
        double[][] doubleArray80 = array2DRowRealMatrix72.getData();
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix72);
        int int82 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(illegalArgumentException29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(nullPointerException53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.getColumnMatrix((int) (byte) 1);
        int int13 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.subtract(blockRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix12.getRowMatrix(4);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        int int7 = array2DRowRealMatrix0.getRowDimension();
        int int8 = array2DRowRealMatrix0.getColumnDimension();
        double double9 = array2DRowRealMatrix0.getFrobeniusNorm();
        int int10 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) ' ');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException4 = new org.apache.commons.math.linear.MatrixIndexException("", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = matrixIndexException4.getLocalizablePattern();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException10 = new org.apache.commons.math.linear.MatrixIndexException("", objArray9);
        org.apache.commons.math.exception.Localizable localizable11 = matrixIndexException10.getLocalizablePattern();
        double[] doubleArray18 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray25 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray32 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray39 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray40 = new double[][] { doubleArray18, doubleArray25, doubleArray32, doubleArray39 };
        org.apache.commons.math.linear.RealMatrix realMatrix41 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable6, localizable11, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException47 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable50, objArray55);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException56);
        java.lang.Object[] objArray59 = new java.lang.Object[] { convergenceException56, (byte) 100 };
        java.io.EOFException eOFException60 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException47, "", objArray59);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException62 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException43, "", objArray59);
        java.util.ConcurrentModificationException concurrentModificationException64 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", objArray59);
        java.io.ObjectInputStream objectInputStream66 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) concurrentModificationException64, "Array2DRowRealMatrix{{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0}}", objectInputStream66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(eOFException60);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException62);
        org.junit.Assert.assertNotNull(concurrentModificationException64);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = blockRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = invalidMatrixException3.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable10, objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { convergenceException16, (byte) 100 };
        java.io.EOFException eOFException20 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException7, "", objArray19);
        java.util.ConcurrentModificationException concurrentModificationException22 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray19);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable4, objArray19);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException26 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable29, objArray34);
        org.apache.commons.math.optimization.OptimizationException optimizationException36 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException35);
        java.lang.Object[] objArray38 = new java.lang.Object[] { convergenceException35, (byte) 100 };
        java.io.EOFException eOFException39 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray38);
        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException26, "", objArray38);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException41 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray38);
        java.util.NoSuchElementException noSuchElementException42 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable4, objArray38);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException43 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MathRuntimeException$3: ", objArray38);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(eOFException20);
        org.junit.Assert.assertNotNull(concurrentModificationException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(eOFException39);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException41);
        org.junit.Assert.assertNotNull(noSuchElementException42);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = invalidMatrixException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable6, objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { convergenceException12, (byte) 100 };
        java.io.EOFException eOFException16 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray15);
        java.lang.IllegalStateException illegalStateException17 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, objArray15);
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        org.apache.commons.math.exception.Localizable localizable22 = matrixIndexException21.getLocalizablePattern();
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException("", objArray26);
        org.apache.commons.math.exception.Localizable localizable28 = matrixIndexException27.getLocalizablePattern();
        double[] doubleArray35 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray42 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray49 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray56 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray57 = new double[][] { doubleArray35, doubleArray42, doubleArray49, doubleArray56 };
        org.apache.commons.math.linear.RealMatrix realMatrix58 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable23, localizable28, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable22, (java.lang.Object[]) doubleArray57);
        java.util.ConcurrentModificationException concurrentModificationException61 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable4, (java.lang.Object[]) doubleArray57);
        java.lang.NullPointerException nullPointerException62 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray57);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(eOFException16);
        org.junit.Assert.assertNotNull(illegalStateException17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(concurrentModificationException61);
        org.junit.Assert.assertNotNull(nullPointerException62);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (byte) 100, (double) (short) 100);
        double[] doubleArray13 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray15 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray15);
        double[] doubleArray17 = vectorialPointValuePair16.getValueRef();
        double[] doubleArray18 = vectorialPointValuePair16.getPoint();
        double[] doubleArray19 = vectorialPointValuePair16.getPoint();
        double[] doubleArray24 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray26 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray26);
        double[] doubleArray28 = vectorialPointValuePair27.getValueRef();
        double[] doubleArray29 = vectorialPointValuePair27.getPoint();
        double[] doubleArray30 = vectorialPointValuePair27.getPoint();
        boolean boolean31 = simpleVectorialValueChecker7.converged((int) 'a', vectorialPointValuePair16, vectorialPointValuePair27);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        java.lang.String str7 = array2DRowRealMatrix0.toString();
        java.lang.String str8 = array2DRowRealMatrix0.toString();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{}" + "'", str7.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{}" + "'", str8.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray15 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray22 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray29 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray36 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray37 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36 };
        org.apache.commons.math.linear.RealMatrix realMatrix38 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, "", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.scalarAdd((double) 100L);
        double[][] doubleArray14 = blockRealMatrix13.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.add(blockRealMatrix13);
        org.apache.commons.math.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 10);
        int int18 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor19, (int) '#', 10, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray27 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray34 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray41 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray42 = new double[][] { doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable8, localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable13, objArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        double[] doubleArray49 = functionEvaluationException48.getArgument();
        double[] doubleArray50 = functionEvaluationException48.getArgument();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable4, objArray10);
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable17 = matrixIndexException16.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable18, objArray23);
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable17, objArray23);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException26 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable4, objArray23);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable31, objArray36);
        org.apache.commons.math.optimization.OptimizationException optimizationException38 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { convergenceException37, (byte) 100 };
        java.io.EOFException eOFException41 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray40);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException42 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray40);
        java.lang.Class<?> wildcardClass43 = objArray40.getClass();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray40);
        java.lang.Throwable[] throwableArray45 = maxIterationsExceededException44.getSuppressed();
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable4, (java.lang.Object[]) throwableArray45);
        java.lang.IllegalArgumentException illegalArgumentException47 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) noSuchElementException46);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(nullPointerException25);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException26);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(eOFException41);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(illegalArgumentException47);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray5 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray7 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair8 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray7);
        double[] doubleArray16 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray23 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray30 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray37 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray38 = new double[][] { doubleArray16, doubleArray23, doubleArray30, doubleArray37 };
        org.apache.commons.math.linear.RealMatrix realMatrix39 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "", (java.lang.Object[]) doubleArray38);
        java.io.EOFException eOFException41 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix44.luDecompose();
        boolean boolean49 = array2DRowRealMatrix44.isSingular();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = array2DRowRealMatrix43.multiply(array2DRowRealMatrix44);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(eOFException41);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray8 = vectorialPointValuePair7.getPoint();
        double[] doubleArray9 = vectorialPointValuePair7.getValue();
        double[] doubleArray10 = vectorialPointValuePair7.getPointRef();
        double[] doubleArray11 = vectorialPointValuePair7.getPointRef();
        double[] doubleArray16 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray18 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getPoint();
        double[] doubleArray21 = vectorialPointValuePair19.getPointRef();
        double[] doubleArray22 = vectorialPointValuePair19.getPointRef();
        double[] doubleArray23 = vectorialPointValuePair19.getValueRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray23, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix1.createMatrix((int) (short) 1, 36);
        double[][] doubleArray5 = array2DRowRealMatrix1.getData();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[]) doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double[] doubleArray8 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray10 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable17 = matrixIndexException16.getLocalizablePattern();
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray45 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray46 = new double[][] { doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.apache.commons.math.linear.RealMatrix realMatrix47 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(throwable12, localizable17, (java.lang.Object[]) doubleArray46);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable17, objArray49);
        java.lang.Object[] objArray58 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException59 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray58);
        org.apache.commons.math.optimization.OptimizationException optimizationException60 = new org.apache.commons.math.optimization.OptimizationException("", objArray58);
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException65 = new org.apache.commons.math.linear.MatrixIndexException("", objArray64);
        org.apache.commons.math.exception.Localizable localizable66 = matrixIndexException65.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        java.lang.NullPointerException nullPointerException74 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable66, objArray72);
        org.apache.commons.math.exception.Localizable localizable76 = null;
        java.lang.Object[] objArray81 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable76, objArray81);
        org.apache.commons.math.optimization.OptimizationException optimizationException83 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException82);
        java.lang.Object[] objArray85 = new java.lang.Object[] { convergenceException82, (byte) 100 };
        java.io.EOFException eOFException86 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray85);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException60, (double) (byte) 0, localizable66, objArray85);
        org.apache.commons.math.exception.Localizable localizable88 = null;
        java.lang.Object[] objArray93 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException(localizable88, objArray93);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException95 = new org.apache.commons.math.linear.InvalidMatrixException(localizable66, objArray93);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable17, objArray93);
        java.lang.ArithmeticException arithmeticException97 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray93);
        java.util.ConcurrentModificationException concurrentModificationException98 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray93);
        java.lang.ArithmeticException arithmeticException99 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.MathRuntimeException$7: ", objArray93);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(nullPointerException59);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(nullPointerException74);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(eOFException86);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(arithmeticException97);
        org.junit.Assert.assertNotNull(concurrentModificationException98);
        org.junit.Assert.assertNotNull(arithmeticException99);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray48 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray50 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair51 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray50);
        double[] doubleArray52 = vectorialPointValuePair51.getPoint();
        double[] doubleArray53 = vectorialPointValuePair51.getValue();
        double[] doubleArray54 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray53, doubleArray54, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix43.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.IllegalStateException illegalStateException12 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalStateException12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(illegalStateException12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.transpose();
        try {
            double[] doubleArray8 = blockRealMatrix4.getRow((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        boolean boolean5 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor6, 6, (int) (short) 0, 2147483647, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix3.transpose();
        double[] doubleArray6 = blockRealMatrix3.getColumn(0);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        double[] doubleArray6 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray8 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray8);
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException1, doubleArray8, "Array2DRowRealMatrix{}", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl16 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException4 = new org.apache.commons.math.linear.MatrixIndexException("", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = matrixIndexException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable6, objArray11);
        java.lang.IllegalStateException illegalStateException13 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable5, objArray11);
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable17, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable16, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable14, "", objArray22);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException26 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) -1, localizable5, objArray22);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable27, objArray32);
        org.apache.commons.math.optimization.OptimizationException optimizationException34 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) optimizationException34);
        java.lang.Throwable[] throwableArray36 = optimizationException34.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(localizable5, (java.lang.Object[]) throwableArray36);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(illegalStateException13);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.IllegalStateException illegalStateException12 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalStateException12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException12);
        java.lang.String str15 = mathRuntimeException14.toString();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(illegalStateException12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.MathRuntimeException: " + "'", str15.equals("org.apache.commons.math.MathRuntimeException: "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        int int8 = blockRealMatrix7.getRowDimension();
        double[] doubleArray14 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray16 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        double[] doubleArray25 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray32 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray39 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray46 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray47 = new double[][] { doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.apache.commons.math.linear.RealMatrix realMatrix48 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, "", (java.lang.Object[]) doubleArray47);
        java.io.EOFException eOFException50 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray47);
        try {
            blockRealMatrix7.setSubMatrix(doubleArray47, 35, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(eOFException50);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10);
        int int8 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int9 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 1);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 36);
        double double14 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1000 + "'", int8 == 1000);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String[] strArray2 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockRealMatrix6.equals(obj7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.getColumnMatrix((int) (byte) 1);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix18.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector23 = blockRealMatrix14.preMultiply(realVector22);
        blockRealMatrix6.setColumnVector(0, realVector23);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix6, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        int int7 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray14 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray16 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        double[] doubleArray25 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray32 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray39 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray46 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray47 = new double[][] { doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.apache.commons.math.linear.RealMatrix realMatrix48 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, "", (java.lang.Object[]) doubleArray47);
        java.io.EOFException eOFException50 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) doubleArray47);
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        java.lang.IllegalStateException illegalStateException52 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, true);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray51, 0, 4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(eOFException50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(illegalStateException52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        double double45 = array2DRowRealMatrix44.getNorm();
        try {
            double[] doubleArray47 = array2DRowRealMatrix44.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 400.0d + "'", double45 == 400.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        int int2 = maxEvaluationsExceededException1.getMaxEvaluations();
        int int3 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException(1000);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray7 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair8 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException0, doubleArray7, "Array2DRowRealMatrix{}", objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        double[] doubleArray13 = functionEvaluationException12.getArgument();
        double[] doubleArray14 = functionEvaluationException12.getArgument();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray27 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray34 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray41 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray42 = new double[][] { doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable8, localizable13, (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable13, objArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException46);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException51 = new org.apache.commons.math.optimization.OptimizationException("", objArray50);
        org.apache.commons.math.exception.Localizable localizable52 = optimizationException51.getLocalizablePattern();
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException61 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray60);
        org.apache.commons.math.optimization.OptimizationException optimizationException62 = new org.apache.commons.math.optimization.OptimizationException("", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException47, (double) '#', localizable52, objArray60);
        java.lang.Object[] objArray71 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException72 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray71);
        org.apache.commons.math.optimization.OptimizationException optimizationException73 = new org.apache.commons.math.optimization.OptimizationException("", objArray71);
        java.lang.UnsupportedOperationException unsupportedOperationException74 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable52, objArray71);
        java.lang.Object[] objArray77 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException78 = new org.apache.commons.math.linear.MatrixIndexException("", objArray77);
        org.apache.commons.math.exception.Localizable localizable79 = matrixIndexException78.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable80 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable80, objArray85);
        java.lang.IllegalStateException illegalStateException87 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable79, objArray85);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalStateException87);
        org.apache.commons.math.MathRuntimeException mathRuntimeException89 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException87);
        unsupportedOperationException74.addSuppressed((java.lang.Throwable) illegalStateException87);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(nullPointerException61);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(nullPointerException72);
        org.junit.Assert.assertNotNull(unsupportedOperationException74);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(localizable79);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(illegalStateException87);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        java.lang.String str4 = array2DRowRealMatrix0.toString();
        boolean boolean5 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor6, (int) ' ', 36, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{}" + "'", str4.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray4 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray6 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        double[] doubleArray8 = vectorialPointValuePair7.getPoint();
        double[] doubleArray9 = vectorialPointValuePair7.getValue();
        double[] doubleArray10 = vectorialPointValuePair7.getPointRef();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        double[] doubleArray16 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray18 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException11, doubleArray18, "Array2DRowRealMatrix{}", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray18, false);
        double[] doubleArray27 = vectorialPointValuePair26.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.scalarAdd((double) 100L);
        double[][] doubleArray14 = blockRealMatrix13.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.add(blockRealMatrix13);
        try {
            double[] doubleArray17 = blockRealMatrix15.getColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.getRowMatrix((int) (byte) 1);
        java.lang.Object obj14 = null;
        boolean boolean15 = blockRealMatrix13.equals(obj14);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix19.getColumnMatrix((int) (byte) 1);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix25.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix25.getColumnVector((int) '#');
        org.apache.commons.math.linear.RealVector realVector30 = blockRealMatrix21.preMultiply(realVector29);
        blockRealMatrix13.setColumnVector(0, realVector30);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix6, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        double double38 = blockRealMatrix35.getEntry((int) (byte) 1, (int) (short) 10);
        org.apache.commons.math.linear.RealVector realVector40 = blockRealMatrix35.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector41 = blockRealMatrix13.operate(realVector40);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        try {
            blockRealMatrix4.setEntry(100, (-1), (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, -1) in a 35x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException5 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable6 = matrixIndexException5.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable7, objArray12);
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable6, objArray12);
        java.lang.Object[] objArray15 = null;
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable6, objArray15);
        java.lang.Object[] objArray18 = null;
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray18);
        java.lang.RuntimeException runtimeException20 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) arrayIndexOutOfBoundsException19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) runtimeException20);
        java.io.IOException iOException22 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException20);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray25);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray36);
        org.apache.commons.math.optimization.OptimizationException optimizationException38 = new org.apache.commons.math.optimization.OptimizationException("", objArray36);
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException43 = new org.apache.commons.math.linear.MatrixIndexException("", objArray42);
        org.apache.commons.math.exception.Localizable localizable44 = matrixIndexException43.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable45 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable45, objArray50);
        java.lang.NullPointerException nullPointerException52 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable44, objArray50);
        org.apache.commons.math.exception.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable54, objArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException61 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { convergenceException60, (byte) 100 };
        java.io.EOFException eOFException64 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray63);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException38, (double) (byte) 0, localizable44, objArray63);
        org.apache.commons.math.exception.Localizable localizable66 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable66, objArray71);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException73 = new org.apache.commons.math.linear.InvalidMatrixException(localizable44, objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException26, (double) 1L, "maximal number of evaluations ({0}) exceeded", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) runtimeException20, "Array2DRowRealMatrix{{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0},{0.0,100.0,-1.0,97.0,10.0,-1.0}}", objArray71);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException76 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, objArray71);
        org.apache.commons.math.optimization.OptimizationException optimizationException77 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.linear.MatrixIndexException: ", objArray71);
        java.util.ConcurrentModificationException concurrentModificationException78 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.linear.MatrixIndexException: ", objArray71);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException19);
        org.junit.Assert.assertNotNull(runtimeException20);
        org.junit.Assert.assertNotNull(iOException22);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(nullPointerException37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(nullPointerException52);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(eOFException64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(concurrentModificationException78);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException4 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        maxEvaluationsExceededException1.addSuppressed((java.lang.Throwable) nonSquareMatrixException4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) nonSquareMatrixException4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = invalidMatrixException9.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable16, objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { convergenceException22, (byte) 100 };
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException13, "", objArray25);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray25);
        java.lang.IllegalArgumentException illegalArgumentException29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable10, objArray25);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException44 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = matrixIndexException44.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable46, objArray51);
        java.lang.NullPointerException nullPointerException53 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable45, objArray51);
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray56);
        org.apache.commons.math.exception.Localizable localizable58 = matrixIndexException57.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable59, objArray64);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable58, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, localizable45, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray64);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable10, objArray64);
        boolean boolean71 = array2DRowRealMatrix0.equals((java.lang.Object) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix72.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix72.luDecompose();
        java.lang.Object obj77 = null;
        boolean boolean78 = array2DRowRealMatrix72.equals(obj77);
        int int79 = array2DRowRealMatrix72.getRowDimension();
        double[][] doubleArray80 = array2DRowRealMatrix72.getData();
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix72);
        try {
            org.apache.commons.math.linear.RealVector realVector83 = array2DRowRealMatrix72.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(illegalArgumentException29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(nullPointerException53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10);
        int int8 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int9 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double10 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1000 + "'", int8 == 1000);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray7 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair8 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException0, doubleArray7, "Array2DRowRealMatrix{}", objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix14.walkInColumnOrder(realMatrixChangingVisitor15, 0, (int) (short) 0, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray1);
        org.apache.commons.math.exception.Localizable localizable3 = invalidMatrixException2.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable9, objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { convergenceException15, (byte) 100 };
        java.io.EOFException eOFException19 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException6, "", objArray18);
        java.util.ConcurrentModificationException concurrentModificationException21 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray18);
        java.lang.IllegalArgumentException illegalArgumentException22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable3, objArray18);
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(1, 100);
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable3, (java.lang.Object[]) doubleArray25);
        double[] doubleArray32 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray34 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray34);
        double[] doubleArray36 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray36, false);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray32);
        java.lang.Throwable[] throwableArray40 = functionEvaluationException39.getSuppressed();
        double[] doubleArray41 = functionEvaluationException39.getArgument();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (byte) 1, 1.0d, (-1L), ' ', (short) -1 };
        java.lang.NullPointerException nullPointerException51 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", objArray50);
        org.apache.commons.math.optimization.OptimizationException optimizationException52 = new org.apache.commons.math.optimization.OptimizationException("", objArray50);
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray56);
        org.apache.commons.math.exception.Localizable localizable58 = matrixIndexException57.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable59, objArray64);
        java.lang.NullPointerException nullPointerException66 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable58, objArray64);
        org.apache.commons.math.exception.Localizable localizable68 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable68, objArray73);
        org.apache.commons.math.optimization.OptimizationException optimizationException75 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException74);
        java.lang.Object[] objArray77 = new java.lang.Object[] { convergenceException74, (byte) 100 };
        java.io.EOFException eOFException78 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException52, (double) (byte) 0, localizable58, objArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) eOFException26, "", objArray77);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(eOFException19);
        org.junit.Assert.assertNotNull(concurrentModificationException21);
        org.junit.Assert.assertNotNull(illegalArgumentException22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(nullPointerException51);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(nullPointerException66);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(eOFException78);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalStateException illegalStateException2 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.MathRuntimeException: hi!", objArray1);
        org.junit.Assert.assertNotNull(illegalStateException2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setQRRankingThreshold(0.0d);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 1L);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) (byte) 100);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker9 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(vectorialConvergenceChecker9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.RealMatrix realMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray5 = blockRealMatrix2.getColumn(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.createMatrix(100, 52);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl11 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix10);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = lUDecompositionImpl11.getL();
        double double13 = lUDecompositionImpl11.getDeterminant();
        int[] intArray14 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl17 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = lUDecompositionImpl17.getL();
        double double19 = lUDecompositionImpl17.getDeterminant();
        int[] intArray20 = lUDecompositionImpl17.getPivot();
        int[] intArray21 = lUDecompositionImpl17.getPivot();
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable24, objArray29);
        org.apache.commons.math.optimization.OptimizationException optimizationException31 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) optimizationException31);
        double[] doubleArray35 = new double[] { 10.0d, 100 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 100, 10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException31, doubleArray35, "", (java.lang.Object[]) doubleArray39);
        java.text.ParseException parseException41 = org.apache.commons.math.MathRuntimeException.createParseException(36, "org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[]) doubleArray39);
        blockRealMatrix2.copySubMatrix(intArray14, intArray21, doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(parseException41);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.getColumnMatrix((int) (byte) 1);
        int int13 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.subtract(blockRealMatrix12);
        blockRealMatrix4.setEntry((int) (short) 10, (int) (byte) 10, (double) (byte) 100);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix0.luDecompose();
        java.lang.Object obj5 = null;
        boolean boolean6 = array2DRowRealMatrix0.equals(obj5);
        int int7 = array2DRowRealMatrix0.getRowDimension();
        int int8 = array2DRowRealMatrix0.getColumnDimension();
        try {
            array2DRowRealMatrix0.multiplyEntry(2147483647, (int) 'a', (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) (byte) -1);
        double[] doubleArray12 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray14 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray14);
        double[] doubleArray16 = vectorialPointValuePair15.getPoint();
        double[] doubleArray17 = vectorialPointValuePair15.getValue();
        double[] doubleArray18 = vectorialPointValuePair15.getPointRef();
        double[] doubleArray23 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray25 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray25);
        double[] doubleArray27 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray28 = vectorialPointValuePair26.getPoint();
        boolean boolean29 = simpleVectorialValueChecker6.converged((int) (short) 10, vectorialPointValuePair15, vectorialPointValuePair26);
        double[] doubleArray35 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray37 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray37);
        double[] doubleArray39 = vectorialPointValuePair38.getPoint();
        double[] doubleArray44 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray46 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray46);
        double[] doubleArray48 = vectorialPointValuePair47.getPoint();
        double[] doubleArray49 = vectorialPointValuePair47.getPointRef();
        double[] doubleArray50 = vectorialPointValuePair47.getPointRef();
        boolean boolean51 = simpleVectorialValueChecker6.converged((int) (byte) 10, vectorialPointValuePair38, vectorialPointValuePair47);
        double[] doubleArray56 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray58 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair59 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray56, doubleArray58);
        double[] doubleArray60 = vectorialPointValuePair59.getPoint();
        double[] doubleArray61 = vectorialPointValuePair59.getValue();
        double[] doubleArray62 = vectorialPointValuePair59.getPointRef();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException();
        double[] doubleArray68 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray70 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair71 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray68, doubleArray70);
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException63, doubleArray70, "Array2DRowRealMatrix{}", objArray73);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException(doubleArray70);
        org.apache.commons.math.linear.RealMatrix realMatrix76 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray70);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray70, false);
        boolean boolean79 = simpleVectorialValueChecker2.converged((int) (short) 1, vectorialPointValuePair38, vectorialPointValuePair78);
        double[] doubleArray84 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray86 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair87 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray84, doubleArray86);
        double[] doubleArray88 = vectorialPointValuePair87.getPoint();
        double[] doubleArray89 = vectorialPointValuePair87.getValue();
        double[] doubleArray90 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair92 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray89, doubleArray90, false);
        try {
            boolean boolean93 = simpleVectorialValueChecker0.converged(1000, vectorialPointValuePair38, vectorialPointValuePair92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix43.copy();
        double[] doubleArray46 = blockRealMatrix43.getColumn(0);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getRowMatrix((int) (byte) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.scalarAdd((double) 100L);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        double double11 = blockRealMatrix10.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double17 = blockRealMatrix10.walkInOptimizedOrder(realMatrixPreservingVisitor12, 1, (int) (short) 0, 36, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = invalidMatrixException9.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable16, objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { convergenceException22, (byte) 100 };
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException13, "", objArray25);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray25);
        java.lang.IllegalArgumentException illegalArgumentException29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable10, objArray25);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable33, objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException39);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException44 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = matrixIndexException44.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable46, objArray51);
        java.lang.NullPointerException nullPointerException53 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable45, objArray51);
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray56);
        org.apache.commons.math.exception.Localizable localizable58 = matrixIndexException57.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable59, objArray64);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable58, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, localizable45, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "maximal number of evaluations ({0}) exceeded", objArray64);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable10, objArray64);
        boolean boolean71 = array2DRowRealMatrix0.equals((java.lang.Object) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix72.createMatrix((int) (short) 1, 36);
        array2DRowRealMatrix72.luDecompose();
        java.lang.Object obj77 = null;
        boolean boolean78 = array2DRowRealMatrix72.equals(obj77);
        int int79 = array2DRowRealMatrix72.getRowDimension();
        double[][] doubleArray80 = array2DRowRealMatrix72.getData();
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix72);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor82 = null;
        try {
            double double87 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor82, (int) (short) 10, (int) (byte) -1, (int) (short) 10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(illegalArgumentException29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(nullPointerException53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable4, objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { convergenceException10, (byte) 100 };
        java.io.EOFException eOFException14 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException1, "", objArray13);
        double[] doubleArray22 = new double[] { 100.0d, 0.0d, (-1.0d), (short) 10, 0.0f, 0.0d };
        double[] doubleArray30 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray37 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray44 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray51 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray52 = new double[][] { doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.apache.commons.math.linear.RealMatrix realMatrix53 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException1, doubleArray22, "hi!", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(eOFException14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxEvaluations(52);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (short) 100);
        double double5 = blockRealMatrix2.getEntry((int) (byte) 1, (int) (short) 10);
        org.apache.commons.math.linear.RealVector realVector7 = blockRealMatrix2.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.getColumnMatrix((int) '#');
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (int) (short) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (short) 1, 36);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0);
        double[][] doubleArray6 = array2DRowRealMatrix0.getData();
        double[] doubleArray11 = new double[] { (-1.0d), (-1.0d), 0.0f, (byte) 1 };
        double[] doubleArray13 = new double[] { 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray11);
        try {
            double[] doubleArray16 = array2DRowRealMatrix0.preMultiply(doubleArray11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray17 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray24 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray31 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray38 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray39 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable5, localizable10, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix43.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor45 = null;
        try {
            double double46 = blockRealMatrix43.walkInOptimizedOrder(realMatrixPreservingVisitor45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException5 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable6 = matrixIndexException5.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable7, objArray12);
        java.lang.NullPointerException nullPointerException14 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable6, objArray12);
        double[] doubleArray21 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray28 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray35 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[] doubleArray42 = new double[] { 0.0f, 100.0f, (short) -1, 'a', 10.0f, (short) -1 };
        double[][] doubleArray43 = new double[][] { doubleArray21, doubleArray28, doubleArray35, doubleArray42 };
        org.apache.commons.math.linear.RealMatrix realMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        java.text.ParseException parseException45 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) -1, localizable6, (java.lang.Object[]) doubleArray43);
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 1, 100);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException(6, localizable6, (java.lang.Object[]) doubleArray48);
        double[] doubleArray58 = new double[] { ' ', (short) 0, (-1), (short) 10, 100.0d, (short) 100 };
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException62 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable65, objArray70);
        org.apache.commons.math.optimization.OptimizationException optimizationException72 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException71);
        java.lang.Object[] objArray74 = new java.lang.Object[] { convergenceException71, (byte) 100 };
        java.io.EOFException eOFException75 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray74);
        org.apache.commons.math.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException62, "", objArray74);
        java.util.ConcurrentModificationException concurrentModificationException77 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException: hi!", objArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58, "org.apache.commons.math.MathRuntimeException: hi!", objArray74);
        java.text.ParseException parseException79 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray74);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException80 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable6, objArray74);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(nullPointerException14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(parseException45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(eOFException75);
        org.junit.Assert.assertNotNull(concurrentModificationException77);
        org.junit.Assert.assertNotNull(parseException79);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException80);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable1, objArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException7);
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable13 = matrixIndexException12.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable14, objArray19);
        java.lang.NullPointerException nullPointerException21 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable13, objArray19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException("", objArray24);
        org.apache.commons.math.exception.Localizable localizable26 = matrixIndexException25.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable27, objArray32);
        java.lang.IllegalStateException illegalStateException34 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable26, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable13, objArray32);
        java.lang.Throwable[] throwableArray36 = convergenceException7.getSuppressed();
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.MathRuntimeException$7: ", (java.lang.Object[]) throwableArray36);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(nullPointerException21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(illegalStateException34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException3 = new org.apache.commons.math.linear.MatrixIndexException("", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = matrixIndexException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable4, objArray10);
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable17 = matrixIndexException16.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), 1, 'a', 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable18, objArray23);
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable17, objArray23);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException26 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable4, objArray23);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(1, 100);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException30 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable4, (java.lang.Object[]) doubleArray29);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(nullPointerException25);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException30);
    }
}

