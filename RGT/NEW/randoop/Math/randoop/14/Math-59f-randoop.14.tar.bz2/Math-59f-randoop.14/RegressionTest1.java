import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 35);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.power10(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField7.getOne();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField7.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.multiply((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.subtract(dfp28);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        int int7 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField5.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1624473515096265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39709459624648213d + "'", double1 == 0.39709459624648213d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double1 = org.apache.commons.math.util.FastMath.cos(18.949874371066198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9949723229224731d + "'", double1 == 0.9949723229224731d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.floor();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.divide(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp19.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.floor();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.divide(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.sqrt();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp31.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp13.subtract(dfp47);
        org.apache.commons.math.dfp.Dfp dfp52 = new org.apache.commons.math.dfp.Dfp(dfp51);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.0d, (java.lang.Number) 8L, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException18);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.getOne();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField51.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.getPi();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp56.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K(32760);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp49.remainder(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray75 = dfpField74.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField77.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField83 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField83.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp85.floor();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp81.divide(dfp85);
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField74.newDfp(dfp87);
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField74.getLn5();
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField74.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp93 = dfp91.power10K(0);
        boolean boolean94 = dfp70.lessThan(dfp91);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp91.multiply(52);
        java.lang.String str97 = dfp91.toString();
        org.apache.commons.math.dfp.Dfp dfp98 = dfp62.divide(dfp91);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpArray75);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "100." + "'", str97.equals("100."));
        org.junit.Assert.assertNotNull(dfp98);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)");
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField17.newDfp(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField17.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.power10K(0);
        boolean boolean37 = dfp13.lessThan(dfp34);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.multiply(52);
        boolean boolean40 = dfp9.equals((java.lang.Object) dfp34);
        int int41 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn5();
        dfpField7.setIEEEFlagsBits((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField7.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathIllegalArgumentException26.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNull(localizable27);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) (-1), false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number20, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getSpecificPattern();
        java.lang.String str24 = numberIsTooSmallException22.toString();
        java.lang.Number number25 = numberIsTooSmallException22.getMin();
        mathIllegalArgumentException18.addSuppressed((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number37, false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException39.getSpecificPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { "", numberIsTooSmallException39, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray45);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException30, localizable31, localizable32, objArray45);
        notStrictlyPositiveException28.addSuppressed((java.lang.Throwable) notStrictlyPositiveException30);
        java.lang.Number number49 = notStrictlyPositiveException28.getArgument();
        mathIllegalArgumentException18.addSuppressed((java.lang.Throwable) notStrictlyPositiveException28);
        numberIsTooSmallException10.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException57.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField60.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField60.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable52, localizable58, (java.lang.Object[]) dfpArray65);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str24.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(localizable40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (byte) 1 + "'", number49.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpArray65);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.floor();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField8.newDfp(dfp21);
        boolean boolean23 = dfp3.unequal(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits((int) '#');
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.ceil();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField9.newDfp(dfp25);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp3.multiply(dfp25);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        long long2 = mersenneTwister1.nextLong();
        int int4 = mersenneTwister1.nextInt(16);
        double double5 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 402613113023623976L + "'", long2 == 402613113023623976L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.9201685993619035d) + "'", double5 == (-0.9201685993619035d));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField7.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        boolean boolean27 = dfp3.lessThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.multiply(52);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp24.newInstance((long) 35);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField39.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.floor();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.divide(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField39.newDfp(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField39.getLn5();
        double double55 = dfp54.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((byte) 100);
        double[] doubleArray60 = dfp59.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp54.multiply(dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp37, dfp54);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.609437912434d + "'", double55 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
    }
}

