import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        java.lang.Class<?> wildcardClass1 = roundingMode0.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4588770968736724d + "'", double2 == 1.4588770968736724d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.4588770968736724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4588770968736724d + "'", double1 == 1.4588770968736724d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (byte) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        byte[] byteArray4 = null;
        try {
            mersenneTwister1.nextBytes(byteArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.620277154609447d + "'", double1 == 23.620277154609447d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        int int4 = dfp3.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.signum(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4319786996724999d + "'", double1 == 0.4319786996724999d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.floor();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp3.subtract(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfp12.add(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.671281819617711d) + "'", double1 == (-5.671281819617711d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.acosh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, (double) 5805985991905072931L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.8059859919050732E18d + "'", double2 == 5.8059859919050732E18d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 3, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10, 0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4162254426224244d + "'", double2 == 0.4162254426224244d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp19 = dfp17.divide(dfp18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9991050130774393d) + "'", double1 == (-0.9991050130774393d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp49 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp50 = dfp18.add(dfp49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math.util.FastMath.round(0.24877846f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 5805985991905072931L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.8059859919050732E18d + "'", double1 == 5.8059859919050732E18d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance((long) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.log10(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits(8);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '4');
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.ceil(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(10L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.007520012911409484d + "'", double3 == 0.007520012911409484d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4588770968736724d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.sin(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        int int3 = dfp2.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        int int15 = dfp13.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.newInstance(4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.949874371066198d + "'", double1 == 18.949874371066198d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4588770968736724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37766702807171765d + "'", double1 == 0.37766702807171765d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.divide(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp24.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.floor();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.sqrt();
        org.apache.commons.math.dfp.Dfp dfp53 = null;
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.floor();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.divide(dfp63);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp49.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp53, dfp63);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp37.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp68 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp37);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp17.ceil();
        int int70 = dfp69.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        boolean boolean7 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField2.getE();
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int2 = org.apache.commons.math.util.FastMath.max(1351811455, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1351811455 + "'", int2 == 1351811455);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 402613113023623976L + "'", long2 == 402613113023623976L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.33809533147143167d + "'", double3 == 0.33809533147143167d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.609437912434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9999999999994977d + "'", double1 == 3.9999999999994977d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp13, dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) -1);
        int int7 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9259573975574423d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4602179047809838d + "'", double1 == 1.4602179047809838d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.4319786996724999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46232677714249d + "'", double1 == 0.46232677714249d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7449400628223749d) + "'", double1 == (-0.7449400628223749d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7581226324091723d) + "'", double1 == (-1.7581226324091723d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5403023058681398d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6526464293101901d + "'", double2 == 0.6526464293101901d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.tan((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9262160379374064d) + "'", double1 == (-0.9262160379374064d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.floor();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField8.newDfp(dfp21);
        boolean boolean23 = dfp3.unequal(dfp22);
        int int24 = dfp3.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.newInstance((double) '#');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        double double51 = dfp30.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.NEGATIVE_INFINITY + "'", double51 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp13, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.divide(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.multiply(100);
        boolean boolean40 = dfp23.unequal(dfp35);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.46232677714249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.17716796186027328d + "'", double0 == 0.17716796186027328d);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 402613113023623976L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 16, 402613113023623976L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.nextAfter(dfp56);
        int int58 = dfp57.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32760);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32760L + "'", long1 == 32760L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-32767));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp27.newInstance(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp9.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9259573975574423d), 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1622776601683795d + "'", double2 == 3.1622776601683795d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double2 = org.apache.commons.math.util.FastMath.min(0.37766702807171765d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.7581226324091723d), (java.lang.Number) (byte) 3, true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-702367417), (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.4588770968736724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4588770968736726d + "'", double1 == 1.4588770968736726d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.newDfp(32.00000000000001d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp21 = null;
        try {
            boolean boolean22 = dfp18.greaterThan(dfp21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.nextAfter(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp3.divide(dfp20);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        double double7 = dfp6.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp6.divide(dfp17);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        boolean boolean51 = dfp30.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        double double6 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5711645f + "'", float4 == 0.5711645f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5805985991905072931L + "'", long5 == 5805985991905072931L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.43899594558373667d + "'", double6 == 0.43899594558373667d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean11 = dfp4.lessThan(dfp10);
        double[] doubleArray12 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(32760);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5711645f + "'", float4 == 0.5711645f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5805985991905072931L + "'", long5 == 5805985991905072931L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3806713761839717d) + "'", double1 == (-0.3806713761839717d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(16);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-702367417), 2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963225332768d) + "'", double2 == (-1.5707963225332768d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 746805014710214202L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32760L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 571.7698629533423d + "'", double1 == 571.7698629533423d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0d), 4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.1752011936438014d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.007520012911409484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.8059859919050732E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.8059859919050732E18d + "'", double1 == 5.8059859919050732E18d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.4319786996724999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.007520012911409484d, (double) 402613113023623976L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.007520012911409485d + "'", double2 == 0.007520012911409485d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8184464592320668d + "'", double1 == 1.8184464592320668d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        boolean boolean4 = mersenneTwister1.nextBoolean();
        double double5 = mersenneTwister1.nextGaussian();
        int int6 = mersenneTwister1.nextInt();
        double double7 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5077076611540343d) + "'", double5 == (-0.5077076611540343d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-702367417) + "'", int6 == (-702367417));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.43948469167762516d + "'", double7 == 0.43948469167762516d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0d), 571.7698629533423d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0017489536353343174d) + "'", double2 == (-0.0017489536353343174d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getOne();
        double[] doubleArray19 = dfp16.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.divide(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField23.newDfp(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField23.getLn5();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField23.newDfp("100.");
        int int41 = dfp40.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp40);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        int int5 = mersenneTwister1.nextInt(52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.24877846f + "'", float3 == 0.24877846f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int[] intArray1 = new int[] { (short) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        boolean boolean4 = mersenneTwister2.nextBoolean();
        long long5 = mersenneTwister2.nextLong();
        boolean boolean6 = mersenneTwister2.nextBoolean();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4162254426224244d + "'", double3 == 0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 746805014710214202L + "'", long5 == 746805014710214202L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (byte) 3);
        int int4 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(0L);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.floor();
        boolean boolean22 = dfp16.unequal(dfp21);
        double[] doubleArray23 = dfp21.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.7160033436347992d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.7160033436347992d + "'", number2.equals(1.7160033436347992d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7160033436347992d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.24877846f + "'", float3 == 0.24877846f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.3380953f + "'", float4 == 0.3380953f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32768 + "'", int2 == 32768);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(11013.232920103323d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.23292010332d + "'", double2 == 11013.23292010332d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        double[] doubleArray12 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField2.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField2.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray16);
        java.lang.Throwable[] throwableArray18 = mathIllegalArgumentException17.getSuppressed();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("100.");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.power10K(32760);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9822633517692823d + "'", double1 == 0.9822633517692823d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2083244963961874d + "'", double1 == 2.2083244963961874d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4588770968736726d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4431177980307374d + "'", double1 == 0.4431177980307374d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 100);
        double[] doubleArray22 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.multiply(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp28.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.getOne();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp16.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.609437912434d + "'", double17 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((byte) 10, (byte) -1);
        double[] doubleArray10 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 100);
        java.lang.Class<?> wildcardClass10 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(8.673617379884035E-19d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.673617379884037E-19d + "'", double2 == 8.673617379884037E-19d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp13, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField24 = dfp13.getField();
        dfpField24.setIEEEFlags((int) ' ');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpField24);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        int int13 = dfp12.classify();
        boolean boolean14 = dfp12.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp14.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.floor();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.divide(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = null;
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.floor();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp49.divide(dfp53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp39.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp43, dfp53);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp27.newInstance(dfp39);
        boolean boolean59 = dfp27.equals((java.lang.Object) true);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance("100.");
        org.apache.commons.math.dfp.Dfp dfp69 = dfp5.dotrap((int) (short) 100, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp27, dfp66);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.floor();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.floor();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp37.divide(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.nextAfter(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.floor();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp50.divide(dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp56.sqrt();
        org.apache.commons.math.dfp.Dfp dfp60 = null;
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.floor();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp66.divide(dfp70);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp56.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp60, dfp70);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp44.newInstance(dfp56);
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.Dfp.copysign(dfp24, dfp44);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField6.newDfp(dfp24);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.605170185988092d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.8059859919050732E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.ulp(18.949874371066198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.signum(11013.23292010332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.007520012911409485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08671800799954693d + "'", double1 == 0.08671800799954693d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) (byte) 2);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((byte) 100, (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.007520012911409485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4308650017076501d + "'", double1 == 0.4308650017076501d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.util.FastMath.max(1.609437912434d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.609437912434d + "'", double2 == 1.609437912434d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.log(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.151292546497023d + "'", double1 == 1.151292546497023d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.5711645f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5600780393704231d) + "'", double1 == (-0.5600780393704231d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        double double2 = mersenneTwister1.nextDouble();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15071724896777527d + "'", double2 == 0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6365903589914876d + "'", double3 == 0.6365903589914876d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("100.");
        java.lang.Class<?> wildcardClass19 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = null;
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField21.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp19.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp13.dotrap((int) (short) -1, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp16, dfp29);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp13, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.divide(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = dfp33.getField();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.floor();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp33.newInstance(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp33);
        boolean boolean55 = dfp13.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpField36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.007520012911409484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43086500170765d + "'", double1 == 0.43086500170765d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        int int15 = dfp13.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 402613113023623976L, 1.4602179047809838d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0261311302362394E17d + "'", double2 == 4.0261311302362394E17d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1L), (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.apache.commons.math.util.FastMath.round(0.3380953f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.43899594558373667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4389959455837367d + "'", double1 == 0.4389959455837367d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2041199826559248d + "'", double1 == 1.2041199826559248d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.1752011936438014d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Number number5 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        int int9 = dfp8.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.6526464293101901d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        boolean boolean4 = mersenneTwister1.nextBoolean();
        double double5 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5077076611540343d) + "'", double5 == (-0.5077076611540343d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        java.lang.String str5 = dfp3.toString();
        boolean boolean6 = dfp3.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100." + "'", str5.equals("100."));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        boolean boolean4 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 1, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((double) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.569397566060481d + "'", double1 == 7.569397566060481d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.154262241479262d + "'", double1 == 15.154262241479262d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4319786996724999d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.26837195774461137d + "'", double2 == 0.26837195774461137d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int1 = org.apache.commons.math.util.FastMath.round(0.5711645f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0L);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.7581226324091723d), (double) (-4));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7581226324091723d) + "'", double2 == (-1.7581226324091723d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField11.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode14);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int[] intArray1 = new int[] { (short) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        mersenneTwister2.setSeed((int) (byte) 100);
        long long6 = mersenneTwister2.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4162254426224244d + "'", double3 == 0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-8422692239103173864L) + "'", long6 == (-8422692239103173864L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186348d + "'", double1 == 1833.4649444186348d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister3.setSeed((long) (short) 10);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        double double7 = mersenneTwister3.nextGaussian();
        int int9 = mersenneTwister3.nextInt(2);
        byte[] byteArray15 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister3.nextBytes(byteArray15);
        mersenneTwister1.nextBytes(byteArray15);
        float float18 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.5077076611540343d) + "'", double7 == (-0.5077076611540343d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.4178288f + "'", float18 == 0.4178288f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.log10(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7581226324091723d + "'", double1 == 1.7581226324091723d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.asin(8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.7160033436347992d, (java.lang.Number) (-1L), true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5600780393704231d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8472136549970425d + "'", double1 == 0.8472136549970425d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.26837195774461137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2651620241495342d + "'", double1 == 0.2651620241495342d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        double double2 = mersenneTwister1.nextDouble();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15071724896777527d + "'", double2 == 0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3607126587566499866L + "'", long3 == 3607126587566499866L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9640275800758169d + "'", double1 == 0.9640275800758169d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1784579474251238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07131408959511519d + "'", double1 == 0.07131408959511519d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.4319786996724999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4069736096505834d + "'", double1 == 0.4069736096505834d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, 0.5711645f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 402613113023623976L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.07131408959511519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06888601606688857d + "'", double1 == 0.06888601606688857d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7581226324091723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.030685028589370025d + "'", double1 == 0.030685028589370025d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp17.newInstance(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.floor();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.divide(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField38.newDfp(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField38.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField38.getOne();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp33.add(dfp54);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.7449400628223749d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.815776214791571d) + "'", double1 == (-0.815776214791571d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.43086500170765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp20 = dfp17.nextAfter(dfp19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 402613113023623976L, (java.lang.Number) 11013.232920103323d, true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 10);
        boolean boolean19 = dfp14.lessThan(dfp18);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 746805014710214202L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.4680501471021427E17d + "'", double1 == 7.4680501471021427E17d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.1784579474251238d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7581226324091723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number10, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { "", numberIsTooSmallException12, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3, localizable4, localizable5, objArray18);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathIllegalArgumentException28.getGeneralPattern();
        java.lang.String str30 = mathIllegalArgumentException28.toString();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException28);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str30.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.floor();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp31.divide(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp25.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.getOne();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp18.remainder(dfp39);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField1.getRoundingMode();
        int int17 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp27.newInstance(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp9.remainder(dfp46);
        double double48 = dfp46.toDouble();
        int int49 = dfp46.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 9.99999999999812E127d + "'", double48 == 9.99999999999812E127d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 128 + "'", int49 == 128);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-4), 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.3380953f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.3380953f + "'", float1 == 0.3380953f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.floor();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.divide(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp26.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.floor();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.divide(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.sqrt();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp38.newInstance(dfp54);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp20.subtract(dfp54);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp6.nextAfter(dfp54);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpField19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624473515096265d + "'", double1 == 1.1624473515096265d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5077076611540343d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(571.7698629533423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.2999170793155d + "'", double1 == 8.2999170793155d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.nextAfter(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField59.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.floor();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp66.divide(dfp70);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField59.newDfp(dfp72);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField59.getLn5();
        double double75 = dfp74.toDouble();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp57.newInstance(dfp74);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp74.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.newInstance((double) (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.609437912434d + "'", double75 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.0d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 65536.0d + "'", double2 == 65536.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) 4);
        int int10 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField7.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        boolean boolean27 = dfp3.lessThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.multiply(52);
        java.lang.String str30 = dfp24.toString();
        int int31 = dfp24.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "100." + "'", str30.equals("100."));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.log((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.ulp(8.673617379884037E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9259299443872359E-34d + "'", double1 == 1.9259299443872359E-34d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp(dfp17);
        boolean boolean21 = dfp20.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("100.");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number10, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { "", numberIsTooSmallException12, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3, localizable4, localizable5, objArray18);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
        java.lang.Number number22 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.floor();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.divide(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp29.nextAfter(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.floor();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.sqrt();
        org.apache.commons.math.dfp.Dfp dfp58 = null;
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp68.floor();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp64.divide(dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp54.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp58, dfp68);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp42.newInstance(dfp54);
        java.lang.Object[] objArray74 = new java.lang.Object[] { dfp42, (-1.0f) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray74);
        java.lang.Object[] objArray76 = mathIllegalArgumentException75.getArguments();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException75);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) 1 + "'", number22.equals((byte) 1));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField1.getRoundingMode();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.185039863261519d) + "'", double1 == (-2.185039863261519d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        int int4 = dfp3.log10K();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getPi();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp11.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp3.subtract(dfp25);
        int int27 = dfp25.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathRuntimeException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        double[] doubleArray10 = dfp9.toSplitDouble();
        java.lang.String str11 = dfp9.toString();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.negate();
        boolean boolean13 = dfp5.greaterThan(dfp9);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100." + "'", str11.equals("100."));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp9.getField();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.floor();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.floor();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.divide(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField31.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField31.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField31.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp9.remainder(dfp50);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
        java.lang.String str8 = mathIllegalArgumentException6.toString();
        java.lang.String str9 = mathIllegalArgumentException6.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str8.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str9.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.0d), 0.08671800799954693d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        double double4 = mersenneTwister1.nextGaussian();
        long long5 = mersenneTwister1.nextLong();
        boolean boolean6 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0000679992263888d) + "'", double4 == (-1.0000679992263888d));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3850396226921085255L + "'", long5 == 3850396226921085255L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-32767), (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32767.0d) + "'", double2 == (-32767.0d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.641588833612779d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable24, objArray30);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable24, (java.lang.Object[]) dfpArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField47.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField47.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField47.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException2, localizable3, localizable45, (java.lang.Object[]) dfpArray54);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.rint();
        int int7 = dfp3.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp15 = null;
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp11.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp15, dfp25);
        java.lang.String str29 = dfp11.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0." + "'", str29.equals("0."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.1752011936438014d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.1752011936438014d + "'", number3.equals(1.1752011936438014d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.569397566060481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999994674815105d + "'", double1 == 0.9999994674815105d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance((long) (-702367417));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) Double.NaN, true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) -1);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32760);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4436354751788103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.821622829149065d + "'", double1 == 7.821622829149065d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        boolean boolean4 = mersenneTwister1.nextBoolean();
        int int5 = mersenneTwister1.nextInt();
        int[] intArray7 = new int[] { (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1351811455 + "'", int5 == 1351811455);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        double[] doubleArray10 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.nextAfter(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.newInstance((-4));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        boolean boolean4 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp17.newInstance(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.newInstance(3.141592653589793d);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance((long) (short) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.0000679992263888d), 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5707963267948967d + "'", double1 == 0.5707963267948967d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        double[] doubleArray4 = dfp3.toSplitDouble();
        java.lang.String str5 = dfp3.toString();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance((byte) 0);
        boolean boolean16 = dfp3.greaterThan(dfp15);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100." + "'", str5.equals("100."));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.atanh(23.620277154609447d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.5077076611540343d), (java.lang.Number) 1.0d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.508 is smaller than, or equal to, the minimum (1)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.508 is smaller than, or equal to, the minimum (1)"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number10, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { "", numberIsTooSmallException12, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0L, (java.lang.Number) 0, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.569397566060481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1936.9724294518476d + "'", double1 == 1936.9724294518476d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("100.");
        int int19 = dfp18.getRadixDigits();
        java.lang.String str20 = dfp18.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100." + "'", str20.equals("100."));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp27.newInstance(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp9.remainder(dfp46);
        int int48 = dfp46.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 128 + "'", int48 == 128);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.ceil();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getESplit();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.floor();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp31.divide(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField24.newDfp(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.getTwo();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp14.dotrap(4, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp22, dfp39);
        int int42 = dfp22.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        long long1 = org.apache.commons.math.util.FastMath.round(0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 3, 3850396226921085255L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3850396226921085255L + "'", long2 == 3850396226921085255L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.ceil();
        double[] doubleArray16 = dfp15.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.ceil();
        boolean boolean16 = dfp15.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        boolean boolean50 = dfp18.equals((java.lang.Object) true);
        org.apache.commons.math.dfp.DfpField dfpField51 = dfp18.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField51.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfpField51);
        org.junit.Assert.assertNotNull(dfpArray52);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(32.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5834904057792243d) + "'", double1 == (-0.5834904057792243d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = null;
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp30.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getOne();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp55.multiply(dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp30.add(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp67.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp73.floor();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp69.divide(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = dfp73.getField();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp80.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField84 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField84.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp86.floor();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp82.divide(dfp86);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp88.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp92 = dfp88.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp73.newInstance(dfp92);
        boolean boolean94 = dfp62.unequal(dfp73);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfpField76);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.3380953f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.225904041787973d + "'", double1 == 1.225904041787973d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9866275920404853d, (java.lang.Number) 1.7160033436347992d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.987 is smaller than, or equal to, the minimum (1.716)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.987 is smaller than, or equal to, the minimum (1.716)"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.power10((int) 'a');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number10, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { "", numberIsTooSmallException12, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField28.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField28.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField28.newDfp(dfp40);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField28.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, (java.lang.Object[]) dfpArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray42);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray42);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance(100L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.multiply(100);
        int int16 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number8, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getSpecificPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { "", numberIsTooSmallException10, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, objArray16);
        java.lang.String str19 = mathRuntimeException18.toString();
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str19.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        java.lang.Class<?> wildcardClass4 = dfp3.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.0000679992263888d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp27.newInstance(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp9.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4436354751788103d, (java.lang.Number) 8.673617379884035E-19d, false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(4.0261311302362394E17d);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.divide(4);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.divide(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp24.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.floor();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.sqrt();
        org.apache.commons.math.dfp.Dfp dfp53 = null;
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.floor();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.divide(dfp63);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp49.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp53, dfp63);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp37.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp68 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp37);
        int int69 = dfp37.log10();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp37.newInstance((double) (short) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.7581226324091723d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp9.getField();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.floor();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.ceil();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp9.remainder(dfp33);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.floor();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.divide(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.sqrt();
        org.apache.commons.math.dfp.Dfp dfp42 = null;
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.floor();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp38.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp42, dfp52);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp26.newInstance(dfp38);
        java.lang.Object[] objArray58 = new java.lang.Object[] { dfp26, (-1.0f) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray58);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException59);
        java.lang.Object[] objArray61 = mathIllegalArgumentException59.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable62 = mathIllegalArgumentException59.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNull(localizable62);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp18.getField();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp28.nextAfter(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.floor();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.divide(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.sqrt();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp40.newInstance(dfp56);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp22.subtract(dfp56);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp8.add(dfp60);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.0000000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        int int4 = dfp3.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.divide(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.floor();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField21.newDfp(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp19.add(dfp35);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        java.lang.Class<?> wildcardClass3 = mersenneTwister1.getClass();
        float float4 = mersenneTwister1.nextFloat();
        double double5 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.24877846f + "'", float4 == 0.24877846f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.33809533147143167d + "'", double5 == 0.33809533147143167d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        dfpField1.setIEEEFlags(10000);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField7.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        boolean boolean27 = dfp3.lessThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp3.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp3.getField();
        dfpField29.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.7160033436347992d);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (short) 10);
        boolean boolean4 = mersenneTwister1.nextBoolean();
        double double5 = mersenneTwister1.nextGaussian();
        int int6 = mersenneTwister1.nextInt();
        double double7 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(16L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5077076611540343d) + "'", double5 == (-0.5077076611540343d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-702367417) + "'", int6 == (-702367417));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.1784579474251238d + "'", double7 == 1.1784579474251238d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 1.7160033436347992d, (java.lang.Number) 10000, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) (-1), false);
        java.lang.Number number20 = numberIsTooSmallException19.getMin();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (byte) -1, 0, 0.0f };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable22, objArray26);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number29, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getSpecificPattern();
        java.lang.String str33 = numberIsTooSmallException31.toString();
        java.lang.Number number34 = numberIsTooSmallException31.getMin();
        mathIllegalArgumentException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), number46, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getSpecificPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { "", numberIsTooSmallException48, (byte) 100, 1L, 100, 52.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray54);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException39, localizable40, localizable41, objArray54);
        notStrictlyPositiveException37.addSuppressed((java.lang.Throwable) notStrictlyPositiveException39);
        java.lang.Number number58 = notStrictlyPositiveException37.getArgument();
        mathIllegalArgumentException27.addSuppressed((java.lang.Throwable) notStrictlyPositiveException37);
        numberIsTooSmallException19.addSuppressed((java.lang.Throwable) mathIllegalArgumentException27);
        org.apache.commons.math.exception.util.Localizable localizable61 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) (-1), false);
        java.lang.Number number67 = numberIsTooSmallException66.getMin();
        java.lang.Object[] objArray68 = numberIsTooSmallException66.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable61, objArray68);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1) + "'", number20.equals((-1)));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str33.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (byte) 1 + "'", number58.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (-1) + "'", number67.equals((-1)));
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.tanh(23.620277154609447d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013388202148675738d + "'", double1 == 0.013388202148675738d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int[] intArray1 = new int[] { (short) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        int[] intArray4 = new int[] { 1 };
        mersenneTwister2.setSeed(intArray4);
        double double6 = mersenneTwister2.nextDouble();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.13436424090271992d + "'", double6 == 0.13436424090271992d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1), 1.7581226324091723d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int[] intArray1 = new int[] { (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        long long3 = mersenneTwister2.nextLong();
        long long4 = mersenneTwister2.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2687123488734686643L + "'", long3 == 2687123488734686643L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8391922005148157297L + "'", long4 == 8391922005148157297L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        double double4 = mersenneTwister1.nextGaussian();
        long long5 = mersenneTwister1.nextLong();
        float float6 = mersenneTwister1.nextFloat();
        int int8 = mersenneTwister1.nextInt(1351811455);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister12.setSeed((long) (short) 10);
        boolean boolean15 = mersenneTwister12.nextBoolean();
        double double16 = mersenneTwister12.nextGaussian();
        int int18 = mersenneTwister12.nextInt(2);
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister12.nextBytes(byteArray24);
        mersenneTwister10.nextBytes(byteArray24);
        mersenneTwister1.nextBytes(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.24877846f + "'", float3 == 0.24877846f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9259573975574423d) + "'", double4 == (-0.9259573975574423d));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-7099672186460106370L) + "'", long5 == (-7099672186460106370L));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.9195709f + "'", float6 == 0.9195709f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1151020078 + "'", int8 == 1151020078);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.5077076611540343d) + "'", double16 == (-0.5077076611540343d));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.floor();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.divide(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.nextAfter(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.divide(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.sqrt();
        org.apache.commons.math.dfp.Dfp dfp39 = null;
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.floor();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.divide(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp35.dotrap(10, "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", dfp39, dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp23.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp35.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp4.newInstance(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField61.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField61.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp59.nextAfter(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp56.nextAfter(dfp70);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long1 = org.apache.commons.math.util.FastMath.abs(3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9640275800758169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.016825455352356293d + "'", double1 == 0.016825455352356293d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32760L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32760 + "'", int1 == 32760);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField7.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.getSqr3Reciprocal();
        int int17 = dfp16.log10();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.floor();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.sqrt();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp16.divide(dfp34);
        boolean boolean36 = dfp5.greaterThan(dfp16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int[] intArray1 = new int[] { (short) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("100.");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.power10K((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2599210498948732d + "'", double1 == 1.2599210498948732d);
    }
}

