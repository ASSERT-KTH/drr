import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, 100.0d, (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1.0f, (double) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray2 = new int[] { (short) 1 };
        int[] intArray4 = new int[] { (short) 10 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray2, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setRowMatrix(0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) 1, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray9 = new double[] { (short) 10, 1.0f, (byte) 0, (-1.0f) };
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        try {
            array2DRowRealMatrix0.copySubMatrix(100, (int) (byte) -1, (-1), 0, doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray3 = new double[] { 1, (byte) -1 };
        double[] doubleArray6 = new double[] { 1, (byte) -1 };
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray6 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray7, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 1 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 100.0f, (double) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, realVector1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { 1, 10, (-1L), (byte) 0, 100, ' ' };
        double[] doubleArray14 = new double[] { 1, 10, (-1L), (byte) 0, 100, ' ' };
        double[] doubleArray21 = new double[] { 1, 10, (-1L), (byte) 0, 100, ' ' };
        double[] doubleArray28 = new double[] { 1, 10, (-1L), (byte) 0, 100, ' ' };
        double[][] doubleArray29 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray29, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 100 columns are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (byte) 0, (double) (byte) 1, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            array2DRowRealMatrix0.setColumnVector(0, realVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) (short) 0, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray6 = new double[] { 52, (byte) 100, 100.0d, '4', 0L };
        try {
            double[] doubleArray7 = array2DRowRealMatrix0.operate(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 0L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.0d, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 100, (double) ' ', 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 100.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E20d + "'", double2 == 1.0E20d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            array2DRowRealMatrix0.setRowVector((int) (byte) 0, realVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.scalarAdd((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (-1), (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = array2DRowRealMatrix0.add(array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) '#', 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.00000000000001d + "'", double2 == 35.00000000000001d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray4 = new double[] { (-0.7853981633974483d), 1.0f, 2.2250738585072014E-308d };
        double[] doubleArray8 = new double[] { (-0.7853981633974483d), 1.0f, 2.2250738585072014E-308d };
        double[] doubleArray12 = new double[] { (-0.7853981633974483d), 1.0f, 2.2250738585072014E-308d };
        double[] doubleArray16 = new double[] { (-0.7853981633974483d), 1.0f, 2.2250738585072014E-308d };
        double[] doubleArray20 = new double[] { (-0.7853981633974483d), 1.0f, 2.2250738585072014E-308d };
        double[][] doubleArray21 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray21, 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 10 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray8 = new double[] { 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException(localizable5, (java.lang.Object[]) doubleArray18);
        try {
            array2DRowRealMatrix0.copySubMatrix(1, (int) 'a', (int) (byte) -1, (int) (byte) 1, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 10, (double) (byte) 0, (double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 'a', (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = null;
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint5 = new org.apache.commons.math3.optimization.linear.LinearConstraint(realVector0, (double) (byte) 1, relationship2, realVector3, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (short) 0, (double) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray5 = new double[] { 1.9155040003582885E22d, (short) 1, (short) 1, 10.0f };
        try {
            double[] doubleArray6 = array2DRowRealMatrix0.operate(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray4 = new double[] { 0.0f, 1, 100.0d, 10L };
        org.apache.commons.math3.optimization.linear.Relationship relationship5 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint7 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray4, relationship5, (double) 0L);
        double double8 = linearConstraint7.getValue();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(1.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9988551111734393d + "'", double1 == 0.9988551111734393d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor1 = null;
        try {
            double double4 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor1, (int) (byte) 10, (-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(10.0d, Double.NaN, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            arrayRealVector0.setEntry((int) (short) -1, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor1 = null;
        try {
            double double2 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setEntry((int) '4', (int) (short) -1, 2.2250738585072014E-308d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 'a', 0.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray2 = new double[] { (short) 10 };
        org.apache.commons.math3.optimization.linear.Relationship relationship4 = null;
        double[] doubleArray9 = new double[] { 0.0f, 100.0d, 100L, 1.0d };
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint11 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray2, 1.0d, relationship4, doubleArray9, (double) 0.0f);
        try {
            double[] doubleArray12 = array2DRowRealMatrix0.operate(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        try {
            double[] doubleArray4 = blockRealMatrix2.getColumn((-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[] doubleArray5 = new double[] { (short) 10 };
        org.apache.commons.math3.optimization.linear.Relationship relationship7 = null;
        double[] doubleArray12 = new double[] { 0.0f, 100.0d, 100L, 1.0d };
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint14 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, 1.0d, relationship7, doubleArray12, (double) 0.0f);
        try {
            blockRealMatrix2.setColumn((int) (short) -1, doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            arrayRealVector0.addToEntry((int) (byte) 1, (double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8828124514936193E-4d + "'", double1 == 4.8828124514936193E-4d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (short) 100, 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append(1.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.getSubVector(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[] doubleArray7 = new double[] { 0.0f, 1, 100.0d, 10L };
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint10 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray7, relationship8, (double) 0L);
        try {
            double[] doubleArray11 = blockRealMatrix2.operate(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        java.lang.Throwable throwable1 = null;
        try {
            mathArithmeticException0.addSuppressed(throwable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.subtract(realMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(1072693248, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693248 + "'", int2 == 1072693248);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        double[] doubleArray6 = null;
        try {
            blockRealMatrix4.setColumn(1, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, 1, (-1233437887), (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3, 0, 1072693248, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) 100L, true);
        try {
            double[] doubleArray6 = array2DRowRealMatrix0.preMultiply(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = array2DRowRealMatrix0.transpose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor5, (int) (byte) 0, (int) (short) 100, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1233437887));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 5, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray5 = new double[] { 0.0f, ' ' };
        double[] doubleArray8 = new double[] { 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray5, doubleArray8, doubleArray11, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable2, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (-1L), false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.util.MathUtils.checkFinite(10.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix4.walkInColumnOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 0L, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "", "", "");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1233437887), (float) '4', (float) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math3.util.FastMath.signum(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        java.text.ParsePosition parsePosition6 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = realVectorFormat3.parse("", parsePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.8414709848078965d, 2.2250738585072014E-308d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        try {
            arrayRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry((int) (short) 1, 0, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.subtract(realMatrix23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.ZeroException zeroException19 = new org.apache.commons.math3.exception.ZeroException(localizable4, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException20 = new org.apache.commons.math3.exception.MathArithmeticException(localizable3, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, true);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = array2DRowRealMatrix0.add(array2DRowRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 4x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        try {
            array2DRowRealMatrix22.setEntry((int) (byte) 10, 1072693248, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((-0.7853981633974483d), 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 10L, (float) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double20 = arrayRealVector15.walkInOptimizedOrder(realVectorPreservingVisitor17, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        int int6 = matrixDimensionMismatchException4.getExpectedDimension(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix1.createMatrix((int) (byte) 1, (int) '4');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 1.0d, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.optimization.linear.UnboundedSolutionException unboundedSolutionException0 = new org.apache.commons.math3.optimization.linear.UnboundedSolutionException();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix4.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix4.add(realMatrix8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append(1.0d);
        try {
            double double4 = arrayRealVector0.getEntry((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix22.walkInRowOrder(realMatrixPreservingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix4.scalarAdd(0.8414709848078965d);
        int int8 = blockRealMatrix4.getColumnDimension();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!");
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse("hi!", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double[] doubleArray8 = null;
        try {
            blockRealMatrix6.setColumn((int) (byte) 100, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix4, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        double[] doubleArray17 = new double[] { (short) 10 };
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = null;
        double[] doubleArray24 = new double[] { 0.0f, 100.0d, 100L, 1.0d };
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint26 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray17, 1.0d, relationship19, doubleArray24, (double) 0.0f);
        try {
            arrayRealVector14.setSubVector((int) ' ', doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[][] doubleArray2 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 1, (int) 'a', doubleArray2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        org.apache.commons.math3.exception.util.Localizable localizable26 = null;
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        org.apache.commons.math3.exception.util.Localizable localizable29 = null;
        double[] doubleArray32 = new double[] { 0.0f, ' ' };
        double[] doubleArray35 = new double[] { 0.0f, ' ' };
        double[] doubleArray38 = new double[] { 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 0.0f, ' ' };
        double[][] doubleArray42 = new double[][] { doubleArray32, doubleArray35, doubleArray38, doubleArray41 };
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray42);
        org.apache.commons.math3.exception.ZeroException zeroException44 = new org.apache.commons.math3.exception.ZeroException(localizable29, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException45 = new org.apache.commons.math3.exception.MathArithmeticException(localizable28, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException46 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable26, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray42);
        try {
            array2DRowRealMatrix22.setSubMatrix(doubleArray42, (-1233437887), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray5 = new double[] { 0.0f, 1, 100.0d, 10L };
        org.apache.commons.math3.optimization.linear.Relationship relationship6 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint8 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, relationship6, (double) 0L);
        try {
            double[] doubleArray9 = array2DRowRealMatrix0.preMultiply(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        double[][] doubleArray7 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix12.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix12.scalarAdd(0.8414709848078965d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = blockRealMatrix4.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            double double3 = array2DRowRealMatrix0.getEntry((int) (byte) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        long long2 = org.apache.commons.math3.util.FastMath.max(100L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] { 52 };
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray2);
        try {
            java.lang.String str4 = zeroException3.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction29 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector25.mapToSelf(univariateFunction29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector31.append(arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.append(arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector37.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        try {
            blockRealMatrix21.setColumnVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        try {
            array2DRowRealMatrix17.addToEntry(0, 100, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException noFeasibleSolutionException0 = new org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException();
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 10.0f, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 10, (int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix5.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        double[][] doubleArray7 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix4.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 'a', (double) (byte) 100, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor5 = null;
        try {
            double double8 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor5, 1072693248, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (short) 100, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        java.io.ObjectOutputStream objectOutputStream26 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix22, objectOutputStream26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double26 = arrayRealVector22.walkInOptimizedOrder(realVectorChangingVisitor23, 52, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double31 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixChangingVisitor26, 0, 52, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse(",");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector3.append(arrayRealVector4);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction8 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector4.mapToSelf(univariateFunction8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector10.append(arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector15);
        try {
            array2DRowRealMatrix0.setRowVector((int) (byte) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) -1, 1.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector12.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 0L, true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] { 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 0.0f, ' ' };
        double[] doubleArray20 = new double[] { 0.0f, ' ' };
        double[][] doubleArray21 = new double[][] { doubleArray11, doubleArray14, doubleArray17, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable8, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException24 = new org.apache.commons.math3.exception.MathArithmeticException(localizable7, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable5, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        double double30 = array2DRowRealMatrix27.getEntry(0, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 4x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.27675392434470114d + "'", double0 == 0.27675392434470114d);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) '4', (float) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        double double5 = blockRealMatrix2.getNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector12.mapAddToSelf((double) 10);
        try {
            arrayRealVector12.addToEntry(100, (double) (-0.99999994f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray12 = blockRealMatrix11.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix7.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double2 = org.apache.commons.math3.util.Precision.round(Double.POSITIVE_INFINITY, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix22.walkInOptimizedOrder(realMatrixChangingVisitor27, (-1233437887), 5, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix6.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix6.scalarAdd((double) (byte) 100);
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        try {
            java.lang.StringBuffer stringBuffer13 = realMatrixFormat0.format(realMatrix10, stringBuffer11, fieldPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 100, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) '4', (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse(",", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor10, (int) (short) 10, (int) (short) 10, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial column 35 after final column 10");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 0.8414709848078965d, 1072693248);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector15 = blockRealMatrix13.getColumnVector(0);
        try {
            org.apache.commons.math3.linear.RealVector realVector16 = blockRealMatrix6.operateTranspose(realVector15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor13 = null;
        try {
            double double14 = arrayRealVector12.walkInDefaultOrder(realVectorPreservingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 52);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray3, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 52 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(6.283185307179586d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor9, (int) (short) 1, (int) (byte) -1, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(6.283185307179586d, (double) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17260374626909167d) + "'", double1 == (-0.17260374626909167d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 0.0f, ' ' };
        double[][] doubleArray19 = new double[][] { doubleArray9, doubleArray12, doubleArray15, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        try {
            blockRealMatrix6.setSubMatrix(doubleArray19, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) '4', 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (byte) 1, 2.718281828459045d, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4365636569180902d + "'", double3 == 1.4365636569180902d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 97.00000000000001d, 0.3796077390275217d, (-0.7853981633974483d), 572.9577951308232d, 10.0d, 99.99999999999999d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int[] intArray26 = new int[] {};
        int[] intArray33 = new int[] { (-1233437887), 2, (-1233437887), 52, 'a', 0 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix22, intArray26, intArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected row index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 1072693248, (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932479999999E9d + "'", double2 == 1.0726932479999999E9d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 267.7467614837482d + "'", double1 == 267.7467614837482d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.append(arrayRealVector16);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.mapToSelf(univariateFunction20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector22.append(arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14, arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector31.append(arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector28.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        boolean boolean37 = arrayRealVector32.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector13.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        java.lang.String str39 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{}" + "'", str39.equals("{}"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray4 = blockRealMatrix3.getData();
        int int5 = blockRealMatrix3.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        try {
            java.lang.StringBuffer stringBuffer11 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8, stringBuffer9, fieldPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        java.io.ObjectInputStream objectInputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (byte) 100, "{}", objectInputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector16.append(arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivide((double) (short) 100);
        try {
            org.apache.commons.math3.linear.RealVector realVector24 = blockRealMatrix4.preMultiply(realVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        try {
            array2DRowRealMatrix0.multiplyEntry((int) (byte) 0, 5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math3.util.FastMath.signum(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = blockRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor4, (int) (byte) 100, 0, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, number1, (java.lang.Number) (-0.99999994f), true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(5, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 360.0d + "'", double1 == 360.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor33 = null;
        try {
            double double36 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor33, (int) (byte) 0, (-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.append(1.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = realVector9.mapMultiply(Double.POSITIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = blockRealMatrix4.operateTranspose(realVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-1.0d), (double) 0.0f, 3.732511156817248d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "", "", "", "", "");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        double[][] doubleArray6 = blockRealMatrix4.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.getColumnMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(100, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.0d, (double) 2, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor23 = null;
        try {
            double double26 = arrayRealVector22.walkInDefaultOrder(realVectorPreservingVisitor23, 1072693248, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray17 = blockRealMatrix16.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix12.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix12.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor19, (int) '#', (int) (byte) 100, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 5, (double) 5, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        double[][] doubleArray8 = null;
        try {
            blockRealMatrix6.setSubMatrix(doubleArray8, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector24.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector30);
        double double36 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray37 = arrayRealVector30.getDataRef();
        try {
            double double39 = arrayRealVector30.getEntry((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) '4', (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray10 = blockRealMatrix9.getData();
        int int11 = blockRealMatrix9.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.getRowMatrix(10);
        try {
            blockRealMatrix4.setRowMatrix((int) (byte) 10, blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1189396031849523d + "'", double1 == 1.1189396031849523d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.util.FastMath.cos(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1432705801223346d + "'", double1 == 0.1432705801223346d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass15 = arrayRealVector12.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector33.append(arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.append(arrayRealVector40);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction44 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.mapToSelf(univariateFunction44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector46.append(arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        double double52 = arrayRealVector38.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        double double53 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector55.append(arrayRealVector56);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction60 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector56.mapToSelf(univariateFunction60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector63.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector62.append(arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector56, arrayRealVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector54, arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector72.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector71.append(arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector68.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix77 = arrayRealVector46.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(arrayRealVector76);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.ZeroException zeroException19 = new org.apache.commons.math3.exception.ZeroException(localizable4, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException20 = new org.apache.commons.math3.exception.MathArithmeticException(localizable3, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, true);
        double double26 = array2DRowRealMatrix23.getEntry(0, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 2.2250738585072014E-308d, number2, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
        try {
            java.lang.String str3 = notStrictlyPositiveException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 6.283185307179586d, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 35.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter(",", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        double[] doubleArray17 = null;
        try {
            blockRealMatrix15.setColumn(0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1771933557663626E-8d + "'", double1 == 5.1771933557663626E-8d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 9.536743E-7f, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.5367431640625E-7d + "'", double2 == 9.5367431640625E-7d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat1.parse("hi!", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865476d + "'", double1 == 0.7071067811865476d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964228836762624d + "'", double1 == 0.9964228836762624d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.RealVector realVector6 = realVector4.mapMultiply(Double.POSITIVE_INFINITY);
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        try {
            java.lang.StringBuffer stringBuffer9 = realVectorFormat1.format(realVector4, stringBuffer7, fieldPosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass32 = arrayRealVector29.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector56.append(arrayRealVector57);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.mapToSelf(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        double double69 = arrayRealVector55.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        boolean boolean72 = arrayRealVector63.isInfinite();
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        try {
            array2DRowRealMatrix17.addToEntry((int) (byte) 1, 2, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray6 = pointValuePair4.getPoint();
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 100L, true);
        double[] doubleArray12 = pointValuePair11.getFirst();
        boolean boolean13 = pointValuePair4.equals((java.lang.Object) pointValuePair11);
        java.lang.Double double14 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14.equals(100.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = array2DRowRealMatrix17.walkInRowOrder(realMatrixChangingVisitor19, 1, (int) (byte) 0, (int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException5.getExpectedDimensions();
        java.lang.Integer[] intArray8 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.9988551111734393d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor33 = null;
        try {
            double double36 = arrayRealVector32.walkInDefaultOrder(realVectorPreservingVisitor33, (int) '#', 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.27675392434470114d, (java.lang.Number) (short) 10, false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = relationship17.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector15, relationship18, (double) 0.0f);
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor1 = null;
        try {
            double double4 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor1, (int) (byte) -1, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor27, (int) '4', (int) (byte) 0, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Throwable[] throwableArray6 = matrixDimensionMismatchException4.getSuppressed();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getWrongDimensions();
        try {
            int int9 = matrixDimensionMismatchException4.getExpectedDimension(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getRowMatrix(5);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = blockRealMatrix4.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray4 = new double[] { 0.0f, 1, 100.0d, 10L };
        org.apache.commons.math3.optimization.linear.Relationship relationship5 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint7 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray4, relationship5, (double) 0L);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = linearConstraint7.getRelationship();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNull(relationship8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1L), (float) 52, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4, 1072693248, 0, 29, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0L + "'", number2.equals(0L));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (byte) 1, Double.NaN, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (byte) 100, (double) '#', 0.9988551111734393d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.00114488882656d + "'", double3 == 29.00114488882656d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray17 = blockRealMatrix16.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix12.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix12.copy();
        double[] doubleArray21 = blockRealMatrix19.getColumn((int) ' ');
        try {
            double[] doubleArray22 = blockRealMatrix9.operate(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getRowMatrix(5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix10.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix10.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 100x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray4 = blockRealMatrix3.getData();
        int int5 = blockRealMatrix3.getRowDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 0.9964228836762624d, false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        double[][] doubleArray7 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = blockRealMatrix4.walkInOptimizedOrder(realMatrixPreservingVisitor8, 0, (int) 'a', (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        int[] intArray10 = new int[] { (byte) 1, ' ' };
        int[] intArray16 = new int[] { (short) 10, 'a', (byte) 10, (short) -1, (-1) };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray20 = blockRealMatrix19.getData();
        try {
            blockRealMatrix6.copySubMatrix(intArray10, intArray16, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray8 = new double[] { 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException(localizable5, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math3.exception.MathArithmeticException(localizable4, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable2, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 360.0d, (java.lang.Object[]) doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.util.MathUtils.checkFinite(5.1771933557663626E-8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (byte) -1, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double2 = org.apache.commons.math3.util.Precision.round(9.5367431640625E-7d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 2, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        double[][] doubleArray4 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5, (int) ' ', (int) (byte) 10, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.ZeroException zeroException19 = new org.apache.commons.math3.exception.ZeroException(localizable4, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, false);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 4x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1, (int) '#', (int) (short) 0, (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        int[] intArray19 = null;
        int[] intArray26 = new int[] { 10, 2, 52, (short) 0, 1, (byte) 100 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix27.createMatrix((int) (byte) 1, (int) '4');
        double[][] doubleArray31 = array2DRowRealMatrix27.getData();
        try {
            blockRealMatrix2.copySubMatrix(intArray19, intArray26, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math3.util.FastMath.max(99.99999999999999d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) 0, 5);
        int int3 = simplexSolver2.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix6.getSubMatrix(1072693248, 2, 52, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0f, 10.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(29.00114488882656d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.00114488882656d + "'", double2 == 29.00114488882656d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(1.5430806348152437d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.9988551111734393d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9155040003582885E22d + "'", double2 == 1.9155040003582885E22d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray9 = blockRealMatrix8.getData();
        int int10 = blockRealMatrix8.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix8.getRowMatrix(10);
        double double13 = blockRealMatrix8.getNorm();
        boolean boolean14 = pointValuePair4.equals((java.lang.Object) double13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (byte) 0, (double) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        double[][] doubleArray4 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        double[][] doubleArray6 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix4.walkInColumnOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix3.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray8 = blockRealMatrix7.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix3.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix3.copy();
        double[] doubleArray12 = blockRealMatrix10.getColumn((int) ' ');
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix12.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix18.scalarMultiply((double) 10.0f);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix22);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix2.multiply(blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace(",", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float float1 = org.apache.commons.math3.util.FastMath.abs(9.536743E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 0, 1072693248);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector9.mapToSelf(univariateFunction13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.append(arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector20);
        double double22 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship24 = relationship23.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint26 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector21, relationship24, (double) 0.0f);
        boolean boolean27 = pointValuePair4.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship24 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship24.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(5.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0000005f + "'", float1 == 5.0000005f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector32.append(arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector26.append((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector39);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction43 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector39.mapToSelf(univariateFunction43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector46.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector45.append(arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        try {
            double double54 = arrayRealVector7.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNull(doubleArray1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "{", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "{}", "{}");
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        try {
            org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix14.getColumnVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.createMatrix((int) (short) -1, (-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        double[][] doubleArray4 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.scalarMultiply((double) 10.0f);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) 100L, true);
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, 0.27675392434470114d, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector31);
        double double33 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.optimization.linear.Relationship relationship34 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship35 = relationship34.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint37 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector32, relationship35, (double) 0.0f);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint39 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray9, relationship35, 10.0d);
        try {
            blockRealMatrix2.setRow(100, doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship34 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship34.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship35 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship35.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double double23 = arrayRealVector18.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction30 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector26.mapToSelf(univariateFunction30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector32.append(arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24, arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector38.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 52);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (-0.17260374626909167d), (java.lang.Object[]) doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0L + "'", number3.equals(0L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(Double.POSITIVE_INFINITY, 9.5367431640625E-7d, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix4.walkInOptimizedOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 0.0f, ' ' };
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[][] doubleArray14 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.ZeroException zeroException16 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14, false);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix0.add(array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 4x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.0d + "'", number2.equals(1.0d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(99.99999999999999d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        double double8 = blockRealMatrix7.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 5L, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9765625.0d + "'", double2 == 9765625.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("hi!", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        try {
            double double21 = array2DRowRealMatrix17.getEntry((-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction12 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector8.mapToSelf(univariateFunction12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.append(arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector20.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector29.append(arrayRealVector30);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction34 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector30.mapToSelf(univariateFunction34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector36.append(arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, arrayRealVector36);
        double double42 = arrayRealVector28.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double[] doubleArray43 = arrayRealVector36.getDataRef();
        try {
            double[] doubleArray44 = blockRealMatrix2.preMultiply(doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) ' ', (float) (-1233437887), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double19 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) (-1233437887), 35.00000000000001d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix2.getColumnVector(52);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double3 = org.apache.commons.math3.util.Precision.round(0.0d, 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 29);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.385164807134504d + "'", double1 == 5.385164807134504d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        double[] doubleArray6 = pointValuePair4.getFirst();
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 100L, true);
        double[] doubleArray12 = pointValuePair11.getFirst();
        double[] doubleArray13 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        org.apache.commons.math3.linear.RealVector realVector5 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray1);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, 0.27675392434470114d, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.append(arrayRealVector12);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction16 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.mapToSelf(univariateFunction16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector10, arrayRealVector23);
        double double25 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.optimization.linear.Relationship relationship26 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship27 = relationship26.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector24, relationship27, (double) 0.0f);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint31 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray1, relationship27, 10.0d);
        org.apache.commons.math3.optimization.linear.Relationship relationship32 = relationship27.oppositeRelationship();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship26 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship26.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship27 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship27.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship32 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship32.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.4365636569180902d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4365636569180902d + "'", double2 == 1.4365636569180902d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.append(arrayRealVector12);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction16 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.mapToSelf(univariateFunction16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector10, arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector27.append(arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector24.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        try {
            blockRealMatrix2.setRowVector(1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "hi!");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray25 = array2DRowRealMatrix24.getDataRef();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix22.multiply(array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNull(doubleArray25);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        try {
            arrayRealVector17.addToEntry((int) (byte) 10, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor26 = null;
        try {
            double double31 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor26, 2, (int) 'a', 29, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector13.mapAddToSelf((double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector19.mapToSelf(univariateFunction23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector32.append(arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.append(arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector31, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector48.append(arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector45.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        boolean boolean54 = arrayRealVector49.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector30.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, (org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(arrayRealVector55);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0.0f, (double) (short) 0, (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        try {
            blockRealMatrix2.addToEntry((-1233437887), 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        double[] doubleArray11 = blockRealMatrix9.getColumn((int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.subtract(realMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 267.7467614837482d, 4.8828124514936193E-4d, 35.0d, 1.0726932479999999E9d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 96 is larger than the maximum (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (short) 100, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        int[] intArray13 = new int[] { '#', 1, 52 };
        int[] intArray14 = new int[] {};
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, intArray13, intArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        try {
            arrayRealVector7.addToEntry(0, 0.27675392434470114d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix2.getColumnMatrix(2);
        org.apache.commons.math3.linear.RealVector realVector12 = blockRealMatrix2.getColumnVector(52);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix2.getSubMatrix((int) (short) 10, 52, (-1233437887), 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = null;
        try {
            blockRealMatrix4.setColumnMatrix((int) (byte) 10, realMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.subtract(blockRealMatrix25);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = blockRealMatrix26.walkInOptimizedOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int2 = org.apache.commons.math3.util.FastMath.min(100, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(97, 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Throwable[] throwableArray0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getWrongDimensions();
        org.apache.commons.math3.util.Pair<java.lang.Throwable[], org.apache.commons.math3.linear.MatrixDimensionMismatchException> throwableArrayPair7 = new org.apache.commons.math3.util.Pair<java.lang.Throwable[], org.apache.commons.math3.linear.MatrixDimensionMismatchException>(throwableArray0, matrixDimensionMismatchException5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) -1, 97);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(",", "hi!", "");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix((int) (byte) 1, (int) '4');
        double[][] doubleArray4 = array2DRowRealMatrix0.getData();
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass15 = arrayRealVector12.getClass();
        double double16 = arrayRealVector12.getLInfNorm();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix22.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector29.append(arrayRealVector30);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction34 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector30.mapToSelf(univariateFunction34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector36.append(arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28, arrayRealVector41);
        arrayRealVector28.set(0.9988551111734393d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector46.append(arrayRealVector47);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction51 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector47.mapToSelf(univariateFunction51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector54.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector53.append(arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector45, arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector63.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector62.append(arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector59.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector69.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector68.append(arrayRealVector69);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction73 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector69.mapToSelf(univariateFunction73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector75.append(arrayRealVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector69, arrayRealVector75);
        double double81 = arrayRealVector67.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        double[] doubleArray82 = arrayRealVector75.getDataRef();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction84 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector75, (double) (short) 100);
        double double85 = arrayRealVector28.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        try {
            org.apache.commons.math3.linear.RealVector realVector86 = array2DRowRealMatrix22.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(arrayRealVector79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 29, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double2 = org.apache.commons.math3.util.Precision.round(0.7071067811865476d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray1 = new double[] { (short) 10 };
        org.apache.commons.math3.optimization.linear.Relationship relationship3 = null;
        double[] doubleArray8 = new double[] { 0.0f, 100.0d, 100L, 1.0d };
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint10 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray1, 1.0d, relationship3, doubleArray8, (double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector11 = linearConstraint10.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 97, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray6 = pointValuePair4.getPoint();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = maxCountExceededException8.getContext();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) exceptionContext9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) 100L, true);
        java.lang.Double double16 = pointValuePair15.getSecond();
        boolean boolean17 = pointValuePair4.equals((java.lang.Object) pointValuePair15);
        java.lang.Double double18 = pointValuePair4.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18.equals(100.0d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        double[] doubleArray19 = null;
        try {
            double[] doubleArray20 = blockRealMatrix2.operate(doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        double[][] doubleArray7 = blockRealMatrix4.getData();
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) 100L, true);
        java.lang.Double double13 = pointValuePair12.getSecond();
        double[] doubleArray14 = pointValuePair12.getKey();
        try {
            double[] doubleArray15 = blockRealMatrix4.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        double[] doubleArray11 = blockRealMatrix9.getColumn((int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.append(arrayRealVector16);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.mapToSelf(univariateFunction20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector22.append(arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14, arrayRealVector27);
        double double29 = arrayRealVector13.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.optimization.linear.Relationship relationship30 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = relationship30.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint33 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector28, relationship31, (double) 0.0f);
        double[] doubleArray40 = new double[] { 1, 10, (-1), (byte) 1, Double.NaN, 100.0f };
        int int41 = org.apache.commons.math3.util.MathUtils.hash(doubleArray40);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint43 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray11, (double) 100L, relationship31, doubleArray40, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship30 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship30.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1233437887) + "'", int41 == (-1233437887));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector14.mapSubtractToSelf((double) 100.0f);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor5, (int) (byte) 10, (int) (byte) 1, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 10 after final row 1");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08726646259971647d + "'", double1 == 0.08726646259971647d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        arrayRealVector0.set(0.9988551111734393d);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector0.mapSubtractToSelf((double) 1);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        double[] doubleArray11 = blockRealMatrix9.getColumn((int) ' ');
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.apache.commons.math3.util.FastMath.min(52, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9589242746631385d) + "'", double1 == (-0.9589242746631385d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = blockRealMatrix8.scalarMultiply((double) 10.0f);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) realMatrix12);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, 2, (int) (short) 0, 0, 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 2 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 1072693248, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.002165675163269d) + "'", double2 == (-1.002165675163269d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.text.NumberFormat numberFormat9 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", ",", "{}", "", ",", "{}", numberFormat9);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat(",", "{}", "{", numberFormat9);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = realVectorFormat11.parse("{}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int8 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        try {
            blockRealMatrix6.setEntry((int) (short) 10, 0, 0.7853981633974483d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794630987664d + "'", double1 == 0.3678794630987664d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        try {
            double double12 = blockRealMatrix9.getEntry((int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 52, (java.lang.Number) 5.0000005f, (java.lang.Number) 0.1432705801223346d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        double[][] doubleArray27 = null;
        try {
            array2DRowRealMatrix22.setSubMatrix(doubleArray27, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(9.536743E-7f, (float) (-1233437887), 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        double[] doubleArray24 = new double[] { 0.0f, 1, 100.0d, 10L };
        org.apache.commons.math3.optimization.linear.Relationship relationship25 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint27 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray24, relationship25, (double) 0L);
        try {
            blockRealMatrix18.setRow(2, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x4 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver0 = new org.apache.commons.math3.optimization.linear.SimplexSolver();
        int int1 = simplexSolver0.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.4365636569180902d, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.072693248E9d + "'", double2 == 1.072693248E9d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.08726646259971647d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1968247711 + "'", int1 == 1968247711);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        java.lang.Class<?> wildcardClass5 = blockRealMatrix4.getClass();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        double[] doubleArray20 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) 100L, true);
        java.lang.Double double24 = pointValuePair23.getSecond();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray27 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) 100L, true);
        double[] doubleArray31 = pointValuePair30.getFirst();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, doubleArray32);
        try {
            double[] doubleArray34 = array2DRowRealMatrix17.operate(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 147.4131591025766d + "'", double1 == 147.4131591025766d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 3.1622776601683795d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        double[] doubleArray6 = pointValuePair4.getKey();
        double[] doubleArray7 = pointValuePair4.getKey();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) 36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.getColumnMatrix(0);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) 100L, true);
        java.lang.Double double18 = pointValuePair17.getSecond();
        double[] doubleArray19 = pointValuePair17.getFirst();
        double[] doubleArray21 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair24 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) 100L, true);
        double[] doubleArray25 = pointValuePair24.getFirst();
        double[] doubleArray26 = pointValuePair24.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, doubleArray26);
        try {
            blockRealMatrix11.setColumn(1, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) ' ', (int) 'a', doubleArray16, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1,664");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(10, 52);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        arrayRealVector0.set(0.9988551111734393d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int2 = org.apache.commons.math3.util.FastMath.min(2, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(5.385164807134504d);
        org.apache.commons.math3.linear.RealVector realVector17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.ebeMultiply(realVector17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getRowMatrix(5);
        try {
            double[] doubleArray9 = blockRealMatrix7.getRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.subtract(blockRealMatrix25);
        double[] doubleArray28 = blockRealMatrix25.getRow(1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) ' ');
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) (-1L));
        double double28 = arrayRealVector18.dotProduct(realVector27);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.mapToSelf(univariateFunction5);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix5.getColumnMatrix(10);
        try {
            array2DRowRealMatrix0.setRowMatrix((int) (byte) -1, realMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNull(doubleArray1);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 10, number2, (java.lang.Number) (-0.9589242746631385d));
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix22.walkInRowOrder(realMatrixPreservingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass32 = arrayRealVector29.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector56.append(arrayRealVector57);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.mapToSelf(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        double double69 = arrayRealVector55.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray75 = blockRealMatrix74.getData();
        int int76 = blockRealMatrix74.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix74.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix74.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector71.append(realVector80);
        double[] doubleArray82 = arrayRealVector71.getDataRef();
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 52 + "'", int76 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        int int5 = blockRealMatrix2.getRowDimension();
        int[] intArray8 = new int[] { 100, (short) 1 };
        int[] intArray10 = new int[] { 0 };
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        org.apache.commons.math3.exception.util.Localizable localizable14 = null;
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] { 0.0f, ' ' };
        double[] doubleArray21 = new double[] { 0.0f, ' ' };
        double[] doubleArray24 = new double[] { 0.0f, ' ' };
        double[] doubleArray27 = new double[] { 0.0f, ' ' };
        double[][] doubleArray28 = new double[][] { doubleArray18, doubleArray21, doubleArray24, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException(localizable15, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math3.exception.MathArithmeticException(localizable14, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException32 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable12, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math3.exception.ZeroException zeroException33 = new org.apache.commons.math3.exception.ZeroException(localizable11, (java.lang.Object[]) doubleArray28);
        try {
            blockRealMatrix2.copySubMatrix(intArray8, intArray10, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector7 = blockRealMatrix5.getColumnVector(0);
        double[][] doubleArray8 = blockRealMatrix5.getData();
        double[] doubleArray10 = blockRealMatrix5.getRow(0);
        try {
            double[] doubleArray11 = array2DRowRealMatrix0.preMultiply(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        try {
            int int9 = matrixDimensionMismatchException4.getWrongDimension(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 267.7467614837482d, 4.8828124514936193E-4d, 35.0d, 1.0726932479999999E9d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) -1, (int) '4');
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) '4', (-1233437887));
        int int4 = dimensionMismatchException3.getDimension();
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1233437887) + "'", int4 == (-1233437887));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math3.util.FastMath.log((-0.17260374626909167d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass32 = arrayRealVector29.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector56.append(arrayRealVector57);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.mapToSelf(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        double double69 = arrayRealVector55.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray75 = blockRealMatrix74.getData();
        int int76 = blockRealMatrix74.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix74.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix74.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector71.append(realVector80);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor82 = null;
        try {
            double double83 = arrayRealVector71.walkInOptimizedOrder(realVectorPreservingVisitor82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 52 + "'", int76 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector81);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(1.1189396031849523d, (int) (byte) 0);
        int int3 = simplexSolver2.getIterations();
        simplexSolver2.setMaxIterations((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.9155040003582885E22d, (double) (-0.99999994f), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (-1233437887));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.233437887E9d) + "'", double1 == (-1.233437887E9d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(10, 52);
        int[] intArray5 = new int[] { 0, (byte) 10 };
        int[] intArray8 = new int[] { 1072693248, (short) -1 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.getSubMatrix(intArray5, intArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.subtract(blockRealMatrix25);
        boolean boolean27 = blockRealMatrix9.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        try {
            double double16 = arrayRealVector0.getEntry((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix22.copy();
        array2DRowRealMatrix22.setEntry((int) (short) 1, (int) (byte) 0, (double) 5.0000005f);
        try {
            double[] doubleArray33 = array2DRowRealMatrix22.getRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        org.apache.commons.math3.linear.RealVector realVector5 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray1);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, 0.27675392434470114d, false);
        java.lang.Double double9 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.27675392434470114d + "'", double9.equals(0.27675392434470114d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray8 = blockRealMatrix7.getData();
        int int9 = blockRealMatrix7.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix7.getRowMatrix(10);
        double double12 = blockRealMatrix7.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix7.scalarAdd(100.0d);
        double[] doubleArray16 = blockRealMatrix14.getColumn((int) 'a');
        double[][] doubleArray17 = blockRealMatrix14.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray6 = pointValuePair4.getPoint();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = maxCountExceededException8.getContext();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) exceptionContext9);
        double[] doubleArray11 = pointValuePair4.getFirst();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 4.8828124514936193E-4d, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        java.lang.Double double6 = pointValuePair4.getSecond();
        java.lang.Double double7 = pointValuePair4.getValue();
        double[] doubleArray8 = pointValuePair4.getKey();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.99999994f), (java.lang.Number) 1.0000001f, number3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.util.MathUtils.checkFinite((-1.002165675163269d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double[] doubleArray8 = new double[] { (short) 10 };
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = null;
        double[] doubleArray15 = new double[] { 0.0f, 100.0d, 100L, 1.0d };
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint17 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray8, 1.0d, relationship10, doubleArray15, (double) 0.0f);
        try {
            double[] doubleArray18 = blockRealMatrix2.operate(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getKey();
        double[] doubleArray6 = pointValuePair4.getKey();
        java.lang.Double double7 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7.equals(100.0d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix10, 2, 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix2.add(realMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 100x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.000004f + "'", float1 == 52.000004f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math3.util.FastMath.log((-1.233437887E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
        java.lang.Class<?> wildcardClass1 = nullArgumentException0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(572.9577951308232d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 572.9577951308232d + "'", double2 == 572.9577951308232d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        int int23 = arrayRealVector14.getMinIndex();
        double double24 = arrayRealVector14.getLInfNorm();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor25 = null;
        try {
            double double26 = arrayRealVector14.walkInDefaultOrder(realVectorPreservingVisitor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1072693248, (java.lang.Number) (byte) 0, (java.lang.Number) 1L);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 0.0f, ' ' };
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[][] doubleArray14 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        java.lang.Object[] objArray16 = new java.lang.Object[] { realMatrix15 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray16);
        try {
            java.lang.String str19 = zeroException18.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 3.1622776601683795d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor5, (int) '#', 100, 36, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        double[] doubleArray6 = pointValuePair4.getFirst();
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 100L, true);
        double[] doubleArray12 = pointValuePair11.getFirst();
        double[] doubleArray13 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor15 = null;
        try {
            double double18 = arrayRealVector14.walkInDefaultOrder(realVectorChangingVisitor15, (int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(10);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        double[] doubleArray11 = blockRealMatrix9.getColumn((int) 'a');
        double[][] doubleArray12 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double18 = blockRealMatrix9.walkInColumnOrder(realMatrixPreservingVisitor13, (int) '#', 97, (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = relationship17.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector15, relationship18, (double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector21 = linearConstraint20.getCoefficients();
        org.apache.commons.math3.linear.RealVector realVector22 = linearConstraint20.getCoefficients();
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 'a', (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{", ",", "hi!");
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix22.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix4.getRowVector((int) (byte) 10);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix4.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix8, (int) (short) 1, 0, 52, (-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarAdd((double) (byte) 100);
        java.io.ObjectInputStream objectInputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) realMatrix8, "}", objectInputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = relationship17.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector15, relationship18, (double) 0.0f);
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = linearConstraint20.getRelationship();
        org.apache.commons.math3.linear.RealVector realVector22 = linearConstraint20.getCoefficients();
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector24.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector30);
        double double36 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray37 = arrayRealVector30.getDataRef();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction39 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector30, (double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.append(arrayRealVector41);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction45 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector41.mapToSelf(univariateFunction45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector47.append(arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector55.append(arrayRealVector56);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction60 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector56.mapToSelf(univariateFunction60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector63.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector62.append(arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector56, arrayRealVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector69.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector68.append(arrayRealVector69);
        org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector62.append((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, arrayRealVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, (org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector30.copy();
        int int77 = arrayRealVector76.getMinIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) '#', (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix6.multiply(blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector24.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector30);
        double double36 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        boolean boolean38 = arrayRealVector22.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector22.mapMultiplyToSelf(572.9577951308232d);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction42 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector40, 0.7853981633974483d);
        double[] doubleArray49 = new double[] { (-0.99999994f), 1.1102230246251565E-16d, 5.385164807134504d, 1.0f, 0.0f, 0.27675392434470114d };
        try {
            double double50 = linearObjectiveFunction42.getValue(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector7 = null;
        try {
            blockRealMatrix5.setColumnVector((int) (short) 1, realVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(0, (int) 'a');
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix4.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] { 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 0.0f, ' ' };
        double[] doubleArray20 = new double[] { 0.0f, ' ' };
        double[][] doubleArray21 = new double[][] { doubleArray11, doubleArray14, doubleArray17, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable8, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, false);
        try {
            blockRealMatrix4.setSubMatrix(doubleArray21, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction29 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector25.mapToSelf(univariateFunction29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector31.append(arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.append(arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector37.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        double double46 = arrayRealVector41.getLInfNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix22, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(1, (int) ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 5, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapMultiplyToSelf(0.9988551111734393d);
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2924316695611777d + "'", double1 == 2.2924316695611777d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 360.0d, (java.lang.Number) 2.2250738585072014E-308d, false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        double[] doubleArray9 = null;
        try {
            double[] doubleArray10 = blockRealMatrix8.operate(doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarAdd((double) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector31);
        arrayRealVector18.set(0.9988551111734393d);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector18.append((double) (byte) -1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 52 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 100.0f, 29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }
}

