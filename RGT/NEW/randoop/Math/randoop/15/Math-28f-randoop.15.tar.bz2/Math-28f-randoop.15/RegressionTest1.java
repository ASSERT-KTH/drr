import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 0.0f, ' ' };
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[][] doubleArray14 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.ZeroException zeroException16 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14, false);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = nullArgumentException19.getContext();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix2.getRowVector((int) '#');
        double[][] doubleArray9 = blockRealMatrix2.getData();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        int int5 = blockRealMatrix4.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix14.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray19 = blockRealMatrix18.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix14.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix20.createMatrix(5, 10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix4.multiply(blockRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        boolean boolean5 = blockRealMatrix2.isSquare();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException7 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray8 = matrixDimensionMismatchException7.getExpectedDimensions();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) (short) -1, (java.lang.Object[]) intArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray8);
        java.lang.Throwable[] throwableArray11 = zeroException10.getSuppressed();
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix2.getRowVector(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.getColumnMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 29, 5.1771933557663626E-8d, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 1L, 0.0d, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector24.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector30);
        double double36 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray37 = arrayRealVector30.getDataRef();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction39 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector30, (double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction46 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector42.mapToSelf(univariateFunction46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector48.append(arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector40, arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector57.append(arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector54.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        double double63 = arrayRealVector58.getLInfNorm();
        double double64 = linearObjectiveFunction39.getValue((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.0d + "'", double64 == 100.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 100);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.tan(2.2924316695611777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1364083366959243d) + "'", double1 == (-1.1364083366959243d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarAdd((double) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix23.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray28 = blockRealMatrix27.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix23.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix29, 0);
        try {
            blockRealMatrix15.setRowMatrix((int) ' ', (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix2.getColumnMatrix(2);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix10, (int) (byte) 1, 100, 10, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(100.0f, (float) (-1), (float) (-1233437887));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector24.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector30);
        double double36 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        boolean boolean38 = arrayRealVector22.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector22.mapMultiplyToSelf(572.9577951308232d);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction42 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector40, 0.7853981633974483d);
        try {
            org.apache.commons.math3.linear.RealVector realVector43 = realVector40.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Throwable[] throwableArray6 = matrixDimensionMismatchException4.getSuppressed();
        int int7 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int8 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        double[][] doubleArray6 = blockRealMatrix4.getData();
        double[] doubleArray8 = blockRealMatrix4.getColumn((int) (byte) 0);
        double[] doubleArray15 = new double[] { 1, 10, (-1), (byte) 1, Double.NaN, 100.0f };
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray15);
        try {
            double[] doubleArray17 = blockRealMatrix4.operate(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1233437887) + "'", int16 == (-1233437887));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector19.mapToSelf(univariateFunction23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.append(arrayRealVector41);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction45 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector41.mapToSelf(univariateFunction45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector47.append(arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, arrayRealVector47);
        double double53 = arrayRealVector39.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        double[] doubleArray54 = arrayRealVector47.getDataRef();
        try {
            blockRealMatrix4.setRow((int) (byte) 0, doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor19 = null;
        try {
            double double20 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.27675392434470114d, true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        double[] doubleArray15 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) 100L, true);
        double[] doubleArray19 = pointValuePair18.getKey();
        try {
            arrayRealVector7.setSubVector((int) '4', doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor6, (int) (byte) -1, 29, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", ",", "{}", "", ",", "{}", numberFormat6);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        java.text.ParsePosition parsePosition10 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = realVectorFormat8.parse(",", parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 1L, 1.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.createMatrix(5, 10);
        double[][] doubleArray19 = blockRealMatrix14.getData();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(1.5430806348152437d, (int) (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.subtract(blockRealMatrix25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector28.append(arrayRealVector29);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction33 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector29.mapToSelf(univariateFunction33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector36.append(arrayRealVector37);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction41 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector37.mapToSelf(univariateFunction41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector43.append(arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector35, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector52.append(arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector49.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        double double58 = arrayRealVector53.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector29.append((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        try {
            blockRealMatrix26.setRowVector(100, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(29.00114488882656d, 9.5367431640625E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.001144888826556d + "'", double2 == 29.001144888826556d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getKey();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1079574559 + "'", int8 == 1079574559);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor19 = null;
        try {
            double double24 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixPreservingVisitor19, 100, (int) (short) -1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        try {
            org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix14.getColumnVector((-1233437887));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,233,437,887)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix18.getColumnMatrix(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        int int28 = blockRealMatrix15.getColumnDimension();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(97, (int) (byte) 10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = nonSquareMatrixException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        double[] doubleArray11 = blockRealMatrix9.getColumn((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply(267.7467614837482d);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 'a', (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 52.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866269702728209d + "'", double1 == 0.9866269702728209d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray6 = pointValuePair4.getPoint();
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair7 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        java.lang.Double double8 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8.equals(100.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass32 = arrayRealVector29.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector56.append(arrayRealVector57);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.mapToSelf(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        double double69 = arrayRealVector55.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray75 = blockRealMatrix74.getData();
        int int76 = blockRealMatrix74.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix74.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix74.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector71.append(realVector80);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector71.mapSubtract((double) 4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 52 + "'", int76 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(realVector83);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        int int19 = blockRealMatrix18.getColumnDimension();
        java.lang.Class<?> wildcardClass20 = blockRealMatrix18.getClass();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException5.getExpectedDimensions();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) intArray7);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        int int5 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix14.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray19 = blockRealMatrix18.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix14.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix24.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray29 = blockRealMatrix28.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = blockRealMatrix24.getColumnMatrix(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        java.text.ParsePosition parsePosition6 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = realVectorFormat3.parse("{}", parsePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix2.getColumnMatrix(2);
        org.apache.commons.math3.linear.RealVector realVector12 = blockRealMatrix2.getColumnVector(52);
        int int13 = blockRealMatrix2.getRowDimension();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix9.getColumnMatrix(0);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix5.scalarAdd((double) 1072693248);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) 1, 52);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getRowSuffix();
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.scalarMultiply((double) 10.0f);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor7, 52, 4, (-1), 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add(blockRealMatrix14);
        double[][] doubleArray19 = blockRealMatrix18.getData();
        double[] doubleArray23 = new double[] { 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 0.0f, ' ' };
        double[] doubleArray29 = new double[] { 0.0f, ' ' };
        double[] doubleArray32 = new double[] { 0.0f, ' ' };
        double[][] doubleArray33 = new double[][] { doubleArray23, doubleArray26, doubleArray29, doubleArray32 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray33);
        try {
            blockRealMatrix18.setColumnMatrix(1, realMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x2 but expected 52x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.text.NumberFormat numberFormat9 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", ",", "{}", "", ",", "{}", numberFormat9);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat(",", "{}", "{", numberFormat9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix14.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray19 = blockRealMatrix18.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix14.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix14.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = blockRealMatrix26.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix14.add(blockRealMatrix26);
        double[][] doubleArray31 = blockRealMatrix30.getData();
        org.apache.commons.math3.util.Pair<java.text.Format, double[][]> formatPair32 = new org.apache.commons.math3.util.Pair<java.text.Format, double[][]>((java.text.Format) numberFormat9, doubleArray31);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat33 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 1, 2.2250738585072014E-308d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector27.append(arrayRealVector28);
        try {
            double double32 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = blockRealMatrix8.getColumnMatrix(10);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 5.0000005f, 0.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 0, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 5.0000005f, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.283184830342428d) + "'", double2 == (-1.283184830342428d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix4.getColumnVector(0);
        double[][] doubleArray7 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix4.scalarMultiply((double) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 35.0d, number1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.scalarAdd((double) 100);
        try {
            blockRealMatrix9.setRowMatrix((int) (short) 10, blockRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 52x100 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.append(arrayRealVector15);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction19 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector15.mapToSelf(univariateFunction19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector21.append(arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector13, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector27.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        boolean boolean36 = arrayRealVector31.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector12.mapDivideToSelf(29.00114488882656d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix42.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealVector realVector46 = blockRealMatrix44.getColumnVector(0);
        try {
            double double47 = arrayRealVector12.getL1Distance(realVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray8 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int9 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        int int23 = arrayRealVector14.getMinIndex();
        double double24 = arrayRealVector14.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector14.mapAdd(2.718281828459045d);
        java.lang.Class<?> wildcardClass27 = realVector26.getClass();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        try {
            array2DRowRealMatrix18.multiplyEntry(2, 1079574559, 0.08726646259971647d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,079,574,559)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(0, 100);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        double[][] doubleArray8 = blockRealMatrix6.getData();
        double[] doubleArray10 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) 100L, true);
        double[] doubleArray14 = pointValuePair13.getKey();
        double[] doubleArray15 = pointValuePair13.getKey();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix6.subtract(realMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x100 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass15 = arrayRealVector12.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector33.append(arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.append(arrayRealVector40);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction44 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.mapToSelf(univariateFunction44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector46.append(arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        double double52 = arrayRealVector38.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        double double53 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        arrayRealVector12.set((double) 10);
        java.lang.String str56 = arrayRealVector12.toString();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{}" + "'", str56.equals("{}"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) 100L, true);
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair31 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, 0.27675392434470114d, false);
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        try {
            blockRealMatrix21.setRowVector((int) (byte) 0, realVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 1x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        try {
            blockRealMatrix6.multiplyEntry((int) 'a', (int) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix22.copy();
        array2DRowRealMatrix22.setEntry((int) (short) 1, (int) (byte) 0, (double) 5.0000005f);
        try {
            array2DRowRealMatrix22.setEntry(0, 1079574559, (double) 1968247711);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,079,574,559)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 35.0d, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 35.0d + "'", number4.equals(35.0d));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.text.NumberFormat numberFormat15 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat16 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", ",", "{}", "", ",", "{}", numberFormat15);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat17 = new org.apache.commons.math3.linear.RealVectorFormat(",", "{}", "{", numberFormat15);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat18 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", "{}", "hi!", "", "hi!", "{", numberFormat15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix21.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray26 = blockRealMatrix25.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix21.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix21.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = blockRealMatrix33.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = blockRealMatrix33.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix21.add(blockRealMatrix33);
        double[][] doubleArray38 = blockRealMatrix37.getData();
        java.lang.StringBuffer stringBuffer39 = null;
        java.text.FieldPosition fieldPosition40 = null;
        try {
            java.lang.StringBuffer stringBuffer41 = realMatrixFormat18.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37, stringBuffer39, fieldPosition40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        double[] doubleArray25 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) 100L, true);
        java.lang.Double double29 = pointValuePair28.getSecond();
        double[] doubleArray30 = pointValuePair28.getKey();
        double[] doubleArray31 = pointValuePair28.getKey();
        try {
            double[] doubleArray32 = array2DRowRealMatrix22.preMultiply(doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 267.7467614837482d, 4.8828124514936193E-4d, 35.0d, 1.0726932479999999E9d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        boolean boolean6 = arrayRealVector5.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-0.7853981633974483d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor23 = null;
        try {
            double double26 = arrayRealVector18.walkInOptimizedOrder(realVectorPreservingVisitor23, (int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix2.getRowVector((int) '#');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor9, (int) '4', 0, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        double[] doubleArray6 = pointValuePair4.getFirst();
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 100L, true);
        double[] doubleArray12 = pointValuePair11.getFirst();
        double[] doubleArray13 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector33.append(arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.append(arrayRealVector40);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction44 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.mapToSelf(univariateFunction44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector46.append(arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        double double52 = arrayRealVector38.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        boolean boolean54 = arrayRealVector38.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector38.mapMultiplyToSelf(572.9577951308232d);
        try {
            arrayRealVector14.setSubVector(29, (org.apache.commons.math3.linear.RealVector) arrayRealVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (29)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 1, 10, (-1), (byte) 1, Double.NaN, 100.0f };
        int int40 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector43.append(arrayRealVector44);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction48 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector44.mapToSelf(univariateFunction48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44, arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector42, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector60.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector59.append(arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector56.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector60);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1233437887) + "'", int40 == (-1233437887));
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertNotNull(arrayRealVector64);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((-1.1364083366959243d), 1072693248);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        double double7 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.scalarAdd(100.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = blockRealMatrix14.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.subtract(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray30 = blockRealMatrix29.getData();
        try {
            blockRealMatrix9.setSubMatrix(doubleArray30, 5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (56)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 36, (double) '#', (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(1.1189396031849523d, (int) (byte) 0);
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 1.1189396031849523d, "hi!", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarAdd((double) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getRowMatrix(10);
        double[][] doubleArray20 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.RealVector realVector24 = realVector22.mapDivide((double) 97);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.append(arrayRealVector15);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction19 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector15.mapToSelf(univariateFunction19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector21.append(arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector13, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector30.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector27.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        boolean boolean36 = arrayRealVector31.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double[] doubleArray38 = arrayRealVector31.getDataRef();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, 0.0d, false);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = blockRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor8, 36, 5, (int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) 0, 5);
        int int3 = simplexSolver2.getIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Integer[] intArray8 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int9 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int10 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat1.parse(",", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.Throwable[] throwableArray6 = matrixDimensionMismatchException4.getSuppressed();
        int int7 = matrixDimensionMismatchException4.getWrongRowDimension();
        int int8 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = matrixDimensionMismatchException4.getContext();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) '4', 5, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) '#', (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) 100L, true);
        java.lang.Double double5 = pointValuePair4.getSecond();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.apache.commons.math3.optimization.linear.Relationship relationship7 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint9 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray6, relationship7, (double) (short) 100);
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = linearConstraint9.getRelationship();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNull(relationship10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector14.getSubVector(1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) '4', (-1233437887));
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException3, localizable5, objArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1233437887) + "'", int4 == (-1233437887));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        int int26 = array2DRowRealMatrix22.getColumnDimension();
        int int27 = array2DRowRealMatrix22.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray31 = blockRealMatrix30.getData();
        int int32 = blockRealMatrix30.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix30.getRowMatrix(10);
        double double35 = blockRealMatrix30.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix22, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x2 but expected 52x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", ",", "{}");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix6.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix8.transpose();
        double[][] doubleArray10 = blockRealMatrix8.getData();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.RealVectorFormat, java.lang.Object[]> realVectorFormatPair11 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.RealVectorFormat, java.lang.Object[]>(realVectorFormat3, (java.lang.Object[]) doubleArray10);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.872202904151208E7d + "'", double1 == 1.872202904151208E7d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        arrayRealVector0.set(0.9988551111734393d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector19.mapToSelf(univariateFunction23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.append(arrayRealVector41);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction45 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector41.mapToSelf(univariateFunction45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector47.append(arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, arrayRealVector47);
        double double53 = arrayRealVector39.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        double[] doubleArray54 = arrayRealVector47.getDataRef();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction56 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector47, (double) (short) 100);
        double double57 = arrayRealVector0.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor58 = null;
        try {
            double double61 = arrayRealVector47.walkInOptimizedOrder(realVectorPreservingVisitor58, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.lang.Throwable[] throwableArray3 = maxCountExceededException1.getSuppressed();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.text.NumberFormat numberFormat7 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", ",", "{}", "", ",", "{}", numberFormat7);
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Number number10 = org.apache.commons.math3.util.CompositeFormat.parseNumber(",", numberFormat7, parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = relationship17.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector15, relationship18, (double) 0.0f);
        java.lang.String str21 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector22.append(arrayRealVector23);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction27 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector23.mapToSelf(univariateFunction27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector29.append(arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector37.append(arrayRealVector38);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction42 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector38.mapToSelf(univariateFunction42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector44.append(arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector44.append((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector15.add((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{}" + "'", str21.equals("{}"));
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector57);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarAdd((double) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getRowMatrix(10);
        double[][] doubleArray20 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double28 = blockRealMatrix15.walkInRowOrder(realMatrixChangingVisitor23, 5, (int) (short) -1, (-1), 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0d, (java.lang.Number) 1.5430806348152437d, false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.append(arrayRealVector14);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.append(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray39 = new double[] { 1, 10, (-1), (byte) 1, Double.NaN, 100.0f };
        int int40 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector43.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector42.append(arrayRealVector43);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction47 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector43.mapToSelf(univariateFunction47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector49.append(arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector55.append(arrayRealVector56);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector49.append((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector61.append(arrayRealVector62);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction66 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector62.mapToSelf(univariateFunction66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector69.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector68.append(arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62, arrayRealVector68);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector73.mapDivide((double) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector59.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector17.append((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1233437887) + "'", int40 == (-1233437887));
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector77);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        arrayRealVector12.set(1.072693248E9d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.append(arrayRealVector19);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector19.mapToSelf(univariateFunction23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.combineToSelf((double) 10L, 100.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction46 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector42.mapToSelf(univariateFunction46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector48.append(arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector40, arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector57.append(arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector54.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction68 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector64.mapToSelf(univariateFunction68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector71.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector70.append(arrayRealVector71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector64, arrayRealVector70);
        double double76 = arrayRealVector62.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        double double77 = arrayRealVector39.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector39.mapSubtract((double) 100.0f);
        double double80 = arrayRealVector12.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        double[] doubleArray81 = arrayRealVector39.toArray();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(arrayRealVector74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 9.536743E-7f, (java.lang.Number) 100.0f, (java.lang.Number) 1.1189396031849523d);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix20.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = blockRealMatrix20.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix8.add(blockRealMatrix20);
        double[][] doubleArray25 = blockRealMatrix24.getData();
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException4, localizable5, (java.lang.Object[]) doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray23 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix18.getColumnMatrix(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix27.transpose();
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math3.util.FastMath.sin(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865475d + "'", double1 == 0.7071067811865475d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor26 = null;
        try {
            double double27 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        int int4 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix13.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = blockRealMatrix13.scalarAdd(0.8414709848078965d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        int[] intArray22 = new int[] { 10, 4, 'a', '4' };
        int[] intArray23 = new int[] {};
        double[] doubleArray28 = new double[] { (-1.0d), (byte) -1, (byte) 100, (-0.7853981633974483d) };
        double[] doubleArray33 = new double[] { (-1.0d), (byte) -1, (byte) 100, (-0.7853981633974483d) };
        double[] doubleArray38 = new double[] { (-1.0d), (byte) -1, (byte) 100, (-0.7853981633974483d) };
        double[] doubleArray43 = new double[] { (-1.0d), (byte) -1, (byte) 100, (-0.7853981633974483d) };
        double[] doubleArray48 = new double[] { (-1.0d), (byte) -1, (byte) 100, (-0.7853981633974483d) };
        double[][] doubleArray49 = new double[][] { doubleArray28, doubleArray33, doubleArray38, doubleArray43, doubleArray48 };
        try {
            blockRealMatrix13.copySubMatrix(intArray22, intArray23, doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) 'a', (int) 'a');
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException8 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray9 = matrixDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray10 = matrixDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray11 = matrixDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray12 = matrixDimensionMismatchException8.getExpectedDimensions();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonSquareMatrixException2, localizable3, (java.lang.Object[]) intArray12);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix4.scalarMultiply((double) 10.0f);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        try {
            java.lang.StringBuffer stringBuffer11 = realMatrixFormat0.format(realMatrix8, stringBuffer9, fieldPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(97, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 0.0f, ' ' };
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[][] doubleArray18 = array2DRowRealMatrix17.getData();
        try {
            double double21 = array2DRowRealMatrix17.getEntry((int) (byte) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray6 = new double[] { 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double25 = array2DRowRealMatrix22.getEntry(0, (int) (short) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix22.createMatrix((int) 'a', (int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException7 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', 52, (int) (short) 100, 52);
        java.lang.Integer[] intArray8 = matrixDimensionMismatchException7.getExpectedDimensions();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) (short) -1, (java.lang.Object[]) intArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = zeroException10.getContext();
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray13 = blockRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix4.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarAdd((double) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getRowMatrix(10);
        double[][] doubleArray20 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray26 = blockRealMatrix25.getData();
        boolean boolean27 = blockRealMatrix25.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix15.add(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass15 = arrayRealVector12.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector33.append(arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.append(arrayRealVector40);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction44 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.mapToSelf(univariateFunction44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector46.append(arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        double double52 = arrayRealVector38.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        double double53 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector46.mapMultiply(0.08726646259971647d);
        double double56 = arrayRealVector46.getLInfNorm();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.0d + "'", double1 == 45.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.append(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector16.append(arrayRealVector17);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector17.mapToSelf(univariateFunction21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.append(arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15, arrayRealVector28);
        double double30 = arrayRealVector14.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship32 = relationship31.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint34 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector29, relationship32, (double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector36.append(arrayRealVector37);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction41 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector37.mapToSelf(univariateFunction41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector43.append(arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector35, arrayRealVector48);
        boolean boolean51 = arrayRealVector35.equals((java.lang.Object) 0.0f);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint53 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector1, 1.1102230246251565E-16d, relationship32, (org.apache.commons.math3.linear.RealVector) arrayRealVector35, 0.0d);
        boolean boolean54 = arrayRealVector35.isInfinite();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship32 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship32.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 0.0f, ' ' };
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[][] doubleArray14 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.ZeroException zeroException16 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = mathArithmeticException17.getContext();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(exceptionContext18);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector1.append(arrayRealVector2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector8.append(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        int int23 = arrayRealVector14.getMinIndex();
        arrayRealVector14.set((double) (short) 0);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector14.mapAdd(0.0d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(97, (int) (byte) 10);
        java.lang.Number number3 = nonSquareMatrixException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 97 + "'", number3.equals(97));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(0.0d, 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.append(arrayRealVector3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector3.mapToSelf(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector9.append(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector14);
        double double16 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.append(arrayRealVector18);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector18.mapToSelf(univariateFunction22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivide((double) (short) 100);
        java.lang.Class<?> wildcardClass32 = arrayRealVector29.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector34.append(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector41.append(arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector50.append(arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.combine((double) 1L, (double) 10L, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector56.append(arrayRealVector57);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.mapToSelf(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.append(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector63.append(arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        double double69 = arrayRealVector55.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix(52, (int) (byte) 100);
        double[][] doubleArray75 = blockRealMatrix74.getData();
        int int76 = blockRealMatrix74.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix74.getRowMatrix(10);
        org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix74.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector71.append(realVector80);
        double[] doubleArray83 = new double[] { 100.0f };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair86 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray83, (double) 100L, true);
        java.lang.Double double87 = pointValuePair86.getSecond();
        java.lang.Double double88 = pointValuePair86.getValue();
        boolean boolean89 = arrayRealVector71.equals((java.lang.Object) pointValuePair86);
        double[] doubleArray90 = pointValuePair86.getKey();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction92 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray90, (double) 1.0000001f);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 52 + "'", int76 == 52);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 100.0d + "'", double87.equals(100.0d));
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 100.0d + "'", double88.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray90);
    }
}

