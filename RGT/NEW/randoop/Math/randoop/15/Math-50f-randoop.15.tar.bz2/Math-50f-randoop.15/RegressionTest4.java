import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1395059857, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.528444521E9d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double11 = noBracketingException10.getHi();
        double double12 = noBracketingException10.getFHi();
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) noBracketingException10);
        boolean boolean14 = numberIsTooSmallException5.getBoundIsAllowed();
        java.lang.Number number15 = numberIsTooSmallException5.getMin();
        tooManyEvaluationsException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.9867717342662448d + "'", double11 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1024458752);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = noBracketingException4.getContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        java.util.Set<java.lang.String> strSet8 = exceptionContext6.getKeys();
        java.lang.Object obj10 = exceptionContext6.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 35, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray22 = mathArithmeticException21.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 100, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 7.6293945E-6f);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100.00001f, 4.61512051684126d, 6.691673596021348E41d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((int) (short) 100, univariateRealFunction5, (double) 4.6863407E18f, (double) 70L, 1.079574628E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray5 = mathArithmeticException4.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 23459280248L, (java.lang.Number) 3.762195691083632d, true);
        java.lang.String str12 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "row index ({0})" + "'", str12.equals("row index ({0})"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Number number2 = notPositiveException1.getMin();
        java.lang.String str3 = notPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotPositiveException: 0.834 is smaller than the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotPositiveException: 0.834 is smaller than the minimum (0)"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.0d, 6.283185307179586d, 1.2927473687524549d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) '4');
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(6.283185307179586d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1000000000000L, 1.2927473687524549d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6575927734375d) + "'", double2 == (-0.6575927734375d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 1.02445882E9f, (int) 'a');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = nonMonotonousSequenceException3.getContext();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) (byte) 10, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray4 = notPositiveException3.getSuppressed();
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.0d, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = maxCountExceededException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = maxCountExceededException6.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 7, (long) 14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1609564159, (long) (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1609564159L + "'", long2 == 1609564159L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { (-1L), (short) -1 };
        double[] doubleArray32 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.0E-14d);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 810830942L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0E-14d, (java.lang.Number) 1.3440585709080678E43d, true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5607966601082315d, (double) 1.0f);
        double double3 = regulaFalsiSolver2.getMax();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { (-1L), (short) -1 };
        double[] doubleArray32 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.0E-14d);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, (int) (short) 0);
        try {
            double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, (-725723463));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.61512051684126d, 3649.1211495028297d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.615120516841261d + "'", double2 == 4.615120516841261d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve(0, univariateRealFunction4, 1.000000000000007d, 363.7393755555636d, 4.762613918721343d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.7591697253775689d, (double) (-1074790358L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double9 = noBracketingException8.getHi();
        double double10 = noBracketingException8.getFHi();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) noBracketingException8);
        double double12 = noBracketingException8.getFLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray19 = mathArithmeticException18.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 100, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 109.99946827998635d, (java.lang.Object[]) throwableArray19);
        noBracketingException8.addSuppressed((java.lang.Throwable) notFiniteNumberException22);
        double double24 = noBracketingException8.getLo();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.9867717342662448d + "'", double9 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double1 = org.apache.commons.math.util.FastMath.acos(20.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1091414619, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.09141466E9f + "'", float2 == 1.09141466E9f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Float.POSITIVE_INFINITY, (java.lang.Number) 0.0f, 9700);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) nonMonotonousSequenceException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 4.733165E-30f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7331650551678786E-30d + "'", double1 == 4.7331650551678786E-30d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException(localizable5, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 100L, objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, objArray7);
        java.lang.Class<?> wildcardClass12 = notFiniteNumberException11.getClass();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = notFiniteNumberException11.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray23);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray31 = new double[] { (-1L), (short) -1 };
        double[] doubleArray38 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        double[] doubleArray42 = new double[] { (-1L), (short) -1 };
        double[] doubleArray49 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray38);
        double[] doubleArray55 = new double[] { (-1L), (short) -1 };
        double[] doubleArray62 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray62);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray62);
        double[] doubleArray70 = new double[] { (-1L), (short) -1 };
        double[] doubleArray77 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 10);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double[] doubleArray84 = new double[] { (-1L), (short) -1 };
        double[] doubleArray91 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray84, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, (double) 10);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray91);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray91);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 92.90780141843972d + "'", double27 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.0d + "'", double63 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.0d + "'", double78 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 7.481177023534592d + "'", double81 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 2.0d + "'", double92 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 92.90780141843972d + "'", double95 == 92.90780141843972d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1024458752, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.02445875E9f + "'", float2 == 1.02445875E9f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-4.9334336E8f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 59, 1.4E-45f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 59.0f + "'", float2 == 59.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 1.0E-14d);
        double[] doubleArray17 = new double[] { (-1L), (short) -1 };
        double[] doubleArray24 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray24);
        double[] doubleArray28 = new double[] { (-1L), (short) -1 };
        double[] doubleArray35 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = new double[] { (-1L), (short) -1 };
        double[] doubleArray49 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 10);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray49);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49, 1);
        double double57 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray24, doubleArray49);
        double[] doubleArray60 = new double[] { (-1L), (short) -1 };
        double[] doubleArray67 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 10);
        double[] doubleArray73 = new double[] { (-1L), (short) -1 };
        double[] doubleArray80 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 10);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray70, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray70);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 7.481177023534592d + "'", double39 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 92.90780141843972d + "'", double53 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 11127.0d + "'", double57 == 11127.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 98.00341900830317d + "'", double85 == 98.00341900830317d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { 0, 9700, 'a', 35, (byte) 10 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.019686266404607394d, (-1.2927473687524549d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.9867717342662448d, 1.2845651917849061d, (-0.9821933800072388d));
        double double4 = regulaFalsiSolver3.getStartValue();
        double double5 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        double double2 = org.apache.commons.math.util.FastMath.min(1.08790385916443d, 0.027241040673019475d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.027241040673019475d + "'", double2 == 0.027241040673019475d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1219066849));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,219,066,849");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5607966601082315d, (double) 1.0f);
        double double5 = regulaFalsiSolver4.getMax();
        double double6 = regulaFalsiSolver4.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(107, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, (double) 1024L, (-0.020511130202451787d), (double) (-2085012671), allowedSolution10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1024.0d + "'", double11 == 1024.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) (-1023));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 14, (-493343386));
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14 + "'", number4.equals(14));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1364700796), 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 52, 789.1489361702128d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-53));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -53");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        java.lang.String str3 = nullArgumentException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NullArgumentException: zero not allowed here" + "'", str3.equals("org.apache.commons.math.exception.NullArgumentException: zero not allowed here"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-6L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.797559753635442d + "'", double1 == 15.797559753635442d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.3459280247626457E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.571679180279222d + "'", double1 == 24.571679180279222d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-1.0000001f), 97, 1078591435);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,078,591,435, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int2 = org.apache.commons.math.util.FastMath.max(530, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 530 + "'", int2 == 530);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, 0.0f, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.691843614640512d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(202.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 201.99998f + "'", float2 == 201.99998f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        double double2 = org.apache.commons.math.util.FastMath.min(0.00526682479542662d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.401298464324817E-45d + "'", double2 == 1.401298464324817E-45d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException(localizable4, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException(number1, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 70, (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(6.691673596021348E41d, (double) 9700L, (double) 1.02445882E9f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.024458816E9d) + "'", double3 == (-1.024458816E9d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(29);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray4 = mathArithmeticException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Object[]) throwableArray4);
        java.lang.Object[] objArray6 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException7.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathIllegalArgumentException10.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException(localizable13, objArray15);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 95.66199317006688d, (-3.503324705098717d), 0.5840734641020688d, 0.0d, objArray15);
        double double19 = noBracketingException18.getFLo();
        double double20 = noBracketingException18.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5840734641020688d + "'", double19 == 0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 95.66199317006688d + "'", double20 == 95.66199317006688d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 4.6863407E18f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-102));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.ulp(24.571679180279222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        double double1 = org.apache.commons.math.util.FastMath.atanh(92.90780141843972d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.7741775444868297d, (java.lang.Number) 9.306943617238488d, true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        float float2 = org.apache.commons.math.util.MathUtils.round(107.0f, 1078591435);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9816843611112658d), 1.4721828779246281E31d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9816843611112658d) + "'", double2 == (-0.9816843611112658d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1078591594, (long) 1078591488);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1163359712316751872L + "'", long2 == 1163359712316751872L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.8390715290764523d));
        double double4 = regulaFalsiSolver3.getMin();
        int int5 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = null;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-100), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 3628800.0d, 3.4814149300557423E25d, 0.5840734641020688d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(0);
        incrementor0.setMaximalCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.9821933800072388d), (double) 100, (double) (short) 10);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver3.solve(530, univariateRealFunction6, (-0.017453292519943295d), (double) 205785009937601268L, 48.055330991744995d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.8390715290764523d));
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getMax();
        int int5 = regulaFalsiSolver1.getEvaluations();
        double double6 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.8390715290764523d) + "'", double6 == (-0.8390715290764523d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.0045735325691467E-51d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0045735325691467E-51d + "'", double1 == 2.0045735325691467E-51d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.math.util.MathUtils.pow(810831012, (long) 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6717532003326174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-102), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (-3.503324705098717d), 11013.232920103323d, (double) 1163359712316751872L, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (byte) 1);
        int[] intArray3 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 1);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) 1);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
        int[] intArray11 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (int) (byte) 1);
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (byte) 1);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 1);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (byte) 1);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (byte) 1);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, (int) (byte) 1);
        int[] intArray33 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (int) (byte) 1);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray33);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray33);
        int[] intArray39 = new int[] {};
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, (int) (byte) 1);
        int[] intArray42 = new int[] {};
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray42, (int) (byte) 1);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray42);
        int[] intArray46 = new int[] {};
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, (int) (byte) 1);
        int[] intArray51 = new int[] {};
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, (int) (byte) 1);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int[] intArray55 = null;
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray48);
        int[] intArray58 = new int[] {};
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray58, (int) (byte) 1);
        int[] intArray61 = new int[] {};
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray61, (int) (byte) 1);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray61);
        int[] intArray65 = new int[] {};
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray65, (int) (byte) 1);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray58);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray48);
        int[] intArray71 = new int[] {};
        int[] intArray73 = org.apache.commons.math.util.MathUtils.copyOf(intArray71, (int) (byte) 1);
        int[] intArray74 = new int[] {};
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray74, (int) (byte) 1);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        int[] intArray78 = new int[] {};
        int[] intArray80 = org.apache.commons.math.util.MathUtils.copyOf(intArray78, (int) (byte) 1);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray71);
        int[] intArray84 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, 101);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.38905609893065d, 3.4814149300557423E25d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-71));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(267.74489404101644d, (double) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(201.7156361224559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0088970726893107E87d + "'", double1 == 2.0088970726893107E87d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.105427357601002E-15d, (double) 128.0f, 2.2250738585072014E-308d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve((int) (byte) 100, univariateRealFunction6, 0.0d, 8.366600265340756d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.5456333482512485E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11665899835365919d + "'", double1 == 0.11665899835365919d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(100, 530);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 107.0f, (java.lang.Number) 5.0d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1754754559420733d, (java.lang.Number) (short) 10, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 102L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        float float1 = org.apache.commons.math.util.FastMath.signum(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.9867717342662448d, 1.2845651917849061d, (-0.9821933800072388d));
        double double4 = regulaFalsiSolver3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', (-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-2)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0747903947415927E11d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0747903947415927E11d) + "'", number3.equals((-1.0747903947415927E11d)));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray4 = notPositiveException3.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        double[] doubleArray12 = new double[] { (-1L), (short) -1 };
        double[] doubleArray19 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 10);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray26 = new double[] { (-1L), (short) -1 };
        double[] doubleArray33 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray33);
        double[] doubleArray37 = new double[] { (-1L), (short) -1 };
        double[] doubleArray44 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray48 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, orderDirection47, doubleArray48);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, doubleArray48);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException51 = new org.apache.commons.math.exception.MathArithmeticException(localizable9, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException52 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException53 = new org.apache.commons.math.exception.MathArithmeticException(localizable6, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException55 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.14998797277684019E18d, (java.lang.Object[]) doubleArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 761385567 + "'", int23 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(15.797559753635442d, 1.4449703012069437d, (-71));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0E-15d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-2.356194490192345d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve(9700, univariateRealFunction3, (double) (-65));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray23);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, 7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 92.90780141843972d + "'", double27 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.14998797277684019E18d), number1, true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52.0f, 11013.232920103323d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.07859162E9f, (float) (short) 100, (float) (-1078591488));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.762195691083632d, (double) 1.07859162E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) '4');
        double[] doubleArray31 = new double[] { (-1L), (short) -1 };
        double[] doubleArray38 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        double[] doubleArray42 = new double[] { (-1L), (short) -1 };
        double[] doubleArray49 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray49);
        double[] doubleArray54 = new double[] { (-1L), (short) -1 };
        double[] doubleArray61 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 10);
        double[] doubleArray67 = new double[] { (-1L), (short) -1 };
        double[] doubleArray74 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 10);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64, (int) '4');
        double[] doubleArray83 = new double[] { (-1L), (short) -1 };
        double[] doubleArray90 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray83, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray90);
        double double93 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray49, doubleArray64);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray49);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.0d + "'", double75 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.0d + "'", double91 == 2.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 98.00341900830317d + "'", double92 == 98.00341900830317d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 789.1489361702128d + "'", double93 == 789.1489361702128d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 98.00341900830317d + "'", double94 == 98.00341900830317d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 761385567 + "'", int95 == 761385567);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6931471805599453d, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471805599453d + "'", double2 == 0.6931471805599453d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.8342233605065096d, 7.105427357600977E-15d, (-2.356194490192345d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7763568394002505E-15d + "'", double3 == 1.7763568394002505E-15d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getMin();
        int int3 = regulaFalsiSolver1.getMaxEvaluations();
        double double4 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.6931471805599453d, (java.lang.Number) 100.00001f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.00001f + "'", number4.equals(100.00001f));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1074790400), (float) (-1901072361));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-100), 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-99.99999f) + "'", float2 == (-99.99999f));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 2, 1.3731644178712397d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.9999999f + "'", float2 == 1.9999999f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.074790394741597E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        double[] doubleArray12 = new double[] { (-1L), (short) -1 };
        double[] doubleArray19 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 10);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray26 = new double[] { (-1L), (short) -1 };
        double[] doubleArray33 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray33);
        double[] doubleArray37 = new double[] { (-1L), (short) -1 };
        double[] doubleArray44 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray48 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, orderDirection47, doubleArray48);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, doubleArray48);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException51 = new org.apache.commons.math.exception.MathArithmeticException(localizable9, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException52 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.exception.NoBracketingException noBracketingException53 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.175475455942073d, (-0.7628881244594873d), (double) 1024458752, 2.5456333482512485E41d, (java.lang.Object[]) doubleArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 761385567 + "'", int23 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 59.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray4 = mathArithmeticException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1024458787, number4, 100);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 1.14998797277684019E18d, 350, orderDirection8, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 350 + "'", int11 == 350);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1L);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver1.solve(97, univariateRealFunction4, 24.113475177304977d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException3.getContext();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-0.5840734641020688d), 0.0d, 4.5d, (-493343386));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { (-1L), (short) -1 };
        double[] doubleArray32 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray38 = new double[] { (-1L), (short) -1 };
        double[] doubleArray45 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        double[] doubleArray49 = new double[] { (-1L), (short) -1 };
        double[] doubleArray56 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray56);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray56);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-3.6187045384210283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.7160033436347992d, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-44.8534693539332d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.496672362262929d) + "'", double1 == (-4.496672362262929d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 262144.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 262144.00000000006d + "'", double1 == 262144.00000000006d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray20 = new double[] { (-0.9821933800072388d), 1.7453292519943295d, 1149987972776840193L, 1.9867717342662448d, (-0.99999994f), 6 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray20);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly increasing (1,149,987,972,776,840,190 >= 1.987)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 761385567 + "'", int13 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 6.1798740081135376E10d, 6.471550100004411E9d, 1.0547118733938987E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray4 = mathArithmeticException3.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = nullArgumentException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray10 = mathArithmeticException9.getSuppressed();
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray10);
        java.lang.Object obj13 = exceptionContext7.getValue("org.apache.commons.math.exception.NoBracketingException: wrong array shape (block length = 1,149,987,972,776,840,190, expected 14,721,828,779,246,281,000,000,000,000,000)");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, 1942043457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1942043467 + "'", int2 == 1942043467);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray5 = notPositiveException4.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-9) + "'", int2 == (-9));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.329724061956462E-6d), (java.lang.Number) (-0.0f), true);
        org.apache.commons.math.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 107);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7.425804057581267E47d, (java.lang.Number) 1.14998797277684019E18d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-4.949006185501188E10d), 4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.949006185501188E10d + "'", double2 == 4.949006185501188E10d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (byte) 1);
        int[] intArray3 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 1);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) 1);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
        int[] intArray11 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (int) (byte) 1);
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (byte) 1);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 1);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (byte) 1);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (byte) 1);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, (int) (byte) 1);
        int[] intArray33 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (int) (byte) 1);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray33);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray33);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { 0, 9700, 'a', 35, (byte) 10 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray45);
        int[] intArray48 = new int[] {};
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, (int) (byte) 1);
        int[] intArray51 = new int[] {};
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, (int) (byte) 1);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int[] intArray55 = new int[] {};
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray55, (int) (byte) 1);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray55);
        int[] intArray59 = null;
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray59);
        try {
            int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray40 = new double[] { (-1L), (short) -1 };
        double[] doubleArray47 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray51 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray36, orderDirection50, doubleArray51);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray51);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException54 = new org.apache.commons.math.exception.MathArithmeticException(localizable12, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException55 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.NoBracketingException noBracketingException56 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, 1.175475455942073d, 4.9E-324d, 1.1499879727768402E20d, (double) 0, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.NoBracketingException noBracketingException57 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 14, (-0.4161468365471424d), (double) 1.07479027E9f, 0.0d, (java.lang.Object[]) doubleArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 761385567 + "'", int26 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(99.99999f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 70L, 7.681145747868608d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [70, 7.681]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1L);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double8 = regulaFalsiSolver1.solve((int) (short) 1, univariateRealFunction4, 0.0d, 1.7453292519943295d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3628806L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628806L + "'", long1 == 3628806L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.2927473687524549d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9123950785114173d) + "'", double1 == (-0.9123950785114173d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (-4.6863412E18f), (double) 1000L, 0.18478174456066745d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.18478174456066745d) + "'", double3 == (-0.18478174456066745d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.195005897219113E24d + "'", double1 == 2.195005897219113E24d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 7.105427357600977E-15d, (double) 70L, 1.0E-15d, 62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1.14998794E18f, 105.48459603183775d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-25.644331776902106d) + "'", double2 == (-25.644331776902106d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (byte) 1);
        int[] intArray3 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 1);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) 1);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
        int[] intArray11 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (int) (byte) 1);
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (byte) 1);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 1);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (byte) 1);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (byte) 1);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, (int) (byte) 1);
        int[] intArray33 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (int) (byte) 1);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray33);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray33);
        int[] intArray39 = new int[] {};
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, (int) (byte) 1);
        int[] intArray42 = new int[] {};
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray42, (int) (byte) 1);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray42);
        int[] intArray46 = new int[] {};
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, (int) (byte) 1);
        int[] intArray51 = new int[] {};
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, (int) (byte) 1);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int[] intArray55 = null;
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray48);
        int[] intArray58 = new int[] {};
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray58, (int) (byte) 1);
        int[] intArray61 = new int[] {};
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray61, (int) (byte) 1);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray61);
        int[] intArray65 = new int[] {};
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray65, (int) (byte) 1);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray58);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray48);
        int[] intArray71 = new int[] {};
        int[] intArray73 = org.apache.commons.math.util.MathUtils.copyOf(intArray71, (int) (byte) 1);
        int[] intArray74 = new int[] {};
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray74, (int) (byte) 1);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        int[] intArray78 = new int[] {};
        int[] intArray80 = org.apache.commons.math.util.MathUtils.copyOf(intArray78, (int) (byte) 1);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray71);
        int[] intArray84 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, (int) ' ');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = noBracketingException4.getContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        java.util.Set<java.lang.String> strSet8 = exceptionContext6.getKeys();
        java.lang.Object obj10 = null;
        exceptionContext6.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: row index (0)", obj10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        int[] intArray16 = new int[] {};
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, (int) (byte) 1);
        int[] intArray19 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 1);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray19);
        int[] intArray23 = new int[] {};
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, (int) (byte) 1);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException32 = new org.apache.commons.math.exception.NullArgumentException(localizable29, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray31);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) intArray16, localizable27, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.07479027E9f, objArray31);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException36 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray31);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException37 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray31);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray31);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(24.571679180279222d, (-1496542223), 1942043457);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double double1 = org.apache.commons.math.util.FastMath.log10(1292.098616377079d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1112956614252845d + "'", double1 == 3.1112956614252845d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1078591594);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078591594E9d + "'", double1 == 1.078591594E9d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { (-1L), (short) -1 };
        double[] doubleArray32 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.0E-14d);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, (int) (short) 0);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, 3710);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException43 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext44 = mathArithmeticException43.getContext();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean50 = nonMonotonousSequenceException49.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext51 = nonMonotonousSequenceException49.getContext();
        int int52 = nonMonotonousSequenceException49.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException49.getDirection();
        exceptionContext44.setValue("", (java.lang.Object) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = nonMonotonousSequenceException49.getDirection();
        boolean boolean58 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection55, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(exceptionContext51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 7.425804057581267E47d, (java.lang.Number) 4.890573605144879d, false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1219066849), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalArgumentException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { (-1L), (short) -1 };
        double[] doubleArray27 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 10);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray34 = new double[] { (-1L), (short) -1 };
        double[] doubleArray41 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray41);
        double[] doubleArray45 = new double[] { (-1L), (short) -1 };
        double[] doubleArray52 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, orderDirection55, doubleArray56);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray30, doubleArray56);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException59 = new org.apache.commons.math.exception.MathArithmeticException(localizable17, (java.lang.Object[]) doubleArray56);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) doubleArray56);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray65 = new double[] { (-1L), (short) -1 };
        double[] doubleArray72 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray62);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray62, 350);
        exceptionContext15.setValue("zero norm", (java.lang.Object) 350);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 761385567 + "'", int31 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.0d + "'", double73 == 2.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-71), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(6.691673596021348E41d, (-0.9816843611112658d), 0.6483608274590866d, (-70.0d), 0.0d, (double) 103L, 52.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-6.5691113188753434E41d) + "'", double8 == (-6.5691113188753434E41d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 12.1781464311013d, 0.0d, 4.248699261236361d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.9999999f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double double2 = org.apache.commons.math.util.FastMath.scalb(2.178183556608571d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7611756929421145E30d + "'", double2 == 2.7611756929421145E30d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        double[] doubleArray7 = new double[] { (-1L), (short) -1 };
        double[] doubleArray14 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 10);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 7.481177023534592d);
        double[] doubleArray24 = new double[] { (-1L), (short) -1 };
        double[] doubleArray31 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray31);
        double[] doubleArray35 = new double[] { (-1L), (short) -1 };
        double[] doubleArray42 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray42);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray46 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray31, orderDirection45, doubleArray46);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, doubleArray46);
        org.apache.commons.math.exception.NoBracketingException noBracketingException49 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1149987972776840193L, 1.4721828779246281E31d, (-0.8390715290764524d), (double) (-1.9999999f), (java.lang.Object[]) doubleArray46);
        double double50 = noBracketingException49.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 761385567 + "'", int18 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-1.9999998807907104d) + "'", double50 == (-1.9999998807907104d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1.8452701486440284d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 7, (float) 70, 1.02445882E9f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray4 = mathArithmeticException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Object[]) throwableArray4);
        java.lang.Object[] objArray6 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        java.lang.Throwable[] throwableArray9 = mathArithmeticException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1078591488));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(24.571679180279222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.956982870686485d + "'", double1 == 4.956982870686485d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = nonMonotonousSequenceException6.getContext();
        int int9 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException6.getDirection();
        exceptionContext1.setValue("", (java.lang.Object) nonMonotonousSequenceException6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = nonMonotonousSequenceException15.getContext();
        int int18 = nonMonotonousSequenceException15.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException15.getDirection();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.425804057581267E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2546723199052833E49d + "'", double1 == 4.2546723199052833E49d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1563524172));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.563524172E9d + "'", double1 == 1.563524172E9d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.820216522839121d + "'", double1 == 4.820216522839121d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double5 = regulaFalsiSolver4.getRelativeAccuracy();
        double double6 = regulaFalsiSolver4.getMax();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray10 = new double[] { (-1L), (short) -1 };
        double[] doubleArray17 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 10);
        java.lang.Object[] objArray24 = new java.lang.Object[] { regulaFalsiSolver4, localizedFormats7, doubleArray20, (byte) 1, 0.8342233605065096d, 1.1102230246251565E-16d };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray24);
        java.lang.Class<?> wildcardClass27 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-4.6863412E18f), (java.lang.Number) 1.07859149E9f, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-4.6863412E18f) + "'", number5.equals((-4.6863412E18f)));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.65586277108846d, 0.3796077390275217d, (-0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        long long1 = org.apache.commons.math.util.MathUtils.sign(202L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 35, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [35, 6.283]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double[] doubleArray5 = new double[] { (-1L), (short) -1 };
        double[] doubleArray12 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray30 = new double[] { (-1L), (short) -1 };
        double[] doubleArray37 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 10);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray45 = new double[] { (-1L), (short) -1 };
        double[] doubleArray52 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        double[] doubleArray56 = new double[] { (-1L), (short) -1 };
        double[] doubleArray63 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray67 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray52, orderDirection66, doubleArray67);
        double[] doubleArray71 = new double[] { (-1L), (short) -1 };
        double[] doubleArray78 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray78);
        double[] doubleArray82 = new double[] { (-1L), (short) -1 };
        double[] doubleArray89 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray89);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection92 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray93 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray78, orderDirection92, doubleArray93);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, orderDirection66, doubleArray93);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection66, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException99 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35L, (java.lang.Number) 7.481177023534592d, (-2), orderDirection66, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.481177023534592d + "'", double27 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 92.90780141843972d + "'", double41 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 2.0d + "'", double79 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 2.0d + "'", double90 == 2.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection92 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection92.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalArgumentException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.481177023534592d);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 0.0d);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (-0.9821933800072388d));
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 761385567 + "'", int13 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1957696648 + "'", int17 == 1957696648);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 0.6931471805599453d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException3.getContext();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.6931471805599453d + "'", number4.equals(0.6931471805599453d));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.6931471805599453d + "'", number7.equals(0.6931471805599453d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1024458752, 0.008903309996380615d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0011617909390816972d + "'", double2 == 0.0011617909390816972d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int int2 = org.apache.commons.math.util.FastMath.min((-9), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-9) + "'", int2 == (-9));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        long long1 = org.apache.commons.math.util.FastMath.round(24.113475177304977d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24L + "'", long1 == 24L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4686341230761026059L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7L, (java.lang.Number) 5.308267697401205d, false);
        boolean boolean7 = numberIsTooSmallException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(20.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3490658503988659d + "'", double1 == 0.3490658503988659d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(29, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(35.0d, (double) 1528444521, (double) Float.POSITIVE_INFINITY);
        double double4 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((int) (short) 0, univariateRealFunction6, (double) 1024458787, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        float[] floatArray6 = new float[] { 52L, 52.0f, (-1.0f), (-20L), (short) 0, 6L };
        float[] floatArray11 = new float[] { 10.0f, (short) -1, (-100), 1.07859162E9f };
        float[] floatArray15 = new float[] { '#', 52.0f, 1 };
        float[] floatArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray15, floatArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray15);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray6, floatArray11);
        float[] floatArray24 = new float[] { (short) -1, 100L, (-19.999998f), (-4L) };
        float[] floatArray25 = new float[] {};
        float[] floatArray28 = new float[] { (-20L), (-1.9999999f) };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray25, floatArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray24);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1496542223), (java.lang.Number) 52.0f, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) '4');
        double[] doubleArray31 = new double[] { (-1L), (short) -1 };
        double[] doubleArray38 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        double[] doubleArray42 = new double[] { (-1L), (short) -1 };
        double[] doubleArray49 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray49);
        double[] doubleArray54 = new double[] { (-1L), (short) -1 };
        double[] doubleArray61 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 10);
        double[] doubleArray67 = new double[] { (-1L), (short) -1 };
        double[] doubleArray74 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 10);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64, (int) '4');
        double[] doubleArray83 = new double[] { (-1L), (short) -1 };
        double[] doubleArray90 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray83, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray90);
        double double93 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray49, doubleArray64);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray49);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.0d + "'", double75 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.0d + "'", double91 == 2.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 98.00341900830317d + "'", double92 == 98.00341900830317d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 789.1489361702128d + "'", double93 == 789.1489361702128d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 98.00341900830317d + "'", double94 == 98.00341900830317d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.4161468365471424d), 0.0d);
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-102), 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6324) + "'", int2 == (-6324));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 1078591494);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07859162E9f + "'", float1 == 1.07859162E9f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] { (-1L), (short) -1 };
        double[] doubleArray16 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 10);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray23 = new double[] { (-1L), (short) -1 };
        double[] doubleArray30 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray30);
        double[] doubleArray34 = new double[] { (-1L), (short) -1 };
        double[] doubleArray41 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray45 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray30, orderDirection44, doubleArray45);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, doubleArray45);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException48 = new org.apache.commons.math.exception.MathArithmeticException(localizable6, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException49 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException50 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1024, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException51 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.0d, (java.lang.Object[]) doubleArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 761385567 + "'", int20 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalArgumentException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean23 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext24 = nonMonotonousSequenceException22.getContext();
        int int25 = nonMonotonousSequenceException22.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException22.getDirection();
        exceptionContext17.setValue("zero norm", (java.lang.Object) nonMonotonousSequenceException22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(exceptionContext24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-1496542223), (-2.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.49654208E9f) + "'", float2 == (-1.49654208E9f));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 7.105427357600977E-15d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1036589357));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1464788108 + "'", int1 == 1464788108);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 102402L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((-18.631206179699266d), 4.820216522839121d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.649659911657217d + "'", double2 == 0.649659911657217d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 761385567, (-100));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(341642467, (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathIllegalArgumentException10.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException(localizable13, objArray15);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 95.66199317006688d, (-3.503324705098717d), 0.5840734641020688d, 0.0d, objArray15);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 0);
        java.lang.Number number21 = maxCountExceededException20.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = maxCountExceededException20.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        exceptionContext22.setValue("", (java.lang.Object) localizedFormats24);
        org.apache.commons.math.exception.NotPositiveException notPositiveException27 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray28 = notPositiveException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 0 + "'", number21.equals((byte) 0));
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(1078591488);
        int int4 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((int) (short) 10);
        int int7 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1078591488 + "'", int4 == 1078591488);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1078591488 + "'", int7 == 1078591488);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 59.0f, (double) 202L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1091414619, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1091414619L + "'", long2 == 1091414619L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0d, (java.lang.Number) 1.4129651365067377d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.4129651365067377d + "'", number4.equals(1.4129651365067377d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4129651365067377d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.108118494670218d + "'", double1 == 3.108118494670218d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 202L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1080639488 + "'", int1 == 1080639488);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double9 = noBracketingException8.getHi();
        double double10 = noBracketingException8.getFHi();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) noBracketingException8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = noBracketingException8.getContext();
        double double13 = noBracketingException8.getHi();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.9867717342662448d + "'", double9 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.9867717342662448d + "'", double13 == 1.9867717342662448d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5403023058681398d, (double) 1395059857, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 205785009937601268L, (float) 1024458752L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.05785009E17f + "'", float2 == 2.05785009E17f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 103L, (double) (-6324), 0.7658461948190802d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 20.795391502771416d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(21.147516402267446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.765369212872876d + "'", double1 == 2.765369212872876d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.07859149E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.074790272E9d, (double) 6L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,074,790,272, 6]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = localizedFormats0.getLocalizedString(locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.171820983713485d, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.8164659837591994d, 1.3868311854569213E80d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8164659837591997d + "'", double2 == 1.8164659837591997d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int2 = org.apache.commons.math.util.FastMath.max((-103), 341642467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341642467 + "'", int2 == 341642467);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) '4');
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 1.4012984643248169E-45d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1219066849) + "'", int29 == (-1219066849));
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, 1078591435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (-1.0000001f), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.881373587019543d, 11.548739357257746d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        float float2 = org.apache.commons.math.util.FastMath.copySign(5.4975581E11f, (float) 530);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.4975581E11f + "'", float2 == 5.4975581E11f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = noBracketingException5.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException5.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException(localizable10, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathIllegalArgumentException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException(localizable17, objArray19);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray19);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        double[] doubleArray32 = new double[] { (-1L), (short) -1 };
        double[] doubleArray39 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 10);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray46 = new double[] { (-1L), (short) -1 };
        double[] doubleArray53 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray53);
        double[] doubleArray57 = new double[] { (-1L), (short) -1 };
        double[] doubleArray64 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray68 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray53, orderDirection67, doubleArray68);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, doubleArray68);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException71 = new org.apache.commons.math.exception.MathArithmeticException(localizable29, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException72 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException73 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 1024, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException74 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.329724061956462E-6d), (java.lang.Object[]) doubleArray68);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 761385567 + "'", int43 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 2.0d + "'", double65 == 2.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(1078591488);
        int int4 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) 'a');
        incrementor0.incrementCount();
        incrementor0.incrementCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(1024);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 29, (double) 101L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.0d + "'", double2 == 101.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1.0747903947415927E11d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException(localizable7, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathIllegalArgumentException11.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math.exception.NullArgumentException(localizable14, objArray16);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray16);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 10.0f, objArray16);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) notPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.5607966601082315d, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-1.0947293165043385E10d), 0.6060592962329323d, 92.90780141843972d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1364700796));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1024458752, (int) (byte) 1);
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 201L, (float) (-100));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-201.0f) + "'", float2 == (-201.0f));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray23);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException31.getDirection();
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection32, false, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 92.90780141843972d + "'", double27 == 92.90780141843972d);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1074790358L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1364700796), 1074790400);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,074,790,400, n = -1,364,700,796");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (short) 100, (-8.965486638573949E8d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = nonMonotonousSequenceException3.getContext();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        int int9 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 530);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 530 + "'", int2 == 530);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1.07859149E9f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1078591488L + "'", long1 == 1078591488L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) (-1L), (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1091414619, (long) 14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1091414633L + "'", long2 == 1091414633L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-25.644331776902106d), 6.38905609893065d, 0.29814797267434384d, 11127.0d, (-2.159149055991982E9d), (double) 6, 1.024458787E9d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9827790001697525E10d + "'", double8 == 1.9827790001697525E10d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.1945892763841132E11d, 12.1781464311013d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09571884126639346d + "'", double2 == 0.09571884126639346d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.171820983713485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-6), 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) -1, 6);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray4 = notPositiveException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1078591435, (-493343386));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(530);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2798.680347738637d + "'", double1 == 2798.680347738637d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) 'a');
        incrementor0.setMaximalCount((int) (short) -1);
        int int6 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        double double5 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray9 = new double[] { (-1L), (short) -1 };
        double[] doubleArray16 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 10);
        java.lang.Object[] objArray23 = new java.lang.Object[] { regulaFalsiSolver3, localizedFormats6, doubleArray19, (byte) 1, 0.8342233605065096d, 1.1102230246251565E-16d };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.apache.commons.math.exception.NotPositiveException notPositiveException26 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        mathIllegalStateException24.addSuppressed((java.lang.Throwable) notPositiveException26);
        java.lang.Throwable[] throwableArray28 = mathIllegalStateException24.getSuppressed();
        java.lang.Object[] objArray29 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getFLo();
        double double8 = noBracketingException4.getHi();
        java.lang.Throwable[] throwableArray9 = noBracketingException4.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 10.0d, (int) '#', orderDirection13, false);
        noBracketingException4.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        double double17 = noBracketingException4.getHi();
        double double18 = noBracketingException4.getFLo();
        double double19 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.9867717342662448d + "'", double5 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9867717342662448d + "'", double8 == 1.9867717342662448d);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.9867717342662448d + "'", double17 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.9867717342662448d + "'", double19 == 1.9867717342662448d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 107, 350);
        int int4 = dimensionMismatchException3.getDimension();
        int int5 = dimensionMismatchException3.getDimension();
        int int6 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 350 + "'", int4 == 350);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 350 + "'", int5 == 350);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 350 + "'", int6 == 350);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-2000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.762613918721343d, (java.lang.Number) 7.681145747868608d, 1078591435);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(5.237055765311842d, (-0.01214849521004071d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6124536350509007d + "'", double2 == 2.6124536350509007d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 59);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7710802229758452d) + "'", double1 == (-0.7710802229758452d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 7417428586279207114L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.4174291E18f + "'", float1 == 7.4174291E18f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray20 = new double[] { (-0.9821933800072388d), 1.7453292519943295d, 1149987972776840193L, 1.9867717342662448d, (-0.99999994f), 6 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray20);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1078591494);
        double[] doubleArray27 = new double[] { (-1L), (short) -1 };
        double[] doubleArray34 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 10);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 761385567 + "'", int13 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.0d + "'", double35 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 761385567 + "'", int38 == 761385567);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0785914869078014E9d + "'", double39 == 1.0785914869078014E9d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (-1036589357));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 10);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((-1563524172), univariateRealFunction5, 0.649659911657217d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.8390715290764523d));
        double double2 = regulaFalsiSolver1.getMin();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8390715290764523d) + "'", double4 == (-0.8390715290764523d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.481177023534592d, 0.29814797267434384d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1L), (long) (-6324));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        double[] doubleArray7 = new double[] { (-1L), (short) -1 };
        double[] doubleArray14 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double[] doubleArray18 = new double[] { (-1L), (short) -1 };
        double[] doubleArray25 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray29 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray14, orderDirection28, doubleArray29);
        java.lang.Object[] objArray31 = new java.lang.Object[] { localizedFormats4, orderDirection28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-1.0d), objArray31);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException34 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2.40518169E12f, objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 262144.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (-44.8534693539332d), (-0.7716958419032098d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7398490904282058d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8601448078249416d + "'", double1 == 0.8601448078249416d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.6960575029702292d), number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-7417428586279206912L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray3 = notPositiveException2.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray3);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = mathIllegalStateException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.1563424315419204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 333566592, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 333566557L + "'", long2 == 333566557L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(210.84814453125d, (double) 1010, 1.08790385916443d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 209.76024067208556d + "'", double3 == 209.76024067208556d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 10);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, (int) '4');
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean50 = nonMonotonousSequenceException49.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext51 = nonMonotonousSequenceException49.getContext();
        int int52 = nonMonotonousSequenceException49.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException49.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection53, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.071 >= -0.071)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 7.481177023534592d + "'", double44 == 7.481177023534592d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(exceptionContext51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-19.999998f), 530);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 530 + "'", int4 == 530);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 70L, 0.0f, (-103));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction> univariateRealFunctionBracketedUnivariateRealSolver2 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver10 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 4686341230761026059L, 4.584967478670572d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-2085012671), univariateRealFunction7, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver10, 25.832815729997478d, (double) 1395059857, (-9.379315578525171E8d), allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(14, univariateRealFunction1, univariateRealFunctionBracketedUnivariateRealSolver2, 1.074790394741597E11d, 6.283185307179586d, Double.NEGATIVE_INFINITY, allowedSolution14);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 25.832815729997478d + "'", double15 == 25.832815729997478d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.074790394741597E11d + "'", double16 == 1.074790394741597E11d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1L));
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalArgumentException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        java.lang.Throwable[] throwableArray15 = mathArithmeticException14.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = mathArithmeticException14.getContext();
        java.lang.String str17 = mathArithmeticException14.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: population size (0)" + "'", str17.equals("org.apache.commons.math.exception.MathArithmeticException: population size (0)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1000000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.63102111592955d + "'", double1 == 27.63102111592955d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, 1149987972776840193L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 10);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (-1L), (short) -1 };
        double[] doubleArray50 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        double[] doubleArray56 = new double[] { (-1L), (short) -1 };
        double[] doubleArray63 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 10);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53, (int) '4');
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 107.0f);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray72);
        double[] doubleArray74 = new double[] {};
        double[][] doubleArray75 = new double[][] { doubleArray74 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, doubleArray75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 7.481177023534592d + "'", double40 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 2.0d + "'", double51 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 35, (double) 59);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.258967783049207E91d + "'", double2 == 1.258967783049207E91d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(3710, (int) '#');
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.425804057581267E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.425804057581269E47d + "'", double1 == 7.425804057581269E47d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 1.0E-14d);
        double double26 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray9, doubleArray20);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray29);
        double[] doubleArray41 = new double[] { (-71), 1079574628 };
        try {
            double double42 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray20, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 6 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 11127.0d + "'", double26 == 11127.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-2), (java.lang.Number) 1.609564159E9d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1, (double) 99.99999f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.175475455942073d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray4 = mathArithmeticException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Object[]) throwableArray4);
        java.lang.Object[] objArray6 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        java.lang.Object obj10 = exceptionContext8.getValue("number of robustness iterations ({0})");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4686341230761026059L);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "matrix must have at least one row" + "'", str3.equals("matrix must have at least one row"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9589470817428194d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8342233605065096d, number1, 1942043467, orderDirection3, false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        double double1 = org.apache.commons.math.util.FastMath.tanh(350.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (byte) 1);
        int[] intArray3 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 1);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) (byte) 1);
        int[] intArray12 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) (byte) 1);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray12);
        int[] intArray16 = null;
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray19 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 1);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (byte) 1);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (byte) 1);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, (int) (byte) 1);
        int[] intArray33 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (int) (byte) 1);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray33);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray19);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(32007.167197363782d, 1.9621270585409616d, 7.681145747868608d, 3.7621956910836314d, 1.0785914869078014E9d, 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.314428778658004E9d + "'", double6 == 4.314428778658004E9d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 1, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1010);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083150336 + "'", int1 == 1083150336);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.629062629670808d, 5.916079783099616d, 0.0d, (double) 810831012);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.7215847056989477d + "'", double4 == 3.7215847056989477d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        double double1 = org.apache.commons.math.util.FastMath.ulp(6.1798740081135376E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.62939453125E-6d + "'", double1 == 7.62939453125E-6d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double7 = noBracketingException6.getFLo();
        tooManyEvaluationsException1.addSuppressed((java.lang.Throwable) noBracketingException6);
        double double9 = noBracketingException6.getFHi();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray6 = mathArithmeticException5.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 100, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 1609564159, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        long long2 = org.apache.commons.math.util.MathUtils.pow(4L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-0.9250245035569947d), 0.9932959150220343d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-493343386));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -2");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35, (java.lang.Number) (short) 0, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("function is not differentiable");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.7215847056989477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.677016732262693d + "'", double1 == 20.677016732262693d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 59, (-0.017453292519943295d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37960773902752176d, (java.lang.Number) 30.000000059604645d, 0, orderDirection3, true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577404893098d + "'", double1 == 572.9577404893098d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1024, 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1395059857);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 107, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = noBracketingException6.getContext();
        java.util.Set<java.lang.String> strSet9 = exceptionContext8.getKeys();
        java.util.Set<java.lang.String> strSet10 = exceptionContext8.getKeys();
        java.lang.Object obj12 = exceptionContext8.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 35, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException23 = new org.apache.commons.math.exception.MathArithmeticException();
        java.lang.Throwable[] throwableArray24 = mathArithmeticException23.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 100, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray24);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 530, true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1080639488);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.012097700501686678d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1000000000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 9700, (-2.0d), (double) 23459280248L, (double) (-1074790400), objArray5);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.012097700501686678d, 0.03107424657417441d, 38.58449548504905d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { 0, 9700, 'a', 35, (byte) 10 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray9 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) (byte) 1);
        int[] intArray12 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) (byte) 1);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray12);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 29);
        int[] intArray18 = new int[] {};
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray18, (int) (byte) 1);
        int[] intArray21 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray21, (int) (byte) 1);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int[] intArray25 = new int[] {};
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) (byte) 1);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        int[] intArray29 = new int[] {};
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray29, (int) (byte) 1);
        int[] intArray32 = new int[] {};
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, (int) (byte) 1);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray32);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray32);
        int[] intArray37 = new int[] {};
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray37, (int) (byte) 1);
        int[] intArray40 = new int[] {};
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray40, (int) (byte) 1);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray40);
        int[] intArray44 = new int[] {};
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray44, (int) (byte) 1);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int[] intArray48 = null;
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray48);
        int[] intArray50 = new int[] {};
        int[] intArray56 = new int[] { 0, 9700, 'a', 35, (byte) 10 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray18);
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 10);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 10);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (-1L), (short) -1 };
        double[] doubleArray50 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        double[] doubleArray56 = new double[] { (-1L), (short) -1 };
        double[] doubleArray63 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 10);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53, (int) '4');
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 107.0f);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 7.481177023534592d + "'", double40 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 2.0d + "'", double51 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 761385567 + "'", int74 == 761385567);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1024458787, number1, 100);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.3440585709080678E43d, 643398.1754551897d, 38.488623253465065d);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 38.488623253465065d + "'", double4 == 38.488623253465065d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4686341230761026059L);
        org.apache.commons.math.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8342233605065096d);
        java.lang.Throwable[] throwableArray5 = notPositiveException4.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        int int5 = regulaFalsiSolver1.getEvaluations();
        double double6 = regulaFalsiSolver1.getMin();
        int int7 = regulaFalsiSolver1.getMaxEvaluations();
        int int8 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1496542223));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,496,542,223");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        long long2 = org.apache.commons.math.util.FastMath.max((-1074790358L), (long) (-2085012671));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790358L) + "'", long2 == (-1074790358L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = new double[] { (-0.9821933800072388d), 1.7453292519943295d, 1149987972776840193L, 1.9867717342662448d, (-0.99999994f), 6 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        double[] doubleArray38 = new double[] { (-1L), (short) -1 };
        double[] doubleArray45 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        double[] doubleArray49 = new double[] { (-1L), (short) -1 };
        double[] doubleArray56 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray34, doubleArray45);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 761385567 + "'", int13 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 761385567 + "'", int27 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.1499879727768402E20d + "'", double59 == 1.1499879727768402E20d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 8.1559430693392916E18d + "'", double61 == 8.1559430693392916E18d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8739699313687563d, 92.90780141843972d, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1074790299));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07479027E9f) + "'", float2 == (-1.07479027E9f));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1528444521, (int) (byte) -1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, (java.lang.Number) 1.8452701486440284d, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray14);
        int int16 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-4.949006185501188E10d), (double) 3.8146973E-6f, (double) (-9));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, -9]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 6L, (float) 761385567, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray1, (int) (byte) 1);
        int[] intArray4 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, (int) (byte) 1);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray8 = new int[] {};
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, (int) (byte) 1);
        int[] intArray13 = new int[] {};
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, (int) (byte) 1);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray13);
        int[] intArray17 = null;
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray20 = new int[] {};
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, (int) (byte) 1);
        int[] intArray23 = new int[] {};
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, (int) (byte) 1);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray27 = new int[] {};
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) (byte) 1);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray20);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 7);
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = nonMonotonousSequenceException3.getContext();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-1.2927473687524549d), (-2.159149055991982E9d), (double) (-20.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.707252631247545d + "'", double3 == 18.707252631247545d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(38.58449548504905d, 2.9589122825978977E47d, 2.157182976E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [295,891,228,259,789,770,000,000,000,000,000,000,000,000,000,000, 2,157,182,976]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(2.765369212872876d, (double) 262144.0f, (double) (-65), 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9004027864507008215L, (int) '#', 1609564159);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,609,564,159, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.584967478670572d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver1.solve(1528444521, univariateRealFunction6, 1.7160033436347992d, (double) (-65), 4.89057360514488d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.6863412E18f, 0.0f, (float) 1163359712316751872L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        java.lang.String str7 = localizedFormats6.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException10 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.175475455942073d);
        java.lang.Throwable[] throwableArray11 = tooManyEvaluationsException10.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) number5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0} points are required, got only {1}" + "'", str7.equals("{0} points are required, got only {1}"));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { (-1L), (short) -1 };
        double[] doubleArray20 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray24 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, orderDirection23, doubleArray24);
        double[] doubleArray28 = new double[] { (-1L), (short) -1 };
        double[] doubleArray35 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 7.481177023534592d);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray42);
        double[] doubleArray46 = new double[] { (-1L), (short) -1 };
        double[] doubleArray53 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 10);
        double[] doubleArray59 = new double[] { (-1L), (short) -1 };
        double[] doubleArray66 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray66);
        double[] doubleArray70 = new double[] { (-1L), (short) -1 };
        double[] doubleArray77 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray77);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 761385567 + "'", int39 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.0d + "'", double78 == 2.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.8390715290764523d));
        double double2 = regulaFalsiSolver1.getMin();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getStartValue();
        int int5 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(1078591488);
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1078591488 + "'", int4 == 1078591488);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 1078591488);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 11013.232920103323d, (double) 1010, (double) (-0.99999994f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        float float2 = org.apache.commons.math.util.FastMath.copySign((-1.0000001f), (float) 1149987972776840193L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        double[] doubleArray7 = new double[] { (-1L), (short) -1 };
        double[] doubleArray14 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 10);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray21 = new double[] { (-1L), (short) -1 };
        double[] doubleArray28 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray28);
        double[] doubleArray32 = new double[] { (-1L), (short) -1 };
        double[] doubleArray39 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray28, orderDirection42, doubleArray43);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, doubleArray43);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException46 = new org.apache.commons.math.exception.MathArithmeticException(localizable4, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException47 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1.4142135623730951d, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException48 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1024, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.00001f, (java.lang.Number) 1.074790394741597E11d, true);
        boolean boolean53 = numberIsTooSmallException52.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 761385567 + "'", int18 == 761385567);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int1 = org.apache.commons.math.util.MathUtils.sign(22);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2), 1024L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.10939871311849832d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1093987131184983d) + "'", double1 == (-0.1093987131184983d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.8164659837591994d, 1.401298464324817E-45d, (-1563524172));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.7398490904282058d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5537983798262428d + "'", double1 == 0.5537983798262428d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 107.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 70L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 70.00001f + "'", float1 == 70.00001f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (-2085012671));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 810831012, (float) 102402L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 35, 0.99999994f, 9700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-0.0d), (double) (-100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(2.718281828459045d, (double) 5.4975581E11f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-1364700796));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.598642887012151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (short) 10, 149.8776452122921d, (double) 1528444521);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 71.11504888534546d + "'", double3 == 71.11504888534546d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 24L, (double) 14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.433629385640828d + "'", double2 == 11.433629385640828d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int int2 = org.apache.commons.math.util.FastMath.min(70, (-103));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-103) + "'", int2 == (-103));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray23);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray31 = new double[] { (-1L), (short) -1 };
        double[] doubleArray38 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        double[] doubleArray42 = new double[] { (-1L), (short) -1 };
        double[] doubleArray49 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray38);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 1024);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 92.90780141843972d + "'", double27 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.32435767170008E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(530, (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { (-1L), (short) -1 };
        double[] doubleArray10 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 350);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        try {
            double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (-1023));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-20.0d), (java.lang.Number) 99.99999f, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.0088970726893107E87d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((-0.7628881244594873d), 6.1798740081135376E10d, 1.0d, Double.NaN);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.5840734641020688d);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver1.solve(1024458752, univariateRealFunction4, 1.171820983713485d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079574628, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1165481377421338384L + "'", long2 == 1165481377421338384L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 5900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.375854803271912d + "'", double1 == 9.375854803271912d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-493343386), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 97, n = -493,343,386");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1078591488);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1024458787, 0.0d, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(0);
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(97.00000000000004d, (double) (-1364700796));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1563524172), (double) (-1.0000001f), 24.113475177304977d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3628800L, (float) (-4L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.4161468365471424d), 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve((int) (byte) 1, univariateRealFunction4, (double) (-59L), (-9.379315578525171E8d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 9.306943617238488d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4012984643248169E-45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { (-1L), (short) -1 };
        double[] doubleArray10 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 350);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.05555555555555555d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05549847010902635d) + "'", double1 == (-0.05549847010902635d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double double1 = org.apache.commons.math.util.FastMath.ceil(643398.1754551897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 643399.0d + "'", double1 == 643399.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1609564159);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-725723463), (float) 1024458752L, (float) 4686341230761026059L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-65));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.609564159E9d, 3628800.0d, (-1.14998797277684019E18d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,609,564,159, 3,628,800]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 9.28825894386454d, 0.0d, (double) 1, 1464788108);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100);
        double double5 = regulaFalsiSolver4.getRelativeAccuracy();
        double double6 = regulaFalsiSolver4.getMax();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray10 = new double[] { (-1L), (short) -1 };
        double[] doubleArray17 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 10);
        java.lang.Object[] objArray24 = new java.lang.Object[] { regulaFalsiSolver4, localizedFormats7, doubleArray20, (byte) 1, 0.8342233605065096d, 1.1102230246251565E-16d };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray24);
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException32 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 5.237055765311842d, 3.762195691083632d, (-0.4161468365471424d), (-0.017453292519943295d), objArray31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException42 = new org.apache.commons.math.exception.NullArgumentException(localizable39, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray41);
        java.lang.Object[] objArray44 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray41);
        org.apache.commons.math.exception.NoBracketingException noBracketingException45 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (double) (-0.99999994f), 1.4012984643248169E-45d, 6.579251212010101d, 4.61512051684126d, objArray41);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 5.857933154483459d, (java.lang.Number) 99.99999f, true);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException52 = new org.apache.commons.math.exception.DimensionMismatchException(1528444521, (int) (byte) -1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats53, number54, (java.lang.Number) 1.8452701486440284d, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException62 = new org.apache.commons.math.exception.NullArgumentException(localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats58, objArray61);
        java.lang.Object[] objArray64 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray61);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException52, (org.apache.commons.math.exception.util.Localizable) localizedFormats53, objArray64);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 5.237055765311842d, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray64);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray64);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) 'a');
        incrementor0.incrementCount();
        incrementor0.incrementCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = noBracketingException4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException(localizable9, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = mathIllegalArgumentException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math.exception.NullArgumentException(localizable16, objArray18);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray18);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray18);
        java.util.Set<java.lang.String> strSet22 = exceptionContext6.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1010, (double) (-6324));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6322.477253478577d) + "'", double2 == (-6322.477253478577d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(333566592, (-1078591488));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 384 + "'", int2 == 384);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 52, (-1.2927473687524549d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.999996f + "'", float2 == 51.999996f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1074790400, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.079574628E9d, 0.0d, (double) (-6));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1091414619L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963258786546d + "'", double1 == 1.5707963258786546d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(23.4845423302582d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, (long) 1528444521);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1528444424L) + "'", long2 == (-1528444424L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 1024458787, (int) (short) 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((-1.6225927682921336E34d), 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        double double2 = org.apache.commons.math.util.FastMath.copySign(20.795391502771416d, (double) 1.14998794E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.795391502771416d + "'", double2 == 20.795391502771416d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.8390715290764523d));
        double double2 = regulaFalsiSolver1.getStartValue();
        double double3 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 107.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4739391957277546E46d + "'", double1 == 1.4739391957277546E46d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, number1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (-725723463));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-725,723,463)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(363.7393755555636d, 6.471550100004411E9d, (double) 1942043457);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.6124536350509007d, (java.lang.Number) (-14L), (-102));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1609564159);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 10.0d, (int) '#', orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 81.55795945611504d, 1078591488, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.691673596021348E41d, (java.lang.Number) 0.6610060414837631d, 1024, orderDirection9, true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        float[] floatArray4 = new float[] { 10.0f, (short) -1, (-100), 1.07859162E9f };
        float[] floatArray8 = new float[] { '#', 52.0f, 1 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray8);
        float[] floatArray15 = new float[] { '#', 52.0f, 1 };
        float[] floatArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray15, floatArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray16);
        float[] floatArray25 = new float[] { 52L, 52.0f, (-1.0f), (-20L), (short) 0, 6L };
        float[] floatArray30 = new float[] { 10.0f, (short) -1, (-100), 1.07859162E9f };
        float[] floatArray34 = new float[] { '#', 52.0f, 1 };
        float[] floatArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray34, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray30, floatArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray30);
        float[] floatArray43 = new float[] { 202L, 'a', (-19.999998f), 3628799.8f };
        float[] floatArray48 = new float[] { 102400L, 1.07859149E9f, (-71), 1078591494 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray30, floatArray43);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray43);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 51.94273703751599d, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray23);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.481177023534592d + "'", double13 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 92.90780141843972d + "'", double27 == 92.90780141843972d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 105.48459603183775d + "'", double31 == 105.48459603183775d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(100.0d, 25.832815729997478d, 2.0088970726893107E87d, (-0.0d), 3.7621956910836314d, 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2948.21455503486d + "'", double6 == 2948.21455503486d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2599210498948732d) + "'", double1 == (-1.2599210498948732d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 52.0d, (java.lang.Number) 1163359712316751872L, false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { (-1L), (short) -1 };
        double[] doubleArray10 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray16 = new double[] { (-1L), (short) -1 };
        double[] doubleArray23 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double[] doubleArray29 = new double[] { (-1L), (short) -1 };
        double[] doubleArray36 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray40 = new double[] { (-1L), (short) -1 };
        double[] doubleArray47 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray47);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray23);
        double[] doubleArray54 = new double[] { (-1L), (short) -1 };
        double[] doubleArray61 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 10);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray68 = new double[] { (-1L), (short) -1 };
        double[] doubleArray75 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray75);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 10);
        double[] doubleArray81 = new double[] { (-1L), (short) -1 };
        double[] doubleArray88 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray81, doubleArray88);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) 10);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray78, (int) '4');
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray64);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 7.481177023534592d + "'", double65 == 7.481177023534592d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 2.0d + "'", double76 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.0d + "'", double89 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 7.481177023534592d + "'", double96 == 7.481177023534592d);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        double double2 = org.apache.commons.math.util.FastMath.copySign(6.1798740081135376E10d, 352899.6264909459d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.1798740081135376E10d + "'", double2 == 6.1798740081135376E10d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-7417428586279206912L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.62939453125E-6d, 1.5223978110163001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0114329355827245E-6d + "'", double2 == 5.0114329355827245E-6d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3628800L, (float) (-103));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-103.0f) + "'", float2 == (-103.0f));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) (short) 100, 6.38905609893065d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1754754559420733d, 1.2927473687524549d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 35L, 92.90780141843973d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        double[] doubleArray4 = new double[] { (-1L), (short) -1 };
        double[] doubleArray11 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray11);
        double[] doubleArray15 = new double[] { (-1L), (short) -1 };
        double[] doubleArray22 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection25, doubleArray26);
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats1, orderDirection25 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray28);
        org.apache.commons.math.exception.NoBracketingException noBracketingException34 = new org.apache.commons.math.exception.NoBracketingException((double) 10.0f, 1.9867717342662448d, (double) (-1), (double) 100.0f);
        double double35 = noBracketingException34.getHi();
        double double36 = noBracketingException34.getFHi();
        mathIllegalStateException29.addSuppressed((java.lang.Throwable) noBracketingException34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException44 = new org.apache.commons.math.exception.NullArgumentException(localizable41, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray43);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext46 = mathIllegalArgumentException45.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException51 = new org.apache.commons.math.exception.NullArgumentException(localizable48, objArray50);
        exceptionContext46.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray50);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException53 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray50);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) noBracketingException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray50);
        java.lang.Throwable[] throwableArray55 = noBracketingException34.getSuppressed();
        double double56 = noBracketingException34.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.9867717342662448d + "'", double35 == 1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(exceptionContext46);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0L };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException(localizable3, objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray5);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, objArray5);
        java.lang.String str9 = notFiniteNumberException8.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NotFiniteNumberException: overflow: lcm(100, 0) is 2^63" + "'", str9.equals("org.apache.commons.math.exception.NotFiniteNumberException: overflow: lcm(100, 0) is 2^63"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) 'a');
        incrementor0.setMaximalCount((int) (short) -1);
        int int6 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.020683531529582487d) + "'", double1 == (-0.020683531529582487d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.9155040003582885E22d, (double) 1.02445882E9f, 1.079574628E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.1559430693392916E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.1559430693392927E18d + "'", double1 == 8.1559430693392927E18d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 1.07859162E9f, 3.141592653589793d, (double) (-99.99999f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver0.solve(1942043457, univariateRealFunction3, 1.8452701486440284d, (double) 1079574528, 4.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(94.69420069252865d, (double) (-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [94.694, -1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 100.0f, (double) 530);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.7591697253775689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065095d + "'", double1 == 0.8342233605065095d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 24L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-1496542223), (float) (-9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "conversion exception in transformation" + "'", str1.equals("conversion exception in transformation"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438018d + "'", double1 == 1.1752011936438018d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1563524172));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) (-70));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        double[] doubleArray2 = new double[] { (-1L), (short) -1 };
        double[] doubleArray9 = new double[] { 1.0d, (-1), (byte) 100, (-1), ' ', 10.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray9);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        double double1 = org.apache.commons.math.util.FastMath.log(1.1499879727768402E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.19145334374646d + "'", double1 == 46.19145334374646d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.01214849521004071d), 0.881373587019543d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 103L, (-0.9589470817428194d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        double double1 = org.apache.commons.math.util.FastMath.signum(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 7, 149.9290780141844d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        double double2 = org.apache.commons.math.util.FastMath.max((-44.8534693539332d), (double) (-71));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-44.8534693539332d) + "'", double2 == (-44.8534693539332d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-19.999998f), 0.5537983798262428d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5537983798262428d + "'", double2 == 0.5537983798262428d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 761385567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 761385567 + "'", int2 == 761385567);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int int2 = org.apache.commons.math.util.FastMath.max((-9), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (byte) 1);
        int[] intArray3 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 1);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) (byte) 1);
        int[] intArray12 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) (byte) 1);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray12);
        int[] intArray16 = null;
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
    }
}

