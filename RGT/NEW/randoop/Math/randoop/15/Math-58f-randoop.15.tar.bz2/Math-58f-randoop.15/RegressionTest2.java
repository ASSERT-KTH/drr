import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.17453292519943295d, (-0.5637033385775058d), (double) (-100.0f), 10.0d, 0.8623188722876839d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double double1 = simpleVectorialValueChecker0.getRelativeThreshold();
        double double2 = simpleVectorialValueChecker0.getAbsoluteThreshold();
        double double3 = simpleVectorialValueChecker0.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-14d + "'", double1 == 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2250738585072014E-306d + "'", double2 == 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2250738585072014E-306d + "'", double3 == 2.2250738585072014E-306d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 33.0f, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.41733920768E11d + "'", double2 == 1.41733920768E11d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) -1, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0000001f) + "'", float2 == (-1.0000001f));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) ' ');
        int int4 = incrementor0.getCount();
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52, (java.lang.Number) 100L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter8 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        gaussianFitter8.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer13 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker14 = levenbergMarquardtOptimizer13.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter15 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer13);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric16 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray23 = curveFitter15.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric16, doubleArray22);
        double[] doubleArray24 = gaussianFitter8.fit(doubleArray23);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint28 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double29 = weightedObservedPoint28.getWeight();
        double double30 = weightedObservedPoint28.getY();
        gaussianFitter8.addObservedPoint(weightedObservedPoint28);
        curveFitter6.addObservedPoint(weightedObservedPoint28);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 35.0d + "'", double29 == 35.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', 3.600244966869294E10d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-2.2165681500327983d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker10 = levenbergMarquardtOptimizer9.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter11 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer9);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric12 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray18 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray19 = curveFitter11.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric12, doubleArray18);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker24 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter25 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer23);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric26 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray33 = curveFitter25.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric26, doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray32, true);
        double[] doubleArray36 = vectorialPointValuePair35.getPoint();
        double[] doubleArray37 = vectorialPointValuePair35.getValue();
        double[] doubleArray38 = vectorialPointValuePair35.getValue();
        double[] doubleArray39 = gaussianFitter5.fit(doubleArray38);
        double[] doubleArray40 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray40, true);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-99.99999f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        curveFitter5.clearObservations();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.Number number4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number4, objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number8);
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable12, "", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        java.lang.String str23 = optimizationException22.getPattern();
        java.lang.Object[] objArray24 = optimizationException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException9, "hi!", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) maxCountExceededException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.8147045416011185E-6d, (java.lang.Number) 1.0000001192092967d, true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6065306134380164d, 0.25979131427121077d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8781870412871935d + "'", double2 == 0.8781870412871935d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.Object[] objArray13 = optimizationException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException19 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats18);
        java.lang.Object[] objArray20 = zeroException19.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(throwable23, "", objArray31);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException19, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray31);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException34 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 10, objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray31);
        java.lang.Object[] objArray36 = mathException14.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException39 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats38);
        java.lang.Throwable[] throwableArray40 = zeroException39.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException45 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats44);
        java.lang.Object[] objArray46 = zeroException45.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable49 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(throwable49, "", objArray57);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException45, (org.apache.commons.math.exception.util.Localizable) localizedFormats47, (org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray57);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException39, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray57);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, "hi!", objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5585053606381855d, (java.lang.Number) (-2.176084443557479d), (java.lang.Number) 7.105427357601002E-15d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3796077390275217d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.0d, (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9251475365964139d + "'", double2 == 0.9251475365964139d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.2737569024245374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8214334865463183d + "'", double1 == 0.8214334865463183d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException16, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray18);
        outOfRangeException3.addSuppressed((java.lang.Throwable) optimizationException16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer22 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter23 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer22);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = gaussianFitter23.getObservations();
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) weightedObservedPointArray24);
        java.lang.Object[] objArray27 = optimizationException16.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number6 = outOfRangeException5.getHi();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(throwable8, "", objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray16);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException18, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray20);
        outOfRangeException5.addSuppressed((java.lang.Throwable) optimizationException18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats1, outOfRangeException5 };
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        org.apache.commons.math.optimization.OptimizationException optimizationException26 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException25);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 1, (double) 1L, 2.9982229502979694d, 23.14069263277927d, (double) 9);
        double double6 = levenbergMarquardtOptimizer5.getRMS();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        int int6 = levenbergMarquardtOptimizer3.getEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588951654484d + "'", double1 == 4.641588951654484d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter3 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        gaussianFitter3.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker9 = levenbergMarquardtOptimizer8.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter10 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray17 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray18 = curveFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray17);
        double[] doubleArray19 = gaussianFitter3.fit(doubleArray18);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker24 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter25 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer23);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric26 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray33 = curveFitter25.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric26, doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray32);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter36 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        gaussianFitter36.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer41 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker42 = levenbergMarquardtOptimizer41.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter43 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer41);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric44 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray50 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray51 = curveFitter43.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric44, doubleArray50);
        double[] doubleArray52 = gaussianFitter36.fit(doubleArray51);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer56 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker57 = levenbergMarquardtOptimizer56.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter58 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer56);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric59 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray65 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray66 = curveFitter58.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric59, doubleArray65);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair67 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray65);
        boolean boolean68 = simpleVectorialValueChecker0.converged((int) (byte) 0, vectorialPointValuePair34, vectorialPointValuePair67);
        double[] doubleArray69 = vectorialPointValuePair67.getValue();
        double[] doubleArray70 = vectorialPointValuePair67.getValue();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker57);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(9.536743E-7f, 2.8872709503576206d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536744E-7f + "'", float2 == 9.536744E-7f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.math.util.FastMath.hypot(6.0d, 1.4012984643248174E-45d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, (int) (short) 1);
        int int3 = dimensionMismatchException2.getDimension();
        org.apache.commons.math.exception.util.Localizable localizable4 = dimensionMismatchException2.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, (double) (-1L), (double) (byte) -1);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter10 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer9);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = curveFitter10.getObservations();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) dimensionMismatchException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) weightedObservedPointArray11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.303822857388105E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.303822857388105E-10d + "'", double1 == 4.303822857388105E-10d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 127L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.151039979174052E54d + "'", double1 == 7.151039979174052E54d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        java.lang.Number number13 = null;
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number13, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0, number1, false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray9);
        java.lang.String str12 = optimizationException11.getPattern();
        java.lang.Object[] objArray13 = optimizationException11.getArguments();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException16);
        optimizationException11.addSuppressed((java.lang.Throwable) mathRuntimeException17);
        java.lang.String str19 = optimizationException11.getPattern();
        java.lang.String str20 = optimizationException11.getPattern();
        java.lang.String str21 = optimizationException11.toString();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.optimization.OptimizationException: hi!" + "'", str21.equals("org.apache.commons.math.optimization.OptimizationException: hi!"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 4.303822857388105E-10d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.922816251426434E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 69.53786160730874d + "'", double1 == 69.53786160730874d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException2);
        java.lang.Throwable[] throwableArray4 = mathException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-63.5f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6442371294280543E-28d + "'", double1 == 2.6442371294280543E-28d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 9.536743E-7f, (double) 33.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.5367431640625E-7d + "'", double2 == 9.5367431640625E-7d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.5585053606381855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number7 = outOfRangeException6.getHi();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(throwable9, "", objArray17);
        org.apache.commons.math.optimization.OptimizationException optimizationException19 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException19, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray21);
        outOfRangeException6.addSuppressed((java.lang.Throwable) optimizationException19);
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats2, outOfRangeException6 };
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0000109184894803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931526397897838d + "'", double1 == 0.6931526397897838d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter3 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        float float2 = org.apache.commons.math.util.FastMath.copySign(33.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-33.0f) + "'", float2 == (-33.0f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1752011936438014d, (double) (-47), (-58.0d), 1.4680664593762272d, 4.641588951654484d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(3.600244966869294E10d, 0.3796077390275217d, (double) 10.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException3 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats2);
        java.lang.Object[] objArray4 = zeroException3.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(throwable7, "", objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException22 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(throwable25, "", objArray33);
        org.apache.commons.math.optimization.OptimizationException optimizationException35 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray33);
        java.lang.Object[] objArray36 = optimizationException35.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException37 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException41 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats40);
        java.lang.Object[] objArray42 = zeroException41.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number49 = outOfRangeException48.getHi();
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(throwable51, "", objArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException61 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray59);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException61, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray63);
        outOfRangeException48.addSuppressed((java.lang.Throwable) optimizationException61);
        java.lang.Object[] objArray66 = new java.lang.Object[] { localizedFormats44, outOfRangeException48 };
        java.lang.Object[] objArray67 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException41, (org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray67);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException69 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException37, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray67);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException70 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray67);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray67);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException72 = new org.apache.commons.math.exception.MathIllegalStateException(objArray67);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException72);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (byte) 1 + "'", number49.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27941549819892586d) + "'", double1 == (-0.27941549819892586d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.69314718055995d, (java.lang.Number) (-57.29577951308232d), true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100.693 is smaller than the minimum (-57.296): exception generated in user code" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100.693 is smaller than the minimum (-57.296): exception generated in user code"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6108652381980153d + "'", double1 == 0.6108652381980153d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (int) (short) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray17 = optimizationException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException23 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats22);
        java.lang.Object[] objArray24 = zeroException23.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(throwable27, "", objArray35);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 10, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.asin(65.58819114166313d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (short) 10);
        incrementor0.incrementCount((int) (short) 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 97, (java.lang.Number) (-2.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-32L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.log10((-58.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        java.lang.Object[] objArray3 = zeroException2.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1023), (java.lang.Number) 10.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920929E-7f + "'", float2 == 1.1920929E-7f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 'a', 3.174802103936399d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.99999f + "'", float2 == 96.99999f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.math.util.FastMath.min(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = gaussianFitter7.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser9 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((-1.0d), (double) 10L, (double) 10L);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = gaussian3.derivative();
        double double6 = gaussian3.value(2.2165681500327983d);
        org.junit.Assert.assertNotNull(univariateRealFunction4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.7386662699788795d) + "'", double6 == (-0.7386662699788795d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        java.lang.Object[] objArray3 = zeroException2.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException19 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, (int) (short) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException22 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats21);
        java.lang.Object[] objArray23 = zeroException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) dimensionMismatchException19, "", objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException(localizable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 6L, (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.526483E-38f + "'", float2 == 3.526483E-38f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0000036394832477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException20 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats19);
        java.lang.Object[] objArray21 = zeroException20.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(throwable24, "", objArray32);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException20, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray32);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray32);
        java.lang.Object[] objArray38 = mathException15.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException15);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.addObservedPoint((double) (-1.0000001f), 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.String str13 = optimizationException12.getPattern();
        java.lang.Object[] objArray14 = optimizationException12.getArguments();
        org.apache.commons.math.exception.ConvergenceException convergenceException15 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.rint((-36.21784016432742d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.0d) + "'", double1 == (-36.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double22 = weightedObservedPoint21.getWeight();
        double double23 = weightedObservedPoint21.getY();
        gaussianFitter1.addObservedPoint(weightedObservedPoint21);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = gaussianFitter1.getObservations();
        gaussianFitter1.addObservedPoint((-14.148409796207115d), (double) 640.0f);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer32 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker33 = levenbergMarquardtOptimizer32.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter34 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer32);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric35 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray41 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray42 = curveFitter34.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric35, doubleArray41);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer46 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker47 = levenbergMarquardtOptimizer46.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter48 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer46);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric49 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray55 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray56 = curveFitter48.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric49, doubleArray55);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair58 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray55, true);
        double[] doubleArray59 = vectorialPointValuePair58.getPoint();
        double[] doubleArray60 = vectorialPointValuePair58.getValueRef();
        try {
            double[] doubleArray61 = gaussianFitter1.fit(doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 35.0d + "'", double22 == 35.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1102230246251627E-14d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) ' ');
        int int4 = incrementor0.getCount();
        incrementor0.incrementCount(0);
        int int7 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-63.5f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((-1.0000001f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double22 = weightedObservedPoint21.getWeight();
        double double23 = weightedObservedPoint21.getY();
        gaussianFitter1.addObservedPoint(weightedObservedPoint21);
        gaussianFitter1.clearObservations();
        gaussianFitter1.addObservedPoint((double) (-99.99999f), (double) 100.0f);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(1.0477450232973254E41d, 0.0d, 1.1447298858494002d);
        gaussianFitter1.addObservedPoint(weightedObservedPoint32);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 35.0d + "'", double22 == 35.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 0, (int) (short) -1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1.0f, 4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian(0.0d, 0.0d, (double) 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) nullArgumentException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.String str5 = localizedFormats4.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(throwable8, "", objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray16);
        java.lang.String str19 = optimizationException18.getPattern();
        java.lang.Object[] objArray20 = optimizationException18.getArguments();
        org.apache.commons.math.exception.ConvergenceException convergenceException21 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) nullArgumentException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "distribution not loaded" + "'", str5.equals("distribution not loaded"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException5 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats4);
        java.lang.Object[] objArray6 = zeroException5.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(throwable9, "", objArray17);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException24 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(throwable27, "", objArray35);
        org.apache.commons.math.optimization.OptimizationException optimizationException37 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray35);
        java.lang.Object[] objArray38 = optimizationException37.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException39 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException43 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats42);
        java.lang.Object[] objArray44 = zeroException43.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number51 = outOfRangeException50.getHi();
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(throwable53, "", objArray61);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray61);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException63, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray65);
        outOfRangeException50.addSuppressed((java.lang.Throwable) optimizationException63);
        java.lang.Object[] objArray68 = new java.lang.Object[] { localizedFormats46, outOfRangeException50 };
        java.lang.Object[] objArray69 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray68);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException70 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException43, (org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray69);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException71 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray69);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException72 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray69);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray69);
        convergenceException1.addSuppressed((java.lang.Throwable) convergenceException21);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (byte) 1 + "'", number51.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray69);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, (double) (-1L), (double) (byte) -1);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        curveFitter4.addObservedPoint((-2.0d), 0.25979131427121077d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(32.0d, (double) (-1), (double) 1, (double) 1.0f, (double) 100);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-2.2165681500327983d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2165681500327983d + "'", double2 == 2.2165681500327983d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, 52, (int) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number11 = outOfRangeException10.getHi();
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(throwable13, "", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException23, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray25);
        outOfRangeException10.addSuppressed((java.lang.Throwable) optimizationException23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException31 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats30);
        java.lang.Object[] objArray32 = zeroException31.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(throwable35, "", objArray43);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray43);
        java.lang.String str47 = convergenceException46.getPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException50 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats49);
        java.lang.Throwable[] throwableArray51 = zeroException50.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException56 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats55);
        java.lang.Object[] objArray57 = zeroException56.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable60, "", objArray68);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException56, (org.apache.commons.math.exception.util.Localizable) localizedFormats58, (org.apache.commons.math.exception.util.Localizable) localizedFormats59, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats54, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException50, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray68);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException46, "matrix must have at least one row", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable28, objArray68);
        java.lang.Throwable[] throwableArray76 = convergenceException75.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException77 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray76);
        java.lang.Number number78 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 1 + "'", number11.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "row index ({0})" + "'", str47.equals("row index ({0})"));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + (byte) 10 + "'", number78.equals((byte) 10));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.8146972656435034E-6d, (java.lang.Number) 23.14069263277927d, false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((-1.0d), (double) 10L, (double) 10L);
        double double5 = gaussian3.value(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = gaussian3.derivative();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.6065306597126334d) + "'", double5 == (-0.6065306597126334d));
        org.junit.Assert.assertNotNull(univariateRealFunction6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 9.536744E-7f, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.536744300930875E-7d + "'", double2 == 9.536744300930875E-7d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9251475365964139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(3.174802103936399d, (double) 100.0f, 2.2250738585072014E-306d);
        double double4 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.2250738585072014E-306d + "'", double4 == 2.2250738585072014E-306d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1023));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1023.0d) + "'", double1 == (-1023.0d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 1, (double) 1L, 2.9982229502979694d, 23.14069263277927d, (double) 9);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-32L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.8413553802373092d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getSpecificPattern();
        java.lang.Throwable[] throwableArray3 = convergenceException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-0.0d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) tooManyEvaluationsException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number10 = outOfRangeException9.getHi();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable12, "", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException22, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        outOfRangeException9.addSuppressed((java.lang.Throwable) optimizationException22);
        java.lang.Number number27 = outOfRangeException9.getLo();
        java.lang.Number number28 = outOfRangeException9.getLo();
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray36 = notStrictlyPositiveException35.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException(throwable30, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)", (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException41 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats40);
        java.lang.Object[] objArray42 = zeroException41.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable45 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(throwable45, "", objArray53);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException41, (org.apache.commons.math.exception.util.Localizable) localizedFormats43, (org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException58 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats57);
        java.lang.Object[] objArray59 = zeroException58.getArguments();
        java.lang.Object[] objArray60 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray59);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException61 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, (java.lang.Number) 127L, objArray59);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) tooManyEvaluationsException1, "out of bounds significance level {0}, must be between {1} and {2}", objArray59);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 17.5d + "'", number27.equals(17.5d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 17.5d + "'", number28.equals(17.5d));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float1 = org.apache.commons.math.util.FastMath.signum(8.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        float float2 = org.apache.commons.math.util.FastMath.min((-99.99999f), 35.000004f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-99.99999f) + "'", float2 == (-99.99999f));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        incrementor0.resetCount();
        incrementor0.setMaximalCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian(3.8146972656435034E-6d, 1.6550750510951014E68d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian(4.4864456922990596E-9d, 0.6931471805599453d, 17.5d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker18 = levenbergMarquardtOptimizer17.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter19 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer17);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric20 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray27 = curveFitter19.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric20, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray26, true);
        double[] doubleArray30 = vectorialPointValuePair29.getPoint();
        double[] doubleArray31 = vectorialPointValuePair29.getPoint();
        double[] doubleArray32 = vectorialPointValuePair29.getValueRef();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray9);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException11, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(throwable18, "", objArray26);
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray26);
        java.lang.String str29 = optimizationException28.getPattern();
        java.lang.Object[] objArray30 = optimizationException28.getArguments();
        org.apache.commons.math.exception.ConvergenceException convergenceException31 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException34 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats33);
        java.lang.Throwable[] throwableArray35 = zeroException34.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "org.apache.commons.math.exception.NumberIsTooSmallException: 100.693 is smaller than the minimum (-57.296): exception generated in user code", (java.lang.Object[]) throwableArray35);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 25L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1102230246251565E-14d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        float float2 = org.apache.commons.math.util.FastMath.scalb(640.00006f, (-1023));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        incrementor0.resetCount();
        int int6 = incrementor0.getCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer21 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker22 = levenbergMarquardtOptimizer21.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter23 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer21);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric24 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray30 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray31 = curveFitter23.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric24, doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray30);
        double[] doubleArray33 = vectorialPointValuePair32.getValue();
        double[] doubleArray34 = vectorialPointValuePair32.getValue();
        double[] doubleArray35 = vectorialPointValuePair32.getValue();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (int) (short) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray17 = optimizationException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException23 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats22);
        java.lang.Object[] objArray24 = zeroException23.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(throwable27, "", objArray35);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 10, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 32L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 47.0106325440482d, (java.lang.Number) (-0.0d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-2L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.9999999f) + "'", float1 == (-1.9999999f));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.440892098500626E-16d, (java.lang.Number) 2.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.0f + "'", number4.equals(2.0f));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1.0f), 0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        java.lang.Object[] objArray3 = zeroException2.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        java.lang.Throwable throwable20 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(throwable20, "", objArray28);
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math.optimization.OptimizationException optimizationException31 = new org.apache.commons.math.optimization.OptimizationException("", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, "exponent ({0})", objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.ZeroException zeroException34 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(throwable37, "", objArray45);
        java.lang.Object[] objArray47 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray45);
        org.apache.commons.math.optimization.OptimizationException optimizationException48 = new org.apache.commons.math.optimization.OptimizationException("", objArray47);
        java.lang.Object[] objArray49 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray47);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray47);
        java.lang.Throwable[] throwableArray51 = mathIllegalStateException50.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.log(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.35050620855721d) + "'", double1 == (-35.35050620855721d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.Object[] objArray13 = optimizationException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        java.lang.String str15 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "percentile implementation {0} does not support {1}" + "'", str15.equals("percentile implementation {0} does not support {1}"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 10);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 10 + "'", number2.equals((byte) 10));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        int int5 = levenbergMarquardtOptimizer3.getJacobianEvaluations();
        double double6 = levenbergMarquardtOptimizer3.getRMS();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5267301521329272d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 0L, (double) 100.0f, (double) (byte) -1);
        curveFitter5.addObservedPoint(weightedObservedPoint17);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        float float2 = org.apache.commons.math.util.FastMath.max((-99.99999f), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) ' ');
        int int4 = incrementor0.getCount();
        int int5 = incrementor0.getCount();
        int int6 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(throwable5, "", objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) zeroException1);
        org.apache.commons.math.exception.util.Localizable localizable17 = zeroException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) zeroException1);
        java.lang.Number number19 = zeroException1.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(3.1622776601683795d, (double) 6);
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker9 = levenbergMarquardtOptimizer8.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter10 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray17 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray18 = curveFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray17);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer22 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker23 = levenbergMarquardtOptimizer22.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter24 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer22);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric25 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray31 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray32 = curveFitter24.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric25, doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray31, true);
        double[] doubleArray35 = vectorialPointValuePair34.getPoint();
        double[] doubleArray36 = vectorialPointValuePair34.getValue();
        double[] doubleArray37 = vectorialPointValuePair34.getValueRef();
        double[] doubleArray38 = vectorialPointValuePair34.getValueRef();
        double[] doubleArray39 = vectorialPointValuePair34.getPointRef();
        double[] doubleArray40 = vectorialPointValuePair34.getPoint();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer44 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker45 = levenbergMarquardtOptimizer44.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter46 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer44);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric47 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray53 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray54 = curveFitter46.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric47, doubleArray53);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer58 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker59 = levenbergMarquardtOptimizer58.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter60 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer58);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric61 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray67 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray68 = curveFitter60.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric61, doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray54, doubleArray67, true);
        double[] doubleArray71 = vectorialPointValuePair70.getPoint();
        double[] doubleArray72 = vectorialPointValuePair70.getPoint();
        double[] doubleArray73 = vectorialPointValuePair70.getPoint();
        boolean boolean74 = simpleVectorialValueChecker2.converged((int) (short) 1, vectorialPointValuePair34, vectorialPointValuePair70);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1622776601683795d + "'", double3 == 3.1622776601683795d);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number9 = outOfRangeException8.getHi();
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable11, "", objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray19);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException21, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray23);
        outOfRangeException8.addSuppressed((java.lang.Throwable) optimizationException21);
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats4, outOfRangeException8 };
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException31 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats30);
        java.lang.Object[] objArray32 = zeroException31.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number39 = outOfRangeException38.getHi();
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(throwable41, "", objArray49);
        org.apache.commons.math.optimization.OptimizationException optimizationException51 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray49);
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException51, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray53);
        outOfRangeException38.addSuppressed((java.lang.Throwable) optimizationException51);
        java.lang.Object[] objArray56 = new java.lang.Object[] { localizedFormats34, outOfRangeException38 };
        java.lang.Object[] objArray57 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray56);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray57);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number63 = outOfRangeException62.getHi();
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(throwable65, "", objArray73);
        org.apache.commons.math.optimization.OptimizationException optimizationException75 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray73);
        java.lang.Object[] objArray77 = null;
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException75, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray77);
        outOfRangeException62.addSuppressed((java.lang.Throwable) optimizationException75);
        java.lang.Number number80 = outOfRangeException62.getLo();
        java.lang.Number number81 = outOfRangeException62.getLo();
        java.lang.Throwable throwable83 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats84 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats85 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats86 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats86, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray89 = notStrictlyPositiveException88.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException90 = new org.apache.commons.math.exception.MathIllegalStateException(throwable83, (org.apache.commons.math.exception.util.Localizable) localizedFormats84, (org.apache.commons.math.exception.util.Localizable) localizedFormats85, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException62, "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)", (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 1 + "'", number9.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (byte) 1 + "'", number39.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + (byte) 1 + "'", number63.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 17.5d + "'", number80.equals(17.5d));
        org.junit.Assert.assertTrue("'" + number81 + "' != '" + 17.5d + "'", number81.equals(17.5d));
        org.junit.Assert.assertTrue("'" + localizedFormats84 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats84.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertTrue("'" + localizedFormats85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats85.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats86 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats86.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.5637033385775058d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5343202207565196d) + "'", double1 == (-0.5343202207565196d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = tooManyEvaluationsException1.getGeneralPattern();
        org.apache.commons.math.exception.ConvergenceException convergenceException3 = new org.apache.commons.math.exception.ConvergenceException(localizable2);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 9.536744E-7f, (double) 52, 1.468066459376227d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.String str13 = optimizationException12.getPattern();
        java.lang.Object[] objArray14 = optimizationException12.getArguments();
        org.apache.commons.math.exception.ConvergenceException convergenceException15 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException18 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats17);
        java.lang.Throwable[] throwableArray19 = zeroException18.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.ZeroException zeroException29 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats28);
        org.apache.commons.math.exception.util.Localizable localizable30 = zeroException29.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number37 = outOfRangeException36.getHi();
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(throwable39, "", objArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException49 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray47);
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException49, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray51);
        outOfRangeException36.addSuppressed((java.lang.Throwable) optimizationException49);
        java.lang.Object[] objArray54 = new java.lang.Object[] { localizedFormats32, outOfRangeException36 };
        java.lang.Object[] objArray55 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("hi!", objArray54);
        java.lang.Object[] objArray57 = convergenceException56.getArguments();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable30, objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray57);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (byte) 1 + "'", number37.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (int) (short) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray17 = optimizationException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException23 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats22);
        java.lang.Object[] objArray24 = zeroException23.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(throwable27, "", objArray35);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 10, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray50 = notStrictlyPositiveException49.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.optimization.OptimizationException optimizationException53 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.ZeroException zeroException55 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats41);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.String str1 = mathException0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math.MathException: " + "'", str1.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.27941549819892586d), (java.lang.Number) 100, (java.lang.Number) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(6);
        int int5 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker18 = levenbergMarquardtOptimizer17.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter19 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer17);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric20 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray27 = curveFitter19.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric20, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray26, true);
        double[] doubleArray30 = vectorialPointValuePair29.getPoint();
        double[] doubleArray31 = vectorialPointValuePair29.getValue();
        double[] doubleArray32 = vectorialPointValuePair29.getValueRef();
        double[] doubleArray33 = vectorialPointValuePair29.getValueRef();
        double[] doubleArray34 = vectorialPointValuePair29.getValue();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException16, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray18);
        outOfRangeException3.addSuppressed((java.lang.Throwable) optimizationException16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer22 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter23 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer22);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = gaussianFitter23.getObservations();
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) weightedObservedPointArray24);
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser27 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-58.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.014684421564509876d), (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.014684421564509874d) + "'", double2 == (-0.014684421564509874d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.69314718055995d, (java.lang.Number) (-57.29577951308232d), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number10 = outOfRangeException9.getHi();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable12, "", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException22, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        outOfRangeException9.addSuppressed((java.lang.Throwable) optimizationException22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer28 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter29 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer28);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray30 = gaussianFitter29.getObservations();
        java.lang.Object[] objArray31 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException22, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) weightedObservedPointArray30);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException35 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException43.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) dimensionMismatchException35, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) throwableArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-57.29577951308232d) + "'", number5.equals((-57.29577951308232d)));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertNotNull(weightedObservedPointArray30);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(throwableArray44);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, 52, (int) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number11 = outOfRangeException10.getHi();
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(throwable13, "", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException23, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray25);
        outOfRangeException10.addSuppressed((java.lang.Throwable) optimizationException23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException31 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats30);
        java.lang.Object[] objArray32 = zeroException31.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable35 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(throwable35, "", objArray43);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray43);
        java.lang.String str47 = convergenceException46.getPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException50 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats49);
        java.lang.Throwable[] throwableArray51 = zeroException50.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException56 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats55);
        java.lang.Object[] objArray57 = zeroException56.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable60, "", objArray68);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException56, (org.apache.commons.math.exception.util.Localizable) localizedFormats58, (org.apache.commons.math.exception.util.Localizable) localizedFormats59, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats54, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException50, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray68);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException46, "matrix must have at least one row", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable28, objArray68);
        java.lang.Throwable[] throwableArray76 = convergenceException75.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException77 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException80 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, (int) (short) 1);
        java.lang.Object[] objArray81 = dimensionMismatchException80.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats82 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats83 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        java.lang.Object[] objArray84 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException85 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats83, objArray84);
        java.lang.Object[] objArray86 = mathIllegalStateException85.getArguments();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException87 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException80, (org.apache.commons.math.exception.util.Localizable) localizedFormats82, objArray86);
        org.apache.commons.math.optimization.OptimizationException optimizationException88 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray86);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 1 + "'", number11.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "row index ({0})" + "'", str47.equals("row index ({0})"));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + localizedFormats82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats82.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats83 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats83.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertNotNull(objArray86);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, (int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException3 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) dimensionMismatchException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray17 = optimizationException16.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException22 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats21);
        java.lang.Object[] objArray23 = zeroException22.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number30 = outOfRangeException29.getHi();
        java.lang.Throwable throwable32 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable32, "", objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray40);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException42, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray44);
        outOfRangeException29.addSuppressed((java.lang.Throwable) optimizationException42);
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizedFormats25, outOfRangeException29 };
        java.lang.Object[] objArray48 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray47);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException22, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray48);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number58 = outOfRangeException57.getHi();
        java.lang.Throwable throwable60 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable60, "", objArray68);
        org.apache.commons.math.optimization.OptimizationException optimizationException70 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray68);
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException70, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray72);
        outOfRangeException57.addSuppressed((java.lang.Throwable) optimizationException70);
        java.lang.Object[] objArray75 = new java.lang.Object[] { localizedFormats53, outOfRangeException57 };
        java.lang.Object[] objArray76 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray75);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException77 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats51, (java.lang.Number) (-32L), objArray75);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray75);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) dimensionMismatchException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray79);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (byte) 1 + "'", number30.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (byte) 1 + "'", number58.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(32.0d, (double) (-1), (double) 1, (double) 1.0f, (double) 100);
        double double6 = levenbergMarquardtOptimizer5.getRMS();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer4);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = gaussianFitter5.getObservations();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("row index ({0})", (java.lang.Object[]) weightedObservedPointArray6);
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser8 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (-47));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (byte) 1, (java.lang.Number) (-1023), (java.lang.Number) 35.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable11, "", objArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("", objArray21);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException("", objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(throwable8, "", objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray16);
        java.lang.Object[] objArray19 = optimizationException18.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException23 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): simplex must contain at least one point" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): simplex must contain at least one point"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        incrementor0.resetCount();
        int int6 = incrementor0.getCount();
        int int7 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.rint((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.0d) + "'", double1 == (-57.0d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) ' ');
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.991470797049389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.476445976823991d + "'", double1 == 2.476445976823991d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) 10, 2.6881171418161356E43d, 0.0d, (double) (-1023), (-1.0d));
        int int6 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078154E-7d + "'", double1 == 1.1920928955078154E-7d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((int) ' ', (-47));
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException4.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7.105427357601002E-15d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker18 = levenbergMarquardtOptimizer17.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter19 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer17);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric20 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray27 = curveFitter19.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric20, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray26, true);
        double[] doubleArray30 = vectorialPointValuePair29.getPoint();
        double[] doubleArray31 = vectorialPointValuePair29.getValue();
        double[] doubleArray32 = vectorialPointValuePair29.getValueRef();
        double[] doubleArray33 = vectorialPointValuePair29.getValueRef();
        double[] doubleArray34 = vectorialPointValuePair29.getPointRef();
        double[] doubleArray35 = vectorialPointValuePair29.getPoint();
        double[] doubleArray36 = vectorialPointValuePair29.getValue();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer37 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter38 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer37);
        gaussianFitter38.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer43 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker44 = levenbergMarquardtOptimizer43.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter45 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer43);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric46 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray52 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray53 = curveFitter45.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric46, doubleArray52);
        double[] doubleArray54 = gaussianFitter38.fit(doubleArray53);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer58 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker59 = levenbergMarquardtOptimizer58.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter60 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer58);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric61 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray67 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray68 = curveFitter60.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric61, doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair69 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray53, doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray67);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker44);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }
}

