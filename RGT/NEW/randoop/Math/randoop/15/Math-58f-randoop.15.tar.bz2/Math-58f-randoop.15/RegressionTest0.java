import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray0 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] {};
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser1 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 10L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) '#', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.5d + "'", double2 == 17.5d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 0, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        float float1 = org.apache.commons.math.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.140692632779267d + "'", double1 == 23.140692632779267d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) -1, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction7 = null;
        double[] doubleArray12 = new double[] { Double.NEGATIVE_INFINITY, 1.7182818284590453d, (byte) 1, 10.0f };
        double[] doubleArray16 = new double[] { 0, 1.7182818284590453d, '4' };
        double[] doubleArray17 = null;
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = levenbergMarquardtOptimizer5.optimize(0, differentiableMultivariateVectorialFunction7, doubleArray12, doubleArray16, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        try {
            double[] doubleArray4 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair2 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair3 = null;
        try {
            boolean boolean4 = simpleVectorialValueChecker0.converged((int) (byte) -1, vectorialPointValuePair2, vectorialPointValuePair3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4012984643248174E-45d + "'", double1 == 1.4012984643248174E-45d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "out of bounds significance level {0}, must be between {1} and {2}" + "'", str1.equals("out of bounds significance level {0}, must be between {1} and {2}"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.1920929E-7f, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078124E-7d + "'", double2 == 1.1920928955078124E-7d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "exponent ({0})" + "'", str1.equals("exponent ({0})"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException(localizable0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(Double.NaN, 1.7182818284590453d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1 + "'", number2.equals(1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7724538509055159d + "'", double1 == 1.7724538509055159d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100.0f, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        try {
            double[] doubleArray8 = gaussianFitter7.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException3.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, (double) (-1L), (double) (byte) -1);
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction5 = null;
        double[] doubleArray11 = new double[] { 1.7182818284590453d, 1.4012984643248174E-45d, 1.7724538509055159d, 1L, (-1.0d) };
        double[] doubleArray12 = null;
        double[] doubleArray18 = new double[] { 1.1102230246251565E-14d, (-1L), (byte) 0, 100.0d, 2.718281828459045d };
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = levenbergMarquardtOptimizer3.optimize((int) (short) 10, differentiableMultivariateVectorialFunction5, doubleArray11, doubleArray12, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1920928955078124E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (short) 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.6321205588285577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray9);
        java.lang.String str12 = optimizationException11.getPattern();
        java.lang.Object[] objArray13 = optimizationException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable14 = optimizationException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = optimizationException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(23.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1325.8640228677293d + "'", double1 == 1325.8640228677293d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.69314718055995d + "'", double1 == 100.69314718055995d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric15 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray18 = new double[] { (-1.5707963267948966d), 17.5d };
        try {
            double[] doubleArray19 = curveFitter5.fit((int) (byte) 0, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric15, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.TooManyEvaluationsException; message: evaluations");
        } catch (org.apache.commons.math.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9997860728793259d) + "'", double1 == (-0.9997860728793259d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7781512503836436d + "'", double1 == 0.7781512503836436d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker18 = levenbergMarquardtOptimizer17.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter19 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer17);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric20 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray27 = curveFitter19.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric20, doubleArray26);
        double[] doubleArray28 = null;
        try {
            double[] doubleArray29 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric20, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) ' ', (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.0d) + "'", double2 == (-32.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.Object[] objArray13 = optimizationException12.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-0.0d), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1920928955078124E-7d, (java.lang.Number) 1.4E-45f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7615941559557649d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        java.lang.Number number3 = zeroException1.getArgument();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable5, objArray6);
        try {
            java.lang.String str8 = mathException7.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.27829965900511133d + "'", double2 == 0.27829965900511133d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-14.148409796207115d) + "'", double1 == (-14.148409796207115d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, 1.4012984643248174E-45d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 97.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4680664593762272d + "'", double2 == 1.4680664593762272d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        double double8 = levenbergMarquardtOptimizer5.getRMS();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction10 = null;
        double[] doubleArray11 = null;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer15 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker16 = levenbergMarquardtOptimizer15.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter17 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer15);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric18 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray24 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray25 = curveFitter17.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric18, doubleArray24);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer29 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker30 = levenbergMarquardtOptimizer29.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter31 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer29);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric32 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray38 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray39 = curveFitter31.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric32, doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray38, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer45 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker46 = levenbergMarquardtOptimizer45.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter47 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer45);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric48 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray54 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray55 = curveFitter47.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric48, doubleArray54);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer59 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker60 = levenbergMarquardtOptimizer59.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter61 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer59);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric62 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray68 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray69 = curveFitter61.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric62, doubleArray68);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair71 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray55, doubleArray68, true);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair72 = levenbergMarquardtOptimizer5.optimize((int) (byte) 0, differentiableMultivariateVectorialFunction10, doubleArray11, doubleArray25, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker60);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E10d + "'", double2 == 1.0E10d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range" + "'", str1.equals("{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, (double) (-1L), (double) (byte) -1);
        double double4 = levenbergMarquardtOptimizer3.getChiSquare();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = gaussianFitter1.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser3 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) -1, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.6931471805599453d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (short) 10, 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 640.0f + "'", float2 == 640.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-127));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 127L + "'", long1 == 127L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter7 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric8 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray14 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray15 = curveFitter7.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric8, doubleArray14);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer19 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker20 = levenbergMarquardtOptimizer19.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter21 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer19);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric22 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray28 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray29 = curveFitter21.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric22, doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray28, true);
        double[] doubleArray32 = vectorialPointValuePair31.getPoint();
        try {
            double double33 = parametric0.value((-1.5707963267948966d), doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction5 = null;
        double[] doubleArray6 = null;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter8 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        gaussianFitter8.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer13 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker14 = levenbergMarquardtOptimizer13.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter15 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer13);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric16 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray23 = curveFitter15.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric16, doubleArray22);
        double[] doubleArray24 = gaussianFitter8.fit(doubleArray23);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer28 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker29 = levenbergMarquardtOptimizer28.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter30 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer28);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric31 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray37 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray38 = curveFitter30.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray37);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray37);
        double[] doubleArray40 = null;
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = levenbergMarquardtOptimizer3.optimize((int) ' ', differentiableMultivariateVectorialFunction5, doubleArray6, doubleArray23, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter3 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        gaussianFitter3.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker10 = levenbergMarquardtOptimizer9.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter11 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer9);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric12 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray18 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray19 = curveFitter11.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric12, doubleArray18);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker24 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter25 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer23);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric26 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray33 = curveFitter25.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric26, doubleArray32);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer37 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker38 = levenbergMarquardtOptimizer37.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter39 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer37);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric40 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray46 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray47 = curveFitter39.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric40, doubleArray46);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair49 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray46, true);
        double[] doubleArray50 = vectorialPointValuePair49.getPoint();
        double[] doubleArray51 = gaussianFitter3.fit((int) (short) 100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric12, doubleArray50);
        try {
            double[] doubleArray52 = parametric0.gradient((double) (short) 10, doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9982229502979694d + "'", double1 == 2.9982229502979694d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker8 = levenbergMarquardtOptimizer7.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter9 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray16 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray17 = curveFitter9.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray16);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer21 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker22 = levenbergMarquardtOptimizer21.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter23 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer21);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric24 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray30 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray31 = curveFitter23.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric24, doubleArray30);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker36 = levenbergMarquardtOptimizer35.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter37 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric38 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray44 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray45 = curveFitter37.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric38, doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray44, true);
        double[] doubleArray48 = vectorialPointValuePair47.getPoint();
        double[] doubleArray49 = gaussianFitter1.fit((int) (short) 100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray48);
        try {
            double[] doubleArray50 = gaussianFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4012984643248174E-45d, (-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6321205588285577d) + "'", double2 == (-0.6321205588285577d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("", objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0E10d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double22 = weightedObservedPoint21.getWeight();
        double double23 = weightedObservedPoint21.getY();
        gaussianFitter1.addObservedPoint(weightedObservedPoint21);
        try {
            double[] doubleArray25 = gaussianFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 35.0d + "'", double22 == 35.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(35.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.6321205588285577d), (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (-1023));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023) + "'", int2 == (-1023));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        float float1 = org.apache.commons.math.util.FastMath.ulp(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1920928955078124E-7d, (java.lang.Number) (byte) 10, (java.lang.Number) 1.4680664593762272d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number8 = outOfRangeException7.getHi();
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(throwable10, "", objArray18);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray18);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException20, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray22);
        outOfRangeException7.addSuppressed((java.lang.Throwable) optimizationException20);
        java.lang.Object[] objArray25 = new java.lang.Object[] { localizedFormats3, outOfRangeException7 };
        java.lang.Object[] objArray26 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-127), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-63.5f) + "'", float2 == (-63.5f));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103304d + "'", double1 == 11013.232920103304d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.0d), (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1), (java.lang.Number) 3.1622776601683795d, (java.lang.Number) 7.105427357601002E-15d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-1023));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter15 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer14);
        gaussianFitter15.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer21 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker22 = levenbergMarquardtOptimizer21.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter23 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer21);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric24 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray30 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray31 = curveFitter23.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric24, doubleArray30);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker36 = levenbergMarquardtOptimizer35.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter37 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric38 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray44 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray45 = curveFitter37.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric38, doubleArray44);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer49 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker50 = levenbergMarquardtOptimizer49.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter51 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer49);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric52 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray58 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray59 = curveFitter51.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric52, doubleArray58);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair61 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray58, true);
        double[] doubleArray62 = vectorialPointValuePair61.getPoint();
        double[] doubleArray63 = gaussianFitter15.fit((int) (short) 100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric24, doubleArray62);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer67 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker68 = levenbergMarquardtOptimizer67.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter69 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer67);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric70 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray76 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray77 = curveFitter69.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric70, doubleArray76);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer81 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker82 = levenbergMarquardtOptimizer81.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter83 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer81);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric84 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray90 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray91 = curveFitter83.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric84, doubleArray90);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair93 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray77, doubleArray90, true);
        double[] doubleArray94 = vectorialPointValuePair93.getPoint();
        double[] doubleArray95 = vectorialPointValuePair93.getValue();
        double[] doubleArray96 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric24, doubleArray95);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker82);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        gaussianFitter1.addObservedPoint(weightedObservedPoint2);
        gaussianFitter1.addObservedPoint((-1.0d), (double) 100L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.apache.commons.math.util.FastMath.round(32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian(10.0d, (double) 9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        java.lang.Object[] objArray3 = zeroException2.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) zeroException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8146972656435034E-6d + "'", double1 == 3.8146972656435034E-6d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 7.105427357601002E-15d, false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1.0f, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.17453292519943295d, (-0.6065306597126334d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17453292519943295d + "'", double2 == 0.17453292519943295d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5511630870009127d + "'", double0 == 0.5511630870009127d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.6881171418161356E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long1 = org.apache.commons.math.util.FastMath.round((-32.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-32L) + "'", long1 == (-32L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(640.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 640.00006f + "'", float1 == 640.00006f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.9997860728793259d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8413553802373092d) + "'", double1 == (-0.8413553802373092d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7949577687638787d) + "'", double1 == (-0.7949577687638787d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251627E-14d + "'", double1 == 1.1102230246251627E-14d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.Localizable localizable2 = zeroException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-32L), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.0d) + "'", double2 == (-32.0d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32.0d, (java.lang.Number) 100, true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number6 = outOfRangeException5.getHi();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(throwable8, "", objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray16);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException18, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray20);
        outOfRangeException5.addSuppressed((java.lang.Throwable) optimizationException18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats1, outOfRangeException5 };
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 640.00006f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.2982224876602d + "'", double1 == 25.2982224876602d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer18 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter19 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer18);
        gaussianFitter19.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer25 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker26 = levenbergMarquardtOptimizer25.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter27 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer25);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric28 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray34 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray35 = curveFitter27.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray34);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer39 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker40 = levenbergMarquardtOptimizer39.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter41 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer39);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric42 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray48 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray49 = curveFitter41.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric42, doubleArray48);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer53 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker54 = levenbergMarquardtOptimizer53.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter55 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer53);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric56 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray62 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray63 = curveFitter55.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric56, doubleArray62);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair65 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray49, doubleArray62, true);
        double[] doubleArray66 = vectorialPointValuePair65.getPoint();
        double[] doubleArray67 = gaussianFitter19.fit((int) (short) 100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray66);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair68 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray66);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable6, "", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException16, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray18);
        outOfRangeException3.addSuppressed((java.lang.Throwable) optimizationException16);
        java.lang.Number number21 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 1 + "'", number21.equals((byte) 1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(23.140692632779267d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.14069263277927d + "'", double2 == 23.14069263277927d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        java.lang.Number number3 = tooManyEvaluationsException1.getMax();
        java.lang.Number number4 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str2.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1 + "'", number3.equals(1));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException("", objArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        double double4 = levenbergMarquardtOptimizer3.getRMS();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 3.174802103936399d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5585053606381855d, (double) 33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4864456922990596E-9d + "'", double2 == 4.4864456922990596E-9d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(throwable3, "", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray11);
        java.lang.Object[] objArray14 = optimizationException13.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        gaussianFitter4.addObservedPoint(1.1102230246251627E-14d, 4.4864456922990596E-9d, (-0.9997860728793259d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double4 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1920928955078124E-7d + "'", double4 == 1.1920928955078124E-7d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, (float) 127L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(throwable3, "", objArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray11);
        java.lang.Object[] objArray14 = optimizationException13.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.6881171418161356E43d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6550750510951014E68d + "'", double2 == 1.6550750510951014E68d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "simplex must contain at least one point" + "'", str3.equals("simplex must contain at least one point"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.8146972656435034E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 127L, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 127.0d + "'", double2 == 127.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        java.lang.Number number3 = zeroException1.getArgument();
        java.lang.Number number4 = zeroException1.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) zeroException1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.Object[] objArray13 = optimizationException12.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        java.lang.Object[] objArray15 = optimizationException14.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number6 = outOfRangeException5.getHi();
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(throwable8, "", objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray16);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException18, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray20);
        outOfRangeException5.addSuppressed((java.lang.Throwable) optimizationException18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats1, outOfRangeException5 };
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        java.lang.String str26 = mathException25.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str26.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 127L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 33);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        java.lang.String str13 = optimizationException12.getPattern();
        java.lang.Object[] objArray14 = optimizationException12.getArguments();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, 1.7182818284590453d, 2.718281828459045d, (double) 10L, 17.5d);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        gaussianFitter7.addObservedPoint((double) 100.00001f, (double) 10.0f, 1.1102230246251627E-14d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray12 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray13 = curveFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray12);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = curveFitter5.getObservations();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-32.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999873d) + "'", double1 == (-0.9999999999999873d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10L, (-14.148409796207115d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-14.148409796207115d) + "'", double2 == (-14.148409796207115d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter7 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric8 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray14 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray15 = curveFitter7.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric8, doubleArray14);
        try {
            double[] doubleArray16 = parametric0.gradient((double) 1.0f, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = gaussianFitter2.getObservations();
        java.lang.Object[] objArray4 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray3);
        org.apache.commons.math.optimization.OptimizationException optimizationException5 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math.util.FastMath.pow(17.5d, (double) 33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0477450232973254E41d + "'", double2 == 1.0477450232973254E41d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.1102230246251565E-14d, (double) (short) 100, 0.0d);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter7 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        gaussianFitter7.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer13 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker14 = levenbergMarquardtOptimizer13.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter15 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer13);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric16 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray23 = curveFitter15.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric16, doubleArray22);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer27 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker28 = levenbergMarquardtOptimizer27.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter29 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer27);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric30 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray36 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray37 = curveFitter29.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric30, doubleArray36);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer41 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker42 = levenbergMarquardtOptimizer41.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter43 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer41);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric44 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray50 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray51 = curveFitter43.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric44, doubleArray50);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray50, true);
        double[] doubleArray54 = vectorialPointValuePair53.getPoint();
        double[] doubleArray55 = gaussianFitter7.fit((int) (short) 100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric16, doubleArray54);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer56 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter57 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer56);
        gaussianFitter57.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer62 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker63 = levenbergMarquardtOptimizer62.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter64 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer62);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric65 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray71 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray72 = curveFitter64.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric65, doubleArray71);
        double[] doubleArray73 = gaussianFitter57.fit(doubleArray72);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer77 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker78 = levenbergMarquardtOptimizer77.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter79 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer77);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric80 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray86 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray87 = curveFitter79.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric80, doubleArray86);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair88 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray72, doubleArray86);
        double[] doubleArray89 = vectorialPointValuePair88.getValue();
        double[] doubleArray90 = gaussianFitter4.fit(32, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric16, doubleArray89);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker63);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker78);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10.0f, (java.lang.Number) (-1.0f), (java.lang.Number) 0);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0477450232973254E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.714314324855805E13d + "'", double1 == 4.714314324855805E13d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float2 = org.apache.commons.math.util.FastMath.copySign(32.0f, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(4.440892098500626E-16d, (double) 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.7724538509055159d, (java.lang.Number) 97, (java.lang.Number) 10L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Throwable throwable3 = null;
        try {
            notStrictlyPositiveException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "matrix must have at least one row" + "'", str1.equals("matrix must have at least one row"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number9 = outOfRangeException8.getHi();
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable11, "", objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray19);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException21, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray23);
        outOfRangeException8.addSuppressed((java.lang.Throwable) optimizationException21);
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats4, outOfRangeException8 };
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = zeroException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 1 + "'", number9.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 5, 0.6931471805599453d, (double) 1.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        gaussianFitter1.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter8 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer6);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray16 = curveFitter8.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray15);
        double[] doubleArray17 = gaussianFitter1.fit(doubleArray16);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) '#', 1.1920928955078124E-7d, (double) (short) 100);
        double double22 = weightedObservedPoint21.getWeight();
        double double23 = weightedObservedPoint21.getY();
        gaussianFitter1.addObservedPoint(weightedObservedPoint21);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = gaussianFitter1.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser26 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 35.0d + "'", double22 == 35.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 127L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.844187086458591d + "'", double1 == 4.844187086458591d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        java.lang.Object[] objArray3 = zeroException2.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 17.5d, (java.lang.Number) (byte) 1);
        java.lang.Number number10 = outOfRangeException9.getHi();
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable12, "", objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray20);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException22, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray24);
        outOfRangeException9.addSuppressed((java.lang.Throwable) optimizationException22);
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats5, outOfRangeException9 };
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) zeroException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray28);
        org.apache.commons.math.optimization.OptimizationException optimizationException30 = new org.apache.commons.math.optimization.OptimizationException("exponent ({0})", objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        double double5 = levenbergMarquardtOptimizer3.getRMS();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(3.1622776601683795d, (double) 6);
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        double double4 = simpleVectorialValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1622776601683795d + "'", double3 == 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.0d + "'", double4 == 6.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.814697265634252E-6d + "'", double1 == 3.814697265634252E-6d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(throwable0, "", objArray8);
        java.lang.Class<?> wildcardClass10 = mathException9.getClass();
        java.lang.String str11 = mathException9.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.MathException: " + "'", str11.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 2, 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1102230246251565E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double2 = org.apache.commons.math.util.FastMath.scalb(9.999999999999998d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2676506002282292E31d + "'", double2 == 1.2676506002282292E31d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, (double) (-1L), (double) (byte) -1);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        curveFitter4.clearObservations();
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter3 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        gaussianFitter3.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker9 = levenbergMarquardtOptimizer8.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter10 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray17 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray18 = curveFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray17);
        double[] doubleArray19 = gaussianFitter3.fit(doubleArray18);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker24 = levenbergMarquardtOptimizer23.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter25 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer23);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric26 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray33 = curveFitter25.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric26, doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray32);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter36 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        gaussianFitter36.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer41 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker42 = levenbergMarquardtOptimizer41.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter43 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer41);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric44 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray50 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray51 = curveFitter43.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric44, doubleArray50);
        double[] doubleArray52 = gaussianFitter36.fit(doubleArray51);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer56 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 1.4E-45f, 0.0d, (double) '#');
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker57 = levenbergMarquardtOptimizer56.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter58 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer56);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric59 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray65 = new double[] { (-1L), 7.105427357601002E-15d, 7.105427357601002E-15d, 7.105427357601002E-15d, (-1023) };
        double[] doubleArray66 = curveFitter58.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric59, doubleArray65);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair67 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray65);
        boolean boolean68 = simpleVectorialValueChecker0.converged((int) (byte) 0, vectorialPointValuePair34, vectorialPointValuePair67);
        double double69 = simpleVectorialValueChecker0.getRelativeThreshold();
        double double70 = simpleVectorialValueChecker0.getRelativeThreshold();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker57);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.1102230246251565E-14d + "'", double69 == 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.1102230246251565E-14d + "'", double70 == 1.1102230246251565E-14d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 9L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(throwable4, "", objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray12);
        java.lang.String str15 = optimizationException14.getPattern();
        java.lang.Object[] objArray16 = optimizationException14.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "hi!", objArray16);
        java.lang.String str18 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str18.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.9999999999999873d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = localizedFormats0.getLocalizedString(locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.ulp(127.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8413553802373092d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.206112358222406d) + "'", double1 == (-48.206112358222406d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(100, (-127));
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-127) + "'", int3 == (-127));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "invalid iteration limits: min={0}, max={1}" + "'", str1.equals("invalid iteration limits: min={0}, max={1}"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0L, 10.0d, (-1.0f), false, (-1L), 0.0f };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "", objArray9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray9);
        java.lang.Object[] objArray12 = optimizationException11.getArguments();
        java.lang.Object[] objArray13 = optimizationException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable14 = optimizationException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable14);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(100.0d, (double) (byte) 10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int2 = org.apache.commons.math.util.FastMath.min(52, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.0d, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000007d + "'", double1 == 1.000000000000007d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251504E-14d + "'", double1 == 1.1102230246251504E-14d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxCountExceededException1.getGeneralPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }
}

