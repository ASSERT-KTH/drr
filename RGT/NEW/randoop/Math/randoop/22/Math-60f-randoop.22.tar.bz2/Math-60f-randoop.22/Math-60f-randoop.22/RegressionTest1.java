import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        try {
            long long15 = randomDataImpl1.nextLong((long) 64, (long) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 64 is larger than, or equal to, the maximum (0): lower bound (64) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator20);
//        int int24 = randomDataImpl21.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str26 = randomDataImpl21.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray27 = new java.lang.Object[] { randomDataImpl21 };
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable19, objArray27);
//        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable34, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException33.getGeneralPattern();
//        java.lang.Number number39 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 184.51869951185168d, number39, false);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray48 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable45, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray48);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("8a5edff846", objArray48);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable37, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray48);
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable13, objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getGeneralPattern();
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 98 + "'", int24 == 98);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10d6a94818" + "'", str26.equals("10d6a94818"));
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNull(localizable30);
//        org.junit.Assert.assertNotNull(localizable37);
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(localizable55);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 64);
//        java.lang.Number number78 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 11.548739357257746d, number78, (java.lang.Number) 184.51869951185168d);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 95 + "'", int27 == 95);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "defc254fdc" + "'", str29.equals("defc254fdc"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 95 + "'", int54 == 95);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "c7bb22f347" + "'", str56.equals("c7bb22f347"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.0d, 3.255561438896672d, (double) (byte) -1);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 44.4756275059492d + "'", double4 == 44.4756275059492d);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double3 = randomDataImpl1.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 67);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.19721136851337d + "'", double1 == 4.19721136851337d);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextBeta(41.0d, (double) 91);
//        double double14 = randomDataImpl1.nextBeta((double) 1L, (double) 87);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution16 = null;
//        try {
//            double double17 = randomDataImpl1.nextInversionDeviate(continuousDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c5407a5e1bf1aa1944199875f94e1c8b5a1928" + "'", str3.equals("c5407a5e1bf1aa1944199875f94e1c8b5a1928"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33370408350622244d + "'", double11 == 0.33370408350622244d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0024898063107158083d + "'", double14 == 0.0024898063107158083d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.tanh(25.395008001580504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 10, (java.lang.Number) 0.7799726475466374d, true);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, number35);
        boolean boolean37 = notStrictlyPositiveException36.getBoundIsAllowed();
        java.lang.Number number38 = notStrictlyPositiveException36.getMin();
        java.lang.Number number39 = notStrictlyPositiveException36.getMin();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0 + "'", number38.equals(0));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0 + "'", number39.equals(0));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.23265307578861238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23694363411609892d + "'", double1 == 0.23694363411609892d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 51);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) 13, 1.0227183470559362d, 3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double31 = randomDataImpl1.nextExponential(2.226441832186995d);
//        long long33 = randomDataImpl1.nextPoisson((double) 56L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "90963bad66815e3db6ec703d2de7a99687886a" + "'", str3.equals("90963bad66815e3db6ec703d2de7a99687886a"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-60.501391007494405d) + "'", double15 == (-60.501391007494405d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-56.905138339446495d) + "'", double20 == (-56.905138339446495d));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 90.29962663383017d + "'", double29 == 90.29962663383017d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.7354624402515602d + "'", double31 == 0.7354624402515602d);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 48L + "'", long33 == 48L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 71L, 3.2584665919121987d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1077118.4929066005d + "'", double2 == 1077118.4929066005d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.special.Gamma.digamma(55.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9982147270216544d + "'", double1 == 3.9982147270216544d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException7.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 72, (java.lang.Number) 0.4430227202923068d, (java.lang.Number) 86);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.4430227202923068d + "'", number4.equals(0.4430227202923068d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 86 + "'", number7.equals(86));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        java.lang.Throwable throwable0 = null;
//        java.lang.Object[] objArray3 = null;
//        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("hi!", objArray3);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        java.lang.Object[] objArray6 = null;
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, localizable5, objArray6);
//        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
//        int int14 = randomDataImpl11.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str16 = randomDataImpl11.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { randomDataImpl11 };
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable9, objArray17);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable8, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable20 = maxIterationsExceededException19.getGeneralPattern();
//        java.lang.Number number23 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number23);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable28, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray33);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, localizable35, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException34.getGeneralPattern();
//        java.lang.Number number40 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 184.51869951185168d, number40, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        java.lang.Object[] objArray52 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable49, objArray52);
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray52);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable38, objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Object[] objArray62 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable59, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray62);
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray62);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable31, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator70 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl71 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator70);
//        int int74 = randomDataImpl71.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str76 = randomDataImpl71.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray77 = new java.lang.Object[] { randomDataImpl71 };
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable69, objArray77);
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray77);
//        java.lang.Object[] objArray80 = convergenceException79.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("4b94a28651eef283957c32092c148307a2fb06", objArray80);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(throwable0, localizable31, objArray80);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 69, (java.lang.Number) 13.0d, false);
//        java.lang.Number number88 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 93, number88, (java.lang.Number) 4);
//        org.junit.Assert.assertNotNull(localizable8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 45 + "'", int14 == 45);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "8fae4bab45" + "'", str16.equals("8fae4bab45"));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(localizable38);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 45 + "'", int74 == 45);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "dbff376ea3" + "'", str76.equals("dbff376ea3"));
//        org.junit.Assert.assertNotNull(objArray77);
//        org.junit.Assert.assertNotNull(objArray80);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9511872732601234d + "'", double1 == 2.9511872732601234d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1175745404058084E27d, (java.lang.Number) (-60.501391007494405d), true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), 1.5184364492350668d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5184364492350668d + "'", double2 == 1.5184364492350668d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        randomDataImpl1.reSeed((long) 43);
        long long9 = randomDataImpl1.nextPoisson(4.19721136851337d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        try {
//            int int17 = randomDataImpl1.nextInt(4, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (0): lower bound (4) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "fc62936e3c" + "'", str6.equals("fc62936e3c"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8629493566162406d) + "'", double9 == (-0.8629493566162406d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "f017ba9a9cfadb881bd3b4a51bb3f41afd83e4f029c9fe631024" + "'", str14.equals("f017ba9a9cfadb881bd3b4a51bb3f41afd83e4f029c9fe631024"));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException34.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 80);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.308869380063768d + "'", double1 == 4.308869380063768d);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextCauchy((double) 4, (double) 6);
//        int int11 = randomDataImpl1.nextBinomial(72, 0.569750334265312d);
//        double double14 = randomDataImpl1.nextCauchy((double) 100L, 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9ee7b29820e568dc378533716cc7fbd0729fca" + "'", str3.equals("9ee7b29820e568dc378533716cc7fbd0729fca"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.9947002357337635d + "'", double8 == 2.9947002357337635d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 40 + "'", int11 == 40);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 209.73631536691357d + "'", double14 == 209.73631536691357d);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 95);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5443.099053742821d + "'", double1 == 5443.099053742821d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        int int8 = randomDataImpl1.nextZipf(66, 9.889030319346946E42d);
        try {
            double double11 = randomDataImpl1.nextBeta((double) 69, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.012");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.437128995686965d, (double) 94);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02592109715867092d + "'", double2 == 0.02592109715867092d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.cos(53.08495167300164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9485653159430099d) + "'", double1 == (-0.9485653159430099d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-46.15206278612473d), 0.999999999524131d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(63);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        randomDataImpl1.reSeedSecure();
//        long long18 = randomDataImpl1.nextPoisson(3.408223431367131d);
//        try {
//            double double21 = randomDataImpl1.nextGamma(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7d29bb9c27e7e4839e7d349aedb6ddd2278b78" + "'", str3.equals("7d29bb9c27e7e4839e7d349aedb6ddd2278b78"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999982037104d + "'", double11 == 0.9999999982037104d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.4348782962482798d) + "'", double13 == (-1.4348782962482798d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "edfeb2039e1ffd759ae47f3ad6982f42e40a0b6c5a2952fde3873d09a8302fb0ac53fd4e52aed7720a66ac639e7821dcb2aa" + "'", str15.equals("edfeb2039e1ffd759ae47f3ad6982f42e40a0b6c5a2952fde3873d09a8302fb0ac53fd4e52aed7720a66ac639e7821dcb2aa"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2L + "'", long18 == 2L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.440148832340114d, (double) 87);
        double double3 = normalDistributionImpl2.getMean();
        double double5 = normalDistributionImpl2.density(55.9264997777119d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.440148832340114d + "'", double3 == 10.440148832340114d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.003999751265873087d + "'", double5 == 0.003999751265873087d);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        double double12 = randomDataImpl1.nextGaussian(1.5707963267948963d, 0.011366898564937883d);
//        randomDataImpl1.reSeedSecure((long) 51);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0ee0409b471b3529bcfbad2a4aef8ca5aacb63" + "'", str3.equals("0ee0409b471b3529bcfbad2a4aef8ca5aacb63"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 74.2165889273594d + "'", double9 == 74.2165889273594d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.5652237700568907d + "'", double12 == 1.5652237700568907d);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.004243366843189796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999909969324263d + "'", double1 == 0.9999909969324263d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(217.91434136884345d, (double) 72, 305.12701831142147d, 66);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long1 = org.apache.commons.math.util.FastMath.abs(56L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 56L + "'", long1 == 56L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 90);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.33370408350622244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005824234984533685d + "'", double1 == 0.005824234984533685d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.7333789863465999d, (-0.8414709848078965d), 94);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextBeta(41.0d, (double) 91);
//        double double14 = randomDataImpl1.nextBeta((double) 1L, (double) 87);
//        randomDataImpl1.reSeed();
//        java.lang.String str17 = randomDataImpl1.nextHexString(80);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e159038baa42c2a3f4294233935956d1f228a7" + "'", str3.equals("e159038baa42c2a3f4294233935956d1f228a7"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33370408350622244d + "'", double11 == 0.33370408350622244d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0024898063107158083d + "'", double14 == 0.0024898063107158083d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "f47afd8b4a8da2e8e96ca95f66e16b9ef82ba65bc3cd3bced9bc3aa6905d88189feb7613bcc4f910" + "'", str17.equals("f47afd8b4a8da2e8e96ca95f66e16b9ef82ba65bc3cd3bced9bc3aa6905d88189feb7613bcc4f910"));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.04568105053249237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.046740500384251975d + "'", double1 == 0.046740500384251975d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        java.lang.String str17 = mathException16.getPattern();
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.density((double) 32);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-16.484386101324358d) + "'", double3 == (-16.484386101324358d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.19223589283789d + "'", double4 == 103.19223589283789d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0042019221392496225d + "'", double6 == 0.0042019221392496225d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.log10(49.65108724106803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.695928762954793d + "'", double1 == 1.695928762954793d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.acos(40.89926471991978d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 64);
//        java.lang.Number number77 = null;
//        java.lang.Number number78 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number77, number78, (java.lang.Number) 0.5772156649015329d);
//        org.apache.commons.math.exception.util.Localizable localizable82 = null;
//        java.lang.Object[] objArray85 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable82, objArray85);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray85);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 35 + "'", int27 == 35);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "db09e6dfcc" + "'", str29.equals("db09e6dfcc"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 35 + "'", int54 == 35);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "7ef7ef7559" + "'", str56.equals("7ef7ef7559"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(objArray85);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0496509093924307d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.special.Gamma.digamma(7.307139146118315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9188677814631587d + "'", double1 == 1.9188677814631587d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.6245197929597313d, (java.lang.Number) 62, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str6 = convergenceException5.getPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 62 + "'", number4.equals(62));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013276747223059479d) + "'", double1 == (-0.013276747223059479d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        java.lang.Class<?> wildcardClass13 = normalDistributionImpl6.getClass();
        double double15 = normalDistributionImpl6.cumulativeProbability(1.7453292519943295d);
        double double17 = normalDistributionImpl6.cumulativeProbability((double) (byte) 0);
        double double20 = normalDistributionImpl6.cumulativeProbability(0.9999999980706751d, (double) 1.0f);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5078229326523436d + "'", double15 == 0.5078229326523436d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.647638161107807E-12d + "'", double20 == 8.647638161107807E-12d);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "76c837d9f4e9653c6442c80e9dc6d016b5dfd1" + "'", str3.equals("76c837d9f4e9653c6442c80e9dc6d016b5dfd1"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999987096935d + "'", double11 == 0.9999999987096935d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-27.937433942813755d) + "'", double13 == (-27.937433942813755d));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.278088627393561d + "'", double1 == 5.278088627393561d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 64);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5551725981744198d + "'", double1 == 1.5551725981744198d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 98);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 98L + "'", long1 == 98L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        java.lang.String str22 = notStrictlyPositiveException20.toString();
        boolean boolean23 = notStrictlyPositiveException20.getBoundIsAllowed();
        java.lang.Number number24 = notStrictlyPositiveException20.getMin();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        boolean boolean22 = notStrictlyPositiveException20.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double15 = normalDistributionImpl6.cumulativeProbability(0.0d, 71.7372090208965d);
        double[] doubleArray17 = normalDistributionImpl6.sample(78);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2898889703334897d + "'", double15 == 0.2898889703334897d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.028983478471571338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3071733273821858d + "'", double1 == 0.3071733273821858d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray5 = maxIterationsExceededException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "16d2ed3c8e61592e641e9df41be551be16f39e", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1), (-8.765505546166722d), 96.99999999999999d, 52);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 13L, (java.lang.Number) 37.83904140382365d, false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7799726475466374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0453007043318272d + "'", double1 == 1.0453007043318272d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.178979876918484E23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54.93061443340548d + "'", double1 == 54.93061443340548d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        java.lang.Number number37 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException34);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 3.948148009134E13d + "'", number37.equals(3.948148009134E13d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int1 = org.apache.commons.math.util.FastMath.abs(34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
//        int int20 = maxIterationsExceededException18.getMaxIterations();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "e400ac4929" + "'", str15.equals("e400ac4929"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 93 + "'", int20 == 93);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 38, (float) 41);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 38.0f + "'", float2 == 38.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 184.51869951185168d, number9, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 0.04457085352364287d);
        java.lang.Number number22 = notStrictlyPositiveException21.getMin();
        java.lang.Object[] objArray23 = notStrictlyPositiveException21.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0 + "'", number22.equals(0));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(85);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(90.00508564644407d, (-118.72272756237454d), 35.0d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 70);
//        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray6 = null;
//        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("hi!", objArray6);
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable8, objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException7.getGeneralPattern();
//        java.lang.Number number13 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 184.51869951185168d, number13, false);
//        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
//        java.lang.Number number17 = numberIsTooLargeException15.getMax();
//        java.lang.Number number18 = numberIsTooLargeException15.getMax();
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray24 = null;
//        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException22, localizable23, objArray24);
//        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException22.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator28 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator28);
//        int int32 = randomDataImpl29.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str34 = randomDataImpl29.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { randomDataImpl29 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable27, objArray35);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable26, objArray35);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("hi!", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException49, localizable50, objArray51);
//        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException49.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator55 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl56 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator55);
//        int int59 = randomDataImpl56.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str61 = randomDataImpl56.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { randomDataImpl56 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable54, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable53, objArray62);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException68 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number70 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) (short) 100, number70, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable53, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray78 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable53, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException15, localizable26, objArray78);
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, objArray78);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(localizable26);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 70 + "'", int32 == 70);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1cc5a58aa1" + "'", str34.equals("1cc5a58aa1"));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(localizable53);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 70 + "'", int59 == 70);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "e85cf81189" + "'", str61.equals("e85cf81189"));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray78);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        java.lang.Class<?> wildcardClass13 = normalDistributionImpl6.getClass();
        double double15 = normalDistributionImpl6.cumulativeProbability(1.7453292519943295d);
        double double17 = normalDistributionImpl6.cumulativeProbability((double) (byte) 0);
        double double19 = normalDistributionImpl6.density(1.2261911676652137d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5078229326523436d + "'", double15 == 0.5078229326523436d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.004482072124447999d + "'", double19 == 0.004482072124447999d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.0d, 3.255561438896672d, (double) (byte) -1);
        double double5 = normalDistributionImpl3.density(127.85671915442806d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.341351718524658E-156d + "'", double5 == 3.341351718524658E-156d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9999999988993884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999994496942d + "'", double1 == 0.9999999994496942d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        try {
//            double double11 = randomDataImpl1.nextF(55.9264997777119d, (-153.95873736361798d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -153.959 is smaller than, or equal to, the minimum (0): degrees of freedom (-153.959)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "18c99706e34b98a9c92745fc008e9af8790249" + "'", str3.equals("18c99706e34b98a9c92745fc008e9af8790249"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) (-0.9126063361940036d), (java.lang.Number) Double.NaN);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Object[] objArray5 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.9126063361940036d) + "'", number4.equals((-0.9126063361940036d)));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.0f, (java.lang.Number) (-1), (java.lang.Number) 1L);
        java.lang.Number number15 = outOfRangeException14.getHi();
        java.lang.Number number16 = outOfRangeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException14.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0f + "'", number16.equals(0.0f));
        org.junit.Assert.assertNotNull(localizable17);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
//        java.lang.String str21 = notStrictlyPositiveException20.toString();
//        java.lang.String str22 = notStrictlyPositiveException20.toString();
//        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
//        java.lang.Object[] objArray25 = null;
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26, localizable27, objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException26.getGeneralPattern();
//        java.lang.Number number32 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 184.51869951185168d, number32, false);
//        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
//        java.lang.Number number36 = numberIsTooLargeException34.getMax();
//        java.lang.Number number37 = numberIsTooLargeException34.getMax();
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("hi!", objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable42, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator47 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator47);
//        int int51 = randomDataImpl48.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str53 = randomDataImpl48.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { randomDataImpl48 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable46, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable45, objArray54);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray67 = null;
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("hi!", objArray67);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        java.lang.Object[] objArray70 = null;
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException68, localizable69, objArray70);
//        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException68.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable73 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator74 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl75 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator74);
//        int int78 = randomDataImpl75.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str80 = randomDataImpl75.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray81 = new java.lang.Object[] { randomDataImpl75 };
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable73, objArray81);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable72, objArray81);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException87 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable72, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number89 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException91 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable72, (java.lang.Number) (short) 100, number89, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException95 = new org.apache.commons.math.exception.OutOfRangeException(localizable72, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray97 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable72, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException34, localizable45, objArray97);
//        org.apache.commons.math.MathException mathException99 = new org.apache.commons.math.MathException(localizable23, objArray97);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
//        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNotNull(localizable45);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 69 + "'", int51 == 69);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "d9f47c9fba" + "'", str53.equals("d9f47c9fba"));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(localizable72);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 69 + "'", int78 == 69);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "24220d5884" + "'", str80.equals("24220d5884"));
//        org.junit.Assert.assertNotNull(objArray81);
//        org.junit.Assert.assertNotNull(objArray97);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.04457085352364287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3509490491747835d) + "'", double1 == (-1.3509490491747835d));
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        double double8 = randomDataImpl1.nextCauchy(0.0d, (double) 50);
//        randomDataImpl1.reSeed();
//        double double12 = randomDataImpl1.nextGamma(4.19721136851337d, 10.440148832340114d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1296.4656934408517d) + "'", double8 == (-1296.4656934408517d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 37.43048065418202d + "'", double12 == 37.43048065418202d);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        java.lang.Number number15 = outOfRangeException14.getArgument();
        java.lang.Number number16 = outOfRangeException14.getHi();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) 0 + "'", number16.equals((byte) 0));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextBeta(41.0d, (double) 91);
//        double double14 = randomDataImpl1.nextBeta((double) 1L, (double) 87);
//        randomDataImpl1.reSeed();
//        int int18 = randomDataImpl1.nextSecureInt((int) (short) -1, 9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dfeb39c347ddc8727ed261458fbb27f49c1506" + "'", str3.equals("dfeb39c347ddc8727ed261458fbb27f49c1506"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33370408350622244d + "'", double11 == 0.33370408350622244d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0024898063107158083d + "'", double14 == 0.0024898063107158083d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.9385299322202547d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int2 = org.apache.commons.math.util.FastMath.max(81, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81 + "'", int2 == 81);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 76);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-27.937433942813755d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.0d) + "'", double1 == (-27.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 78, 69.56422124950807d, 0.3309781210727745d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(5.278088627393561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6052761185108837d + "'", double1 == 3.6052761185108837d);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator3 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator3);
//        int int7 = randomDataImpl4.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str9 = randomDataImpl4.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray10 = new java.lang.Object[] { randomDataImpl4 };
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray10);
//        java.lang.Object[] objArray13 = convergenceException12.getArguments();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        java.lang.Number number23 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 184.51869951185168d, number23, false);
//        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException25.getGeneralPattern();
//        java.lang.Object[] objArray30 = null;
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("hi!", objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable32, objArray33);
//        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException31.getGeneralPattern();
//        java.lang.Number number37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 184.51869951185168d, number37, false);
//        boolean boolean40 = numberIsTooLargeException39.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooLargeException39.getGeneralPattern();
//        java.lang.Object[] objArray44 = null;
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("hi!", objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        java.lang.Object[] objArray47 = null;
//        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException45, localizable46, objArray47);
//        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException45.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator51 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl52 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator51);
//        int int55 = randomDataImpl52.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str57 = randomDataImpl52.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray58 = new java.lang.Object[] { randomDataImpl52 };
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable50, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable49, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable41, objArray58);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "7129b79c9874f86f179bc2c416604492209abe", objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("f863960b923d8bce846791679ea6b3b6a88e38", objArray58);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 51 + "'", int7 == 51);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "203dd83f58" + "'", str9.equals("203dd83f58"));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable35);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable49);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 51 + "'", int55 == 51);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1268278c5e" + "'", str57.equals("1268278c5e"));
//        org.junit.Assert.assertNotNull(objArray58);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray5 = maxIterationsExceededException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "16d2ed3c8e61592e641e9df41be551be16f39e", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.4430227202923068d, (java.lang.Number) 46, false);
//        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = null;
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator15);
//        int int19 = randomDataImpl16.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str21 = randomDataImpl16.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray22 = new java.lang.Object[] { randomDataImpl16 };
//        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable14, objArray22);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable13, objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable25 = maxIterationsExceededException24.getGeneralPattern();
//        java.lang.Number number28 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number28);
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39, localizable40, objArray41);
//        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
//        java.lang.Number number45 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 184.51869951185168d, number45, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        java.lang.Object[] objArray57 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable54, objArray57);
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray57);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable43, objArray57);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        java.lang.Object[] objArray67 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable64, objArray67);
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray67);
//        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray67);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable36, objArray67);
//        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "ee2996d2a9", objArray67);
//        org.junit.Assert.assertNotNull(objArray4);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 48 + "'", int19 == 48);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "b2096dff7f" + "'", str21.equals("b2096dff7f"));
//        org.junit.Assert.assertNotNull(objArray22);
//        org.junit.Assert.assertNotNull(localizable25);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(localizable43);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray67);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 75);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 75.0f + "'", float2 == 75.0f);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        int[] intArray32 = randomDataImpl1.nextPermutation(89, 51);
//        randomDataImpl1.reSeed((long) 46);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "62ba3cb56f10da8ed55f6eb1d5c3159f804aab" + "'", str3.equals("62ba3cb56f10da8ed55f6eb1d5c3159f804aab"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999986529899d + "'", double11 == 0.9999999986529899d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-107.674757616243d) + "'", double15 == (-107.674757616243d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 42.66011773423538d + "'", double20 == 42.66011773423538d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-203.99202485697083d) + "'", double29 == (-203.99202485697083d));
//        org.junit.Assert.assertNotNull(intArray32);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.floor((-58.79790177908768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-59.0d) + "'", double1 == (-59.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.861648705529517d + "'", double1 == 1.861648705529517d);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double8 = randomDataImpl1.nextExponential(88.0394601776806d);
//        long long10 = randomDataImpl1.nextPoisson(2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dccafa14cb" + "'", str6.equals("dccafa14cb"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 92.49007379019659d + "'", double8 == 92.49007379019659d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4L + "'", long10 == 4L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.035591508433712726d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03559902319934646d) + "'", double1 == (-0.03559902319934646d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double2 = org.apache.commons.math.util.FastMath.min(5.344864515413418E-21d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        double double14 = randomDataImpl1.nextGaussian((double) 52.0f, (double) 86);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-47.306540794297604d) + "'", double14 == (-47.306540794297604d));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9999999983975412d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.09057202605979577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0867023531348225d + "'", double1 == 0.0867023531348225d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9849051783319762d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008901761968588495d + "'", double1 == 0.008901761968588495d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextSecureLong((long) 56, (long) 75);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 68L + "'", long4 == 68L);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 89, 0.9999999958776928d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 58, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-153.95873736361798d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-153.0d) + "'", double1 == (-153.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException7.getGeneralPattern();
        java.lang.String str10 = mathException7.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.MathException: {0} out of [{1}, {2}] range" + "'", str10.equals("org.apache.commons.math.MathException: {0} out of [{1}, {2}] range"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.912539149877874d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.089024395704929d + "'", double1 == 1.089024395704929d);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString(91);
//        double double9 = randomDataImpl1.nextF(3.4023066454805946d, 0.9999999986529899d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "b887320bbc2d8fc724b24697761f71169b3b0de98bef8953358fefd0167ca543477656d2624af34f69968d34b07" + "'", str6.equals("b887320bbc2d8fc724b24697761f71169b3b0de98bef8953358fefd0167ca543477656d2624af34f69968d34b07"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.144279871589963d + "'", double9 == 7.144279871589963d);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        double double8 = randomDataImpl1.nextCauchy(0.0d, (double) 50);
//        randomDataImpl1.reSeed();
//        double double12 = randomDataImpl1.nextGamma((double) 75, (double) 14);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1296.4656934408517d) + "'", double8 == (-1296.4656934408517d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1121.3139155281578d + "'", double12 == 1121.3139155281578d);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextUniform(0.5403023058681398d, (double) 32);
//        double double11 = randomDataImpl1.nextBeta((double) 89, (double) 14);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cda4333a9a488fb5b8e1b8adc6da02e0f8ca0d" + "'", str3.equals("cda4333a9a488fb5b8e1b8adc6da02e0f8ca0d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.191991386670784d + "'", double8 == 6.191991386670784d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8721887229884621d + "'", double11 == 0.8721887229884621d);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 41);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        long long15 = randomDataImpl1.nextPoisson(0.5464784470336415d);
//        double double18 = randomDataImpl1.nextGaussian((double) 15, 5.697825610774079d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a0188e3fe227d597b62f1476b54dc4ab558bc9" + "'", str3.equals("a0188e3fe227d597b62f1476b54dc4ab558bc9"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3979659389611621d + "'", double13 == 0.3979659389611621d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 13.728756420312397d + "'", double18 == 13.728756420312397d);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.417431849188475d + "'", double3 == 17.417431849188475d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        double double14 = randomDataImpl1.nextGaussian(0.04457085352364287d, 0.6931471805599453d);
//        double double17 = randomDataImpl1.nextCauchy((double) 99, 96.99999999999999d);
//        try {
//            double double20 = randomDataImpl1.nextBeta((-32.14578920209099d), 0.9442157056960553d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.98");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 83 + "'", int4 == 83);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 49.20479172372044d + "'", double7 == 49.20479172372044d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.3178163058565815d + "'", double11 == 2.3178163058565815d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25347808901268803d + "'", double14 == 0.25347808901268803d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 121.33451997190441d + "'", double17 == 121.33451997190441d);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            double double23 = randomDataImpl1.nextBeta((-1.6261509044766869d), 2.718281828459045d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.647");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "25a7dc3d1f03617f998aee02e1dab4f3236b7f" + "'", str3.equals("25a7dc3d1f03617f998aee02e1dab4f3236b7f"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 102.21046355374686d + "'", double15 == 102.21046355374686d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-30.53099448523066d) + "'", double20 == (-30.53099448523066d));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 42, (java.lang.Number) 50.30685281944005d, true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double2 = org.apache.commons.math.util.FastMath.atan2(156.65930874427332d, (double) 56);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.227487958250663d + "'", double2 == 1.227487958250663d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 94, (long) 44);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.special.Erf.erf(3.408223431367131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999985640996927d + "'", double1 == 0.9999985640996927d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 79L, 12.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 79.0d + "'", double2 == 79.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.2584665919121987d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.009623181596712d + "'", double1 == 26.009623181596712d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(59.93155962165593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.74154762445184d + "'", double1 == 7.74154762445184d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9442157056960553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.789922836398257d + "'", double1 == 1.789922836398257d);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double31 = randomDataImpl1.nextExponential(2.226441832186995d);
//        randomDataImpl1.reSeedSecure();
//        double double35 = randomDataImpl1.nextWeibull(1.0635597985607013d, 51.99999999999999d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8d04982fc6c2ebd66f39d277124c983b52c419" + "'", str3.equals("8d04982fc6c2ebd66f39d277124c983b52c419"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 36.137757084977785d + "'", double15 == 36.137757084977785d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-38.83505664078239d) + "'", double20 == (-38.83505664078239d));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-16.760738870170442d) + "'", double29 == (-16.760738870170442d));
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.7151992201856743d + "'", double31 == 0.7151992201856743d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 38.47109954768264d + "'", double35 == 38.47109954768264d);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1898842314256335d + "'", double1 == 4.1898842314256335d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.437128995686965d, 79.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4371289956869653d + "'", double2 == 2.4371289956869653d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 11.548739357257746d, (java.lang.Number) 0.7414757232563353d, true);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6f6f4aba3b" + "'", str15.equals("6f6f4aba3b"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable19);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-52.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(61, 36, 71);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than the maximum (61): sample size (71) must be less than or equal to population size (61)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.6773027466712307d + "'", double7 == 1.6773027466712307d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.002768786815806915d + "'", double11 == 0.002768786815806915d);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        int int23 = randomDataImpl1.nextZipf(59, 1.9385299322202547d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "667c19097d68f1e91999184bda9029a3b9f7b2" + "'", str3.equals("667c19097d68f1e91999184bda9029a3b9f7b2"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999980730114d + "'", double11 == 0.9999999980730114d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.770445623056948d + "'", double15 == 3.770445623056948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-47.47466291813209d) + "'", double20 == (-47.47466291813209d));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        try {
//            double double9 = randomDataImpl1.nextUniform((double) (byte) 1, (-0.632723255813097d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-0.633): lower bound (1) must be strictly less than upper bound (-0.633)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e19ddf0e86f784f4d9323107e7647902a68280" + "'", str3.equals("e19ddf0e86f784f4d9323107e7647902a68280"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.sin((-4.9213767696831185d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9782414189988183d + "'", double1 == 0.9782414189988183d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        long long39 = randomDataImpl1.nextSecureLong((long) 13, (long) 50);
//        try {
//            randomDataImpl1.setSecureAlgorithm("7129b79c9874f86f179bc2c416604492209abe", "d19a1a7eea");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d19a1a7eea");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "91440b0d0499eba3569cb722a9a25dd987ef5c" + "'", str9.equals("91440b0d0499eba3569cb722a9a25dd987ef5c"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9999999986639234d + "'", double17 == 0.9999999986639234d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 62.33862286047264d + "'", double21 == 62.33862286047264d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-5.891532132500428d) + "'", double26 == (-5.891532132500428d));
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-41.537068224220874d) + "'", double35 == (-41.537068224220874d));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 30L + "'", long39 == 30L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.sample();
//        double[] doubleArray6 = normalDistributionImpl2.sample(42);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 176.16714749834458d + "'", double4 == 176.16714749834458d);
//        org.junit.Assert.assertNotNull(doubleArray6);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.sample();
//        try {
//            double double6 = normalDistributionImpl2.inverseCumulativeProbability(44.4756275059492d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 44.476 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 267.76136447244136d + "'", double3 == 267.76136447244136d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.003317128740706d) + "'", double4 == (-7.003317128740706d));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.906241428376445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9324255575771938d + "'", double1 == 1.9324255575771938d);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        long long15 = randomDataImpl1.nextPoisson(0.5464784470336415d);
//        double double17 = randomDataImpl1.nextT((double) 26);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b72e760b22fb1a336fa88cd5b483e62036bf18" + "'", str3.equals("b72e760b22fb1a336fa88cd5b483e62036bf18"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3314020447945015d + "'", double13 == 0.3314020447945015d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.4483771956262554d) + "'", double17 == (-1.4483771956262554d));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01834810912483715d + "'", double1 == 0.01834810912483715d);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        try {
//            int[] intArray11 = randomDataImpl1.nextPermutation(69, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "994bd2fc4673f9aebf0aa4767e069a79dcce76" + "'", str3.equals("994bd2fc4673f9aebf0aa4767e069a79dcce76"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.319937718455069d + "'", double8 == 0.319937718455069d);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        randomDataImpl1.reSeedSecure();
        try {
            int int7 = randomDataImpl1.nextSecureInt(38, 28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 38 is larger than, or equal to, the maximum (28): lower bound (38) must be strictly less than upper bound (28)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        randomDataImpl1.reSeedSecure((long) 60);
//        try {
//            randomDataImpl1.setSecureAlgorithm("667c19097d68f1e91999184bda9029a3b9f7b2", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c30a28fb6504457b86a057607886eeb4912659" + "'", str3.equals("c30a28fb6504457b86a057607886eeb4912659"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 78.05585035605478d + "'", double9 == 78.05585035605478d);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-52.0d), (java.lang.Number) 0.9782414189988183d, false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 10, (java.lang.Number) 0.7799726475466374d, true);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, number35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable42, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 184.51869951185168d, number47, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number58 = outOfRangeException57.getLo();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException57);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 72, (java.lang.Number) 0.4430227202923068d, (java.lang.Number) 86);
        java.lang.Number number65 = outOfRangeException64.getLo();
        org.apache.commons.math.exception.util.Localizable localizable66 = outOfRangeException64.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable70, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60, localizable66, objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray73);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0.4430227202923068d + "'", number65.equals(0.4430227202923068d));
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray73);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString(91);
//        long long9 = randomDataImpl1.nextSecureLong(4L, (long) 26);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "30a961ec699b582fb3bd613dc0990a5c85888e34f9c6ac2a95e456b83c425dc8d1ff49b2c8bceccb25dfb8674df" + "'", str6.equals("30a961ec699b582fb3bd613dc0990a5c85888e34f9c6ac2a95e456b83c425dc8d1ff49b2c8bceccb25dfb8674df"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 17L + "'", long9 == 17L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.1898842314256335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 240.0626831091035d + "'", double1 == 240.0626831091035d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7713111955699076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.25966336095252274d) + "'", double1 == (-0.25966336095252274d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.abs(84.30637937465765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 84.30637937465765d + "'", double1 == 84.30637937465765d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5723649429247d + "'", double1 == 0.5723649429247d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.log((-52.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double16 = normalDistributionImpl15.sample();
//        double double17 = normalDistributionImpl15.getMean();
//        double double18 = normalDistributionImpl15.getStandardDeviation();
//        double double19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        try {
//            int int22 = randomDataImpl1.nextSecureInt((int) (byte) 100, 98);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (98): lower bound (100) must be strictly less than upper bound (98)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 61 + "'", int4 == 61);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0920c71f6f" + "'", str6.equals("0920c71f6f"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4081602774740465d) + "'", double9 == (-0.4081602774740465d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-30.18603483629269d) + "'", double16 == (-30.18603483629269d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 89.0d + "'", double18 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.69682427755683d + "'", double19 == 10.69682427755683d);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.144279871589963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 91, (float) 50);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.004482072124447999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999899555315509d + "'", double1 == 0.9999899555315509d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(Double.NaN);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability(1.0239382666551615d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.024 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long1 = org.apache.commons.math.util.FastMath.round(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        mathException5.addSuppressed((java.lang.Throwable) convergenceException15);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("hi!", objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        java.lang.Object[] objArray22 = null;
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20, localizable21, objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException20.getGeneralPattern();
//        java.lang.Number number26 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 184.51869951185168d, number26, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        java.lang.Number number37 = outOfRangeException36.getLo();
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("hi!", objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable42, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
//        java.lang.Number number47 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 184.51869951185168d, number47, false);
//        boolean boolean50 = numberIsTooLargeException49.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException49.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable51, (java.lang.Number) 79.87899290686482d, (java.lang.Number) 46, true);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        java.lang.Object[] objArray61 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable58, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray61);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException36, "ac82763deb", objArray61);
//        java.lang.Object[] objArray66 = outOfRangeException36.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "135ff11687", objArray66);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 82 + "'", int11 == 82);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dde3f73c70" + "'", str13.equals("dde3f73c70"));
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1L) + "'", number37.equals((-1L)));
//        org.junit.Assert.assertNotNull(localizable45);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray61);
//        org.junit.Assert.assertNotNull(objArray66);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            double double5 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fb4ea63022d3b2abcfed094a361a52ffb11b2f" + "'", str3.equals("fb4ea63022d3b2abcfed094a361a52ffb11b2f"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.999999999524131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.085025156788169E-5d + "'", double1 == 3.085025156788169E-5d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray8 = normalDistributionImpl6.sample(86);
//        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        java.lang.Class<?> wildcardClass13 = normalDistributionImpl6.getClass();
//        double double15 = normalDistributionImpl6.cumulativeProbability(1.7453292519943295d);
//        double double17 = normalDistributionImpl6.density(1.5060973145850306E35d);
//        double[] doubleArray19 = normalDistributionImpl6.sample(58);
//        double double20 = normalDistributionImpl6.sample();
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5078229326523436d + "'", double15 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 48.621302116473196d + "'", double20 == 48.621302116473196d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double15 = randomDataImpl1.nextGaussian(0.5772156649015329d, 62.34684918138814d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-34.449165460132576d) + "'", double15 == (-34.449165460132576d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 68);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8979276806892913d) + "'", double1 == (-0.8979276806892913d));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double12 = normalDistributionImpl11.sample();
//        double double13 = normalDistributionImpl11.sample();
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double16 = randomDataImpl1.nextChiSquare((-0.5772156677920679d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.289 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 151.0908934816928d + "'", double12 == 151.0908934816928d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.2535083091191d + "'", double13 == 57.2535083091191d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.25595682471165d + "'", double14 == 35.25595682471165d);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        try {
//            long long14 = randomDataImpl1.nextPoisson((-148.42807025643404d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -148.428 is smaller than, or equal to, the minimum (0): mean (-148.428)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "95d118fe1e" + "'", str6.equals("95d118fe1e"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.23708031815294217d) + "'", double9 == (-0.23708031815294217d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 15, (long) 66);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(89);
//        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
//        java.lang.Object[] objArray3 = maxIterationsExceededException1.getArguments();
//        int int4 = maxIterationsExceededException1.getMaxIterations();
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "5e3dac5d81", objArray14);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(objArray3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 80 + "'", int11 == 80);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "29077ac949" + "'", str13.equals("29077ac949"));
//        org.junit.Assert.assertNotNull(objArray14);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.rint((-58.79790177908768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-59.0d) + "'", double1 == (-59.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.586840308962423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2419880144230016d + "'", double1 == 1.2419880144230016d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7765997770389097d + "'", double1 == 2.7765997770389097d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        try {
//            int int12 = randomDataImpl1.nextBinomial(85, 217.91434136884345d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 217.914 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8995ce20e6f46b91bea9c372716dbf8e8f4584" + "'", str3.equals("8995ce20e6f46b91bea9c372716dbf8e8f4584"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03810780509795465d + "'", double8 == 0.03810780509795465d);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.pow(300.2209486470141d, (double) 29L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.011142507927958E71d + "'", double2 == 7.011142507927958E71d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double6 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.density(1.5707963267948966d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 112.90260018958175d + "'", double3 == 112.90260018958175d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.0d + "'", double5 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.004481799435259219d + "'", double8 == 0.004481799435259219d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 79.87899290686482d, (java.lang.Number) 46, true);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, localizable14, objArray19);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable14, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator25);
//        int int29 = randomDataImpl26.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str31 = randomDataImpl26.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { randomDataImpl26 };
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable24, objArray32);
//        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException33.getGeneralPattern();
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable39, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 184.51869951185168d, number44, false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray53 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable50, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray53);
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("8a5edff846", objArray53);
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable42, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray53);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable14, objArray53);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 43);
//        java.lang.Number number62 = notStrictlyPositiveException61.getMin();
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 77 + "'", int29 == 77);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "bde2e511ed" + "'", str31.equals("bde2e511ed"));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNull(localizable35);
//        org.junit.Assert.assertNotNull(localizable42);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 0 + "'", number62.equals(0));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.util.FastMath.pow(89.0d, 3.408223431367131d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4405109.390086082d + "'", double2 == 4405109.390086082d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 98, 4.1898842314256335d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5280684274650054d + "'", double2 == 1.5280684274650054d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.95411804077025d + "'", double1 == 349.95411804077025d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        boolean boolean27 = numberIsTooLargeException26.getBoundIsAllowed();
//        boolean boolean28 = numberIsTooLargeException26.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray29 = numberIsTooLargeException26.getSuppressed();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 93 + "'", int13 == 93);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1dd21a154d" + "'", str15.equals("1dd21a154d"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(throwableArray29);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.8414709848078965d), (java.lang.Number) 17L, false);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.557407718698416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999910373925457d + "'", double1 == 0.999910373925457d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Number number13 = numberIsTooLargeException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException10.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 184.51869951185168d + "'", number13.equals(184.51869951185168d));
        org.junit.Assert.assertNotNull(localizable14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 44);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998433086476912d + "'", double1 == 0.9998433086476912d);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("8a5edff846", objArray47);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable36, objArray47);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray47);
//        org.apache.commons.math.exception.util.Localizable localizable53 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) 10.0d, (java.lang.Number) 1L, true);
//        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException57);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 95 + "'", int23 == 95);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "a39d9c9364" + "'", str25.equals("a39d9c9364"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertNull(localizable29);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(objArray47);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        double double16 = randomDataImpl1.nextCauchy(6.191991386670784d, Double.NaN);
//        try {
//            int int19 = randomDataImpl1.nextBinomial(34, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "29d817590b058b87d24c27ec694c606b95c229" + "'", str3.equals("29d817590b058b87d24c27ec694c606b95c229"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999980361984d + "'", double11 == 0.9999999980361984d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.6247474899469354d) + "'", double13 == (-1.6247474899469354d));
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.308869380063768d, 0.02592109715867092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999962950722d + "'", double2 == 0.9999999962950722d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1102230246251565E-16d, 0.005824234984533685d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.005824234984533685d + "'", double2 == 0.005824234984533685d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0821041362364843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 4L, 55.9264997777119d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.000000000000001d + "'", double2 == 4.000000000000001d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.cos((-3.6648441425804434d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8661989948599823d) + "'", double1 == (-0.8661989948599823d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.cos((-4.9213767696831185d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20746981986587454d + "'", double1 == 0.20746981986587454d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0227183470559362d, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 32.38316732970439d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.6643638388299197d, (java.lang.Number) 100.0d, false);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double16 = normalDistributionImpl15.sample();
//        double double17 = normalDistributionImpl15.getMean();
//        double double18 = normalDistributionImpl15.getStandardDeviation();
//        double double19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double20 = normalDistributionImpl15.getMean();
//        double double22 = normalDistributionImpl15.cumulativeProbability((double) 15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "06522d944d" + "'", str6.equals("06522d944d"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.1982814549326486d) + "'", double9 == (-0.1982814549326486d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 85.62030143016939d + "'", double16 == 85.62030143016939d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 89.0d + "'", double18 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-22.239859627432498d) + "'", double19 == (-22.239859627432498d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5669204957089923d + "'", double22 == 0.5669204957089923d);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 13L, (double) 83, 156.65930874427332d, 48);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.338694784101576E-22d + "'", double4 == 2.338694784101576E-22d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.expm1(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException8.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 184.51869951185168d, number14, false);
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable12, objArray28);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("28ba999a54", objArray28);
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 92 + "'", int25 == 92);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1d6c588f02" + "'", str27.equals("1d6c588f02"));
//        org.junit.Assert.assertNotNull(objArray28);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.log((-8.765505546166722d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, (double) 43);
//        long long13 = randomDataImpl1.nextLong((-1L), (long) 13);
//        randomDataImpl1.reSeed((long) 4);
//        double double17 = randomDataImpl1.nextT(24.500417218821333d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 88 + "'", int4 == 88);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 124.88828910862075d + "'", double7 == 124.88828910862075d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-35.874299272506235d) + "'", double10 == (-35.874299272506235d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9L + "'", long13 == 9L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.6234021765162624d + "'", double17 == 0.6234021765162624d);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 71);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.276666119016055d + "'", double1 == 4.276666119016055d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("24220d5884", objArray1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5001586541738241E84d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable3, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("8a5edff846", objArray6);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("hi!", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException13, localizable14, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException13.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 184.51869951185168d, number19, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number30 = outOfRangeException29.getLo();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, localizable35, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException34.getGeneralPattern();
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 184.51869951185168d, number40, false);
        boolean boolean43 = numberIsTooLargeException42.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException42.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 79.87899290686482d, (java.lang.Number) 46, true);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable51, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException29, "ac82763deb", objArray54);
        java.lang.Object[] objArray59 = outOfRangeException29.getArguments();
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("5f3a39d998", objArray59);
        mathException9.addSuppressed((java.lang.Throwable) mathException60);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1L) + "'", number30.equals((-1L)));
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray59);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable15, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException14.getGeneralPattern();
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 184.51869951185168d, number20, false);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray29);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("8a5edff846", objArray29);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable18, objArray29);
//        java.lang.Object[] objArray34 = mathException33.getArguments();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 84 + "'", int5 == 84);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "487bfe581d" + "'", str7.equals("487bfe581d"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable18);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray34);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 38.47109954768264d, 70.51548891804315d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 1.0635597985607013d, (java.lang.Number) (-21.72848263158244d), (java.lang.Number) 5.697825610774079d);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.33370408350622244d, 6.191991386670784d, 10.440148832340114d, 94);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9997928884694727d + "'", double4 == 0.9997928884694727d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.20746981986587454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23056057779637718d + "'", double1 == 0.23056057779637718d);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) 10);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString(91);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric((int) (short) -1, 100, 56);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "03668f44bfbf0c7900a3ebf3f298f1181775b9ef212aa01e399d51e007121e0a5af2cc86168f12d9b0a2fcd55a5" + "'", str6.equals("03668f44bfbf0c7900a3ebf3f298f1181775b9ef212aa01e399d51e007121e0a5af2cc86168f12d9b0a2fcd55a5"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.341351718524658E-156d, 85.62030143016939d);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Object[] objArray18 = null;
//        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray18);
//        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException16.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator22 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator22);
//        int int26 = randomDataImpl23.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str28 = randomDataImpl23.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl23 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable21, objArray29);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable20, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "e6f21f2cc2", objArray29);
//        java.lang.String str33 = convergenceException32.getPattern();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 85 + "'", int5 == 85);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a301948505" + "'", str7.equals("a301948505"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 85 + "'", int26 == 85);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "95086004a8" + "'", str28.equals("95086004a8"));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "e6f21f2cc2" + "'", str33.equals("e6f21f2cc2"));
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double11 = normalDistributionImpl8.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl8.reseedRandomGenerator((long) (byte) 1);
//        double double15 = normalDistributionImpl8.cumulativeProbability((double) 98);
//        double double16 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8628767227110539d + "'", double15 == 0.8628767227110539d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 74.9945157090603d + "'", double16 == 74.9945157090603d);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density((double) 79L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.003043811033521959d + "'", double5 == 0.003043811033521959d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 70);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0867023531348225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44259886394291303d + "'", double1 == 0.44259886394291303d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 150.14867894829416d, (java.lang.Number) 2.0d, false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        double double16 = randomDataImpl1.nextCauchy((double) 81, 2.6773892640898347d);
//        long long19 = randomDataImpl1.nextSecureLong((long) 8, (long) 61);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fca9644a9161a7fadbf4b69a4fe6cbec3a54af" + "'", str3.equals("fca9644a9161a7fadbf4b69a4fe6cbec3a54af"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.5800102414719395d + "'", double13 == 3.5800102414719395d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 92.07522026191472d + "'", double16 == 92.07522026191472d);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55L + "'", long19 == 55L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 63);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 63L + "'", long1 == 63L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 75);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3089969389957472d + "'", double1 == 1.3089969389957472d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(4);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 83);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 85, (float) 91);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 85.0f + "'", float2 == 85.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.227487958250663d, (double) 82);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9925705585121516E7d + "'", double2 == 1.9925705585121516E7d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6234021765162624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8542587543046395d + "'", double1 == 0.8542587543046395d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform(2.437128995686965d, 0.9999999988626886d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2.437 is larger than, or equal to, the maximum (1): lower bound (2.437) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.308869380063768d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07520395772047966d + "'", double1 == 0.07520395772047966d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.tan(59.93155962165593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24609414932182913d + "'", double1 == 0.24609414932182913d);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        double double14 = randomDataImpl1.nextGaussian((double) 52.0f, (double) 86);
//        try {
//            long long17 = randomDataImpl1.nextLong((long) 78, 5L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 78 is larger than, or equal to, the maximum (5): lower bound (78) must be strictly less than upper bound (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-46.353889037859105d) + "'", double14 == (-46.353889037859105d));
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        int int20 = randomDataImpl1.nextInt(70, 88);
//        try {
//            int int23 = randomDataImpl1.nextSecureInt(51, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 51 is larger than, or equal to, the maximum (1): lower bound (51) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "bcb47b02d8" + "'", str6.equals("bcb47b02d8"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.9555433664556141d) + "'", double9 == (-0.9555433664556141d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "934e0b20dafe5cfd279114347332e573e95216e4c587ae57dfc5" + "'", str14.equals("934e0b20dafe5cfd279114347332e573e95216e4c587ae57dfc5"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.15900189677326226d) + "'", double17 == (-0.15900189677326226d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 78 + "'", int20 == 78);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 'a', 166.98999838850764d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 166.98999838850764d + "'", double2 == 166.98999838850764d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, localizable20, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException19.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 184.51869951185168d, number25, false);
        boolean boolean28 = numberIsTooLargeException27.getBoundIsAllowed();
        mathException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number53 = outOfRangeException52.getHi();
        org.apache.commons.math.exception.util.Localizable localizable54 = outOfRangeException52.getGeneralPattern();
        java.lang.Object[] objArray55 = outOfRangeException52.getArguments();
        java.lang.Object[] objArray56 = outOfRangeException52.getArguments();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable36, objArray56);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 10 + "'", number53.equals(10));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray56);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double30 = normalDistributionImpl23.sample();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "37fd1a881f6e6f020d1c415bba9ef12d8a8a13" + "'", str3.equals("37fd1a881f6e6f020d1c415bba9ef12d8a8a13"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.7595861575800384d + "'", double15 == 2.7595861575800384d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-32.001507797015755d) + "'", double20 == (-32.001507797015755d));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-98.6922119702055d) + "'", double29 == (-98.6922119702055d));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 139.67385975737693d + "'", double30 == 139.67385975737693d);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 67);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8260748027008264d + "'", double1 == 1.8260748027008264d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7320508075688772d, (double) 79L, 5.344864515413418E-21d);
        double double5 = normalDistributionImpl3.density(0.9999999998927765d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.005049685477250568d + "'", double5 == 0.005049685477250568d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3983155205756575d + "'", double1 == 0.3983155205756575d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        int int14 = randomDataImpl1.nextZipf(63, (double) 63);
//        try {
//            int int17 = randomDataImpl1.nextBinomial(23, 2.7595861575800384d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.76 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) (-0.9126063361940036d), (java.lang.Number) Double.NaN);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number9 = outOfRangeException8.getHi();
        org.apache.commons.math.exception.util.Localizable localizable10 = outOfRangeException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getSpecificPattern();
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathException12);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10 + "'", number9.equals(10));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.max(0.04568105053249237d, 7.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        double double13 = randomDataImpl1.nextT((double) 63);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "032c2d7c090b01e82d1e0185998ca7bf3cae11" + "'", str3.equals("032c2d7c090b01e82d1e0185998ca7bf3cae11"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8117566297988853d + "'", double8 == 0.8117566297988853d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.167140027606832d + "'", double13 == 2.167140027606832d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.2767898921480116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004830894954222802d + "'", double1 == 0.004830894954222802d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.acosh(124.88828910862075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.520550802133027d + "'", double1 == 5.520550802133027d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 95, 71L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 71L + "'", long2 == 71L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 88.0394601776806d, (java.lang.Number) 9, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 71L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9510546532543747d + "'", double1 == 0.9510546532543747d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int2 = org.apache.commons.math.util.FastMath.max(89, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        try {
//            java.lang.String str38 = randomDataImpl1.nextHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "d548ff7f2eb5b8d15af264aaebcec9363b3a8a" + "'", str9.equals("d548ff7f2eb5b8d15af264aaebcec9363b3a8a"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 194.64064636862503d + "'", double21 == 194.64064636862503d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-58.922350060596905d) + "'", double26 == (-58.922350060596905d));
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-18.142661199701884d) + "'", double35 == (-18.142661199701884d));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = maxIterationsExceededException36.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException36.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9bb223c487" + "'", str8.equals("9bb223c487"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNull(localizable38);
//        org.junit.Assert.assertNotNull(localizable39);
//        org.junit.Assert.assertNotNull(localizable40);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.util.Localizable localizable75 = convergenceException74.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable79 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator80 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl81 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator80);
//        int int84 = randomDataImpl81.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str86 = randomDataImpl81.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray87 = new java.lang.Object[] { randomDataImpl81 };
//        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable79, objArray87);
//        java.lang.Throwable[] throwableArray89 = convergenceException88.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("553f77ced2b6b0112ec91c90a793c2c01a7548", (java.lang.Object[]) throwableArray89);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(61, "c473f2b86143dd11cabc168f2b8e8cdab3446085c094351db935", (java.lang.Object[]) throwableArray89);
//        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable75, (java.lang.Object[]) throwableArray89);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 33 + "'", int27 == 33);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "b52706a92f" + "'", str29.equals("b52706a92f"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 33 + "'", int54 == 33);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "562d5ef371" + "'", str56.equals("562d5ef371"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(localizable75);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 33 + "'", int84 == 33);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "44c7b5b82d" + "'", str86.equals("44c7b5b82d"));
//        org.junit.Assert.assertNotNull(objArray87);
//        org.junit.Assert.assertNotNull(throwableArray89);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass6 = randomDataImpl1.getClass();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "492c4bd25f48c260c78c7be607945532a5812cee9ea3f536ffabe57aa0844eda4ab26479fb1f69038767685999693c735fd2" + "'", str5.equals("492c4bd25f48c260c78c7be607945532a5812cee9ea3f536ffabe57aa0844eda4ab26479fb1f69038767685999693c735fd2"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        java.lang.Number number37 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException34.getGeneralPattern();
        java.lang.Number number39 = numberIsTooLargeException34.getMax();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 3.948148009134E13d + "'", number37.equals(3.948148009134E13d));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 3.948148009134E13d + "'", number39.equals(3.948148009134E13d));
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 88 + "'", int4 == 88);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "bcb2720016" + "'", str6.equals("bcb2720016"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.455026611111751d) + "'", double9 == (-0.455026611111751d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double2 = org.apache.commons.math.util.FastMath.max(53.08495167300164d, 179.02719848915368d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 179.02719848915368d + "'", double2 == 179.02719848915368d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5430256902014756d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.5772156677920679d), 13.728756420312397d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(64);
//        try {
//            randomDataImpl1.setSecureAlgorithm("516880e946", "371892f8233fe26487071aa59d88c696f3a0656308f37999a4eb5a2efc646afedf856b7fd39f4c8421fee6f7ec78ba88e92f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 371892f8233fe26487071aa59d88c696f3a0656308f37999a4eb5a2efc646afedf856b7fd39f4c8421fee6f7ec78ba88e92f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 84 + "'", int4 == 84);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.272891738100446d + "'", double7 == 7.272891738100446d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0036044333253086557d + "'", double11 == 0.0036044333253086557d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "8c5bf667486dc70084087c58bab662349218cf488527f608eea00ffad908f552" + "'", str13.equals("8c5bf667486dc70084087c58bab662349218cf488527f608eea00ffad908f552"));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.special.Gamma.digamma(644.5529752938935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.467781082943182d + "'", double1 == 6.467781082943182d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9485653159430099d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3872962728435185d + "'", double1 == 0.3872962728435185d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 28.057038202758818d, (java.lang.Number) (-2.4116508064714437d), false);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("a5026b6605", objArray1);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeedSecure((long) 44);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6d184a49a9376c18473dd75d28f20ffee5c769" + "'", str3.equals("6d184a49a9376c18473dd75d28f20ffee5c769"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9999999980706751d, (java.lang.Number) 9.257254883820774d, false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 2.7595861575800384d, (java.lang.Number) 1.9925705585121516E7d, false);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(53.08495167300164d, 54.55518924217818d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4029866955428835d + "'", double2 == 0.4029866955428835d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0232274785475504d + "'", double1 == 1.0232274785475504d);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 35.0d, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable28, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException27.getGeneralPattern();
//        java.lang.Number number33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 184.51869951185168d, number33, false);
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException24, localizable31, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator40 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator40);
//        int int44 = randomDataImpl41.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str46 = randomDataImpl41.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { randomDataImpl41 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable39, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable31, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable10, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 4.532599493153256d, false);
//        java.lang.Number number56 = numberIsTooSmallException55.getArgument();
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 85 + "'", int44 == 85);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "226c9c8559" + "'", str46.equals("226c9c8559"));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 1.7453292519943295d + "'", number56.equals(1.7453292519943295d));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.1588617034487356d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(25.00962318159671d, (-203.99202485697083d), 5.344864515413418E-21d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -203.992 is smaller than, or equal to, the minimum (0): standard deviation (-203.992)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1.5430806348152437d, true);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 0.9999999986051742d, number25);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, localizable31, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException30.getGeneralPattern();
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException37, localizable38, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException37.getGeneralPattern();
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 184.51869951185168d, number43, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable52, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable41, objArray55);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean63 = numberIsTooLargeException62.getBoundIsAllowed();
        java.lang.Object[] objArray64 = numberIsTooLargeException62.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26, "org.apache.commons.math.MathException: {0} out of [{1}, {2}] range", objArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable21, objArray64);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objArray64);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
        convergenceException5.addSuppressed((java.lang.Throwable) mathException11);
        java.lang.Object[] objArray13 = mathException11.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 93);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 93.0f + "'", float2 == 93.0f);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35);
//        java.lang.Object[] objArray37 = convergenceException35.getArguments();
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 79 + "'", int6 == 79);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ea9030fe69" + "'", str8.equals("ea9030fe69"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray37);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 48L, (float) 38);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 38.0f + "'", float2 == 38.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9999999983653864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080632894244d + "'", double1 == 1.543080632894244d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.710657776180059d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.0d, 3.255561438896672d, (double) (byte) -1);
        normalDistributionImpl3.reseedRandomGenerator((long) 99);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.3983155205756575d, 48.621302116473196d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.39831552057565756d + "'", double2 == 0.39831552057565756d);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        java.lang.Object[] objArray11 = convergenceException9.getArguments();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e77c1e147e" + "'", str7.equals("e77c1e147e"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNotNull(objArray11);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int2 = org.apache.commons.math.util.FastMath.min(79, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable25, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray28);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39, localizable40, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 184.51869951185168d, number45, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number56 = outOfRangeException55.getLo();
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("hi!", objArray59);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException60, localizable61, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException60.getGeneralPattern();
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable64, (java.lang.Number) 184.51869951185168d, number66, false);
        boolean boolean69 = numberIsTooLargeException68.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable70 = numberIsTooLargeException68.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable70, (java.lang.Number) 79.87899290686482d, (java.lang.Number) 46, true);
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray80 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable77, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException55, "ac82763deb", objArray80);
        java.lang.Object[] objArray85 = outOfRangeException55.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException("5f3a39d998", objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException(91, localizable7, objArray85);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1L) + "'", number56.equals((-1L)));
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.atanh(20.55392963742268d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        int int39 = randomDataImpl1.nextBinomial(84, 0.5772156649015329d);
//        try {
//            double double42 = randomDataImpl1.nextGamma((double) 94, (-38.3762959874568d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -38.376 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4e0e9a6a43fb6d078bb6807a5fdd0a408022d9" + "'", str9.equals("4e0e9a6a43fb6d078bb6807a5fdd0a408022d9"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9999999983672399d + "'", double17 == 0.9999999983672399d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 72.42138785327558d + "'", double21 == 72.42138785327558d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 123.65350391066964d + "'", double26 == 123.65350391066964d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-37.79884205699326d) + "'", double35 == (-37.79884205699326d));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 50 + "'", int39 == 50);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable5, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(82, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "76c837d9f4e9653c6442c80e9dc6d016b5dfd1", objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        try {
//            int int39 = randomDataImpl1.nextBinomial(0, 13.728756420312397d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 13.729 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2fc66968c058c8055b4f794a5ba836e8c5bfa6" + "'", str9.equals("2fc66968c058c8055b4f794a5ba836e8c5bfa6"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9999999986964676d + "'", double17 == 0.9999999986964676d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 77.53825276706196d + "'", double21 == 77.53825276706196d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-63.924969556744884d) + "'", double26 == (-63.924969556744884d));
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-99.29836914766938d) + "'", double35 == (-99.29836914766938d));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.344864515413418E-21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        randomDataImpl1.reSeedSecure();
//        int int19 = randomDataImpl1.nextInt(23, 33);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a98709673e111e29d501ad77f5ba06f93c746a" + "'", str3.equals("a98709673e111e29d501ad77f5ba06f93c746a"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 314.37039915265575d + "'", double13 == 314.37039915265575d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "342552a0ebab63d3728f3b4956dc16c44b736df398e70eba3d78d9ea6b4f3f14803766171558b90088b567123330412e3e06" + "'", str15.equals("342552a0ebab63d3728f3b4956dc16c44b736df398e70eba3d78d9ea6b4f3f14803766171558b90088b567123330412e3e06"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 89.0d, (java.lang.Number) 50, false);
//        java.lang.Object[] objArray41 = numberIsTooSmallException40.getArguments();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 94 + "'", int6 == 94);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "895f479a69" + "'", str8.equals("895f479a69"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(objArray41);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        int int20 = randomDataImpl1.nextInt(70, 88);
//        double double23 = randomDataImpl1.nextBeta(209.73631536691357d, 51.99999999999999d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution24 = null;
//        try {
//            int int25 = randomDataImpl1.nextInversionDeviate(integerDistribution24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "79913acefa" + "'", str6.equals("79913acefa"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.3897521609587272d) + "'", double9 == (-0.3897521609587272d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 18 + "'", int12 == 18);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "73bdb14cf0be5d1292914fb14cda61cc8a722fa13768c7c6c062" + "'", str14.equals("73bdb14cf0be5d1292914fb14cda61cc8a722fa13768c7c6c062"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.09825630508304428d) + "'", double17 == (-0.09825630508304428d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 84 + "'", int20 == 84);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.7678130724510832d + "'", double23 == 0.7678130724510832d);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed();
//        double double7 = randomDataImpl1.nextChiSquare(40.89926471991978d);
//        long long10 = randomDataImpl1.nextSecureLong((long) 6, (long) 71);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 49.94828595598896d + "'", double7 == 49.94828595598896d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 66L + "'", long10 == 66L);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.Object[] objArray7 = outOfRangeException4.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("7b9cb371cf", objArray7);
        java.lang.Object[] objArray9 = mathException8.getArguments();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, 50.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.3309781210727745d, 314.37039915265575d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3309781210727746d + "'", double2 == 0.3309781210727746d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1825.8278676919804d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5984563541597123d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6348244014913043d) + "'", double1 == (-0.6348244014913043d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(74.9945157090603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0134236054141577d + "'", double1 == 0.0134236054141577d);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(61, 33, 43);
//        try {
//            randomDataImpl1.setSecureAlgorithm("68393ecd1f1db5ac6fca578e23c5af427309cd", "12a23fd5a4");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 12a23fd5a4");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-56.905138339446495d), (java.lang.Number) 46.0d, false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.22011263916635174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.cos((-57.37934216611927d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6743779446105991d + "'", double1 == 0.6743779446105991d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray9);
//        java.lang.Object[] objArray12 = convergenceException11.getArguments();
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Object[] objArray18 = null;
//        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray18);
//        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException16.getGeneralPattern();
//        java.lang.Number number22 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 184.51869951185168d, number22, false);
//        boolean boolean25 = numberIsTooLargeException24.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooLargeException24.getGeneralPattern();
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, localizable31, objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException30.getGeneralPattern();
//        java.lang.Number number36 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 184.51869951185168d, number36, false);
//        boolean boolean39 = numberIsTooLargeException38.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException38.getGeneralPattern();
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable40, objArray57);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray57);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "7129b79c9874f86f179bc2c416604492209abe", objArray57);
//        org.apache.commons.math.exception.util.Localizable localizable63 = convergenceException62.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 91 + "'", int6 == 91);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "44c1340e70" + "'", str8.equals("44c1340e70"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable34);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 90 + "'", int54 == 90);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "c0bfac8670" + "'", str56.equals("c0bfac8670"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNull(localizable63);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        long long2 = org.apache.commons.math.util.FastMath.max(29L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 64);
//        java.lang.Number number77 = notStrictlyPositiveException76.getMin();
//        boolean boolean78 = notStrictlyPositiveException76.getBoundIsAllowed();
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 92 + "'", int27 == 92);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "a790b3c8d0" + "'", str29.equals("a790b3c8d0"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 92 + "'", int54 == 92);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "8a87127d0c" + "'", str56.equals("8a87127d0c"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 0 + "'", number77.equals(0));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) '4', 1.0453007043318272d, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("8a5edff846", objArray47);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable36, objArray47);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray47);
//        java.lang.Number number53 = outOfRangeException3.getLo();
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 43 + "'", int23 == 43);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "a3f95a0cf3" + "'", str25.equals("a3f95a0cf3"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertNull(localizable29);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (short) 0 + "'", number53.equals((short) 0));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.439487336882789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        double double6 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.49689300088292593d + "'", double5 == 0.49689300088292593d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 89.0d + "'", double7 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-94.4790330973858d) + "'", double8 == (-94.4790330973858d));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 59, (long) 39);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59L + "'", long2 == 59L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        java.lang.Number number22 = notStrictlyPositiveException20.getMin();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0 + "'", number22.equals(0));
        org.junit.Assert.assertNotNull(localizable23);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, localizable30, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException29.getGeneralPattern();
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, localizable37, objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
//        java.lang.Number number42 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 184.51869951185168d, number42, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable51, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray54);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable40, objArray54);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
//        boolean boolean62 = numberIsTooLargeException61.getBoundIsAllowed();
//        java.lang.Object[] objArray63 = numberIsTooLargeException61.getArguments();
//        java.lang.Number number64 = numberIsTooLargeException61.getMax();
//        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooLargeException61.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator70 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl71 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator70);
//        int int74 = randomDataImpl71.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str76 = randomDataImpl71.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray77 = new java.lang.Object[] { randomDataImpl71 };
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable69, objArray77);
//        java.lang.Throwable[] throwableArray79 = convergenceException78.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("553f77ced2b6b0112ec91c90a793c2c01a7548", (java.lang.Object[]) throwableArray79);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(61, "c473f2b86143dd11cabc168f2b8e8cdab3446085c094351db935", (java.lang.Object[]) throwableArray79);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable65, (java.lang.Object[]) throwableArray79);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 40 + "'", int13 == 40);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "bb9233bacd" + "'", str15.equals("bb9233bacd"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable33);
//        org.junit.Assert.assertNotNull(localizable40);
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 3.948148009134E13d + "'", number64.equals(3.948148009134E13d));
//        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 39 + "'", int74 == 39);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0f052816a1" + "'", str76.equals("0f052816a1"));
//        org.junit.Assert.assertNotNull(objArray77);
//        org.junit.Assert.assertNotNull(throwableArray79);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("ab3f5b8909", objArray30);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 33 + "'", int6 == 33);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "91621f7b82" + "'", str8.equals("91621f7b82"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.028983478471571338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 32);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable25, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("d7b4c6", objArray28);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) 18L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(92.07522026191472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 323.0032506111982d + "'", double1 == 323.0032506111982d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.12552041549809d + "'", double3 == 25.12552041549809d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-10.609183608401246d) + "'", double4 == (-10.609183608401246d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 54.65622560668708d, (java.lang.Number) 0.9442157056960553d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed((long) (short) 0);
//        try {
//            int int11 = randomDataImpl1.nextHypergeometric(76, 23, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86b00a8b3e46b0c8e05d644714981741e9e87a" + "'", str3.equals("86b00a8b3e46b0c8e05d644714981741e9e87a"));
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.special.Erf.erf(1.847512111813257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9910190036272906d + "'", double1 == 0.9910190036272906d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9782414189988183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9782414189988183d + "'", double1 == 0.9782414189988183d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7320508075688772d, (double) 79L, 5.344864515413418E-21d);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability(0.23694363411609892d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        long long12 = randomDataImpl1.nextLong((long) 26, 55L);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.65622560668708d + "'", double9 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 33L + "'", long12 == 33L);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability((double) 97);
//        try {
//            double double8 = normalDistributionImpl2.cumulativeProbability(9.889030319346946E42d, 4.000000000000001d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-66.63110305854346d) + "'", double3 == (-66.63110305854346d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8621186791753761d + "'", double5 == 0.8621186791753761d);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9092974268256817d, 0.8813735860332522d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9196117797826779d + "'", double2 == 0.9196117797826779d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        randomDataImpl1.reSeed((long) 43);
        try {
            int int11 = randomDataImpl1.nextHypergeometric(72, 86, 87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 86 is larger than the maximum (72): number of successes (86) must be less than or equal to population size (72)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.874007874011811d + "'", double1 == 7.874007874011811d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.085025156788169E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999999524131d + "'", double1 == 0.999999999524131d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(95);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable25, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray28);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator36 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator36);
//        int int40 = randomDataImpl37.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str42 = randomDataImpl37.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { randomDataImpl37 };
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable35, objArray43);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "23ea7a8c59", objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(66, localizable14, objArray43);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray48);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 56 + "'", int40 == 56);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "041414c8e0" + "'", str42.equals("041414c8e0"));
//        org.junit.Assert.assertNotNull(objArray43);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.9912260756924949d, 0.0042019221392496225d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.002898268139389d + "'", double2 == 1.002898268139389d);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
//        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
//        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException20.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, localizable31, objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException30.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator36 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator36);
//        int int40 = randomDataImpl37.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str42 = randomDataImpl37.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { randomDataImpl37 };
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable35, objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable34, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable46 = maxIterationsExceededException45.getGeneralPattern();
//        java.lang.Number number49 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable46, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number49);
//        java.lang.Object[] objArray52 = null;
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("hi!", objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        java.lang.Object[] objArray55 = null;
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException53, localizable54, objArray55);
//        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException53.getGeneralPattern();
//        java.lang.Object[] objArray59 = null;
//        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("hi!", objArray59);
//        org.apache.commons.math.exception.util.Localizable localizable61 = null;
//        java.lang.Object[] objArray62 = null;
//        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException60, localizable61, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException60.getGeneralPattern();
//        java.lang.Number number66 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable64, (java.lang.Number) 184.51869951185168d, number66, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable75 = null;
//        java.lang.Object[] objArray78 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable75, objArray78);
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray78);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable64, objArray78);
//        org.apache.commons.math.exception.util.Localizable localizable85 = null;
//        java.lang.Object[] objArray88 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable85, objArray88);
//        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray88);
//        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray88);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable57, objArray88);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException(6, "4a13dbd0ae", objArray88);
//        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException20, localizable24, objArray88);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
//        org.junit.Assert.assertNotNull(localizable22);
//        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1410035b62" + "'", str42.equals("1410035b62"));
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(localizable46);
//        org.junit.Assert.assertNotNull(localizable57);
//        org.junit.Assert.assertNotNull(localizable64);
//        org.junit.Assert.assertNotNull(objArray78);
//        org.junit.Assert.assertNotNull(objArray88);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.7453292519943295d, (java.lang.Number) 7.144279871589963d, true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long2 = org.apache.commons.math.util.FastMath.max(9L, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 1.6245197929597313d, (java.lang.Number) 94);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 94 + "'", number4.equals(94));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
        double double6 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double8 = normalDistributionImpl2.inverseCumulativeProbability(76.73461137997397d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 76.735 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.49689300088292593d + "'", double5 == 0.49689300088292593d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double2 = org.apache.commons.math.util.FastMath.max((double) ' ', 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 45, (java.lang.Number) 0.9997928884694727d, false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Throwable[] throwableArray7 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 94L, 49.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 93.99999999999999d + "'", double2 == 93.99999999999999d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.26405474070360596d, 0.23056057779637718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.85301253823999d + "'", double2 == 0.85301253823999d);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double8 = randomDataImpl1.nextExponential(25.00962318159671d);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4ab444f613" + "'", str6.equals("4ab444f613"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.136506892297242d + "'", double8 == 7.136506892297242d);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.3309781210727745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3309781210727745d + "'", double1 == 0.3309781210727745d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.FastMath.min(50.30685281944005d, (-16.760738870170442d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-16.760738870170442d) + "'", double2 == (-16.760738870170442d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 88.0394601776806d, (java.lang.Number) 9, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 9 + "'", number4.equals(9));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double14 = normalDistributionImpl6.density((double) 99L);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0024145392718017337d + "'", double14 == 0.0024145392718017337d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.ulp(71.73357607583696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double2 = org.apache.commons.math.util.FastMath.min((-47.47466291813209d), (-28.843873837893746d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-47.47466291813209d) + "'", double2 == (-47.47466291813209d));
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray9);
//        java.lang.Object[] objArray12 = convergenceException11.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException11.getGeneralPattern();
//        java.lang.Number number15 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 35.0d, number15, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 4.626065009182742d, (java.lang.Number) 85, (java.lang.Number) 34);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "92c7d09dcf" + "'", str8.equals("92c7d09dcf"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(localizable13);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 64);
//        java.lang.Number number77 = null;
//        java.lang.Number number78 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number77, number78, (java.lang.Number) 0.5772156649015329d);
//        java.lang.Throwable[] throwableArray81 = outOfRangeException80.getSuppressed();
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 35 + "'", int27 == 35);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "4b56e05639" + "'", str29.equals("4b56e05639"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 35 + "'", int54 == 35);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "651c715fd6" + "'", str56.equals("651c715fd6"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(throwableArray81);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        int int14 = randomDataImpl1.nextZipf(61, 0.35657465508606395d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 65.11733146447183d + "'", double7 == 65.11733146447183d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        int int21 = randomDataImpl1.nextHypergeometric(98, 49, 56);
//        try {
//            long long24 = randomDataImpl1.nextSecureLong(0L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15e72e74e0" + "'", str6.equals("15e72e74e0"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.28112837193400253d) + "'", double9 == (-0.28112837193400253d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "b5cef6646c923d4c32c1a8cb83bad6d318b8c9cbaba036275e13" + "'", str14.equals("b5cef6646c923d4c32c1a8cb83bad6d318b8c9cbaba036275e13"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.8265896506048208d) + "'", double17 == (-0.8265896506048208d));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.math.util.FastMath.max(93, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double9 = randomDataImpl1.nextWeibull((double) 32.0f, 2.226441832186995d);
//        double double12 = randomDataImpl1.nextUniform(0.011366898564937883d, 0.07520395772047966d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a8e53c3202" + "'", str6.equals("a8e53c3202"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.171942528425655d + "'", double9 == 2.171942528425655d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0462605282408842d + "'", double12 == 0.0462605282408842d);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(32);
//        double double6 = randomDataImpl1.nextWeibull(0.9849051783319762d, (double) 66);
//        int int9 = randomDataImpl1.nextInt(0, 50);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(57);
//        java.lang.String str13 = randomDataImpl1.nextHexString(59);
//        try {
//            int int16 = randomDataImpl1.nextSecureInt(81, 20);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 81 is larger than, or equal to, the maximum (20): lower bound (81) must be strictly less than upper bound (20)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1bf9237fa340499d7bd782e64a6122a4" + "'", str3.equals("1bf9237fa340499d7bd782e64a6122a4"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 207.2942102781553d + "'", double6 == 207.2942102781553d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "e01a4ac66284cccfa4fa0ef0236f6ce5cbe3a42f4289ce7502c1ae97b" + "'", str11.equals("e01a4ac66284cccfa4fa0ef0236f6ce5cbe3a42f4289ce7502c1ae97b"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "99f88b9cc55c9d5d1461a5068e8596c7e513f9ec27ed9af8f28d8c76f3e" + "'", str13.equals("99f88b9cc55c9d5d1461a5068e8596c7e513f9ec27ed9af8f28d8c76f3e"));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int2 = org.apache.commons.math.util.FastMath.max(41, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41 + "'", int2 == 41);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, localizable14, objArray19);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable14, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator25);
//        int int29 = randomDataImpl26.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str31 = randomDataImpl26.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { randomDataImpl26 };
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable24, objArray32);
//        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException33.getGeneralPattern();
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable39, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 184.51869951185168d, number44, false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray53 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable50, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray53);
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("8a5edff846", objArray53);
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable42, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray53);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable14, objArray53);
//        java.lang.Object[] objArray61 = null;
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("hi!", objArray61);
//        org.apache.commons.math.exception.util.Localizable localizable63 = null;
//        java.lang.Object[] objArray64 = null;
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException62, localizable63, objArray64);
//        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException62.getGeneralPattern();
//        java.lang.Object[] objArray71 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException62, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray71);
//        org.apache.commons.math.exception.util.Localizable localizable73 = mathException72.getGeneralPattern();
//        java.lang.Number number74 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException(localizable73, number74, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
//        java.lang.Number number78 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable73, number78, (java.lang.Number) 88.0394601776806d, true);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException(89);
//        java.lang.Throwable[] throwableArray84 = maxIterationsExceededException83.getSuppressed();
//        java.lang.Object[] objArray85 = maxIterationsExceededException83.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, objArray85);
//        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable14, objArray85);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException91 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (-16.484386101324358d), (java.lang.Number) 13.728756420312397d, (java.lang.Number) 323.0032506111982d);
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 95 + "'", int29 == 95);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9519f1d3ec" + "'", str31.equals("9519f1d3ec"));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNull(localizable35);
//        org.junit.Assert.assertNotNull(localizable42);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(localizable66);
//        org.junit.Assert.assertNotNull(objArray71);
//        org.junit.Assert.assertNotNull(localizable73);
//        org.junit.Assert.assertNotNull(throwableArray84);
//        org.junit.Assert.assertNotNull(objArray85);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.874007874011811d, (-52.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.87400787401181d + "'", double2 == 7.87400787401181d);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
//        java.lang.Number number18 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, number18, (java.lang.Number) 88.0394601776806d, true);
//        java.lang.Object[] objArray24 = null;
//        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("hi!", objArray24);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray27 = null;
//        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException25, localizable26, objArray27);
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException25.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator31 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator31);
//        int int35 = randomDataImpl32.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str37 = randomDataImpl32.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray38 = new java.lang.Object[] { randomDataImpl32 };
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable30, objArray38);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable29, objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable41 = maxIterationsExceededException40.getGeneralPattern();
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number44);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("hi!", objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        java.lang.Object[] objArray53 = null;
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51, localizable52, objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException51.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator57 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator57);
//        int int61 = randomDataImpl58.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str63 = randomDataImpl58.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { randomDataImpl58 };
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable56, objArray64);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable55, objArray64);
//        org.apache.commons.math.exception.util.Localizable localizable67 = maxIterationsExceededException66.getGeneralPattern();
//        java.lang.Object[] objArray69 = null;
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("hi!", objArray69);
//        org.apache.commons.math.exception.util.Localizable localizable71 = null;
//        java.lang.Object[] objArray72 = null;
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException70, localizable71, objArray72);
//        org.apache.commons.math.exception.util.Localizable localizable74 = convergenceException70.getGeneralPattern();
//        java.lang.Number number76 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable74, (java.lang.Number) 184.51869951185168d, number76, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable74, (java.lang.Number) 0.04457085352364287d);
//        java.lang.Number number89 = notStrictlyPositiveException88.getMin();
//        org.apache.commons.math.exception.util.Localizable localizable90 = notStrictlyPositiveException88.getSpecificPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException94 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.4430227202923068d, (java.lang.Number) 46, false);
//        java.lang.Object[] objArray95 = numberIsTooLargeException94.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable90, objArray95);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(0, "d3faa9e8c6", objArray95);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable41, objArray95);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertNotNull(localizable29);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 51 + "'", int35 == 51);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "f7b8c6ef01" + "'", str37.equals("f7b8c6ef01"));
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(localizable41);
//        org.junit.Assert.assertNotNull(localizable55);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 51 + "'", int61 == 51);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "a8a7113e65" + "'", str63.equals("a8a7113e65"));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(localizable67);
//        org.junit.Assert.assertNotNull(localizable74);
//        org.junit.Assert.assertTrue("'" + number89 + "' != '" + 0 + "'", number89.equals(0));
//        org.junit.Assert.assertNotNull(localizable90);
//        org.junit.Assert.assertNotNull(objArray95);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.9385299322202547d, 79.87899290686482d, 0.0d, 59);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.density(5.344864515413418E-21d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-65.46562574552813d) + "'", double3 == (-65.46562574552813d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.0d + "'", double5 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004482497532600368d + "'", double7 == 0.004482497532600368d);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3872962728435185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9259336037419351d + "'", double1 == 0.9259336037419351d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Number number31 = outOfRangeException30.getLo();
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException30);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 61 + "'", int13 == 61);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "c28bab292c" + "'", str15.equals("c28bab292c"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-57.29577951308232d) + "'", number31.equals((-57.29577951308232d)));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.8665064475770338d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6189567686681903d + "'", double1 == 2.6189567686681903d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.sinh(36.137757084977785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.473993160727642E15d + "'", double1 == 2.473993160727642E15d);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        java.lang.Throwable[] throwableArray32 = convergenceException31.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException31.getGeneralPattern();
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, localizable37, objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException36.getGeneralPattern();
//        java.lang.Number number42 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 184.51869951185168d, number42, false);
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        java.lang.Object[] objArray51 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable48, objArray51);
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray51);
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("8a5edff846", objArray51);
//        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable40, objArray51);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray51);
//        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable6, objArray51);
//        java.lang.Number number59 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 41.352615659729615d, number59, false);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 62 + "'", int27 == 62);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "bbb3006d05" + "'", str29.equals("bbb3006d05"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNull(localizable33);
//        org.junit.Assert.assertNotNull(localizable40);
//        org.junit.Assert.assertNotNull(objArray51);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        randomDataImpl1.reSeed((long) 54);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "05dd32f5f47bf4a3075cfb1592e2339b681941" + "'", str3.equals("05dd32f5f47bf4a3075cfb1592e2339b681941"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 43.84497664187366d + "'", double9 == 43.84497664187366d);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 62);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 62 + "'", int1 == 62);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.9485653159430099d), 1.0635597985607013d, (double) 93.0f);
        double[] doubleArray5 = normalDistributionImpl3.sample(78);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.999999999524131d, (-0.25966336095252274d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999995241309d + "'", double2 == 0.9999999995241309d);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.cumulativeProbability((double) 71L);
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-168.61810012590377d) + "'", double3 == (-168.61810012590377d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7874930241994573d + "'", double6 == 0.7874930241994573d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        int[] intArray15 = randomDataImpl1.nextPermutation(66, 15);
        randomDataImpl1.reSeedSecure((long) 10);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.586840308962423d, (-0.03559902319934646d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 13L + "'", long1 == 13L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 37.43048065418202d, (java.lang.Number) 50.30685281944005d, false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int1 = org.apache.commons.math.util.FastMath.abs(40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40 + "'", int1 == 40);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0051545022222d + "'", double1 == 97.0051545022222d);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test413");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(99, "", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getGeneralPattern();
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException8.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator14);
//        int int18 = randomDataImpl15.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str20 = randomDataImpl15.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray21 = new java.lang.Object[] { randomDataImpl15 };
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable13, objArray21);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable12, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = maxIterationsExceededException23.getGeneralPattern();
//        java.lang.Number number27 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number27);
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable30, objArray33);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable24, objArray33);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 325.2739962095386d, (java.lang.Number) 24.500417218821333d, (java.lang.Number) (-96.29687703478157d));
//        org.junit.Assert.assertNotNull(localizable4);
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "29cc0789f5" + "'", str20.equals("29cc0789f5"));
//        org.junit.Assert.assertNotNull(objArray21);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertNotNull(objArray33);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        randomDataImpl1.reSeed((long) 43);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double11 = normalDistributionImpl10.getStandardDeviation();
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
        long long14 = randomDataImpl1.nextPoisson(53.08495167300164d);
        try {
            double double17 = randomDataImpl1.nextBeta(0.0d, 255.80729084810065d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.532");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 89.0d + "'", double11 == 89.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.55518924217818d + "'", double12 == 54.55518924217818d);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54L + "'", long14 == 54L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(43.84497664187366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.765239202860702d + "'", double1 == 0.765239202860702d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.log10((-4.9E-324d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 20L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 95);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.056195414445117E40d + "'", double1 == 9.056195414445117E40d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7320508075688772d, (double) 79L, 5.344864515413418E-21d);
        double[] doubleArray5 = normalDistributionImpl3.sample(55);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.floor(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.0d + "'", double1 == 2005.0d);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test421");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        int int11 = randomDataImpl1.nextBinomial(83, 0.02464616772939129d);
//        long long14 = randomDataImpl1.nextLong(35L, (long) 90);
//        try {
//            long long17 = randomDataImpl1.nextLong((long) 97, (long) 63);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (63): lower bound (97) must be strictly less than upper bound (63)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "59c5d3d1f4005752502fb8fbad916b241fd622" + "'", str3.equals("59c5d3d1f4005752502fb8fbad916b241fd622"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 50L + "'", long14 == 50L);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        int int32 = randomDataImpl1.nextZipf(52, 1.5060973145850306E35d);
//        double double35 = randomDataImpl1.nextCauchy((-107.674757616243d), 1.6231562043547265d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "db3048d17417e5f128f4a79724e0d01fa29a36" + "'", str3.equals("db3048d17417e5f128f4a79724e0d01fa29a36"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999984386034d + "'", double11 == 0.9999999984386034d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-28.507685362571795d) + "'", double15 == (-28.507685362571795d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 45.96743602496565d + "'", double20 == 45.96743602496565d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.77090970472597d + "'", double29 == 99.77090970472597d);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-106.21073595256878d) + "'", double35 == (-106.21073595256878d));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 99, (java.lang.Number) 0.003043811033521959d, false);
        org.junit.Assert.assertNotNull(localizable10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 50.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8726646259971648d + "'", double1 == 0.8726646259971648d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        try {
//            double double8 = randomDataImpl1.nextF((-60.501391007494405d), 0.47712125471966244d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -60.501 is smaller than, or equal to, the minimum (0): degrees of freedom (-60.501)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2bd909cfb10b604e08962f342841aca106c2d5" + "'", str3.equals("2bd909cfb10b604e08962f342841aca106c2d5"));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.03559902319934646d), (-21.658387150281996d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03559902319934647d) + "'", double2 == (-0.03559902319934647d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 46, 2.9947002357337635d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.99999999999999d + "'", double2 == 45.99999999999999d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.772724140890869d), 1.0821041362364843d);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0821041362364843d + "'", double3 == 1.0821041362364843d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9493120476063805d + "'", double5 == 0.9493120476063805d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.log1p(18.043296693152538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9467151600240094d + "'", double1 == 2.9467151600240094d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.ceil(24.500417218821333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test433");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray16 = normalDistributionImpl14.sample(86);
//        double double19 = normalDistributionImpl14.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        java.lang.Class<?> wildcardClass20 = normalDistributionImpl14.getClass();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        long long23 = randomDataImpl1.nextPoisson(3.028368902863115d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl24 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double26 = normalDistributionImpl24.cumulativeProbability(Double.NaN);
//        double double28 = normalDistributionImpl24.cumulativeProbability((double) (-1));
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.801520017931754d + "'", double7 == 20.801520017931754d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3951090411855414d + "'", double11 == 1.3951090411855414d);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.004482403217643316d + "'", double19 == 0.004482403217643316d);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-118.12788786341271d) + "'", double21 == (-118.12788786341271d));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3L + "'", long23 == 3L);
//        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.15865525393145702d + "'", double28 == 0.15865525393145702d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.7476520016703659d + "'", double29 == 0.7476520016703659d);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test434");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(89);
//        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str11 = randomDataImpl6.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray12 = new java.lang.Object[] { randomDataImpl6 };
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable4, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray12);
//        java.lang.Object[] objArray15 = convergenceException14.getArguments();
//        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) convergenceException14);
//        int int17 = maxIterationsExceededException1.getMaxIterations();
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 54 + "'", int9 == 54);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8250e79e54" + "'", str11.equals("8250e79e54"));
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 89 + "'", int17 == 89);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double12 = randomDataImpl1.nextExponential(217.91434136884345d);
//        double double14 = randomDataImpl1.nextChiSquare(32.38316732970439d);
//        try {
//            int int18 = randomDataImpl1.nextHypergeometric(94, 66, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (94): sample size (100) must be less than or equal to population size (94)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 71.8972006961014d + "'", double7 == 71.8972006961014d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 365.6224314238894d + "'", double12 == 365.6224314238894d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 23.19469667397232d + "'", double14 == 23.19469667397232d);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        try {
//            java.lang.String str9 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 74 + "'", int4 == 74);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.12495884213504d + "'", double7 == 90.12495884213504d);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        long long3 = randomDataImpl0.nextPoisson(139.67385975737693d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 154L + "'", long3 == 154L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.2183089412468484d, (java.lang.Number) 1.7320508075688772d, true);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test439");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextUniform(0.5403023058681398d, (double) 32);
//        java.lang.String str10 = randomDataImpl1.nextHexString(81);
//        int int13 = randomDataImpl1.nextPascal(78, 0.9999999982611434d);
//        try {
//            double double16 = randomDataImpl1.nextGamma((double) (short) 0, (double) 34);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9aafbf1c99e6b565bdb0ed14ee6c5cf75f3dbe" + "'", str3.equals("9aafbf1c99e6b565bdb0ed14ee6c5cf75f3dbe"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8316599355501716d + "'", double8 == 0.8316599355501716d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a64c013d3bbf464ad4ff1011c8b8cf239e25ed32a45baf18eb369c96a1adfa1c9284b3604bbff0033" + "'", str10.equals("a64c013d3bbf464ad4ff1011c8b8cf239e25ed32a45baf18eb369c96a1adfa1c9284b3604bbff0033"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.28203261776953986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2848842516505476d + "'", double1 == 1.2848842516505476d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        int int8 = randomDataImpl1.nextZipf(66, 9.889030319346946E42d);
        try {
            double double10 = randomDataImpl1.nextT((-0.3698875242387616d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.37 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.37)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.02464616772939129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.3015677487665287E-4d + "'", double1 == 4.3015677487665287E-4d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 68.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1868238913561442d + "'", double1 == 1.1868238913561442d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number19 = outOfRangeException18.getLo();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18);
        org.apache.commons.math.exception.util.Localizable localizable21 = outOfRangeException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 92.49007379019659d, (java.lang.Number) 74.2165889273594d, (java.lang.Number) 0.004830894954222802d);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Number number5 = outOfRangeException4.getHi();
//        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = null;
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
//        java.lang.Number number15 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
//        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
//        java.lang.Number number19 = numberIsTooLargeException17.getMax();
//        java.lang.Number number20 = numberIsTooLargeException17.getMax();
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException24.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator30 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator30);
//        int int34 = randomDataImpl31.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str36 = randomDataImpl31.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { randomDataImpl31 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable29, objArray37);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable28, objArray37);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("hi!", objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        java.lang.Object[] objArray53 = null;
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51, localizable52, objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException51.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator57 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator57);
//        int int61 = randomDataImpl58.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str63 = randomDataImpl58.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { randomDataImpl58 };
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable56, objArray64);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable55, objArray64);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number72 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) (short) 100, number72, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray80 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable55, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable28, objArray80);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray80);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 74 + "'", int34 == 74);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "17c74a61ed" + "'", str36.equals("17c74a61ed"));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(localizable55);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 74 + "'", int61 == 74);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "97e3ba1709" + "'", str63.equals("97e3ba1709"));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray80);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test446");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Number number5 = outOfRangeException4.getHi();
//        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
//        java.lang.Object[] objArray7 = outOfRangeException4.getArguments();
//        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("7b9cb371cf", objArray7);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("hi!", objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        java.lang.Object[] objArray22 = null;
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20, localizable21, objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException20.getGeneralPattern();
//        java.lang.Number number26 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 184.51869951185168d, number26, false);
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException17, localizable24, objArray29);
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable24, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator35 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl36 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator35);
//        int int39 = randomDataImpl36.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str41 = randomDataImpl36.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { randomDataImpl36 };
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable34, objArray42);
//        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException43.getGeneralPattern();
//        java.lang.Object[] objArray47 = null;
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("hi!", objArray47);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException48, localizable49, objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException48.getGeneralPattern();
//        java.lang.Number number54 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 184.51869951185168d, number54, false);
//        org.apache.commons.math.exception.util.Localizable localizable60 = null;
//        java.lang.Object[] objArray63 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable60, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray63);
//        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("8a5edff846", objArray63);
//        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException43, localizable52, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray63);
//        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException13, localizable24, objArray63);
//        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, "9bb223c487", objArray63);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 73 + "'", int39 == 73);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "749929a213" + "'", str41.equals("749929a213"));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertNull(localizable45);
//        org.junit.Assert.assertNotNull(localizable52);
//        org.junit.Assert.assertNotNull(objArray63);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test447");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability((double) 97);
//        normalDistributionImpl2.reseedRandomGenerator(0L);
//        double double8 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.144259253975731d) + "'", double3 == (-11.144259253975731d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8621186791753761d + "'", double5 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 89.0d + "'", double8 == 89.0d);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 74);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 74L + "'", long2 == 74L);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test449");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, (double) 43);
//        long long13 = randomDataImpl1.nextLong((-1L), (long) 13);
//        randomDataImpl1.reSeed((long) 4);
//        randomDataImpl1.reSeedSecure(4L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 328.0761107669804d + "'", double7 == 328.0761107669804d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-56.47257550644328d) + "'", double10 == (-56.47257550644328d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9L + "'", long13 == 9L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.FastMath.asin(165.90272130952587d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test451");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator3 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator3);
//        int int7 = randomDataImpl4.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str9 = randomDataImpl4.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray10 = new java.lang.Object[] { randomDataImpl4 };
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray10);
//        java.lang.Object[] objArray13 = convergenceException12.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray24 = null;
//        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException22, localizable23, objArray24);
//        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException22.getGeneralPattern();
//        java.lang.Number number28 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 184.51869951185168d, number28, false);
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable26, objArray31);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 35.0d, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray42 = null;
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("hi!", objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray45 = null;
//        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException43, localizable44, objArray45);
//        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException43.getGeneralPattern();
//        java.lang.Number number49 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 184.51869951185168d, number49, false);
//        java.lang.Object[] objArray52 = null;
//        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40, localizable47, objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator56 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl57 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator56);
//        int int60 = randomDataImpl57.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str62 = randomDataImpl57.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray63 = new java.lang.Object[] { randomDataImpl57 };
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable55, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable47, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable26, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "b0e2fc0bcb26fddc87167c871c686fb0f33910b5c24045e62893ccddc5de431063df1a4e86553972312abc8e2029e7c72094", objArray63);
//        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("e65375e516d9d029f920d945d6942610afcd0f", objArray63);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39 + "'", int7 == 39);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "33f44f0743" + "'", str9.equals("33f44f0743"));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertNotNull(localizable26);
//        org.junit.Assert.assertNotNull(localizable47);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 38 + "'", int60 == 38);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "d42c0b649c" + "'", str62.equals("d42c0b649c"));
//        org.junit.Assert.assertNotNull(objArray63);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long1 = org.apache.commons.math.util.FastMath.round((-14.674528640031419d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-15L) + "'", long1 == (-15L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 4L, (double) 26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.0d + "'", double2 == 26.0d);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 35.0d, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable28, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException27.getGeneralPattern();
//        java.lang.Number number33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 184.51869951185168d, number33, false);
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException24, localizable31, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator40 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator40);
//        int int44 = randomDataImpl41.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str46 = randomDataImpl41.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { randomDataImpl41 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable39, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable31, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable10, objArray47);
//        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "a95ffb519d" + "'", str46.equals("a95ffb519d"));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(throwableArray52);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        java.lang.Class<?> wildcardClass13 = normalDistributionImpl6.getClass();
        double double15 = normalDistributionImpl6.cumulativeProbability(1.7453292519943295d);
        double double17 = normalDistributionImpl6.density(1.5060973145850306E35d);
        double[] doubleArray19 = normalDistributionImpl6.sample(58);
        double double21 = normalDistributionImpl6.density(1.7572742277801137E7d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5078229326523436d + "'", double15 == 0.5078229326523436d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.log(2.8531036963523766E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.464518046973732d) + "'", double1 == (-10.464518046973732d));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test457");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 89.0d, (java.lang.Number) 50, false);
//        java.lang.Number number41 = numberIsTooSmallException40.getMin();
//        boolean boolean42 = numberIsTooSmallException40.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "a2d139a8b5" + "'", str8.equals("a2d139a8b5"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 50 + "'", number41.equals(50));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.144279871589963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 409.3370843023706d + "'", double1 == 409.3370843023706d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-32.001507797015755d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 666.6956115158042d + "'", double1 == 666.6956115158042d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(61, 33, 43);
//        randomDataImpl1.reSeedSecure(68L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 23 + "'", int12 == 23);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.695928762954793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number19 = outOfRangeException18.getLo();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException20);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 72, (java.lang.Number) 0.4430227202923068d, (java.lang.Number) 86);
        java.lang.Number number26 = outOfRangeException25.getLo();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable31, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException21, localizable27, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.4430227202923068d + "'", number26.equals(0.4430227202923068d));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 9, (-1.772724140890869d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test465");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        int int20 = randomDataImpl1.nextInt(70, 88);
//        java.lang.String str22 = randomDataImpl1.nextHexString(82);
//        try {
//            java.lang.String str24 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "847e3963aa" + "'", str6.equals("847e3963aa"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.2992652686895957d) + "'", double9 == (-0.2992652686895957d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "e895a5f9f6af4b134d3bf11ffd255fb4a4f2cd40914985e0ba9d" + "'", str14.equals("e895a5f9f6af4b134d3bf11ffd255fb4a4f2cd40914985e0ba9d"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3414846932096882d + "'", double17 == 1.3414846932096882d);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 70 + "'", int20 == 70);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "7e49006c37fb49c5292581aa5fa8f85bfad6685382223e3320b2548db6daaa97dd651daa82a02e79ad" + "'", str22.equals("7e49006c37fb49c5292581aa5fa8f85bfad6685382223e3320b2548db6daaa97dd651daa82a02e79ad"));
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(20.801520017931754d, 63.085305060930544d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.801520017931757d + "'", double2 == 20.801520017931757d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.ulp(25.821660212515532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.2584665919121987d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10.0d, (java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 34);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 34 + "'", number4.equals(34));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.013311627947871498d), 126.02245023199458d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 126.02245023199458d + "'", double2 == 126.02245023199458d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.449489742783178d + "'", double1 == 2.449489742783178d);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        java.lang.Class<?> wildcardClass16 = randomDataImpl1.getClass();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution17 = null;
//        try {
//            int int18 = randomDataImpl1.nextInversionDeviate(integerDistribution17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "719534736fa3f23dc6ccce3254014667565f5e" + "'", str3.equals("719534736fa3f23dc6ccce3254014667565f5e"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999984755055d + "'", double11 == 0.9999999984755055d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.2696379585361875d) + "'", double13 == (-0.2696379585361875d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ba99a736c0f34defcac72b8ea62fd1561a5e82abb5c67063bd3bceae35d34b7598f74f9e284604a4c4e8244b69a66b71bff9" + "'", str15.equals("ba99a736c0f34defcac72b8ea62fd1561a5e82abb5c67063bd3bceae35d34b7598f74f9e284604a4c4e8244b69a66b71bff9"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test474");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5707963267948966d, (double) 10.0f, 184.51869951185168d);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        double double22 = normalDistributionImpl19.inverseCumulativeProbability(0.5723649429247d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d54c4ec3ddc62f82b430d9fac212172e121bda" + "'", str3.equals("d54c4ec3ddc62f82b430d9fac212172e121bda"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.999999998998564d + "'", double11 == 0.999999998998564d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0280251547140535d + "'", double13 == 1.0280251547140535d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ebb832a6e345002e5ef4ac7c043fd870fd6db048ab3f35d2278b915b298f7e0398b4bfe999ee97ba748214e82625decde1d6" + "'", str15.equals("ebb832a6e345002e5ef4ac7c043fd870fd6db048ab3f35d2278b915b298f7e0398b4bfe999ee97ba748214e82625decde1d6"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.4292036732051034d) + "'", double20 == (-1.4292036732051034d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.5707963267948966d + "'", double22 == 2.5707963267948966d);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test475");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        try {
//            double double7 = randomDataImpl1.nextUniform(24.500417218821333d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 24.5 is larger than, or equal to, the maximum (0): lower bound (24.5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException5.getGeneralPattern();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 184.51869951185168d, number11, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.04457085352364287d);
        java.lang.Object[] objArray24 = notStrictlyPositiveException23.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(4, "57ceb132858911b98da62333a3892fb3850e87", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray24);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable32, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException31.getGeneralPattern();
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable39, objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 184.51869951185168d, number44, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable53, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable42, objArray56);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (short) 10, (java.lang.Number) 0.7799726475466374d, true);
        java.lang.Number number64 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, number64);
        java.lang.Throwable[] throwableArray66 = notStrictlyPositiveException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("5ba2364d8b", (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "ed15593665", (java.lang.Object[]) throwableArray66);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.004481799435259219d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004481814439358454d + "'", double1 == 0.004481814439358454d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(255.80729084810065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003916843573913431d + "'", double1 == 0.003916843573913431d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-108.95880009810901d), (double) 2, 1.19655940622189E15d, 72);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.2804518696792822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3237278296841644d + "'", double1 == 1.3237278296841644d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-58.841552582931406d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.2744692197697d + "'", double1 == 43.2744692197697d);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test482");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 88.0394601776806d, (java.lang.Number) 9, false);
//        maxIterationsExceededException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
//        org.apache.commons.math.exception.util.Localizable localizable24 = maxIterationsExceededException18.getGeneralPattern();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6025bc256a" + "'", str15.equals("6025bc256a"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable24);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-21.72848263158244d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3662497999365752E9d + "'", double1 == 1.3662497999365752E9d);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test484");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = normalDistributionImpl14.cumulativeProbability((double) 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3014aabe9372c1b15b8714af1e8dd3401303e7" + "'", str3.equals("3014aabe9372c1b15b8714af1e8dd3401303e7"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-100.5878663306588d) + "'", double15 == (-100.5878663306588d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-47.16841865994708d) + "'", double20 == (-47.16841865994708d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5268746266601116d + "'", double22 == 0.5268746266601116d);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test485");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int14 = randomDataImpl1.nextZipf(74, 0.011366898564937883d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b12796bdf154c05661d209a7f9ac98e73991b9" + "'", str3.equals("b12796bdf154c05661d209a7f9ac98e73991b9"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.33452028919813576d + "'", double8 == 0.33452028919813576d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 18 + "'", int14 == 18);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test486");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        randomDataImpl1.reSeed();
//        long long9 = randomDataImpl1.nextLong((long) 13, (long) 78);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "bb48e3840a1ec81be5ff0ed6aec695e11498c3cae54a0804da9596e238040acb1d5d08b34a0119f5f0e56f985b943cb2da08" + "'", str5.equals("bb48e3840a1ec81be5ff0ed6aec695e11498c3cae54a0804da9596e238040acb1d5d08b34a0119f5f0e56f985b943cb2da08"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28L + "'", long9 == 28L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Number number12 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(number12);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test489");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        double double13 = randomDataImpl1.nextChiSquare(3.408223431367131d);
//        int int16 = randomDataImpl1.nextBinomial(69, 0.3983155205756575d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 208.97993681162532d + "'", double7 == 208.97993681162532d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.308918695819787d + "'", double13 == 5.308918695819787d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 29 + "'", int16 == 29);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 42, 17L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) (-0.9126063361940036d), (java.lang.Number) Double.NaN);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test492");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double12 = randomDataImpl1.nextExponential(217.91434136884345d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double16 = normalDistributionImpl15.sample();
//        double double18 = normalDistributionImpl15.cumulativeProbability((double) 97);
//        double double19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 67.04458427445913d + "'", double7 == 67.04458427445913d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 651.6499683632566d + "'", double12 == 651.6499683632566d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-19.532901495657423d) + "'", double16 == (-19.532901495657423d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.8621186791753761d + "'", double18 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-94.42736321023246d) + "'", double19 == (-94.42736321023246d));
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeedSecure(0L);
//        double double8 = randomDataImpl1.nextChiSquare((double) 93.0f);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 96.79059831690755d + "'", double8 == 96.79059831690755d);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.4970909989451633E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707813558849066d + "'", double1 == 1.5707813558849066d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-38.3762959874568d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.FastMath.min(90L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(46);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(127.85671915442806d, (-78.09217997635302d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        randomDataImpl1.reSeed((long) '#');
        double double7 = randomDataImpl1.nextExponential(103.19223589283789d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.73177671425391d + "'", double7 == 32.73177671425391d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.92228024511367E-5d, (java.lang.Number) (-1244.9503500129863d), (java.lang.Number) 0.26860739951263224d);
    }
}

