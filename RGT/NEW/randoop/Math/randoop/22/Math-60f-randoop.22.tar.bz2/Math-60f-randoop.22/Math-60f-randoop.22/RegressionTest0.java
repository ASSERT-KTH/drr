import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextZipf(10, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        try {
//            double double7 = randomDataImpl1.nextGamma((double) (short) -1, (double) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.0d), (-1.0d), (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test009");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        try {
//            int int7 = randomDataImpl1.nextInt(0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-57.29577951308232d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            long long6 = randomDataImpl1.nextLong((long) (byte) 100, 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "53f85a61d045d71f0a435241f9a0695b40abeb" + "'", str3.equals("53f85a61d045d71f0a435241f9a0695b40abeb"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1L), (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            long long6 = randomDataImpl1.nextLong(0L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9ba858604f4438f530c512b75824f09b5330bf" + "'", str3.equals("9ba858604f4438f530c512b75824f09b5330bf"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextBinomial((int) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.9849051783319762d + "'", double0 == 0.9849051783319762d);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.7453292519943295d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 93);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6231562043547265d + "'", double1 == 1.6231562043547265d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6261509044766869d) + "'", double1 == (-1.6261509044766869d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            int int6 = randomDataImpl1.nextBinomial((int) (byte) 10, 2.154434690031884d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.154 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "882fd45f8cc4cab76908b1e8e86b3b7aeff87e" + "'", str3.equals("882fd45f8cc4cab76908b1e8e86b3b7aeff87e"));
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        try {
//            long long10 = randomDataImpl1.nextSecureLong(1L, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 91 + "'", int4 == 91);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 99.8229767724534d + "'", double7 == 99.8229767724534d);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        try {
//            int int9 = randomDataImpl1.nextZipf((int) '4', 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 91 + "'", int4 == 91);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "f139823e42" + "'", str6.equals("f139823e42"));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.251752586176186d + "'", double1 == 2.251752586176186d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 38, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "63a386c734");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 63a386c734");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86 + "'", int4 == 86);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a6a23c166b" + "'", str6.equals("a6a23c166b"));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        try {
//            java.lang.String str11 = randomDataImpl1.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3ed8968a79" + "'", str6.equals("3ed8968a79"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.3197902705943442d) + "'", double9 == (-0.3197902705943442d));
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            randomDataImpl1.setSecureAlgorithm("208f284ec3", "63a386c734");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 63a386c734");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4cb31251730223222cf7b6a2e91b5c22940f2d" + "'", str3.equals("4cb31251730223222cf7b6a2e91b5c22940f2d"));
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        try {
//            double double10 = randomDataImpl1.nextWeibull((double) (-1), (double) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): shape (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 211.08510744564555d + "'", double7 == 211.08510744564555d);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5615875626560803d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5091543890434437d) + "'", double1 == (-0.5091543890434437d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5184364492350668d + "'", double1 == 1.5184364492350668d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException2.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNull(localizable7);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        mathException5.addSuppressed((java.lang.Throwable) convergenceException15);
//        try {
//            java.lang.String str17 = convergenceException15.getPattern();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 41 + "'", int11 == 41);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "086765c072" + "'", str13.equals("086765c072"));
//        org.junit.Assert.assertNotNull(objArray14);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 38);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("3b05043edc", "a613fe76cf");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: a613fe76cf");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        try {
//            long long6 = randomDataImpl1.nextLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e600cca528788fe6c00806a0b9b9815775ec45" + "'", str3.equals("e600cca528788fe6c00806a0b9b9815775ec45"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9849051783319762d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.439487336882789d + "'", double1 == 2.439487336882789d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        try {
//            double double8 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3766a3962dbc1ebaf2eba6b2270386dd98bcb8" + "'", str3.equals("3766a3962dbc1ebaf2eba6b2270386dd98bcb8"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        try {
            int int6 = randomDataImpl1.nextPascal(0, (-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 90);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        int int19 = maxIterationsExceededException18.getMaxIterations();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "8a5edff846" + "'", str15.equals("8a5edff846"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 93 + "'", int19 == 93);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1.0f), 1.6231562043547265d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.439487336882789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6245197929597313d + "'", double1 == 1.6245197929597313d);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double8 = randomDataImpl1.nextExponential(88.0394601776806d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1f5338bd28" + "'", str6.equals("1f5338bd28"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 306.04582619592514d + "'", double8 == 306.04582619592514d);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1, (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449340668481562d + "'", double1 == 1.6449340668481562d);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        try {
//            int int8 = randomDataImpl1.nextInt(35, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (32): lower bound (35) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "728e375dd5e857398e7007798483d92328b30ed4693113ca1fbd3fa7117f080160f7c5ec74d9bf9aafa9ee39bb7b7164cd94" + "'", str5.equals("728e375dd5e857398e7007798483d92328b30ed4693113ca1fbd3fa7117f080160f7c5ec74d9bf9aafa9ee39bb7b7164cd94"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5184364492350668d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos(69.56422124950807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9008022248538402d + "'", double1 == 0.9008022248538402d);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        try {
//            double double5 = normalDistributionImpl2.inverseCumulativeProbability((-0.5772156677920679d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.577 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-129.31111687551183d) + "'", double3 == (-129.31111687551183d));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 91);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.atan2(88.0394601776806d, (double) 89);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7799726475466374d + "'", double2 == 0.7799726475466374d);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        try {
//            long long12 = randomDataImpl1.nextLong(0L, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "f01b873bde" + "'", str6.equals("f01b873bde"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.42702913678203736d) + "'", double9 == (-0.42702913678203736d));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double[] doubleArray2 = normalDistributionImpl0.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int11 = randomDataImpl1.nextBinomial(0, (double) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 184.43489389458554d + "'", double7 == 184.43489389458554d);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) -1, 0.9008022248538402d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9999999982611434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.557407718698416d + "'", double1 == 1.557407718698416d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 99);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        try {
//            long long14 = randomDataImpl1.nextLong((long) (short) 1, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ca28f8b301e883a3be64bed9d66aee435f9fa8" + "'", str3.equals("ca28f8b301e883a3be64bed9d66aee435f9fa8"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999989804282d + "'", double11 == 0.9999999989804282d);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        java.lang.Number number27 = numberIsTooLargeException26.getMax();
//        boolean boolean28 = numberIsTooLargeException26.getBoundIsAllowed();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 66 + "'", int13 == 66);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "c4e382fbf7" + "'", str15.equals("c4e382fbf7"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 94);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0, (double) ' ');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        java.lang.String str3 = convergenceException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray4);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.251752586176186d, (double) (-1), (double) 90, 4);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.439487336882789d, (java.lang.Number) 0.9999999982611434d, (java.lang.Number) 2.154434690031884d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '#', (-0.5615875626560803d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.586840308962423d + "'", double2 == 1.586840308962423d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        try {
            java.lang.String str6 = mathException5.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int11 = randomDataImpl1.nextBinomial(61, (double) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 62 + "'", int4 == 62);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 34.01506652822498d + "'", double7 == 34.01506652822498d);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 64);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1175745404058084E27d + "'", double1 == 3.1175745404058084E27d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int2 = org.apache.commons.math.util.FastMath.max(66, 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66 + "'", int2 == 66);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.acos(54.65622560668708d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 41, (double) 89);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.0d + "'", double2 == 41.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0d, (java.lang.Number) 1L, true);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "be3adae81fb11c3fbe3f95e187e8f6f015618e" + "'", str3.equals("be3adae81fb11c3fbe3f95e187e8f6f015618e"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 47.75177203930326d + "'", double9 == 47.75177203930326d);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.log(1.557407718698416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4430227202923068d + "'", double1 == 0.4430227202923068d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.6245197929597313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.439487336882789d + "'", double1 == 2.439487336882789d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134E13d + "'", double1 == 3.948148009134E13d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 49);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.0d + "'", double1 == 49.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.251752586176186d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        try {
//            int[] intArray9 = randomDataImpl1.nextPermutation(93, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        try {
//            double double11 = randomDataImpl1.nextF((double) 35, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32e56dabaec1625a582c3840fba6bd71e5644b" + "'", str3.equals("32e56dabaec1625a582c3840fba6bd71e5644b"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0976388714184833d + "'", double8 == 1.0976388714184833d);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int2 = org.apache.commons.math.util.FastMath.max(8, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        try {
//            int int8 = randomDataImpl1.nextInt((int) 'a', 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (97): lower bound (97) must be strictly less than upper bound (97)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "38b10c40bc6f83ec2c03a93eda30835f7bc1759722d94be59cb80d13bcd605f35f64762ea3d4dfe4be19c40b335ebaa291c8" + "'", str5.equals("38b10c40bc6f83ec2c03a93eda30835f7bc1759722d94be59cb80d13bcd605f35f64762ea3d4dfe4be19c40b335ebaa291c8"));
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("7129b79c9874f86f179bc2c416604492209abe", "208f284ec3");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 208f284ec3");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1aec5491bfee00837ad24031bce30516add6e7" + "'", str3.equals("1aec5491bfee00837ad24031bce30516add6e7"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.557407718698416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2261911676652137d + "'", double1 == 1.2261911676652137d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) 46);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        try {
//            int int12 = randomDataImpl1.nextSecureInt(91, 66);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 91 is larger than, or equal to, the maximum (66): lower bound (91) must be strictly less than upper bound (66)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7f5a1de9db1a09a87f972b2d3ae6f77f3b9cae" + "'", str3.equals("7f5a1de9db1a09a87f972b2d3ae6f77f3b9cae"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.661743152807969d + "'", double9 == 7.661743152807969d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0E-9d, 0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.999999999524131d + "'", double2 == 0.999999999524131d);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        try {
//            randomDataImpl1.setSecureAlgorithm("155032b5a2", "155032b5a2");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 155032b5a2");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 93);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.532599493153256d + "'", double1 == 4.532599493153256d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        try {
            long long6 = randomDataImpl1.nextSecureLong((long) 36, (long) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 36 is larger than, or equal to, the maximum (10): lower bound (36) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.718281828459045d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161212E43d + "'", double2 == 2.6881171418161212E43d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.apache.commons.math.util.FastMath.min(34, 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        java.lang.Class<?> wildcardClass19 = maxIterationsExceededException18.getClass();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 55 + "'", int13 == 55);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a8af20a7ad" + "'", str15.equals("a8af20a7ad"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextCauchy((double) 4, (double) 6);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution9 = null;
//        try {
//            double double10 = randomDataImpl1.nextInversionDeviate(continuousDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6e532bc9429b146be7f00e5ac86eb36c3c114d" + "'", str3.equals("6e532bc9429b146be7f00e5ac86eb36c3c114d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 143.47693207920156d + "'", double8 == 143.47693207920156d);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation(13, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "971381c9612c5f38ae86c145c2ee07a7f26930" + "'", str3.equals("971381c9612c5f38ae86c145c2ee07a7f26930"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.944780523340341d + "'", double9 == 12.944780523340341d);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("e49e318c76", "c8e431ef0b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c8e431ef0b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "df900f3ba7" + "'", str6.equals("df900f3ba7"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.822241221945281d) + "'", double9 == (-0.822241221945281d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl1.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "44c28df0a23ccf4319ec1bd01cd8d82a6945d698f35d0e8cd38280f8b0392015ee3814c459452ec71ab4cf6ada732fe57636" + "'", str5.equals("44c28df0a23ccf4319ec1bd01cd8d82a6945d698f35d0e8cd38280f8b0392015ee3814c459452ec71ab4cf6ada732fe57636"));
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextCauchy((double) 4, (double) 6);
//        try {
//            randomDataImpl1.setSecureAlgorithm("63a386c734", "b25620d2e7");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b25620d2e7");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6cf306c3b8c7d785a10928ca55ab331dc73c44" + "'", str3.equals("6cf306c3b8c7d785a10928ca55ab331dc73c44"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 18.08877211972863d + "'", double8 == 18.08877211972863d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 87, (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7799726475466374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7109327741638521d + "'", double1 == 0.7109327741638521d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        try {
//            double double9 = randomDataImpl1.nextGaussian(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "df6259c1555783298f219a2baeb00e988f19fc" + "'", str3.equals("df6259c1555783298f219a2baeb00e988f19fc"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        try {
            double double8 = randomDataImpl1.nextF(0.7799726475466374d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 100L, (java.lang.Number) 51);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 46);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.0d + "'", double1 == 46.0d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        try {
//            int int9 = randomDataImpl1.nextInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 67 + "'", int4 == 67);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3129cbc764" + "'", str6.equals("3129cbc764"));
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("hi!", objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        java.lang.Object[] objArray22 = null;
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20, localizable21, objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException20.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator26 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator26);
//        int int30 = randomDataImpl27.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str32 = randomDataImpl27.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray33 = new java.lang.Object[] { randomDataImpl27 };
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable25, objArray33);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable24, objArray33);
//        outOfRangeException3.addSuppressed((java.lang.Throwable) maxIterationsExceededException35);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 68 + "'", int30 == 68);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "5e3dac5d81" + "'", str32.equals("5e3dac5d81"));
//        org.junit.Assert.assertNotNull(objArray33);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextSecureLong((long) 32, (long) 59);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8a10c309937055648ba686356a5145fc8c4f01" + "'", str3.equals("8a10c309937055648ba686356a5145fc8c4f01"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 55L + "'", long8 == 55L);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6245197929597313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.3481042072937361d, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): standard deviation (-57.296)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        try {
//            int int8 = randomDataImpl1.nextSecureInt(87, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 87 is larger than, or equal to, the maximum (0): lower bound (87) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "975102ea7d94052a23646f90fc0ed6414826d4" + "'", str3.equals("975102ea7d94052a23646f90fc0ed6414826d4"));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01625980437881211d + "'", double1 == 0.01625980437881211d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        try {
            int int6 = randomDataImpl1.nextInt(94, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 94 is larger than, or equal to, the maximum (1): lower bound (94) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 6, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        try {
//            double double9 = randomDataImpl1.nextUniform(2.439487336882789d, (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2.439 is larger than, or equal to, the maximum (-1): lower bound (2.439) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e485feed422da0319b64ff868493691c1b9d55" + "'", str3.equals("e485feed422da0319b64ff868493691c1b9d55"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 51);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.046745412134694E21d + "'", double1 == 7.046745412134694E21d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5091543890434437d), 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.asin(311.5974716928727d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.acos(166.98999838850764d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 87, (double) 43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 86.99999999999999d + "'", double2 == 86.99999999999999d);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double8 = randomDataImpl1.nextExponential(88.0394601776806d);
//        try {
//            double double11 = randomDataImpl1.nextUniform((double) 97, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (10): lower bound (97) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 84 + "'", int4 == 84);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62ede6bbca" + "'", str6.equals("62ede6bbca"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.46390266501894d + "'", double8 == 90.46390266501894d);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long long1 = org.apache.commons.math.util.FastMath.round(1.586840308962423d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        try {
//            int int9 = randomDataImpl1.nextHypergeometric(0, 0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("68d437826bf2e99951744c4c59b7776345bd73", objArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5707963267948966d, (-0.5615875626560803d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948963d + "'", double2 == 1.5707963267948963d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 85, 1.6449340668481562d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        mathException5.addSuppressed((java.lang.Throwable) convergenceException15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = mathException5.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable18 = mathException5.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 81 + "'", int11 == 81);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "70cda50e14" + "'", str13.equals("70cda50e14"));
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNull(localizable17);
//        org.junit.Assert.assertNull(localizable18);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("8a5edff846", objArray47);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable36, objArray47);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray47);
//        java.lang.Class<?> wildcardClass53 = objArray47.getClass();
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 81 + "'", int23 == 81);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10963b82c0" + "'", str25.equals("10963b82c0"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertNull(localizable29);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 68, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 68.0f + "'", float2 == 68.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 36);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 36.0f + "'", float1 == 36.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 63, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        java.lang.String str19 = maxIterationsExceededException18.getPattern();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78 + "'", int13 == 78);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ce7133aa56" + "'", str15.equals("ce7133aa56"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.cos(359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5464784470336415d + "'", double1 == 0.5464784470336415d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9849051783319762d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7777935025554725d + "'", double1 == 0.7777935025554725d);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("553f77ced2b6b0112ec91c90a793c2c01a7548", (java.lang.Object[]) throwableArray11);
//        java.lang.Class<?> wildcardClass13 = convergenceException12.getClass();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 79 + "'", int6 == 79);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9f7dc540ad" + "'", str8.equals("9f7dc540ad"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        java.lang.Class<?> wildcardClass13 = normalDistributionImpl6.getClass();
        try {
            double double15 = normalDistributionImpl6.inverseCumulativeProbability((-0.5772156677920679d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.577 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        java.lang.Object[] objArray25 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable22, objArray25);
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray25);
//        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable19, objArray25);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78 + "'", int13 == 78);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "b131799281" + "'", str15.equals("b131799281"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray25);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 73 + "'", int4 == 73);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "e2ca04e58b" + "'", str6.equals("e2ca04e58b"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4555357731858426d) + "'", double9 == (-0.4555357731858426d));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        java.lang.Number number17 = numberIsTooSmallException16.getMin();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-0.8414709848078965d) + "'", number17.equals((-0.8414709848078965d)));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 81);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5060973145850306E35d + "'", double1 == 1.5060973145850306E35d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        java.lang.Number number9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 184.51869951185168d, number9, false);
//        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException11.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 79.87899290686482d, (java.lang.Number) 46, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException24.getGeneralPattern();
//        java.lang.Number number30 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 184.51869951185168d, number30, false);
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException21, localizable28, objArray33);
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator37 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator37);
//        int int41 = randomDataImpl38.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str43 = randomDataImpl38.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { randomDataImpl38 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable36, objArray44);
//        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException45.getGeneralPattern();
//        java.lang.Object[] objArray49 = null;
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        java.lang.Object[] objArray52 = null;
//        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException50, localizable51, objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable54 = convergenceException50.getGeneralPattern();
//        java.lang.Number number56 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 184.51869951185168d, number56, false);
//        org.apache.commons.math.exception.util.Localizable localizable62 = null;
//        java.lang.Object[] objArray65 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable62, objArray65);
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray65);
//        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("8a5edff846", objArray65);
//        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException45, localizable54, objArray65);
//        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException21, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray65);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(61, localizable13, objArray65);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 46 + "'", int41 == 46);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "daccac4a8f" + "'", str43.equals("daccac4a8f"));
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertNotNull(throwableArray46);
//        org.junit.Assert.assertNull(localizable47);
//        org.junit.Assert.assertNotNull(localizable54);
//        org.junit.Assert.assertNotNull(objArray65);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 12);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 12.0f + "'", float1 == 12.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        java.lang.Object[] objArray11 = numberIsTooLargeException10.getArguments();
        java.lang.Number number12 = numberIsTooLargeException10.getMax();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(number12);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 35.0d, (java.lang.Number) (byte) 1, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray84 = null;
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("hi!", objArray84);
//        org.apache.commons.math.exception.util.Localizable localizable86 = null;
//        java.lang.Object[] objArray87 = null;
//        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException85, localizable86, objArray87);
//        org.apache.commons.math.exception.util.Localizable localizable89 = convergenceException85.getGeneralPattern();
//        java.lang.Number number91 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException93 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable89, (java.lang.Number) 184.51869951185168d, number91, false);
//        java.lang.Object[] objArray94 = null;
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException82, localizable89, objArray94);
//        java.lang.Object[] objArray96 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable89, objArray96);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39 + "'", int27 == 39);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9be1001eeb" + "'", str29.equals("9be1001eeb"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 39 + "'", int54 == 39);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2e53d0400a" + "'", str56.equals("2e53d0400a"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(localizable89);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int2 = org.apache.commons.math.util.FastMath.max(72, 79);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79 + "'", int2 == 79);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        try {
//            int int9 = randomDataImpl1.nextPascal(13, (double) 63);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 63 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "f58788840d" + "'", str6.equals("f58788840d"));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-15.946367157587245d), 3.141592653589793d, 41.0d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.0f, (java.lang.Number) (-1), (java.lang.Number) 1L);
        java.lang.Number number15 = outOfRangeException14.getHi();
        java.lang.Number number16 = outOfRangeException14.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException14, localizable17, objArray18);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0f + "'", number16.equals(0.0f));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 51, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double5 = normalDistributionImpl2.cumulativeProbability((double) 0L, 0.0d);
        try {
            double double7 = normalDistributionImpl2.inverseCumulativeProbability((-21.612260619239635d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -21.612 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.548739357257746d + "'", double1 == 11.548739357257746d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.64158883361278d + "'", double1 == 4.64158883361278d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math.util.FastMath.min(1.586840308962423d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeedSecure((long) (short) 0);
//        try {
//            randomDataImpl1.setSecureAlgorithm("bc3c96e5d413f56260102db640e332819d40e9", "d7b62899dd");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d7b62899dd");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a82bed59834ae494fcce7de7b369f107b693e" + "'", str3.equals("4a82bed59834ae494fcce7de7b369f107b693e"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9999999986051742d, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999986051741d + "'", double2 == 0.9999999986051741d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed();
//        try {
//            long long7 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, number18, (java.lang.Number) 88.0394601776806d, true);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException21);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 36.0f, (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.844153986113171d + "'", double2 == 0.844153986113171d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 78);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.0d + "'", double1 == 78.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
        try {
            double double8 = randomDataImpl1.nextCauchy((-52.60498160271667d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric(85, 3, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9c3cb6dca5668480194947532cbb3d870fd26b" + "'", str3.equals("9c3cb6dca5668480194947532cbb3d870fd26b"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.7146434946612606d) + "'", double13 == (-0.7146434946612606d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "d6e44e9d7a6364752cc2ab462d271de171ff3ad600504aca91dccb54e2d1f85924b5957403ce0ec2e4c268fef9bb45fa8026" + "'", str15.equals("d6e44e9d7a6364752cc2ab462d271de171ff3ad600504aca91dccb54e2d1f85924b5957403ce0ec2e4c268fef9bb45fa8026"));
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, (double) 43);
//        try {
//            long long13 = randomDataImpl1.nextSecureLong((long) 62, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 62 is larger than, or equal to, the maximum (-1): lower bound (62) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.16671114354322d + "'", double7 == 12.16671114354322d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 17.775065944867276d + "'", double10 == 17.775065944867276d);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.6261509044766869d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 34, 69.56422124950807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4546128215008346d + "'", double2 == 0.4546128215008346d);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable15, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException14.getGeneralPattern();
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 184.51869951185168d, number20, false);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray29);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("8a5edff846", objArray29);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable18, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException9.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 56 + "'", int5 == 56);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "cdfd599a1b" + "'", str7.equals("cdfd599a1b"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable18);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNull(localizable34);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(179.02719848915368d, 0.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.559807758112163d + "'", double1 == 1.559807758112163d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2261911676652137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.408223431367131d + "'", double1 == 3.408223431367131d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 71);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 71L + "'", long1 == 71L);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Object[] objArray18 = null;
//        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray18);
//        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException16.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator22 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator22);
//        int int26 = randomDataImpl23.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str28 = randomDataImpl23.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl23 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable21, objArray29);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable20, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "e6f21f2cc2", objArray29);
//        java.lang.Class<?> wildcardClass33 = convergenceException9.getClass();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9597942afd" + "'", str7.equals("9597942afd"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "96a47da83e" + "'", str28.equals("96a47da83e"));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.19655940622189E15d + "'", double1 == 1.19655940622189E15d);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54 + "'", int4 == 54);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 305.12701831142147d + "'", double7 == 305.12701831142147d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.92228024511367E-5d + "'", double11 == 1.92228024511367E-5d);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.0f, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 12, 78.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5001586541738241E84d + "'", double2 == 1.5001586541738241E84d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.rint(54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.0d + "'", double1 == 55.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 81);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9084850188786497d + "'", double1 == 1.9084850188786497d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.6449340668481562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10607177757202746d) + "'", double1 == (-0.10607177757202746d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.844153986113171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6643638388299197d + "'", double1 == 0.6643638388299197d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 60, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        org.junit.Assert.assertNull(localizable6);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException8.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 184.51869951185168d, number14, false);
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable12, objArray28);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "a613fe76cf", objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getSpecificPattern();
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 73 + "'", int25 == 73);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2c9ba261e3" + "'", str27.equals("2c9ba261e3"));
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNull(localizable33);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long1 = org.apache.commons.math.util.FastMath.abs(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double[] doubleArray6 = normalDistributionImpl2.sample(79);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-21.72848263158244d) + "'", double3 == (-21.72848263158244d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray6);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(Double.NaN);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-58.79790177908768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.767325655951666d) + "'", double1 == (-4.767325655951666d));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.388515662649224d, 19.49251276164419d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8408327347643574E-7d + "'", double2 == 1.8408327347643574E-7d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray4 = normalDistributionImpl2.sample(86);
        double double7 = normalDistributionImpl2.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl2.getClass();
        double double10 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004482403217643316d + "'", double7 == 0.004482403217643316d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.006386112968825d + "'", double10 == 9.006386112968825d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.772724140890869d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.20055834661459787d) + "'", double1 == (-0.20055834661459787d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution10 = null;
        try {
            double double11 = randomDataImpl1.nextInversionDeviate(continuousDistribution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.65622560668708d + "'", double9 == 54.65622560668708d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability((double) 97);
//        double double6 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-203.8239334856476d) + "'", double3 == (-203.8239334856476d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8621186791753761d + "'", double5 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0821041362364843d + "'", double1 == 1.0821041362364843d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        int[] intArray15 = randomDataImpl1.nextPermutation(66, 49);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-21.612260619239635d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.61226061923963d) + "'", double1 == (-21.61226061923963d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double5 = normalDistributionImpl2.cumulativeProbability((double) 0L, 0.0d);
        double double6 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        try {
//            long long15 = randomDataImpl1.nextLong(90L, (long) 58);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 90 is larger than, or equal to, the maximum (58): lower bound (90) must be strictly less than upper bound (58)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0984204afb" + "'", str6.equals("0984204afb"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.6376259850627499d) + "'", double9 == (-0.6376259850627499d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.sin((-21.61226061923963d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3698875242387616d) + "'", double1 == (-0.3698875242387616d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10, (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
        try {
            int int11 = randomDataImpl1.nextBinomial((int) (byte) 0, 94.5694457151821d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 94.569 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.569750334265312d + "'", double1 == 0.569750334265312d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 3, (double) 54, 395.1575553230454d, 73);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.344864515413418E-21d + "'", double4 == 5.344864515413418E-21d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 38, (java.lang.Number) 61, (java.lang.Number) 1.5001586541738241E84d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 52L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        try {
//            int int9 = randomDataImpl1.nextBinomial(78, 1.7453292519943295d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.745 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.10607177757202746d), (-0.035591508433712726d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.035591508433712726d) + "'", double2 == (-0.035591508433712726d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
        convergenceException5.addSuppressed((java.lang.Throwable) mathException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException11.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNull(localizable13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        double double7 = randomDataImpl1.nextT((double) 13);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.632723255813097d) + "'", double7 == (-0.632723255813097d));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, (double) 43);
//        try {
//            double double13 = randomDataImpl1.nextGamma(1.6231562043547265d, (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 75 + "'", int4 == 75);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.088312564077523d + "'", double7 == 6.088312564077523d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-13.369258076802726d) + "'", double10 == (-13.369258076802726d));
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(6);
//        try {
//            int int14 = randomDataImpl1.nextZipf(0, (double) 78);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2f43281ffc993d46cf0efbb2ecd455824413c5" + "'", str3.equals("2f43281ffc993d46cf0efbb2ecd455824413c5"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.051384659790193264d + "'", double8 == 0.051384659790193264d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "922600" + "'", str11.equals("922600"));
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.2804518696792822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2767898921480116d + "'", double1 == 0.2767898921480116d);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 74 + "'", int13 == 74);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3ccb80250f" + "'", str15.equals("3ccb80250f"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray19);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 84, 1.5060973145850306E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5060973145850306E35d + "'", double2 == 1.5060973145850306E35d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.21273601220948d) + "'", double1 == (-48.21273601220948d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6643638388299197d, (double) (short) 10, 184.51869951185168d, 79);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4970909989451633E-5d + "'", double4 == 1.4970909989451633E-5d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(3.948148009134E13d, 40.89926471991978d, 40.89926471991978d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double5 = normalDistributionImpl2.cumulativeProbability((double) 0L, 0.0d);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 1);
        double double8 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 89.0d + "'", double8 == 89.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.pow(150.14867894829416d, 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0227183470559362d + "'", double2 == 1.0227183470559362d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.772724140890869d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.028368902863115d + "'", double1 == 3.028368902863115d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(96.99999999999999d, (double) 41, 69.56422124950807d);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        double double13 = randomDataImpl1.nextChiSquare(3.408223431367131d);
//        try {
//            long long15 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 62 + "'", int4 == 62);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 14.450443045431317d + "'", double7 == 14.450443045431317d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.20370439289755812d + "'", double13 == 0.20370439289755812d);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9849051783319762d, 359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004243366843189796d + "'", double2 == 0.004243366843189796d);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.sample();
//        try {
//            double double7 = normalDistributionImpl2.cumulativeProbability(4.64158883361278d, (-4.9213767696831185d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-25.875144705375302d) + "'", double3 == (-25.875144705375302d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 143.48130677791357d + "'", double4 == 143.48130677791357d);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9999999986051742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735860332522d + "'", double1 == 0.8813735860332522d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.4430227202923068d, 20.55392963742268d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999998927765d + "'", double2 == 0.9999999998927765d);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, localizable14, objArray19);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable14, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator25);
//        int int29 = randomDataImpl26.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str31 = randomDataImpl26.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { randomDataImpl26 };
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable24, objArray32);
//        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException33.getGeneralPattern();
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable39, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 184.51869951185168d, number44, false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray53 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable50, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray53);
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("8a5edff846", objArray53);
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable42, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray53);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable14, objArray53);
//        java.lang.String str60 = numberIsTooLargeException3.toString();
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57 + "'", int29 == 57);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "7b9cb371cf" + "'", str31.equals("7b9cb371cf"));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNull(localizable35);
//        org.junit.Assert.assertNotNull(localizable42);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (-0.509)" + "'", str60.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (-0.509)"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 109.32017583294417d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray5 = maxIterationsExceededException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "16d2ed3c8e61592e641e9df41be551be16f39e", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number8 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0d + "'", number8.equals(10.0d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) '4', (-0.5772156677920679d), (double) 53, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5772156649015329d, (double) 75, 0.8813735860332522d, 56);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 89);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 81);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 81 + "'", int1 == 81);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948963d + "'", double1 == 1.5707963267948963d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double12 = randomDataImpl1.nextCauchy(1.6245197929597313d, (double) 32.0f);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.65622560668708d + "'", double9 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-28.843873837893746d) + "'", double12 == (-28.843873837893746d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double15 = randomDataImpl1.nextF(0.7109327741638521d, (double) 93);
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution16 = null;
        try {
            double double17 = randomDataImpl1.nextInversionDeviate(continuousDistribution16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.04568105053249237d + "'", double15 == 0.04568105053249237d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.569750334265312d, (double) 6, 9);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        try {
//            long long8 = randomDataImpl1.nextSecureLong((long) (byte) 1, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator3 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator3);
//        int int7 = randomDataImpl4.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str9 = randomDataImpl4.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray10 = new java.lang.Object[] { randomDataImpl4 };
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
//        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException11.getGeneralPattern();
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Object[] objArray18 = null;
//        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray18);
//        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException16.getGeneralPattern();
//        java.lang.Number number22 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 184.51869951185168d, number22, false);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable28, objArray31);
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray31);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("8a5edff846", objArray31);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11, localizable20, objArray31);
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable20, objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("aef1fc59db", objArray36);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 79 + "'", int7 == 79);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8728b0ad69" + "'", str9.equals("8728b0ad69"));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNull(localizable13);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray36);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NaN, (double) 100L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9442157056960553d + "'", double1 == 0.9442157056960553d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.532599493153256d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.710657776180059d + "'", double1 == 1.710657776180059d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.255561438896672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.255561438896672d + "'", double1 == 3.255561438896672d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.21837291455813004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0239382666551615d + "'", double1 == 1.0239382666551615d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7320508075688772d + "'", double1 == 1.7320508075688772d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 66, 3.1175745404058084E27d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1175745404058084E27d + "'", double2 == 3.1175745404058084E27d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5091543890434437d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.7320508075688772d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.178979876918484E23d + "'", double2 == 7.178979876918484E23d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int1 = org.apache.commons.math.util.FastMath.abs(91);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 91 + "'", int1 == 91);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        try {
//            double double19 = randomDataImpl1.nextExponential((-1.5707963267948966d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.571 is smaller than, or equal to, the minimum (0): mean (-1.571)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8b8bd97a01" + "'", str6.equals("8b8bd97a01"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.5266764320822119d) + "'", double9 == (-0.5266764320822119d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5b360122bb038e33287842bd9305f0250cab7e17c06ee4cdecda" + "'", str14.equals("5b360122bb038e33287842bd9305f0250cab7e17c06ee4cdecda"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.308072265392898d + "'", double17 == 4.308072265392898d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.027415567780803774d) + "'", double1 == (-0.027415567780803774d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int2 = org.apache.commons.math.util.FastMath.min(43, 83);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 81);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.087558229106764d + "'", double1 == 5.087558229106764d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.apache.commons.math.util.FastMath.abs(14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int2 = org.apache.commons.math.util.FastMath.min(58, 69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58 + "'", int2 == 58);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        java.lang.String str7 = randomDataImpl1.nextHexString(64);
        try {
            int int10 = randomDataImpl1.nextPascal(71, 1.5001586541738241E84d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1,500,158,654,173,824,100,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e6" + "'", str7.equals("33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e6"));
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        boolean boolean23 = numberIsTooSmallException22.getBoundIsAllowed();
//        java.lang.Number number24 = numberIsTooSmallException22.getArgument();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12a23fd5a4" + "'", str15.equals("12a23fd5a4"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertEquals((double) number24, Double.NaN, 0);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("5ba2364d8b", objArray1);
        java.lang.String str3 = mathException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5ba2364d8b" + "'", str3.equals("5ba2364d8b"));
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt(100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) -1, (double) 38, (double) 0, 66);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.046745412134694E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.30685281944005d + "'", double1 == 50.30685281944005d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2L, 0.21837291455813004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.6231562043547265d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9008022248538402d, (java.lang.Number) 1.6449340668481562d, number4);
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = null;
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
//        java.lang.Number number15 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
//        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
//        java.lang.Number number19 = numberIsTooLargeException17.getMax();
//        java.lang.Number number20 = numberIsTooLargeException17.getMax();
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException24.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator30 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator30);
//        int int34 = randomDataImpl31.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str36 = randomDataImpl31.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { randomDataImpl31 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable29, objArray37);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable28, objArray37);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("hi!", objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        java.lang.Object[] objArray53 = null;
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51, localizable52, objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException51.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator57 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator57);
//        int int61 = randomDataImpl58.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str63 = randomDataImpl58.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { randomDataImpl58 };
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable56, objArray64);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable55, objArray64);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number72 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) (short) 100, number72, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray80 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable55, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable28, objArray80);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray80);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "d2c4b11e1429f6b38e87912cff6de16653b66f", objArray80);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 88 + "'", int34 == 88);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1bc6b22011" + "'", str36.equals("1bc6b22011"));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(localizable55);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 88 + "'", int61 == 88);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "5e30dd1fa1" + "'", str63.equals("5e30dd1fa1"));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray80);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-21.72848263158244d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1244.9503500129863d) + "'", double1 == (-1244.9503500129863d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.532599493153256d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4970909989451633E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02464616772939129d + "'", double1 == 0.02464616772939129d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.8665064475770338d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.779584931742134d) + "'", double1 == (-0.779584931742134d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 55);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 55.0f + "'", float1 == 55.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 40.89926471991978d, (java.lang.Number) 2.220446049250313E-16d, false);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        try {
//            double double12 = randomDataImpl1.nextGaussian((-30.187444569334364d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8c11a501ab" + "'", str6.equals("8c11a501ab"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.2323720925767485d) + "'", double9 == (-0.2323720925767485d));
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35);
//        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 80 + "'", int6 == 80);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "c8d7b8a628" + "'", str8.equals("c8d7b8a628"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(throwableArray37);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.889030319346946E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4023066454805946d + "'", double1 == 3.4023066454805946d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException7.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        randomDataImpl1.reSeed((long) 43);
        int int10 = randomDataImpl1.nextPascal(34, 0.999999999524131d);
        try {
            randomDataImpl1.setSecureAlgorithm("", "3b05043edc");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 3b05043edc");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) -1, 3.028368902863115d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        java.lang.Throwable[] throwableArray37 = maxIterationsExceededException36.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ac401520f1" + "'", str8.equals("ac401520f1"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(throwableArray37);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776928d + "'", double1 == 0.9999999958776928d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 75, (long) 69);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 75L + "'", long2 == 75L);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.String str31 = outOfRangeException30.toString();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1c5f184344" + "'", str15.equals("1c5f184344"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [-57.296, 1.623] range: hi!" + "'", str31.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [-57.296, 1.623] range: hi!"));
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        try {
//            int int20 = randomDataImpl1.nextBinomial(74, (double) 80);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 80 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2c5479fefb" + "'", str6.equals("2c5479fefb"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.2928456326834732d) + "'", double9 == (-0.2928456326834732d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5935142b2b3415c4d0a9933d6e2f7c07d5a1cb4da048fbf3df0e" + "'", str14.equals("5935142b2b3415c4d0a9933d6e2f7c07d5a1cb4da048fbf3df0e"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9971972595581778d + "'", double17 == 0.9971972595581778d);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.02464616772939129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6082506002555845d) + "'", double1 == (-1.6082506002555845d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5537374336724407d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.5091543890434437d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5091543890434436d) + "'", double1 == (-0.5091543890434436d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 86, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.4023066454805946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9385299322202547d + "'", double1 == 1.9385299322202547d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (float) 80);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (-48.21273601220948d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0821041362364843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7333789863465999d + "'", double1 == 0.7333789863465999d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 71L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2626798770413155d + "'", double1 == 4.2626798770413155d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(79);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable11, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException10.getGeneralPattern();
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 184.51869951185168d, number16, false);
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, localizable14, objArray19);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable14, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator25);
//        int int29 = randomDataImpl26.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str31 = randomDataImpl26.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { randomDataImpl26 };
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable24, objArray32);
//        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException33.getGeneralPattern();
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable39, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException38.getGeneralPattern();
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 184.51869951185168d, number44, false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray53 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable50, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray53);
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("8a5edff846", objArray53);
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable42, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray53);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable14, objArray53);
//        boolean boolean60 = numberIsTooLargeException3.getBoundIsAllowed();
//        org.junit.Assert.assertNotNull(localizable14);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 82 + "'", int29 == 82);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "c11bd5c6d0" + "'", str31.equals("c11bd5c6d0"));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNull(localizable35);
//        org.junit.Assert.assertNotNull(localizable42);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.atanh(49.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.2898889703334897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28203261776953986d + "'", double1 == 0.28203261776953986d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        java.lang.String str3 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str3.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextUniform(0.5403023058681398d, (double) 32);
//        java.lang.String str10 = randomDataImpl1.nextHexString(81);
//        try {
//            randomDataImpl1.setSecureAlgorithm("8728b0ad69", "f863960b923d8bce846791679ea6b3b6a88e38");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f863960b923d8bce846791679ea6b3b6a88e38");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "700df543d0c776ba593bdd49d14af33d26659d" + "'", str3.equals("700df543d0c776ba593bdd49d14af33d26659d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 26.6820527352413d + "'", double8 == 26.6820527352413d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "796133492cf2143fdddcdafb958f88c637708381012ccaec8e4191d840077d395472bed9b16e0b0b6" + "'", str10.equals("796133492cf2143fdddcdafb958f88c637708381012ccaec8e4191d840077d395472bed9b16e0b0b6"));
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9999999980706751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735856553042d + "'", double1 == 0.8813735856553042d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1.0f, 1.0821041362364843d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.6245197929597313d, (java.lang.Number) 62, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 62 + "'", number4.equals(62));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 62 + "'", number5.equals(62));
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeed((long) 15);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0331a339feb6f9cb6bee6194d2ce0cbb22b6e1" + "'", str3.equals("0331a339feb6f9cb6bee6194d2ce0cbb22b6e1"));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.569750334265312d, 5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9984929107204606d + "'", double2 == 0.9984929107204606d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.tanh(71.7372090208965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable5, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(10, "33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e6", objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5184364492350668d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 36, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.rint(40.89926471991978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 36.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430256902014756d + "'", double1 == 1.5430256902014756d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-199.42944730479053d), (-0.27319785117538253d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5721662231866866d) + "'", double2 == (-1.5721662231866866d));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        try {
//            int int13 = randomDataImpl1.nextHypergeometric(80, (int) (short) 100, 9);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (80): number of successes (100) must be less than or equal to population size (80)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76 + "'", int4 == 76);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "f9fe0e8b67" + "'", str6.equals("f9fe0e8b67"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.18417340947616723d) + "'", double9 == (-0.18417340947616723d));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 73);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 73.0f + "'", float2 == 73.0f);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextUniform(0.5403023058681398d, (double) 32);
//        java.lang.String str10 = randomDataImpl1.nextHexString(81);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5921e01965da0967292f0a66c40f243ff11388" + "'", str3.equals("5921e01965da0967292f0a66c40f243ff11388"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.307139146118315d + "'", double8 == 7.307139146118315d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "cd9fa79ad166389508ff31122095778afb71bceec01c4a7f9a0447bfa5be7fb1c8137518833d8cd93" + "'", str10.equals("cd9fa79ad166389508ff31122095778afb71bceec01c4a7f9a0447bfa5be7fb1c8137518833d8cd93"));
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int1 = org.apache.commons.math.util.FastMath.abs(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        try {
            randomDataImpl1.setSecureAlgorithm("f90da64e16", "5e877c2262c3c344e8217e1c0e54b35aba5d54");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5e877c2262c3c344e8217e1c0e54b35aba5d54");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextCauchy((double) 4, (double) 6);
//        try {
//            double double11 = randomDataImpl1.nextF((-0.5537374336724407d), 71.7372090208965d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.554 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.554)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ae00b11e2ed1dde8fe4255cb2ad14c04d19858" + "'", str3.equals("ae00b11e2ed1dde8fe4255cb2ad14c04d19858"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.1184715648827215d + "'", double8 == 4.1184715648827215d);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.388515662649224d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 99.0f + "'", float1 == 99.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(32.38316732970439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 79.41648300231553d + "'", double1 == 79.41648300231553d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 73, (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999999998927765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292518071893d + "'", double1 == 0.017453292518071893d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(46);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5409943226533644d + "'", double1 == 3.5409943226533644d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 35L, 1.4970909989451633E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000532282123809d + "'", double2 == 1.0000532282123809d);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable15, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException14.getGeneralPattern();
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 184.51869951185168d, number20, false);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray29);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("8a5edff846", objArray29);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable18, objArray29);
//        try {
//            java.lang.String str34 = convergenceException9.getPattern();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 75 + "'", int5 == 75);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "d01dcf3319" + "'", str7.equals("d01dcf3319"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable18);
//        org.junit.Assert.assertNotNull(objArray29);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-52.60498160271667d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-52.0d) + "'", double1 == (-52.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.ceil(50.30685281944005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "bc3c96e5d413f56260102db640e332819d40e9");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: bc3c96e5d413f56260102db640e332819d40e9");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.664957190225795d + "'", double7 == 10.664957190225795d);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int2 = org.apache.commons.math.util.FastMath.max(54, 55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 1, (double) 8L, (-0.5091543890434437d), 87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 8 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 33, (java.lang.Number) 2.439487336882789d, false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8813735856553042d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 300.2209486470141d + "'", double1 == 300.2209486470141d);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        double double11 = randomDataImpl1.nextGamma(109.33371740441963d, 0.02464616772939129d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.6773892640898347d + "'", double11 == 2.6773892640898347d);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.964993995359989d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        try {
//            int int16 = randomDataImpl1.nextPascal(99, 100.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7cd2d36c585b1d504e241128afd903b0a6587e" + "'", str3.equals("7cd2d36c585b1d504e241128afd903b0a6587e"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999984954597d + "'", double11 == 0.9999999984954597d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.555036009711566d + "'", double13 == 0.555036009711566d);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 76);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 76.0f + "'", float1 == 76.0f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35L, (double) 85);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3906070436976868d + "'", double2 == 0.3906070436976868d);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int int24 = randomDataImpl1.nextHypergeometric((int) ' ', 10, 53);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 53 is larger than the maximum (32): sample size (53) must be less than or equal to population size (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "625f8c6cd8e7958bcd48e8319b43f94df17c72" + "'", str3.equals("625f8c6cd8e7958bcd48e8319b43f94df17c72"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 72.15442115998428d + "'", double15 == 72.15442115998428d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 71.46284142674504d + "'", double20 == 71.46284142674504d);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.626065009182742d + "'", double1 == 4.626065009182742d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9912260756924949d + "'", double1 == 1.9912260756924949d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.log1p(25.00962318159671d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2584665919121987d + "'", double1 == 3.2584665919121987d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.42920367320510344d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 12.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.21837291455813004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22011263916635174d + "'", double1 == 0.22011263916635174d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 73.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6767719568873076d) + "'", double1 == (-0.6767719568873076d));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5707963267948966d, (double) 10.0f, 184.51869951185168d);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4152a87324532f24d733dda256921cf660d2a5" + "'", str3.equals("4152a87324532f24d733dda256921cf660d2a5"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.2218684750409692d + "'", double13 == 1.2218684750409692d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "d33ecc966d3eca9ce975b9094cac63c6e6210ea47ad3ce948f1b62ee4bb1e0be7deb8c945c9fd5ffd277b290f83de5f24f1a" + "'", str15.equals("d33ecc966d3eca9ce975b9094cac63c6e6210ea47ad3ce948f1b62ee4bb1e0be7deb8c945c9fd5ffd277b290f83de5f24f1a"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-3.4292036732051034d) + "'", double20 == (-3.4292036732051034d));
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Object[] objArray6 = outOfRangeException5.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(15, "ac401520f1", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double2 = org.apache.commons.math.util.FastMath.max(90.00508564644407d, 1.912539149877874d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.00508564644407d + "'", double2 == 90.00508564644407d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        java.lang.Number number37 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException34.getGeneralPattern();
        java.lang.Number number39 = numberIsTooLargeException34.getArgument();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 3.948148009134E13d + "'", number37.equals(3.948148009134E13d));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 71 + "'", number39.equals(71));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        java.lang.String str22 = notStrictlyPositiveException20.toString();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 19.49251276164419d, number25, true);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int2 = org.apache.commons.math.util.FastMath.min(82, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9008022248538402d, (java.lang.Number) 1.6449340668481562d, number4);
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = null;
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
//        java.lang.Number number15 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
//        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
//        java.lang.Number number19 = numberIsTooLargeException17.getMax();
//        java.lang.Number number20 = numberIsTooLargeException17.getMax();
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24, localizable25, objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException24.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator30 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator30);
//        int int34 = randomDataImpl31.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str36 = randomDataImpl31.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { randomDataImpl31 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable29, objArray37);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable28, objArray37);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("hi!", objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        java.lang.Object[] objArray53 = null;
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51, localizable52, objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException51.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator57 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator57);
//        int int61 = randomDataImpl58.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str63 = randomDataImpl58.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { randomDataImpl58 };
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable56, objArray64);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable55, objArray64);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number72 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) (short) 100, number72, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray80 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable55, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable28, objArray80);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray80);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException(35, "b4a17c5635e5cb292bbb82a573b2fdade4b661f313c369e7c15e5c5d3587ff355c0e405d3dcd0396d147893abf754450ecb0", objArray80);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 90 + "'", int34 == 90);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "53e52de1fa" + "'", str36.equals("53e52de1fa"));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(localizable55);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 90 + "'", int61 == 90);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "9113e400d4" + "'", str63.equals("9113e400d4"));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray80);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.sinh(17.375006705823953d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7572742277801137E7d + "'", double1 == 1.7572742277801137E7d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-58.79790177908768d), (double) 1L);
        normalDistributionImpl2.reseedRandomGenerator(0L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 39);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 39L + "'", long1 == 39L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.559807758112163d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.sin(184.51869951185168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7414757232563353d + "'", double1 == 0.7414757232563353d);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed((long) (short) 0);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (-0.509)", "7cf31f5f4564103dd8c7491798fb593b72be7e242e116bdfb2b8");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 7cf31f5f4564103dd8c7491798fb593b72be7e242e116bdfb2b8");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9307398e153ebec467cf05d7ac21b10c099f49" + "'", str3.equals("9307398e153ebec467cf05d7ac21b10c099f49"));
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 75, (long) 56);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56L + "'", long2 == 56L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray26);
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable10, objArray26);
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29);
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable34, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException33.getGeneralPattern();
//        java.lang.Number number39 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 184.51869951185168d, number39, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 0.04457085352364287d);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 84, (java.lang.Number) (byte) -1, true);
//        java.lang.Object[] objArray57 = null;
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("hi!", objArray57);
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Object[] objArray60 = null;
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58, localizable59, objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = convergenceException58.getGeneralPattern();
//        java.lang.Number number64 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable62, (java.lang.Number) 184.51869951185168d, number64, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        java.lang.Number number75 = outOfRangeException74.getLo();
//        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException74);
//        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 72, (java.lang.Number) 0.4430227202923068d, (java.lang.Number) 86);
//        java.lang.Number number82 = outOfRangeException81.getLo();
//        org.apache.commons.math.exception.util.Localizable localizable83 = outOfRangeException81.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable87 = null;
//        java.lang.Object[] objArray90 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable87, objArray90);
//        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray90);
//        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray90);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException77, localizable83, objArray90);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30, localizable37, objArray90);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35 + "'", int23 == 35);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "45717c8e18" + "'", str25.equals("45717c8e18"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(localizable37);
//        org.junit.Assert.assertNotNull(localizable62);
//        org.junit.Assert.assertTrue("'" + number75 + "' != '" + (-1L) + "'", number75.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + number82 + "' != '" + 0.4430227202923068d + "'", number82.equals(0.4430227202923068d));
//        org.junit.Assert.assertTrue("'" + localizable83 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable83.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray90);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        double double14 = randomDataImpl1.nextGaussian(0.04457085352364287d, 0.6931471805599453d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 205.3970014670717d + "'", double7 == 205.3970014670717d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.9073446364822424d + "'", double11 == 1.9073446364822424d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.8637974810191136d) + "'", double14 == (-0.8637974810191136d));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.906241428376445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7713111955699076d + "'", double1 == 0.7713111955699076d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 83);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1128637547917594E36d + "'", double1 == 1.1128637547917594E36d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 85, 56L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56L + "'", long2 == 56L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 78);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.0d + "'", double1 == 78.0d);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextBeta(41.0d, (double) 91);
//        long long14 = randomDataImpl1.nextSecureLong((long) 15, (long) 'a');
//        try {
//            int int17 = randomDataImpl1.nextBinomial(76, 1.5060973145850306E35d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 150,609,731,458,503,060,000,000,000,000,000,000 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "877940c9bedc9447ad92c26fd0613907343638" + "'", str3.equals("877940c9bedc9447ad92c26fd0613907343638"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33370408350622244d + "'", double11 == 0.33370408350622244d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 70L + "'", long14 == 70L);
//    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeed(90L);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt(52, 46);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (46): lower bound (52) must be strictly less than upper bound (46)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "412fca2114" + "'", str6.equals("412fca2114"));
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextBeta(41.0d, (double) 91);
//        long long14 = randomDataImpl1.nextLong(8L, 71L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "28d35ec99e6237eee343bd96aeb5d30615273d" + "'", str3.equals("28d35ec99e6237eee343bd96aeb5d30615273d"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33370408350622244d + "'", double11 == 0.33370408350622244d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray4 = normalDistributionImpl2.sample(86);
        double double7 = normalDistributionImpl2.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        try {
            double double9 = normalDistributionImpl2.inverseCumulativeProbability((double) 15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 15 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004482403217643316d + "'", double7 == 0.004482403217643316d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(19.49251276164419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.83904140382365d + "'", double1 == 37.83904140382365d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.6245197929597313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10924476704461128d) + "'", double1 == (-0.10924476704461128d));
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator3 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator3);
//        int int7 = randomDataImpl4.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str9 = randomDataImpl4.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray10 = new java.lang.Object[] { randomDataImpl4 };
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray10);
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray10);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ee2996d2a9" + "'", str9.equals("ee2996d2a9"));
//        org.junit.Assert.assertNotNull(objArray10);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.028983478471571338d + "'", double1 == 0.028983478471571338d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 9.568889950538255d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(110.92149382902565d, 0.0d, 3.4657359027997265d, 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int2 = org.apache.commons.math.util.FastMath.min(75, 71);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.344864515413418E-21d, 104.044562495924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.3448645154134186E-21d + "'", double2 == 5.3448645154134186E-21d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.27319785117538253d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.847512111813257d + "'", double1 == 1.847512111813257d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 50);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1.5430806348152437d, true);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9008022248538402d, (java.lang.Number) 1.6449340668481562d, number8);
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("hi!", objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException13, localizable14, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException13.getGeneralPattern();
//        java.lang.Number number19 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 184.51869951185168d, number19, false);
//        boolean boolean22 = numberIsTooLargeException21.getBoundIsAllowed();
//        java.lang.Number number23 = numberIsTooLargeException21.getMax();
//        java.lang.Number number24 = numberIsTooLargeException21.getMax();
//        java.lang.Object[] objArray27 = null;
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("hi!", objArray27);
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        java.lang.Object[] objArray30 = null;
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable29, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException28.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator34 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator34);
//        int int38 = randomDataImpl35.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str40 = randomDataImpl35.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray41 = new java.lang.Object[] { randomDataImpl35 };
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable33, objArray41);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable32, objArray41);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray54 = null;
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("hi!", objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        java.lang.Object[] objArray57 = null;
//        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException55, localizable56, objArray57);
//        org.apache.commons.math.exception.util.Localizable localizable59 = convergenceException55.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable60 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator61 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl62 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator61);
//        int int65 = randomDataImpl62.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str67 = randomDataImpl62.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { randomDataImpl62 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable60, objArray68);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable59, objArray68);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number76 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable59, (java.lang.Number) (short) 100, number76, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable59, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray84 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable59, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException21, localizable32, objArray84);
//        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray84);
//        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException(localizable5, objArray84);
//        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "0d7e5823ac5ba6c78de7bdd446cf29ed2e16e0d28aec1e88d59025f690ddedda", objArray84);
//        org.junit.Assert.assertNotNull(localizable17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNotNull(localizable32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "038a356578" + "'", str40.equals("038a356578"));
//        org.junit.Assert.assertNotNull(objArray41);
//        org.junit.Assert.assertNotNull(localizable59);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 53 + "'", int65 == 53);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3eae14d444" + "'", str67.equals("3eae14d444"));
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray84);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.4023066454805946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.402306645480595d + "'", double1 == 3.402306645480595d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1.5430806348152437d, true);
        java.lang.Object[] objArray8 = numberIsTooLargeException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "aef1fc59db", objArray8);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
//        java.lang.Number number22 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number22);
//        java.lang.Object[] objArray25 = null;
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26, localizable27, objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException26.getGeneralPattern();
//        java.lang.Object[] objArray35 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26);
//        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException26.getGeneralPattern();
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("hi!", objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable42, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
//        java.lang.Object[] objArray50 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable52 = mathException51.getGeneralPattern();
//        java.lang.Number number53 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException(localizable52, number53, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
//        java.lang.Number number57 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, number57, (java.lang.Number) 88.0394601776806d, true);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(89);
//        java.lang.Throwable[] throwableArray63 = maxIterationsExceededException62.getSuppressed();
//        java.lang.Object[] objArray64 = maxIterationsExceededException62.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, objArray64);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable38, objArray64);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 45 + "'", int13 == 45);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "597e66959d" + "'", str15.equals("597e66959d"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(localizable30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(localizable38);
//        org.junit.Assert.assertNotNull(localizable45);
//        org.junit.Assert.assertNotNull(objArray50);
//        org.junit.Assert.assertNotNull(localizable52);
//        org.junit.Assert.assertNotNull(throwableArray63);
//        org.junit.Assert.assertNotNull(objArray64);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        try {
//            int int11 = randomDataImpl1.nextPascal(0, 0.7777935025554725d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "956a92aeed6b61ffe7449e139c7f0af3aa798f" + "'", str3.equals("956a92aeed6b61ffe7449e139c7f0af3aa798f"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        java.lang.Class<?> wildcardClass12 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 44 + "'", int4 == 44);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.010890490288595685d + "'", double7 == 0.010890490288595685d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.8034235338459954d + "'", double11 == 1.8034235338459954d);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(5.087558229106764d, 0.0d, (double) 68, 50);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        java.lang.Class<?> wildcardClass16 = randomDataImpl1.getClass();
//        try {
//            double double19 = randomDataImpl1.nextUniform((double) 65, 0.9999999998927765d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 65 is larger than, or equal to, the maximum (1): lower bound (65) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3ac13a7fd51918eb559997597c1191957e3aab" + "'", str3.equals("3ac13a7fd51918eb559997597c1191957e3aab"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.4136571316436333d) + "'", double13 == (-1.4136571316436333d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12022da969e04a8d0a96a19501ca6a5a9db7417d30d269873a0324a8771e3382a9e4dd04730d565d39ec3e7667020c9b17ad" + "'", str15.equals("12022da969e04a8d0a96a19501ca6a5a9db7417d30d269873a0324a8771e3382a9e4dd04730d565d39ec3e7667020c9b17ad"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        try {
            long long7 = randomDataImpl1.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray4 = normalDistributionImpl2.sample(86);
        double double7 = normalDistributionImpl2.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004482403217643316d + "'", double7 == 0.004482403217643316d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = org.apache.commons.math.util.FastMath.round(73.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 73 + "'", int1 == 73);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Number number31 = outOfRangeException30.getHi();
//        java.lang.Number number32 = outOfRangeException30.getArgument();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2818fbd699" + "'", str15.equals("2818fbd699"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.6231562043547265d + "'", number31.equals(1.6231562043547265d));
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 10L + "'", number32.equals(10L));
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException8.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 184.51869951185168d, number14, false);
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable12, objArray28);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "01aebf23a1bd1494344e821dcbc16458e4ec61", objArray28);
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "16e77a3008" + "'", str27.equals("16e77a3008"));
//        org.junit.Assert.assertNotNull(objArray28);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        double double15 = randomDataImpl1.nextWeibull(3.255561438896672d, 0.6643638388299197d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d15de189c6bbe1a80a7cc5f8740dcc5237414b" + "'", str3.equals("d15de189c6bbe1a80a7cc5f8740dcc5237414b"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 25.395008001580504d + "'", double9 == 25.395008001580504d);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.35657465508606395d + "'", double15 == 0.35657465508606395d);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10.440148832340114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.437128995686965d + "'", double1 == 2.437128995686965d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        try {
//            int int14 = randomDataImpl1.nextZipf(0, (double) 90);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 98 + "'", int4 == 98);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 218.13483021060426d + "'", double7 == 218.13483021060426d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.12307241136008365d + "'", double11 == 0.12307241136008365d);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double23 = randomDataImpl1.nextCauchy(0.9442157056960553d, 5.087558229106764d);
//        double double25 = randomDataImpl1.nextChiSquare(4.2626798770413155d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution26 = null;
//        try {
//            double double27 = randomDataImpl1.nextInversionDeviate(continuousDistribution26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b272a17582941336e670f1ad68ffa0b0c5b0e3" + "'", str3.equals("b272a17582941336e670f1ad68ffa0b0c5b0e3"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-162.06354237474088d) + "'", double15 == (-162.06354237474088d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.764739451615467d + "'", double20 == 8.764739451615467d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 29.740169051026015d + "'", double23 == 29.740169051026015d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.217324411535707d + "'", double25 == 4.217324411535707d);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        double double8 = randomDataImpl1.nextCauchy(1.0E-9d, (double) 52L);
        randomDataImpl1.reSeedSecure();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-46.15206278612473d) + "'", double8 == (-46.15206278612473d));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        double double12 = randomDataImpl1.nextGaussian(1.5707963267948963d, 0.011366898564937883d);
//        try {
//            int int15 = randomDataImpl1.nextBinomial(70, (double) 88);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 88 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "45884c7a2c9ca1c34ad550cc38fbd0d1bec5d7" + "'", str3.equals("45884c7a2c9ca1c34ad550cc38fbd0d1bec5d7"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 70.92244314486827d + "'", double9 == 70.92244314486827d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.590793188035937d + "'", double12 == 1.590793188035937d);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int2 = org.apache.commons.math.util.FastMath.max(62, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6231562043547265d, (double) 74);
    }
}

