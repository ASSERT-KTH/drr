import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.Object[] objArray21 = notStrictlyPositiveException20.getArguments();
        java.lang.Number number22 = notStrictlyPositiveException20.getMin();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0 + "'", number22.equals(0));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.92228024511367E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-52022.128284203376d) + "'", double1 == (-52022.128284203376d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 84);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.430816798843313d + "'", double1 == 4.430816798843313d);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl1.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31294ab27ff764217e4225c726a79c982fdffd" + "'", str3.equals("31294ab27ff764217e4225c726a79c982fdffd"));
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test005");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable15, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException14.getGeneralPattern();
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 184.51869951185168d, number20, false);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray29);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("8a5edff846", objArray29);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable18, objArray29);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(89);
//        java.lang.Throwable[] throwableArray40 = maxIterationsExceededException39.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException36, "16d2ed3c8e61592e641e9df41be551be16f39e", (java.lang.Object[]) throwableArray40);
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "8d4f84d966", (java.lang.Object[]) throwableArray40);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 45 + "'", int5 == 45);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "19fa4adab7" + "'", str7.equals("19fa4adab7"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable18);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(throwableArray40);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.FastMath.pow((-28.507685362571795d), (-58.841552582931406d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        randomDataImpl1.reSeed((-1L));
        int int8 = randomDataImpl1.nextZipf(66, 9.889030319346946E42d);
        try {
            java.lang.String str10 = randomDataImpl1.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(90.0d, (double) 45, (-74.54217797518403d), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (6) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass6 = randomDataImpl1.getClass();
//        double double9 = randomDataImpl1.nextF(0.02464616772939129d, (double) 71);
//        try {
//            double double12 = randomDataImpl1.nextGaussian((-10.49289906896897d), (-1.4483771956262554d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.448 is smaller than, or equal to, the minimum (0): standard deviation (-1.448)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5ff1914683613e2a1a2a179a896dec7163936718de2ff71496265b3d844e3ce76bbbbc87eba94f9450fdebfa2bb0b30f98e6" + "'", str5.equals("5ff1914683613e2a1a2a179a896dec7163936718de2ff71496265b3d844e3ce76bbbbc87eba94f9450fdebfa2bb0b30f98e6"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test010");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        double double13 = randomDataImpl1.nextT(79.41648300231553d);
//        double double15 = randomDataImpl1.nextExponential((double) 99);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5086815698671792d + "'", double13 == 0.5086815698671792d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.39618376965848d + "'", double15 == 35.39618376965848d);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        try {
            int int13 = randomDataImpl1.nextHypergeometric(5, 78, 24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 78 is larger than the maximum (5): number of successes (78) must be less than or equal to population size (5)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.65622560668708d + "'", double9 == 54.65622560668708d);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator3 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator3);
//        int int7 = randomDataImpl4.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str9 = randomDataImpl4.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray10 = new java.lang.Object[] { randomDataImpl4 };
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray10);
//        java.lang.Object[] objArray13 = convergenceException12.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("4b94a28651eef283957c32092c148307a2fb06", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException14.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 40 + "'", int7 == 40);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "c910918f29" + "'", str9.equals("c910918f29"));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNull(localizable15);
//        org.junit.Assert.assertNull(localizable16);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.9126063361940036d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6116859550637399d + "'", double1 == 0.6116859550637399d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.0d + "'", double1 == 50.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.07520395772047966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double5 = normalDistributionImpl2.cumulativeProbability((double) 0L, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6931471805599453d + "'", double6 == 0.6931471805599453d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 45);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.708203932499369d + "'", double1 == 6.708203932499369d);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextUniform(0.5403023058681398d, (double) 32);
//        java.lang.String str10 = randomDataImpl1.nextHexString(81);
//        int int13 = randomDataImpl1.nextPascal(78, 0.9999999982611434d);
//        long long16 = randomDataImpl1.nextSecureLong((long) 57, (long) 73);
//        randomDataImpl1.reSeed(17L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fda84ba3242ad714fc51f2a9cb341182259977" + "'", str3.equals("fda84ba3242ad714fc51f2a9cb341182259977"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 31.337070083746486d + "'", double8 == 31.337070083746486d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "66c0d966165ffe5d31f1c162178195f11c224ffe1fd29acae8a6c675d84a73a66174bac04bbe35c4a" + "'", str10.equals("66c0d966165ffe5d31f1c162178195f11c224ffe1fd29acae8a6c675d84a73a66174bac04bbe35c4a"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 72L + "'", long16 == 72L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.035591508433712726d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03496557859900351d) + "'", double1 == (-0.03496557859900351d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double2 = org.apache.commons.math.util.FastMath.max((-52.8111259808847d), 3.255561438896672d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.255561438896672d + "'", double2 == 3.255561438896672d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.2280277712303863d), 35.39618376965848d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.39618376965848d + "'", double2 == 35.39618376965848d);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.9999999982611434d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 81.1740506971103d + "'", double7 == 81.1740506971103d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5791657598431282d + "'", double11 == 0.5791657598431282d);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString(64);
//        try {
//            int int10 = randomDataImpl1.nextZipf(0, 1.710657776180059d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f289b0a7aa72bf43359b4091721932f289da09" + "'", str3.equals("f289b0a7aa72bf43359b4091721932f289da09"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4d98e71346ea8b6c3f823199de27b6b97697a20a2b3600fc51caf29e22bd91a0" + "'", str7.equals("4d98e71346ea8b6c3f823199de27b6b97697a20a2b3600fc51caf29e22bd91a0"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9999909969324263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999909969324263d + "'", double1 == 0.9999909969324263d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double2 = org.apache.commons.math.util.FastMath.max(0.6116859550637399d, 166.98999838850764d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 166.98999838850764d + "'", double2 == 166.98999838850764d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 88.0394601776806d, (java.lang.Number) 9, false);
//        maxIterationsExceededException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
//        java.lang.Object[] objArray24 = maxIterationsExceededException18.getArguments();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5b3315accd" + "'", str15.equals("5b3315accd"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray24);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double2 = org.apache.commons.math.util.FastMath.max(3.402306645480595d, 165.90272130952587d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 165.90272130952587d + "'", double2 == 165.90272130952587d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 32L, (-47.47466291813209d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.21837291455813004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 76.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.343805421853684d + "'", double1 == 4.343805421853684d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        double double8 = randomDataImpl1.nextCauchy(0.0d, (double) 50);
        double double10 = randomDataImpl1.nextT((double) 75L);
        java.lang.String str12 = randomDataImpl1.nextHexString(10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1296.4656934408517d) + "'", double8 == (-1296.4656934408517d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.4198009461373254d + "'", double10 == 0.4198009461373254d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1a331bea8c" + "'", str12.equals("1a331bea8c"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.2584665919121987d, 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.09488667378125E28d + "'", double2 == 1.09488667378125E28d);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double23 = randomDataImpl1.nextCauchy(0.9442157056960553d, 5.087558229106764d);
//        randomDataImpl1.reSeedSecure(66L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bffcacef4a27c3c53f96165e845f684fe9c427" + "'", str3.equals("bffcacef4a27c3c53f96165e845f684fe9c427"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-6.711781926564451d) + "'", double15 == (-6.711781926564451d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 19.560486072671047d + "'", double20 == 19.560486072671047d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-2.135222784470863d) + "'", double23 == (-2.135222784470863d));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int1 = org.apache.commons.math.util.FastMath.abs(81);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 81 + "'", int1 == 81);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 77, (long) 49);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 77L + "'", long2 == 77L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0024898063107158083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0024898063107158088d + "'", double1 == 0.0024898063107158088d);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test038");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = maxIterationsExceededException36.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException36.getGeneralPattern();
//        java.lang.Throwable[] throwableArray40 = maxIterationsExceededException36.getSuppressed();
//        int int41 = maxIterationsExceededException36.getMaxIterations();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 61 + "'", int6 == 61);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "161f169b11" + "'", str8.equals("161f169b11"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNull(localizable38);
//        org.junit.Assert.assertNotNull(localizable39);
//        org.junit.Assert.assertNotNull(throwableArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("5ba2364d8b", objArray1);
        java.lang.Throwable[] throwableArray3 = mathException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray4 = maxIterationsExceededException3.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(29, "1c5b8a29d5671711c50214d97bca305642c4fd", (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test041");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        double double15 = randomDataImpl1.nextGamma(1.5184364492350668d, 0.7476520016703659d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3c0b200cea" + "'", str6.equals("3c0b200cea"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.6025253314559361d) + "'", double9 == (-0.6025253314559361d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14 + "'", int12 == 14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.844770118570841d + "'", double15 == 0.844770118570841d);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 92);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 92.0f + "'", float1 == 92.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double14 = normalDistributionImpl6.cumulativeProbability((-0.3698875242387616d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.4983419848583182d + "'", double14 == 0.4983419848583182d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 55L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3151.2678732195277d + "'", double1 == 3151.2678732195277d);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test045");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int int12 = randomDataImpl1.nextInt(67, 71);
//        int int15 = randomDataImpl1.nextPascal(66, 0.006284222479158936d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "61b6eff5b582a453bb2ff715d575829d3f8a35" + "'", str3.equals("61b6eff5b582a453bb2ff715d575829d3f8a35"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 24.691739769689935d + "'", double9 == 24.691739769689935d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 71 + "'", int12 == 71);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12239 + "'", int15 == 12239);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-27.990912426753106d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.990912426753102d) + "'", double1 == (-27.990912426753102d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number9 = outOfRangeException8.getHi();
        org.apache.commons.math.exception.util.Localizable localizable10 = outOfRangeException8.getGeneralPattern();
        java.lang.Object[] objArray11 = outOfRangeException8.getArguments();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("7b9cb371cf", objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(throwable2, "", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(81, "", objArray11);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10 + "'", number9.equals(10));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray35);
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = maxIterationsExceededException36.getSpecificPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException36.getGeneralPattern();
//        java.lang.Throwable throwable40 = null;
//        try {
//            maxIterationsExceededException36.addSuppressed(throwable40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2dcaf97fc9" + "'", str8.equals("2dcaf97fc9"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNull(localizable38);
//        org.junit.Assert.assertNotNull(localizable39);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 94L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.546835943776344d + "'", double1 == 4.546835943776344d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(6.467781082943182d, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test052");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double16 = normalDistributionImpl15.sample();
//        double double17 = normalDistributionImpl15.getMean();
//        double double18 = normalDistributionImpl15.getStandardDeviation();
//        double double19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double20 = normalDistributionImpl15.getMean();
//        double double21 = normalDistributionImpl15.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "01acc9fdfc" + "'", str6.equals("01acc9fdfc"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.067562357324772d) + "'", double9 == (-0.067562357324772d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14 + "'", int12 == 14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-4.623547916957355d) + "'", double16 == (-4.623547916957355d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 89.0d + "'", double18 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 137.82702065086616d + "'", double19 == 137.82702065086616d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 89.0d + "'", double21 == 89.0d);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        try {
            long long14 = randomDataImpl1.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 12239, 75L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12239L + "'", long2 == 12239L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        java.lang.Number number5 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 40.89926471991978d, (java.lang.Number) 3L, true);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray28);
//        java.lang.Object[] objArray31 = convergenceException30.getArguments();
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, localizable36, objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException35.getGeneralPattern();
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 184.51869951185168d, number41, false);
//        boolean boolean44 = numberIsTooLargeException43.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException43.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("hi!", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException49, localizable50, objArray51);
//        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException49.getGeneralPattern();
//        java.lang.Number number55 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 184.51869951185168d, number55, false);
//        boolean boolean58 = numberIsTooLargeException57.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooLargeException57.getGeneralPattern();
//        java.lang.Object[] objArray62 = null;
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("hi!", objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        java.lang.Object[] objArray65 = null;
//        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException63, localizable64, objArray65);
//        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException63.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable68 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator69 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator69);
//        int int73 = randomDataImpl70.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str75 = randomDataImpl70.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { randomDataImpl70 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable68, objArray76);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable67, objArray76);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable59, objArray76);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "7129b79c9874f86f179bc2c416604492209abe", objArray76);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException("fca9644a9161a7fadbf4b69a4fe6cbec3a54af", objArray76);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray76);
//        java.lang.Number number86 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 192.91580444921826d, (java.lang.Number) 1.0453007043318272d, number86);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 60 + "'", int25 == 60);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "d4e07e6b0c" + "'", str27.equals("d4e07e6b0c"));
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(localizable39);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable53);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable67);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 59 + "'", int73 == 59);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "b6fda01cd2" + "'", str75.equals("b6fda01cd2"));
//        org.junit.Assert.assertNotNull(objArray76);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        java.lang.String str22 = notStrictlyPositiveException20.toString();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException20.getArgument();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.04457085352364287d + "'", number24.equals(0.04457085352364287d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(Double.NaN);
        normalDistributionImpl0.reseedRandomGenerator((long) 97);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.special.Erf.erf(165.90272130952587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 68);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.912600815606924d + "'", double1 == 4.912600815606924d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.251752586176186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.504378490611614d + "'", double1 == 9.504378490611614d);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray16 = normalDistributionImpl14.sample(86);
//        double double19 = normalDistributionImpl14.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        java.lang.Class<?> wildcardClass20 = normalDistributionImpl14.getClass();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        long long23 = randomDataImpl1.nextPoisson(3.028368902863115d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator24);
//        double double28 = randomDataImpl25.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator29 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator29);
//        randomDataImpl30.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl35 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray37 = normalDistributionImpl35.sample(86);
//        double double40 = normalDistributionImpl35.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double41 = randomDataImpl30.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl35);
//        java.lang.Class<?> wildcardClass42 = normalDistributionImpl35.getClass();
//        double double44 = normalDistributionImpl35.cumulativeProbability(1.7453292519943295d);
//        double double46 = normalDistributionImpl35.density(1.5060973145850306E35d);
//        double[] doubleArray48 = normalDistributionImpl35.sample(58);
//        double double49 = normalDistributionImpl35.getMean();
//        double double50 = randomDataImpl25.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl35);
//        double double52 = normalDistributionImpl35.cumulativeProbability(1.6245197929597313d);
//        double double53 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl35);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 142.98342412840887d + "'", double7 == 142.98342412840887d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.007725019447540268d + "'", double11 == 0.007725019447540268d);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.004482403217643316d + "'", double19 == 0.004482403217643316d);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-65.61440113255685d) + "'", double21 == (-65.61440113255685d));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5L + "'", long23 == 5L);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-57.61805654996876d) + "'", double28 == (-57.61805654996876d));
//        org.junit.Assert.assertNotNull(doubleArray37);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.004482403217643316d + "'", double40 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 54.65622560668708d + "'", double41 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.5078229326523436d + "'", double44 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray48);
//        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-32.94786077449751d) + "'", double50 == (-32.94786077449751d));
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.5072815016278794d + "'", double52 == 0.5072815016278794d);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 6.185926138742939d + "'", double53 == 6.185926138742939d);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test063");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        java.lang.Number number27 = numberIsTooLargeException26.getMax();
//        java.lang.Number number28 = numberIsTooLargeException26.getMax();
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "e2c7cdf41b" + "'", str15.equals("e2c7cdf41b"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNull(number28);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 79L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49567753318135577d + "'", double1 == 0.49567753318135577d);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        java.lang.Throwable throwable0 = null;
//        java.lang.Object[] objArray3 = null;
//        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("hi!", objArray3);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        java.lang.Object[] objArray6 = null;
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, localizable5, objArray6);
//        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator10);
//        int int14 = randomDataImpl11.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str16 = randomDataImpl11.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { randomDataImpl11 };
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable9, objArray17);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable8, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable20 = maxIterationsExceededException19.getGeneralPattern();
//        java.lang.Number number23 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number23);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable28, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray33);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, localizable35, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException34.getGeneralPattern();
//        java.lang.Number number40 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 184.51869951185168d, number40, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        java.lang.Object[] objArray52 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable49, objArray52);
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray52);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable38, objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Object[] objArray62 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable59, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray62);
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("11de92706a1d0c521e193c236f3fadae1d584f", objArray62);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable31, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator70 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl71 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator70);
//        int int74 = randomDataImpl71.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str76 = randomDataImpl71.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray77 = new java.lang.Object[] { randomDataImpl71 };
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable69, objArray77);
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray77);
//        java.lang.Object[] objArray80 = convergenceException79.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("4b94a28651eef283957c32092c148307a2fb06", objArray80);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(throwable0, localizable31, objArray80);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 1.0821041362364843d, (java.lang.Number) 3.0d, false);
//        java.lang.String str87 = numberIsTooLargeException86.toString();
//        org.junit.Assert.assertNotNull(localizable8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "84d1030ce5" + "'", str16.equals("84d1030ce5"));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(localizable20);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(localizable38);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 53 + "'", int74 == 53);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "97080673c8" + "'", str76.equals("97080673c8"));
//        org.junit.Assert.assertNotNull(objArray77);
//        org.junit.Assert.assertNotNull(objArray80);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.082 is larger than, or equal to, the maximum (3): hi!" + "'", str87.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.082 is larger than, or equal to, the maximum (3): hi!"));
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator9);
//        int int13 = randomDataImpl10.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str15 = randomDataImpl10.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray16 = new java.lang.Object[] { randomDataImpl10 };
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray16);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable7, objArray16);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 100, number24, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Number number31 = outOfRangeException30.getHi();
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException30);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 75 + "'", int13 == 75);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "122f7cc1a7" + "'", str15.equals("122f7cc1a7"));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.6231562043547265d + "'", number31.equals(1.6231562043547265d));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int1 = org.apache.commons.math.util.FastMath.abs(50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test068");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeed((long) 15);
//        try {
//            double double7 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7d77ee20219d2de39ac5a830d24f1c8f7a6371" + "'", str3.equals("7d77ee20219d2de39ac5a830d24f1c8f7a6371"));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(22.311032971803535d, 11.548739357257746d);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double38 = normalDistributionImpl29.cumulativeProbability(0.6931471805599453d);
//        double double39 = normalDistributionImpl29.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "25245820e24c790b5c0f6522f0b0ab24092d83" + "'", str9.equals("25245820e24c790b5c0f6522f0b0ab24092d83"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9999999983865339d + "'", double17 == 0.9999999983865339d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 44.092375644028955d + "'", double21 == 44.092375644028955d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 130.65401750312674d + "'", double26 == 130.65401750312674d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-196.587225522613d) + "'", double35 == (-196.587225522613d));
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.5d + "'", double38 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 89.0d + "'", double39 == 89.0d);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.special.Gamma.digamma(5.087558229106764d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.525311653117012d + "'", double1 == 1.525311653117012d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-2.2935068423627687d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5676864740742957d) + "'", double1 == (-1.5676864740742957d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0232274785475504d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long1 = org.apache.commons.math.util.FastMath.round(1.089024395704929d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.0f, (java.lang.Number) (-1), (java.lang.Number) 1L);
        java.lang.Number number15 = outOfRangeException14.getHi();
        java.lang.Object[] objArray16 = outOfRangeException14.getArguments();
        java.lang.Number number17 = outOfRangeException14.getLo();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1) + "'", number17.equals((-1)));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.02464616772939129d, (java.lang.Number) 0.9999999958776927d, (java.lang.Number) 54.65622560668708d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        long long2 = org.apache.commons.math.util.FastMath.min(154L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(34);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        java.lang.Number number19 = outOfRangeException18.getLo();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextSecureInt((int) (byte) 0, 35);
//        double double9 = randomDataImpl1.nextWeibull((double) 71L, (double) 12.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getMean();
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8d7cac276dc3bccbf8df1157c72c870a4dea94" + "'", str3.equals("8d7cac276dc3bccbf8df1157c72c870a4dea94"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 17 + "'", int6 == 17);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.17322869961076d + "'", double9 == 12.17322869961076d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 39.03636123604855d + "'", double13 == 39.03636123604855d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 18.023793667578193d + "'", double15 == 18.023793667578193d);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 64);
//        java.lang.Number number77 = null;
//        java.lang.Number number78 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number77, number78, (java.lang.Number) 0.5772156649015329d);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException84 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 3.9982147270216544d, (java.lang.Number) 30.31139430797614d, true);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 76 + "'", int27 == 76);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "d88839353c" + "'", str29.equals("d88839353c"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 76 + "'", int54 == 76);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "345c99db29" + "'", str56.equals("345c99db29"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 99.99999999999999d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 5.906241428376445d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(49.65108724106803d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9999999988626886d, (double) 75.0f);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        randomDataImpl1.reSeedSecure((long) 60);
//        try {
//            int int17 = randomDataImpl1.nextZipf(0, (double) 63L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "05317c073685feadc396a5ec0e109e877ffb54" + "'", str3.equals("05317c073685feadc396a5ec0e109e877ffb54"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.48781773037098d + "'", double9 == 90.48781773037098d);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        randomDataImpl6.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray13 = normalDistributionImpl11.sample(86);
//        double double16 = normalDistributionImpl11.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double17 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.Class<?> wildcardClass18 = normalDistributionImpl11.getClass();
//        double double20 = normalDistributionImpl11.cumulativeProbability(1.7453292519943295d);
//        double double22 = normalDistributionImpl11.density(1.5060973145850306E35d);
//        double[] doubleArray24 = normalDistributionImpl11.sample(58);
//        double double25 = normalDistributionImpl11.getMean();
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double28 = normalDistributionImpl11.inverseCumulativeProbability((-11.429203673205103d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -11.429 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-57.2499494228359d) + "'", double4 == (-57.2499494228359d));
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.004482403217643316d + "'", double16 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 54.65622560668708d + "'", double17 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5078229326523436d + "'", double20 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-29.383711699627476d) + "'", double26 == (-29.383711699627476d));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.Object[] objArray2 = convergenceException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeedSecure(0L);
//        double double8 = randomDataImpl1.nextT(0.8117566297988853d);
//        try {
//            double double11 = randomDataImpl1.nextGamma(1.227487958250663d, (-14.674528640031419d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -14.675 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.37642378179595665d + "'", double8 == 0.37642378179595665d);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        randomDataImpl1.reSeed((long) (short) 100);
//        double double11 = randomDataImpl1.nextF(10.440148832340114d, (double) 54);
//        try {
//            long long14 = randomDataImpl1.nextLong((long) 47, (long) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 47 is larger than, or equal to, the maximum (35): lower bound (47) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5d84130775d6b185014be7f9efaf10f2f03242" + "'", str3.equals("5d84130775d6b185014be7f9efaf10f2f03242"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.2540338422616613d + "'", double11 == 1.2540338422616613d);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.6082506002555845d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7997623965374672d) + "'", double1 == (-0.7997623965374672d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test095");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        java.lang.Class<?> wildcardClass12 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed();
//        double double16 = randomDataImpl1.nextGaussian(3.0122718830244435d, 2005.3522829578812d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 76.3456789447272d + "'", double7 == 76.3456789447272d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.9526779078798124d + "'", double11 == 1.9526779078798124d);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1606.7729392481385d + "'", double16 == 1606.7729392481385d);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 5.087558229106764d, (java.lang.Number) 395.1575553230454d, false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 10, (java.lang.Number) 0.7799726475466374d, true);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, number35);
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException36);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable37);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.004482497532600368d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004482482521760211d + "'", double1 == 0.004482482521760211d);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test100");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        try {
//            int int9 = randomDataImpl1.nextSecureInt(65, 37);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 65 is larger than, or equal to, the maximum (37): lower bound (65) must be strictly less than upper bound (37)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        int int11 = randomDataImpl1.nextBinomial(83, 0.02464616772939129d);
//        long long14 = randomDataImpl1.nextLong(35L, (long) 90);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3f9c070c7e07496817ccc75a5f3cbce9aaa518" + "'", str3.equals("3f9c070c7e07496817ccc75a5f3cbce9aaa518"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 46L + "'", long14 == 46L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14, (java.lang.Number) (short) 100, (java.lang.Number) 66);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 66 + "'", number4.equals(66));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 56);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.483314773547883d + "'", double1 == 7.483314773547883d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 81);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 35, (java.lang.Number) (-11.429203673205103d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 71 + "'", int4 == 71);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 88.53155055368231d + "'", double7 == 88.53155055368231d);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-14.674528640031419d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.atan((-4.767325655951666d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3640328473124042d) + "'", double1 == (-1.3640328473124042d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(150.14867894829416d, (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.310661921121448E-83d + "'", double2 == 4.310661921121448E-83d);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double8 = randomDataImpl1.nextCauchy((double) 4, (double) 6);
//        int int11 = randomDataImpl1.nextBinomial(72, 0.569750334265312d);
//        java.lang.String str13 = randomDataImpl1.nextHexString(72);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31000a102555a454730630aeb4b4b3b86493c5" + "'", str3.equals("31000a102555a454730630aeb4b4b3b86493c5"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.511222774333378d + "'", double8 == 7.511222774333378d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 40 + "'", int11 == 40);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1f927d17c0cac10e7c8e0962ecc96777e9f4a8c1eb7f54ed421941de77fe6c40fca9998c" + "'", str13.equals("1f927d17c0cac10e7c8e0962ecc96777e9f4a8c1eb7f54ed421941de77fe6c40fca9998c"));
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        org.apache.commons.math.random.RandomGenerator randomGenerator6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator6);
//        java.lang.String str9 = randomDataImpl7.nextHexString(38);
//        randomDataImpl7.reSeedSecure((long) (byte) 0);
//        long long14 = randomDataImpl7.nextLong((long) 0, (long) (byte) 1);
//        double double17 = randomDataImpl7.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double21 = normalDistributionImpl20.sample();
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) 97);
//        normalDistributionImpl20.reseedRandomGenerator((long) 71);
//        double double26 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl29 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double32 = normalDistributionImpl29.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl29.reseedRandomGenerator((long) (byte) 1);
//        double double35 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        double double36 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl29);
//        long long39 = randomDataImpl1.nextSecureLong((long) 13, (long) 50);
//        try {
//            double double42 = randomDataImpl1.nextGamma((-0.067562357324772d), 409.3370843023706d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.068 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "404c190fc372675bbac0baa2999efd90650f9c" + "'", str9.equals("404c190fc372675bbac0baa2999efd90650f9c"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 49.53177202461927d + "'", double21 == 49.53177202461927d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8621186791753761d + "'", double23 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 44.41099426819297d + "'", double26 == 44.41099426819297d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 70.403958311372d + "'", double35 == 70.403958311372d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-199.42944730479053d) + "'", double36 == (-199.42944730479053d));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 45L + "'", long39 == 45L);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        double double13 = randomDataImpl1.nextT(79.41648300231553d);
//        java.lang.String str15 = randomDataImpl1.nextHexString(14);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int19 = randomDataImpl1.nextZipf((int) (byte) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.2906582429792337d + "'", double13 == 1.2906582429792337d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3f7acd50394fad" + "'", str15.equals("3f7acd50394fad"));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) (-56.47257550644328d));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.6245197929597313d, (java.lang.Number) 62, true);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        notStrictlyPositiveException5.addSuppressed((java.lang.Throwable) convergenceException11);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 62 + "'", number10.equals(62));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.8813730537283775d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-107.7947356682755d) + "'", double1 == (-107.7947356682755d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0462605282408842d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35897995258687543d + "'", double1 == 0.35897995258687543d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.atan((-78.09217997635302d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5579916471658746d) + "'", double1 == (-1.5579916471658746d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.asinh(49.67214941470917d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.598692891662723d + "'", double1 == 4.598692891662723d);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        int int17 = randomDataImpl1.nextSecureInt(72, 73);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "986d3745b6" + "'", str6.equals("986d3745b6"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.5828291306664254d) + "'", double9 == (-0.5828291306664254d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "f13e9804968352602724a2aac0e7d359f3c167211a6700a48198" + "'", str14.equals("f13e9804968352602724a2aac0e7d359f3c167211a6700a48198"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 73 + "'", int17 == 73);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test119");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        int int14 = randomDataImpl1.nextInt((int) ' ', 70);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double18 = normalDistributionImpl17.sample();
//        double double19 = normalDistributionImpl17.sample();
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 65 + "'", int4 == 65);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 26.434474371153215d + "'", double7 == 26.434474371153215d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 51 + "'", int14 == 51);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-13.96241396560753d) + "'", double18 == (-13.96241396560753d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 158.6578006505844d + "'", double19 == 158.6578006505844d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-114.92980448055071d) + "'", double20 == (-114.92980448055071d));
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double26 = normalDistributionImpl23.cumulativeProbability((double) 0L, 0.0d);
//        normalDistributionImpl23.reseedRandomGenerator((long) (byte) 1);
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        int int32 = randomDataImpl1.nextZipf(52, 1.5060973145850306E35d);
//        randomDataImpl1.reSeed(18L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fb1fe5fb40b3db60ab2e1700e67ea754e67835" + "'", str3.equals("fb1fe5fb40b3db60ab2e1700e67ea754e67835"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-23.750160298641955d) + "'", double15 == (-23.750160298641955d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-41.447451230734536d) + "'", double20 == (-41.447451230734536d));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 34.518471023427836d + "'", double29 == 34.518471023427836d);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test121");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        int int11 = randomDataImpl1.nextBinomial(83, 0.02464616772939129d);
//        long long14 = randomDataImpl1.nextLong(35L, (long) 90);
//        randomDataImpl1.reSeedSecure();
//        try {
//            randomDataImpl1.setSecureAlgorithm("ab571aaf607647c9357829846b9a2c996d94654e3dfa59b841023c9fd6bbd66102156db4d0956f99251245d04a7", "4109a8d8a65082f26982c0d529e619cc5a6f5f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 4109a8d8a65082f26982c0d529e619cc5a6f5f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c9b6bafa1ec457188685aaa60fc0bf2f251203" + "'", str3.equals("c9b6bafa1ec457188685aaa60fc0bf2f251203"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 74L + "'", long14 == 74L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.251752586176186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.85301253823999d, (java.lang.Number) 1.0d, (java.lang.Number) 0.5268746266601116d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 68.0f, (-0.27319785117538253d), 1.1868238913561442d, 64);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.log(2.439487336882789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8917879093944445d + "'", double1 == 0.8917879093944445d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 40.89926471991978d, (java.lang.Number) 3L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 166.98999838850764d, (java.lang.Number) 1.861648705529517d, true);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.046740500384251975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.046757535932865156d + "'", double1 == 0.046757535932865156d);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) 46);
//        double double8 = randomDataImpl1.nextBeta((double) 58, 0.004481814439358454d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "39b7e402ac9ad2527f67104ac37a30fe74dd63" + "'", str3.equals("39b7e402ac9ad2527f67104ac37a30fe74dd63"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.999999998773571d + "'", double8 == 0.999999998773571d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int1 = org.apache.commons.math.util.FastMath.round(92.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 92 + "'", int1 == 92);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = randomDataImpl1.nextT(0.21837291455813004d);
//        double double25 = randomDataImpl1.nextGaussian(189.71050387483663d, 0.004481799435259219d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1bc73c024d2bbc49217b03bf5d75fcfa16b072" + "'", str3.equals("1bc73c024d2bbc49217b03bf5d75fcfa16b072"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0774928858360027d + "'", double15 == 2.0774928858360027d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 174.6119525140301d + "'", double20 == 174.6119525140301d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4531622617793047d + "'", double22 == 1.4531622617793047d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 189.70645492537236d + "'", double25 == 189.70645492537236d);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        try {
//            double double15 = randomDataImpl1.nextCauchy(137.82702065086616d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b0fb22014b599a331c0960e20b1dd66e424142" + "'", str3.equals("b0fb22014b599a331c0960e20b1dd66e424142"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 37.49583485782634d + "'", double9 == 37.49583485782634d);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
//        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
//        java.lang.Number number12 = numberIsTooLargeException10.getMax();
//        java.lang.Number number13 = numberIsTooLargeException10.getMax();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Object[] objArray19 = null;
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable18, objArray19);
//        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException17.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        int int27 = randomDataImpl24.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str29 = randomDataImpl24.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl24 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable22, objArray30);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable21, objArray30);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Object[] objArray43 = null;
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44, localizable45, objArray46);
//        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator50 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator50);
//        int int54 = randomDataImpl51.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str56 = randomDataImpl51.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { randomDataImpl51 };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray57);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable48, objArray57);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) 1.0f, false);
//        java.lang.Number number65 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (short) 100, number65, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) 10L, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1.6231562043547265d);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) -1, 49, "ba720cc5ce", 100, localizable48, 69.56422124950807d };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable21, objArray73);
//        org.apache.commons.math.exception.util.Localizable localizable75 = convergenceException74.getGeneralPattern();
//        java.lang.Throwable[] throwableArray76 = convergenceException74.getSuppressed();
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(localizable21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 67 + "'", int27 == 67);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0c71a4e10a" + "'", str29.equals("0c71a4e10a"));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 67 + "'", int54 == 67);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "5656e2c7af" + "'", str56.equals("5656e2c7af"));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(localizable75);
//        org.junit.Assert.assertNotNull(throwableArray76);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
//        java.lang.Number number14 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator20);
//        int int24 = randomDataImpl21.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str26 = randomDataImpl21.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray27 = new java.lang.Object[] { randomDataImpl21 };
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable19, objArray27);
//        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable34, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException33.getGeneralPattern();
//        java.lang.Number number39 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 184.51869951185168d, number39, false);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray48 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable45, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray48);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("8a5edff846", objArray48);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable37, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray48);
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable13, objArray48);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 50.0f);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (-0.6025253314559361d), (java.lang.Number) 4.598692891662723d, false);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 55 + "'", int24 == 55);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "e35a78770c" + "'", str26.equals("e35a78770c"));
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNull(localizable30);
//        org.junit.Assert.assertNotNull(localizable37);
//        org.junit.Assert.assertNotNull(objArray48);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 81, 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81L + "'", long2 == 81L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ');
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.tan(89.21580653348614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.021806367761273d + "'", double1 == 3.021806367761273d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, number15, (java.lang.Number) 97, (java.lang.Number) (-0.5772156677920679d));
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, number19, (java.lang.Number) 88.0394601776806d, true);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException24.getSuppressed();
        java.lang.Object[] objArray26 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable31, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable28, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("e219945706", objArray34);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str8 = randomDataImpl3.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray9 = new java.lang.Object[] { randomDataImpl3 };
//        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable1, objArray9);
//        java.lang.Throwable[] throwableArray11 = convergenceException10.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 184.51869951185168d, number21, false);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable27, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray30);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("8a5edff846", objArray30);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable19, objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray30);
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException35.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a440d2ac" + "'", str8.equals("52a440d2ac"));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNull(localizable12);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNull(localizable37);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test142");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        long long7 = randomDataImpl1.nextSecureLong(55L, (long) 80);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-57.57751322154149d) + "'", double4 == (-57.57751322154149d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 55L + "'", long7 == 55L);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5707963267948966d, (double) 10.0f, 184.51869951185168d);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        double double21 = normalDistributionImpl19.getStandardDeviation();
//        double double24 = normalDistributionImpl19.cumulativeProbability((-38.83505664078239d), 0.0d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "134505d14fc67bd54c82683692d88abff7ec12" + "'", str3.equals("134505d14fc67bd54c82683692d88abff7ec12"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999985470021d + "'", double11 == 0.9999999985470021d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5481560233952192d + "'", double13 == 1.5481560233952192d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "437715ba4fe78033fc48d5b4b03191445cd9da917038415f0f7e9ab0a98928fd5d8bd9cb7aabadfcf7047ac1dcfcac88188a" + "'", str15.equals("437715ba4fe78033fc48d5b4b03191445cd9da917038415f0f7e9ab0a98928fd5d8bd9cb7aabadfcf7047ac1dcfcac88188a"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-5.429203673205103d) + "'", double20 == (-5.429203673205103d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.43756438555238625d + "'", double24 == 0.43756438555238625d);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.7595861575800384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4357695596807195d + "'", double1 == 0.4357695596807195d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 59);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8257740091968151d) + "'", double1 == (-0.8257740091968151d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(97);
        java.lang.String str2 = maxIterationsExceededException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded" + "'", str2.equals("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.0d, 3.255561438896672d, (double) (byte) -1);
        double double5 = normalDistributionImpl3.cumulativeProbability(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 1.09488667378125E28d, (java.lang.Number) 49.65108724106803d, (java.lang.Number) 0.3309781210727745d);
        org.junit.Assert.assertNotNull(localizable6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.7595861575800384d, number1, true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        java.lang.Object[] objArray22 = notStrictlyPositiveException20.getArguments();
        boolean boolean23 = notStrictlyPositiveException20.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test152");
//        java.lang.Object[] objArray3 = null;
//        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("hi!", objArray3);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        java.lang.Object[] objArray6 = null;
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, localizable5, objArray6);
//        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException4.getGeneralPattern();
//        java.lang.Number number10 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 184.51869951185168d, number10, false);
//        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException12.getGeneralPattern();
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        java.lang.Object[] objArray20 = null;
//        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18, localizable19, objArray20);
//        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException18.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator24);
//        int int28 = randomDataImpl25.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str30 = randomDataImpl25.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { randomDataImpl25 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable23, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable22, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable14, objArray31);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("1c5b8a29d5671711c50214d97bca305642c4fd", objArray31);
//        org.junit.Assert.assertNotNull(localizable8);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 49 + "'", int28 == 49);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "4954582c13" + "'", str30.equals("4954582c13"));
//        org.junit.Assert.assertNotNull(objArray31);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.FastMath.log((-28.843873837893746d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed(35L);
//        double double13 = randomDataImpl1.nextGamma(1.089024395704929d, 3.770445623056948d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.486068359857487d + "'", double7 == 20.486068359857487d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.358036863974093d + "'", double13 == 5.358036863974093d);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        java.lang.String str14 = randomDataImpl1.nextHexString(59);
//        try {
//            randomDataImpl1.setSecureAlgorithm("3582dc830e", "70cda50e14");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 70cda50e14");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f61274c4b9a979433fd7731f97bd7fbe5865f4" + "'", str3.equals("f61274c4b9a979433fd7731f97bd7fbe5865f4"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.14102751031756d + "'", double9 == 9.14102751031756d);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100d4fd56662ff89509e6e0c93382f0696a3a7e5996dae03b162d0b89e9" + "'", str14.equals("100d4fd56662ff89509e6e0c93382f0696a3a7e5996dae03b162d0b89e9"));
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.23056057779637718d, 158.6578006505844d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.95935329754355E-102d + "'", double2 == 7.95935329754355E-102d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 4, (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.expm1(349.95411804077025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248377E151d + "'", double1 == 9.619275968248377E151d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.430816798843313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 253.8671023693877d + "'", double1 == 253.8671023693877d);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        double double10 = randomDataImpl1.nextGaussian(0.0d, (double) 43);
//        long long13 = randomDataImpl1.nextLong((-1L), (long) 13);
//        randomDataImpl1.reSeed((long) 4);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str18 = randomDataImpl1.nextSecureHexString(13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 27.054747389444767d + "'", double7 == 27.054747389444767d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-15.530815120530153d) + "'", double10 == (-15.530815120530153d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "fd91c904827b7" + "'", str18.equals("fd91c904827b7"));
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test161");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("8a5edff846", objArray47);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable36, objArray47);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray47);
//        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException(localizable53, (java.lang.Number) 8, (java.lang.Number) 85.62030143016939d, (java.lang.Number) 90.0d);
//        java.lang.Object[] objArray59 = null;
//        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("hi!", objArray59);
//        org.apache.commons.math.exception.util.Localizable localizable61 = null;
//        java.lang.Object[] objArray62 = null;
//        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException60, localizable61, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException60.getGeneralPattern();
//        java.lang.Number number66 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable64, (java.lang.Number) 184.51869951185168d, number66, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) 0.04457085352364287d);
//        java.lang.String str79 = notStrictlyPositiveException78.toString();
//        java.lang.String str80 = notStrictlyPositiveException78.toString();
//        boolean boolean81 = notStrictlyPositiveException78.getBoundIsAllowed();
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException78);
//        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException82);
//        java.lang.Object[] objArray84 = convergenceException82.getArguments();
//        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException(localizable53, objArray84);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 51 + "'", int23 == 51);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "e17e07e3bf" + "'", str25.equals("e17e07e3bf"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertNull(localizable29);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(localizable53);
//        org.junit.Assert.assertNotNull(localizable64);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str79.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str80.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(objArray84);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.01625980437881211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9316181666142691d + "'", double1 == 0.9316181666142691d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 0.9999999986051742d, number4);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable17, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException16.getGeneralPattern();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 184.51869951185168d, number22, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable31, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable20, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean42 = numberIsTooLargeException41.getBoundIsAllowed();
        java.lang.Object[] objArray43 = numberIsTooLargeException41.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, "org.apache.commons.math.MathException: {0} out of [{1}, {2}] range", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("4954582c13", objArray43);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(objArray43);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test164");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(6);
//        try {
//            int int14 = randomDataImpl1.nextPascal(35, (double) 59);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 59 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8e9fe40c58756b3a4719f7fe80d6a2564e98fb" + "'", str3.equals("8e9fe40c58756b3a4719f7fe80d6a2564e98fb"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.40810011777204513d + "'", double8 == 0.40810011777204513d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5961fa" + "'", str11.equals("5961fa"));
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test165");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        long long8 = randomDataImpl1.nextPoisson(0.9999999988626886d);
//        long long10 = randomDataImpl1.nextPoisson(0.2804518696792822d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test166");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        randomDataImpl6.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray13 = normalDistributionImpl11.sample(86);
//        double double16 = normalDistributionImpl11.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double17 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.Class<?> wildcardClass18 = normalDistributionImpl11.getClass();
//        double double20 = normalDistributionImpl11.cumulativeProbability(1.7453292519943295d);
//        double double22 = normalDistributionImpl11.density(1.5060973145850306E35d);
//        double[] doubleArray24 = normalDistributionImpl11.sample(58);
//        double double25 = normalDistributionImpl11.getMean();
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double28 = randomDataImpl1.nextChiSquare(1.2848842516505476d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-57.22686745521494d) + "'", double4 == (-57.22686745521494d));
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.004482403217643316d + "'", double16 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 54.65622560668708d + "'", double17 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5078229326523436d + "'", double20 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-97.09056614890821d) + "'", double26 == (-97.09056614890821d));
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.011812381946620045d + "'", double28 == 0.011812381946620045d);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.log((-52022.128284203376d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.tan((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(99, "", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = null;
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable16, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException15.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable19, objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException30.getGeneralPattern();
//        java.lang.Number number34 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number34);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray40 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable37, objArray40);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, objArray40);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray40);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 64 + "'", int25 == 64);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "297ad3e687" + "'", str27.equals("297ad3e687"));
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(objArray40);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1128637547917594E36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9423136647223025E34d + "'", double1 == 1.9423136647223025E34d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double5 = normalDistributionImpl2.inverseCumulativeProbability(106.14086257055767d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 106.141 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(89);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        java.lang.String str3 = maxIterationsExceededException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (89) exceeded" + "'", str3.equals("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (89) exceeded"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        randomDataImpl1.reSeed((long) '#');
        randomDataImpl1.reSeedSecure();
        double double9 = randomDataImpl1.nextF((double) 12239, 2.226441832186995d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.8642423045895287d + "'", double9 == 2.8642423045895287d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-4.9E-324d), 0.004830894954222802d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 40, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.5086815698671792d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test177");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
//        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
//        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 40.89926471991978d, (java.lang.Number) 3L, true);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator21);
//        int int25 = randomDataImpl22.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str27 = randomDataImpl22.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray28 = new java.lang.Object[] { randomDataImpl22 };
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable20, objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("208f284ec3", objArray28);
//        java.lang.Object[] objArray31 = convergenceException30.getArguments();
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = null;
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, localizable36, objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException35.getGeneralPattern();
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 184.51869951185168d, number41, false);
//        boolean boolean44 = numberIsTooLargeException43.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException43.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("hi!", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException49, localizable50, objArray51);
//        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException49.getGeneralPattern();
//        java.lang.Number number55 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 184.51869951185168d, number55, false);
//        boolean boolean58 = numberIsTooLargeException57.getBoundIsAllowed();
//        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooLargeException57.getGeneralPattern();
//        java.lang.Object[] objArray62 = null;
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("hi!", objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        java.lang.Object[] objArray65 = null;
//        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException63, localizable64, objArray65);
//        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException63.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable68 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator69 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator69);
//        int int73 = randomDataImpl70.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str75 = randomDataImpl70.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { randomDataImpl70 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable68, objArray76);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable67, objArray76);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable59, objArray76);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "7129b79c9874f86f179bc2c416604492209abe", objArray76);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException("fca9644a9161a7fadbf4b69a4fe6cbec3a54af", objArray76);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray76);
//        java.lang.Number number85 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 43.2744692197697d, number85, (java.lang.Number) (byte) 100);
//        org.junit.Assert.assertNotNull(localizable6);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 66 + "'", int25 == 66);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "80bce2e1c4" + "'", str27.equals("80bce2e1c4"));
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(localizable39);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable53);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(localizable67);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 66 + "'", int73 == 66);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "6103af3131" + "'", str75.equals("6103af3131"));
//        org.junit.Assert.assertNotNull(objArray76);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test178");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("hi!", objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11, localizable12, objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException11.getGeneralPattern();
//        java.lang.Number number17 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 184.51869951185168d, number17, false);
//        java.lang.Object[] objArray20 = null;
//        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, localizable15, objArray20);
//        java.lang.Object[] objArray22 = null;
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable15, objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator26 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator26);
//        int int30 = randomDataImpl27.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str32 = randomDataImpl27.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray33 = new java.lang.Object[] { randomDataImpl27 };
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable25, objArray33);
//        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException34.getGeneralPattern();
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39, localizable40, objArray41);
//        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException39.getGeneralPattern();
//        java.lang.Number number45 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 184.51869951185168d, number45, false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable51, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray54);
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("8a5edff846", objArray54);
//        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, localizable43, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("0703e0c7a47e661d415c9faf497c4ee92f5e01", objArray54);
//        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable15, objArray54);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 43);
//        java.lang.Object[] objArray63 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(42, localizable15, objArray63);
//        org.junit.Assert.assertNotNull(localizable15);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 58 + "'", int30 == 58);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "a96b101c27" + "'", str32.equals("a96b101c27"));
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNull(localizable36);
//        org.junit.Assert.assertNotNull(localizable43);
//        org.junit.Assert.assertNotNull(objArray54);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-27.990912426753102d), 0.5078229326523436d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-27.9909124267531d) + "'", double2 == (-27.9909124267531d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 58, (float) 59);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 58.0f + "'", float2 == 58.0f);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        long long8 = randomDataImpl1.nextPoisson(0.9999999988626886d);
//        try {
//            int int11 = randomDataImpl1.nextBinomial(100, (double) 2);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(156.65930874427332d, (double) 55.0f, 0.9849051783319762d, 12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6892365873081314E-29d + "'", double4 == 3.6892365873081314E-29d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double2 = org.apache.commons.math.util.FastMath.min(253.8671023693877d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        java.lang.Class<?> wildcardClass17 = mathException16.getClass();
        java.lang.Throwable[] throwableArray18 = mathException16.getSuppressed();
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double[] doubleArray5 = normalDistributionImpl2.sample(90);
        double double6 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6931471805599453d + "'", double6 == 0.6931471805599453d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextGamma((double) 94L, (double) 77);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 81 + "'", int4 == 81);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 82.95092723332394d + "'", double7 == 82.95092723332394d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7123.253513863015d + "'", double11 == 7123.253513863015d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        normalDistributionImpl2.reseedRandomGenerator((long) 95);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(106.14086257055767d, 30.31139430797614d);
        double double4 = normalDistributionImpl2.density((-0.027415567780803774d));
        double double6 = normalDistributionImpl2.density((double) 4L);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.8531036963523766E-5d + "'", double4 == 2.8531036963523766E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.503983622555108E-5d + "'", double6 == 4.503983622555108E-5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 30.31139430797614d + "'", double7 == 30.31139430797614d);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test191");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        mathException5.addSuppressed((java.lang.Throwable) convergenceException15);
//        java.lang.Throwable[] throwableArray17 = mathException5.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 81 + "'", int11 == 81);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dd36214bdb" + "'", str13.equals("dd36214bdb"));
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(throwableArray17);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException20.getSpecificPattern();
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number30 = outOfRangeException29.getHi();
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException29.getGeneralPattern();
        java.lang.Object[] objArray32 = outOfRangeException29.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("7b9cb371cf", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(throwable23, "", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray32);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10 + "'", number30.equals(10));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test193");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        int int7 = randomDataImpl1.nextBinomial(36, 0.2767898921480116d);
//        java.lang.String str9 = randomDataImpl1.nextSecureHexString(73);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-56.87664745919086d) + "'", double4 == (-56.87664745919086d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "7c41606eb539c853f7bca0abf102263bf8cb3938bcc5f9b3310d6784d8ac5bf1cf9138ca8" + "'", str9.equals("7c41606eb539c853f7bca0abf102263bf8cb3938bcc5f9b3310d6784d8ac5bf1cf9138ca8"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(49);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 40.89926471991978d, (java.lang.Number) 3L, true);
        java.lang.Class<?> wildcardClass18 = localizable13.getClass();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.4483771956262554d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test198");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str13 = randomDataImpl8.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl8 };
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray14);
//        mathException5.addSuppressed((java.lang.Throwable) convergenceException15);
//        org.apache.commons.math.exception.util.Localizable localizable17 = mathException5.getSpecificPattern();
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 77 + "'", int11 == 77);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "c2fbfb0adc" + "'", str13.equals("c2fbfb0adc"));
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNull(localizable17);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeed((long) 15);
//        try {
//            long long8 = randomDataImpl1.nextSecureLong((long) 68, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 68 is larger than, or equal to, the maximum (0): lower bound (68) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ae42d22849a6068c8387ab7d9cd7ef9a9235ae" + "'", str3.equals("ae42d22849a6068c8387ab7d9cd7ef9a9235ae"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        randomDataImpl1.reSeed();
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.2848842516505476d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test202");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double6 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 66.29968357541472d + "'", double3 == 66.29968357541472d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.0d + "'", double5 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 89.0d + "'", double7 == 89.0d);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test203");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.density((-1296.4656934408517d));
//        double double9 = normalDistributionImpl2.density(9.585658882134517d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 49.303351209271916d + "'", double3 == 49.303351209271916d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.0d + "'", double5 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.7430818892374675E-49d + "'", double7 == 3.7430818892374675E-49d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.004456573943578281d + "'", double9 == 0.004456573943578281d);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test204");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int int12 = randomDataImpl1.nextPascal(34, 0.7799726475466374d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) '4');
//        double double17 = randomDataImpl1.nextGaussian(0.6931471805599453d, 2.439487336882789d);
//        int int20 = randomDataImpl1.nextInt(70, 88);
//        java.lang.String str22 = randomDataImpl1.nextHexString(82);
//        int int26 = randomDataImpl1.nextHypergeometric(66, 0, 43);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 77 + "'", int4 == 77);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "abc2bce124" + "'", str6.equals("abc2bce124"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.6128701167454179d) + "'", double9 == (-0.6128701167454179d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "374341fbe41840ce9c01e949d1539c61a8090016d42281f970a3" + "'", str14.equals("374341fbe41840ce9c01e949d1539c61a8090016d42281f970a3"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-2.7271412484055952d) + "'", double17 == (-2.7271412484055952d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 88 + "'", int20 == 88);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "b814b5e44ff71d6cde131ec8b629f18f90ab39a062cb28e32a4363dcc353b2df64373a3c049f4552d8" + "'", str22.equals("b814b5e44ff71d6cde131ec8b629f18f90ab39a062cb28e32a4363dcc353b2df64373a3c049f4552d8"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test205");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        int int5 = randomDataImpl2.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str7 = randomDataImpl2.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray8 = new java.lang.Object[] { randomDataImpl2 };
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray8);
//        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable15, objArray16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException14.getGeneralPattern();
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 184.51869951185168d, number20, false);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray29);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("8a5edff846", objArray29);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable18, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException9.getSpecificPattern();
//        try {
//            java.lang.Class<?> wildcardClass35 = localizable34.getClass();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 76 + "'", int5 == 76);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4169d9a087" + "'", str7.equals("4169d9a087"));
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNull(localizable11);
//        org.junit.Assert.assertNotNull(localizable18);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNull(localizable34);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-15.60702868552965d), (double) 1, 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(89);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.004830894954222802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004830876164039145d + "'", double1 == 0.004830876164039145d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948963d) + "'", double1 == (-1.5707963267948963d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) 44);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 44.0f + "'", float2 == 44.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Object[] objArray6 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test213");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        java.lang.String str14 = randomDataImpl1.nextHexString(59);
//        java.lang.String str16 = randomDataImpl1.nextHexString((int) '#');
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "af9a5c296cdb95865400a42139078feef06af0" + "'", str3.equals("af9a5c296cdb95865400a42139078feef06af0"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 45.11475147334332d + "'", double9 == 45.11475147334332d);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4267590a66f41142dc00a5f3dba53f321edf926885a27ab43c1791402eb" + "'", str14.equals("4267590a66f41142dc00a5f3dba53f321edf926885a27ab43c1791402eb"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "d1d4c10d4b383523573a3c260a3acf33d81" + "'", str16.equals("d1d4c10d4b383523573a3c260a3acf33d81"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.special.Gamma.digamma(85.62030143016939d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444071317099006d + "'", double1 == 4.444071317099006d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 41, 11.548739357257746d, 109.33371740441963d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.548739357257746d + "'", double4 == 11.548739357257746d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, localizable20, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException19.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 184.51869951185168d, number25, false);
        boolean boolean28 = numberIsTooLargeException27.getBoundIsAllowed();
        mathException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, localizable36, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException35.getGeneralPattern();
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("hi!", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable43, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException42.getGeneralPattern();
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 184.51869951185168d, number48, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException(localizable46, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable57, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable46, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (short) 10, (java.lang.Number) 0.7799726475466374d, true);
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, number68);
        java.lang.Throwable[] throwableArray70 = notStrictlyPositiveException69.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("5ba2364d8b", (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, localizable31, (java.lang.Object[]) throwableArray70);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray70);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test217");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        double double11 = randomDataImpl1.nextExponential(45.96743602496565d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7f4d6c219e12619bc68035ca40f5501b62809b" + "'", str3.equals("7f4d6c219e12619bc68035ca40f5501b62809b"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.467726651213706d + "'", double9 == 8.467726651213706d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 36.040650704516395d + "'", double11 == 36.040650704516395d);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.special.Erf.erf(0.004456573943578281d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005028671902962146d + "'", double1 == 0.005028671902962146d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        java.lang.Number number37 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.154434690031884d, (java.lang.Number) Double.NaN, (java.lang.Number) (short) -1);
        java.lang.Object[] objArray43 = outOfRangeException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable38, objArray43);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 3.948148009134E13d + "'", number37.equals(3.948148009134E13d));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(139.67385975737693d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.81836958964209d + "'", double1 == 11.81836958964209d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 79, 86.99999999999999d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test222");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        randomDataImpl6.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray13 = normalDistributionImpl11.sample(86);
//        double double16 = normalDistributionImpl11.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double17 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.Class<?> wildcardClass18 = normalDistributionImpl11.getClass();
//        double double20 = normalDistributionImpl11.cumulativeProbability(1.7453292519943295d);
//        double double22 = normalDistributionImpl11.density(1.5060973145850306E35d);
//        double[] doubleArray24 = normalDistributionImpl11.sample(58);
//        double double25 = normalDistributionImpl11.getMean();
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double28 = normalDistributionImpl11.cumulativeProbability(1.6245197929597313d);
//        normalDistributionImpl11.reseedRandomGenerator(3L);
//        double double31 = normalDistributionImpl11.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-57.187955191342105d) + "'", double4 == (-57.187955191342105d));
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.004482403217643316d + "'", double16 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 54.65622560668708d + "'", double17 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5078229326523436d + "'", double20 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-53.377225056994384d) + "'", double26 == (-53.377225056994384d));
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5072815016278794d + "'", double28 == 0.5072815016278794d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 89.0d + "'", double31 == 89.0d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(95);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test224");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare(0.7799726475466374d);
//        java.lang.Class<?> wildcardClass12 = randomDataImpl1.getClass();
//        double double15 = randomDataImpl1.nextGamma((double) 1L, (double) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7320508075688772d, (double) 79L, 5.344864515413418E-21d);
//        double double21 = normalDistributionImpl19.inverseCumulativeProbability(0.0d);
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        try {
//            double double25 = randomDataImpl1.nextWeibull(0.0d, 3.732511156817248d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 71 + "'", int4 == 71);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 44.73349723991271d + "'", double7 == 44.73349723991271d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0011211482715950988d + "'", double11 == 0.0011211482715950988d);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.107416617608481d + "'", double15 == 4.107416617608481d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-110.77730124112054d) + "'", double22 == (-110.77730124112054d));
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-78.09217997635302d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 121.01961317479275d + "'", double1 == 121.01961317479275d);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test226");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        int int11 = randomDataImpl1.nextBinomial(83, 0.02464616772939129d);
//        try {
//            int[] intArray14 = randomDataImpl1.nextPermutation(42, 66);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 66 is larger than the maximum (42): permutation size (66) exceeds permuation domain (42)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "627264162a29ee038b4f3957e20be56f202fbf" + "'", str3.equals("627264162a29ee038b4f3957e20be56f202fbf"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.341351718524658E-156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5091543890434437d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4692860781079095d) + "'", double1 == (-0.4692860781079095d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 82, (long) 76);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 82L + "'", long2 == 82L);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test230");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(61, 33, 43);
//        double double14 = randomDataImpl1.nextExponential(51.0d);
//        randomDataImpl1.reSeed(97L);
//        int int19 = randomDataImpl1.nextBinomial(7, 0.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 16.649161021818838d + "'", double14 == 16.649161021818838d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 53);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53 + "'", int1 == 53);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1.5430806348152437d, true);
        java.lang.Object[] objArray6 = numberIsTooLargeException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("39199b4a051de1f0b08bc748e84dca0651e213d7f636310d0ee45964eb7708c15ee2b018142551205", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-107.674757616243d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test234");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeedSecure(0L);
//        double double8 = randomDataImpl1.nextT(0.8117566297988853d);
//        try {
//            double double11 = randomDataImpl1.nextF(0.0d, (-118.72272756237454d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 73 + "'", int4 == 73);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2423330849520051d + "'", double8 == 1.2423330849520051d);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.5091543890434437d), false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.5091543890434437d) + "'", number6.equals((-0.5091543890434437d)));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-27.937433942813755d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double2 = org.apache.commons.math.util.FastMath.min((-58.076142362066705d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-58.076142362066705d) + "'", double2 == (-58.076142362066705d));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int[] intArray12 = randomDataImpl1.nextPermutation((int) (short) 100, 32);
//        double double15 = randomDataImpl1.nextUniform((-59.0d), 0.21837291455813004d);
//        java.lang.Class<?> wildcardClass16 = randomDataImpl1.getClass();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c2c85a19900e694ef89131783e188c18faa93f" + "'", str3.equals("c2c85a19900e694ef89131783e188c18faa93f"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 98.58982939935947d + "'", double9 == 98.58982939935947d);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-33.48378781280511d) + "'", double15 == (-33.48378781280511d));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        java.lang.Throwable[] throwableArray17 = numberIsTooSmallException16.getSuppressed();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test241");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(32);
//        double double5 = randomDataImpl1.nextExponential(41.0d);
//        java.lang.String str7 = randomDataImpl1.nextHexString(11);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e1ecb364d456951b579b7bce29507ff1" + "'", str3.equals("e1ecb364d456951b579b7bce29507ff1"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 31.622594276749822d + "'", double5 == 31.622594276749822d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e2de35fa329" + "'", str7.equals("e2de35fa329"));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.0f + "'", float1 == 33.0f);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test243");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray8 = normalDistributionImpl6.sample(86);
//        double double11 = normalDistributionImpl6.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double15 = normalDistributionImpl6.cumulativeProbability(0.0d, 71.7372090208965d);
//        double double16 = normalDistributionImpl6.sample();
//        double double18 = normalDistributionImpl6.cumulativeProbability(0.0d);
//        double double20 = normalDistributionImpl6.density(51.0d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004482403217643316d + "'", double11 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.65622560668708d + "'", double12 == 54.65622560668708d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2898889703334897d + "'", double15 == 0.2898889703334897d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.89191187987235d + "'", double16 == 32.89191187987235d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.003803784761266171d + "'", double20 == 0.003803784761266171d);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test244");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        randomDataImpl1.reSeed(35L);
//        try {
//            int int13 = randomDataImpl1.nextInt(85, 59);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 85 is larger than, or equal to, the maximum (59): lower bound (85) must be strictly less than upper bound (59)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test245");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8916762554116714d + "'", double1 == 0.8916762554116714d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.7572742277801137E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4191.9854815828185d + "'", double1 == 4191.9854815828185d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.307139146118315d, 2.437128995686965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9913188016766764d + "'", double2 == 0.9913188016766764d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test248");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        double double7 = randomDataImpl1.nextGamma(1.0d, 99.99999999999999d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 55);
//        java.lang.String str13 = randomDataImpl1.nextHexString(3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93 + "'", int4 == 93);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 192.9673736663035d + "'", double7 == 192.9673736663035d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a53" + "'", str13.equals("a53"));
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test249");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator19);
//        int int23 = randomDataImpl20.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str25 = randomDataImpl20.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl20 };
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray26);
//        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
//        java.lang.Object[] objArray31 = null;
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = null;
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable33, objArray34);
//        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 184.51869951185168d, number38, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("8a5edff846", objArray47);
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, localizable36, objArray47);
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "512e3f7e840ecf240ab415a15c2e57fa7ec8c8", objArray47);
//        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        java.lang.Object[] objArray60 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable57, objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable54, objArray60);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, objArray60);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 92 + "'", int23 == 92);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "48a0533e2a" + "'", str25.equals("48a0533e2a"));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertNull(localizable29);
//        org.junit.Assert.assertNotNull(localizable36);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(localizable53);
//        org.junit.Assert.assertNotNull(objArray60);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-41.447451230734536d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test251");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ee288a5aa234fd49b47a2bea611608d4a6980d" + "'", str3.equals("ee288a5aa234fd49b47a2bea611608d4a6980d"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0042019221392496225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9999999988993884d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999988993884d + "'", double2 == 0.9999999988993884d);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test254");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextInt(12, 61);
//        int[] intArray9 = randomDataImpl1.nextPermutation(81, 39);
//        randomDataImpl1.reSeed((long) 15);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ad734f59e128b6fa4917349ca56fd5d7e5b603" + "'", str3.equals("ad734f59e128b6fa4917349ca56fd5d7e5b603"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 55 + "'", int6 == 55);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(53.08495167300164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.08495167300165d + "'", double1 == 53.08495167300165d);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test256");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(61, 33, 43);
//        double double14 = randomDataImpl1.nextExponential(51.0d);
//        randomDataImpl1.reSeed(97L);
//        java.lang.String str18 = randomDataImpl1.nextSecureHexString(34);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 23 + "'", int12 == 23);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 16.08068994236886d + "'", double14 == 16.08068994236886d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dedf5b435b60c1f0e534e22c9d164d894d" + "'", str18.equals("dedf5b435b60c1f0e534e22c9d164d894d"));
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test257");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        int int12 = randomDataImpl1.nextInt(67, 71);
//        long long14 = randomDataImpl1.nextPoisson(0.8726646259971648d);
//        double double17 = randomDataImpl1.nextGaussian(359.1342053695754d, 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fd7499594050c051fb33b5de460052aca714e4" + "'", str3.equals("fd7499594050c051fb33b5de460052aca714e4"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 45.04790356470073d + "'", double9 == 45.04790356470073d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 370.4165452636342d + "'", double17 == 370.4165452636342d);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(97.0051545022222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594782277005892d + "'", double1 == 4.594782277005892d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((-1L));
        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
        double double8 = randomDataImpl1.nextCauchy(0.0d, (double) 50);
        double double11 = randomDataImpl1.nextF((double) 5L, 4.64158883361278d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1296.4656934408517d) + "'", double8 == (-1296.4656934408517d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.5140851479666988d + "'", double11 == 1.5140851479666988d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 86.99999999999999d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 311.5974716928727d, (java.lang.Number) (-0.8414709848078965d), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getSpecificPattern();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException16);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.4023066454805946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8952685703053898d + "'", double1 == 1.8952685703053898d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-56.47257550644328d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.710657776180059d, 4.276666119016055d);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test265");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(99, "", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getGeneralPattern();
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable9, objArray10);
//        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException8.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        org.apache.commons.math.random.RandomGenerator randomGenerator14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator14);
//        int int18 = randomDataImpl15.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str20 = randomDataImpl15.nextSecureHexString((int) (byte) 10);
//        java.lang.Object[] objArray21 = new java.lang.Object[] { randomDataImpl15 };
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable13, objArray21);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(93, localizable12, objArray21);
//        org.apache.commons.math.exception.util.Localizable localizable24 = maxIterationsExceededException23.getGeneralPattern();
//        java.lang.Number number27 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 100.0d, (java.lang.Number) (-1.6261509044766869d), number27);
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable30, objArray33);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable24, objArray33);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1.5430806348152437d, true);
//        java.lang.Object[] objArray40 = numberIsTooLargeException39.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable24, objArray40);
//        org.junit.Assert.assertNotNull(localizable4);
//        org.junit.Assert.assertNotNull(localizable12);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 92 + "'", int18 == 92);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "e143fa629f" + "'", str20.equals("e143fa629f"));
//        org.junit.Assert.assertNotNull(objArray21);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertNotNull(objArray40);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long1 = org.apache.commons.math.util.FastMath.round(13.728756420312397d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 14L + "'", long1 == 14L);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test267");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double15 = normalDistributionImpl14.sample();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 97);
//        normalDistributionImpl14.reseedRandomGenerator((long) 71);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = randomDataImpl1.nextT(0.21837291455813004d);
//        double double25 = randomDataImpl1.nextF(2.964993995359989d, 2.0588140836377806d);
//        double double28 = randomDataImpl1.nextUniform(0.003803784761266171d, 0.9999999958776928d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1202bd4fee57d100e5ab28c5bed4d02526283b" + "'", str3.equals("1202bd4fee57d100e5ab28c5bed4d02526283b"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 118.93819701242938d + "'", double15 == 118.93819701242938d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8621186791753761d + "'", double17 == 0.8621186791753761d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.21203905233432d + "'", double20 == 97.21203905233432d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.211609160869631d + "'", double22 == 1.211609160869631d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11847470993343417d + "'", double25 == 0.11847470993343417d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.46201215951100166d + "'", double28 == 0.46201215951100166d);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(32);
//        double double6 = randomDataImpl1.nextWeibull(0.9849051783319762d, (double) 66);
//        java.lang.String str8 = randomDataImpl1.nextHexString(33);
//        randomDataImpl1.reSeedSecure(42L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e0f11b4fef9dddb2917cb30f84478754" + "'", str3.equals("e0f11b4fef9dddb2917cb30f84478754"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 42.163928960595186d + "'", double6 == 42.163928960595186d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ea9c7791f8660d688299507e73a6b6276" + "'", str8.equals("ea9c7791f8660d688299507e73a6b6276"));
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.004456573943578281d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 17, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.7414757232563353d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7414757232563354d + "'", double1 == 0.7414757232563354d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 56L, (double) 36, 0.0d, 79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (79) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray4 = normalDistributionImpl2.sample(86);
        double double6 = normalDistributionImpl2.inverseCumulativeProbability(0.9849051783319762d);
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability(1121.3139155281578d, 2.9947002357337635d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 192.91580444921826d + "'", double6 == 192.91580444921826d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 65, 96.79059831690755d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.526607284881551E-4d + "'", double2 == 2.526607284881551E-4d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 39.94771078990054d);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test276");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.cumulativeProbability((double) 2, 90.0d);
//        double double10 = normalDistributionImpl2.cumulativeProbability(0.9999999988993884d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.9551197147302d + "'", double3 == 47.9551197147302d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.0d + "'", double5 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3350840039853573d + "'", double8 == 0.3350840039853573d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5044824032127101d + "'", double10 == 0.5044824032127101d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(95);
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) 1.2540338422616613d, (java.lang.Number) 14);
        org.apache.commons.math.exception.util.Localizable localizable35 = outOfRangeException34.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 0.9999999998927765d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 54.65622560668708d, (java.lang.Number) 84.35908616006576d, false);
        java.lang.Number number42 = numberIsTooLargeException41.getArgument();
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 54.65622560668708d + "'", number42.equals(54.65622560668708d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5430256902014756d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test280");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        long long8 = randomDataImpl1.nextLong((long) 0, (long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(3.948148009134034E13d, 179.02719848915368d);
//        double double13 = randomDataImpl1.nextT(0.5772156649015329d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dd7c55547842fd5b28d9bc67096a3dad31462c" + "'", str3.equals("dd7c55547842fd5b28d9bc67096a3dad31462c"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-4.212914402165499d) + "'", double13 == (-4.212914402165499d));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6, localizable7, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException6.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 184.51869951185168d, number12, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray15);
        java.lang.Number number17 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable18 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10 + "'", number17.equals(10));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass6 = randomDataImpl1.getClass();
//        double double9 = randomDataImpl1.nextF(0.02464616772939129d, (double) 71);
//        randomDataImpl1.reSeed(0L);
//        randomDataImpl1.reSeedSecure((long) 76);
//        double double16 = randomDataImpl1.nextUniform(1.3237278296841644d, (double) 'a');
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f0d2719c9dacaaa180a06545e45d3c12b86943f92883b3f344d51561accfe060979149248426b5cae3e6d4eb5d0d51dda270" + "'", str5.equals("f0d2719c9dacaaa180a06545e45d3c12b86943f92883b3f344d51561accfe060979149248426b5cae3e6d4eb5d0d51dda270"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 71.26000080246676d + "'", double16 == 71.26000080246676d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 70, 12239L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test284");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed((-1L));
//        double double5 = randomDataImpl1.nextChiSquare((double) 'a');
//        double double8 = randomDataImpl1.nextCauchy(0.0d, (double) 50);
//        randomDataImpl1.reSeed();
//        double double12 = randomDataImpl1.nextWeibull(63.085305060930544d, (double) 93.0f);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 88.0394601776806d + "'", double5 == 88.0394601776806d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1296.4656934408517d) + "'", double8 == (-1296.4656934408517d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 93.4875856770248d + "'", double12 == 93.4875856770248d);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9008022248538402d, (java.lang.Number) 1.6449340668481562d, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test286");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        int int6 = randomDataImpl1.nextPascal((int) (short) 10, 0.5772156649015329d);
//        double double8 = randomDataImpl1.nextChiSquare(1.6449340668481562d);
//        randomDataImpl1.reSeed();
//        double double11 = randomDataImpl1.nextExponential(1.211609160869631d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d15a863fb2327f34279656a333b48685688281" + "'", str3.equals("d15a863fb2327f34279656a333b48685688281"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.043609811872228d + "'", double8 == 3.043609811872228d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3547153831639357d + "'", double11 == 0.3547153831639357d);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test287");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((-57.29577951308232d), 0.4430227202923068d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        randomDataImpl6.reSeed((long) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
//        double[] doubleArray13 = normalDistributionImpl11.sample(86);
//        double double16 = normalDistributionImpl11.cumulativeProbability((-1.0d), 1.1102230246251565E-16d);
//        double double17 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.Class<?> wildcardClass18 = normalDistributionImpl11.getClass();
//        double double20 = normalDistributionImpl11.cumulativeProbability(1.7453292519943295d);
//        double double22 = normalDistributionImpl11.density(1.5060973145850306E35d);
//        double[] doubleArray24 = normalDistributionImpl11.sample(58);
//        double double25 = normalDistributionImpl11.getMean();
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            int int29 = randomDataImpl1.nextInt((int) (byte) 100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-56.85807062141165d) + "'", double4 == (-56.85807062141165d));
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.004482403217643316d + "'", double16 == 0.004482403217643316d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 54.65622560668708d + "'", double17 == 54.65622560668708d);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5078229326523436d + "'", double20 == 0.5078229326523436d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 17.866793383331647d + "'", double26 == 17.866793383331647d);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0024898063107158083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0024929084524913663d + "'", double1 == 0.0024929084524913663d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.6773892640898347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3885787214990626d + "'", double1 == 1.3885787214990626d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.2419880144230016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09641093827810998d) + "'", double1 == (-0.09641093827810998d));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test291");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        randomDataImpl1.reSeed((long) 35);
//        double double9 = randomDataImpl1.nextCauchy(7.74154762445184d, Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 83 + "'", int4 == 83);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(96.79059831690755d, 349.95411804077025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.23265307578861238d, (java.lang.Number) (-21.612260619239635d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.23265307578861238d + "'", number4.equals(0.23265307578861238d));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test294");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int[] intArray11 = randomDataImpl1.nextPermutation(91, 15);
//        long long14 = randomDataImpl1.nextLong((long) (byte) 10, (long) 53);
//        randomDataImpl1.reSeed();
//        long long17 = randomDataImpl1.nextPoisson(2.9467151600240094d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28L + "'", long14 == 28L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 7L + "'", long17 == 7L);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test295");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) ' ', (int) (short) 100);
//        java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double9 = randomDataImpl1.nextUniform((-1.0d), (double) (byte) 0);
//        int[] intArray12 = randomDataImpl1.nextPermutation(50, (int) (byte) 10);
//        double double15 = randomDataImpl1.nextF(82.95092723332394d, 0.9999999982611434d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 84 + "'", int4 == 84);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d2b53eb6e8" + "'", str6.equals("d2b53eb6e8"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.09453464405338985d) + "'", double9 == (-0.09453464405338985d));
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.903420040410492d + "'", double15 == 10.903420040410492d);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test296");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        double double6 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.sample();
//        double double9 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.49689300088292593d + "'", double5 == 0.49689300088292593d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 89.0d + "'", double6 == 89.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 81.60004526545444d + "'", double7 == 81.60004526545444d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.49689300088292593d + "'", double9 == 0.49689300088292593d);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6931471805599453d, (double) 89);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
        double[] doubleArray7 = normalDistributionImpl2.sample(60);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 89.0d + "'", double3 == 89.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.49689300088292593d + "'", double5 == 0.49689300088292593d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test298");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric(49, 46, 15);
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) (short) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(61, 33, 43);
//        double double14 = randomDataImpl1.nextExponential(51.0d);
//        randomDataImpl1.reSeedSecure((long) 26);
//        try {
//            java.lang.String str18 = randomDataImpl1.nextSecureHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 23.822608052560838d + "'", double14 == 23.822608052560838d);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 343.77467707849394d + "'", double1 == 343.77467707849394d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 184.51869951185168d, number8, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-1L), (java.lang.Number) 1.6245197929597313d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.04457085352364287d);
        java.lang.String str21 = notStrictlyPositiveException20.toString();
        java.lang.String str22 = notStrictlyPositiveException20.toString();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 3.2183089412468484d, (java.lang.Number) 1.1128637547917594E36d, true);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.045 is smaller than, or equal to, the minimum (0): hi!"));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 78);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.847392632571009E23d + "'", double1 == 3.847392632571009E23d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1L, (java.lang.Number) 75.91204854215849d, false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) 10);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 89);
        double[] doubleArray8 = normalDistributionImpl6.sample(86);
        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
        double double10 = normalDistributionImpl6.getStandardDeviation();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.65622560668708d + "'", double9 == 54.65622560668708d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 89.0d + "'", double10 == 89.0d);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test305");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(38);
//        long long6 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double9 = randomDataImpl1.nextUniform((double) 6, (double) 99L);
//        double double12 = randomDataImpl1.nextGaussian(1.5707963267948963d, 0.011366898564937883d);
//        randomDataImpl1.reSeed((long) 18);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "26a3e021b7d137453482a87c422da7f476aa6c" + "'", str3.equals("26a3e021b7d137453482a87c422da7f476aa6c"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.004534175053763d + "'", double9 == 10.004534175053763d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.576553858903096d + "'", double12 == 1.576553858903096d);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = org.apache.commons.math.util.FastMath.min(42, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        long long1 = org.apache.commons.math.util.FastMath.round(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-15L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.0d) + "'", double1 == (-15.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double2 = org.apache.commons.math.util.FastMath.max(2.226441832186995d, 97.21203905233432d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.21203905233432d + "'", double2 == 97.21203905233432d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException9.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 184.51869951185168d, number15, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0f, (-0.9999999999999999d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("daff3d0d27", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 71, (java.lang.Number) 3.948148009134E13d, false);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooLargeException34.getArguments();
        java.lang.Number number37 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException34.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable42, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException41.getGeneralPattern();
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 184.51869951185168d, number47, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) (short) 100, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("hi!", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException57, localizable58, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable61 = convergenceException57.getGeneralPattern();
        java.lang.Object[] objArray66 = new java.lang.Object[] { 99.99999999999999d, 1.0f, 0.5772156649015329d };
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException57, "6fd8ca585f74914f7f5486f5b281dc6a6d984f", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = mathException67.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) 40.89926471991978d, (java.lang.Number) 3L, true);
        java.lang.Object[] objArray76 = null;
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException77, localizable78, objArray79);
        org.apache.commons.math.exception.util.Localizable localizable81 = convergenceException77.getGeneralPattern();
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException85 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable81, (java.lang.Number) 184.51869951185168d, number83, false);
        java.lang.Object[] objArray86 = numberIsTooLargeException85.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException(87, "57ceb132858911b98da62333a3892fb3850e87", objArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable68, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable45, objArray86);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 3.948148009134E13d + "'", number37.equals(3.948148009134E13d));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(localizable81);
        org.junit.Assert.assertNotNull(objArray86);
    }
}

