import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 43001988);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43001988L + "'", long1 == 43001988L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-4593512421086650189L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011872827488d + "'", double1 == 1.1752011872827488d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17542037193601007d + "'", double1 == 0.17542037193601007d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3241267271828105E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3241267271828105E8d + "'", double1 == 1.3241267271828105E8d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3156541846684752E35d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double[] doubleArray16 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) '4');
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.45231565944180985d);
        double[] doubleArray33 = new double[] { 1.4422495703074083d };
        double[] doubleArray40 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) '4');
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray51 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray43);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double[] doubleArray63 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) '4');
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 0.45231565944180985d);
        double[] doubleArray85 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) '4');
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3241251100007592E8d + "'", double17 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 51.99991685582412d + "'", double20 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.3241251100007592E8d + "'", double28 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241245900015907E8d + "'", double29 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.3241251100007592E8d + "'", double41 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 51.99991685582412d + "'", double44 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.3241251100007592E8d + "'", double52 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.3241245900015907E8d + "'", double53 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 43001979 + "'", int54 == 43001979);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.4422499630189163d + "'", double55 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.3241251100007592E8d + "'", double64 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 51.99991685582412d + "'", double67 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.3241251100007592E8d + "'", double75 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.3241245900015907E8d + "'", double76 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.3241251100007592E8d + "'", double86 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 51.99991685582412d + "'", double89 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 43001979 + "'", int90 == 43001979);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 51.99991685582412d + "'", double92 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int[] intArray25 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray31 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray31);
        int[] intArray38 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray44 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray38);
        int[] intArray50 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray56 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray56);
        int[] intArray61 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray67 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray61);
        int[] intArray73 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray79 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray79);
        int[] intArray84 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray90 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray84, intArray90);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray84);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray84);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray61);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.93475175845634d + "'", double32 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.93475175845634d + "'", double34 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 68.93475175845634d + "'", double45 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 68.93475175845634d + "'", double57 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 68.93475175845634d + "'", double68 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 68.93475175845634d + "'", double80 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 68.93475175845634d + "'", double91 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2182829050172777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.381376601119429d + "'", double1 == 3.381376601119429d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-149), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 305);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.012675565354103E-100d, (double) 123);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.012675565354104E-100d + "'", double2 == 5.012675565354104E-100d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(132412527, 43001979);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89410548 + "'", int2 == 89410548);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 97.0d, 1072693248);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 43001979, 1.490116119384766E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.3001979E7d + "'", double2 == 4.3001979E7d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.18000123927986528d, (java.lang.Number) (-97), (int) (short) 10, orderDirection10, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(107800166400L, (long) 47788349);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 13898959032L, (float) 940900L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 940900.0f + "'", float2 == 940900.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 20, (long) 1994730913);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1994730933L + "'", long2 == 1994730933L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.381376601119429d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.381376601119429d + "'", double2 == 3.381376601119429d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 43001979 + "'", int20 == 43001979);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 51.99991685582412d + "'", double21 == 51.99991685582412d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 132412511);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 305, 1.414213562373095d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3260.847779066595d + "'", double2 == 3260.847779066595d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 20, 2.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.32411944E8d), 305, (-85212565));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(153.66949979849932d, (-1.18114516645089d), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.007096563783077644d), 132412511);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5638033482883058E-282d) + "'", double2 == (-1.5638033482883058E-282d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.389895903181042E10d, (-0.8414709848078964d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6061573028564453d) + "'", double2 == (-1.6061573028564453d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1920319573));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1495188679);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        int int17 = nonMonotonousSequenceException11.getIndex();
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection22, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection28, false);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection36, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection42, false);
        nonMonotonousSequenceException38.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException44);
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException38);
        java.lang.Number number47 = nonMonotonousSequenceException38.getArgument();
        java.lang.Number number48 = nonMonotonousSequenceException38.getArgument();
        java.lang.Number number49 = nonMonotonousSequenceException38.getPrevious();
        java.lang.Number number50 = nonMonotonousSequenceException38.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException38);
        java.lang.Number number52 = nonMonotonousSequenceException38.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (byte) -1 + "'", number47.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (byte) -1 + "'", number48.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 1L + "'", number49.equals(1L));
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 1L + "'", number50.equals(1L));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (byte) -1 + "'", number52.equals((byte) -1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1222131489L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0022976329739E10d + "'", double1 == 7.0022976329739E10d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-97), (-2034178903));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 0, 315L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 315L + "'", long2 == 315L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.8184464592320668d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.305154745528428E30d + "'", double2 == 2.305154745528428E30d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray14 = new double[] { 0L, ' ', 10L };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) '4');
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray33 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray33);
        double[] doubleArray42 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) '4');
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray42);
        double[] doubleArray48 = null;
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 132412511 + "'", int15 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 51.99991685582412d + "'", double26 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.3241251100007592E8d + "'", double34 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.3241245900015907E8d + "'", double35 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241251100007592E8d + "'", double43 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 112.80514172678478d + "'", double47 == 112.80514172678478d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.999642820723645d, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.999642820723645d + "'", double2 == 0.999642820723645d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3156541846684752E35d + "'", double1 == 1.3156541846684752E35d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 1, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection12, false);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 0.9957901442164847d, (int) (short) 100, orderDirection16, true);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 6724520L);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5.078 >= 5.078)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int[] intArray25 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray31 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray31);
        int[] intArray38 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray44 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        int[] intArray49 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray55 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray49);
        int[] intArray61 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray67 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray67);
        int[] intArray72 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray78 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray72);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray72);
        try {
            int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.93475175845634d + "'", double32 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 68.93475175845634d + "'", double45 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 68.93475175845634d + "'", double56 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 68.93475175845634d + "'", double68 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 68.93475175845634d + "'", double79 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.381376601119429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.411230791712423d + "'", double1 == 29.411230791712423d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, (double) 4.7788296E7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        int int17 = nonMonotonousSequenceException11.getIndex();
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection22, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection28, false);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException30.getDirection();
        java.lang.Number number34 = nonMonotonousSequenceException30.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean36 = nonMonotonousSequenceException30.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) -1 + "'", number34.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.9444990484867315d), (double) (-893123829));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 315L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs(53687091200L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 53687091200L + "'", long1 == 53687091200L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.4258259770489514E8d, 0.0d, 700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5752220392306202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.23411976465626E222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.654317432383849d) + "'", double1 == (-0.654317432383849d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1222131453), 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1078034432, 47788297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3241251054776098E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.460139105621001d + "'", double1 == 1.460139105621001d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5430806348152437d, 2.237160944224742d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray28 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray28);
        double[] doubleArray34 = new double[] { 0L, ' ', 10L };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) '4');
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray53);
        double[] doubleArray62 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) '4');
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray62);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray62);
        double[] doubleArray74 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) '4');
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray77);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray86 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) '4');
        double[] doubleArray90 = null;
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray86);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray77);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 43001979 + "'", int20 == 43001979);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 51.99991685582412d + "'", double21 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241251100007592E8d + "'", double29 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.3241245900015907E8d + "'", double30 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 132412511 + "'", int35 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241251100007592E8d + "'", double43 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 51.99991685582412d + "'", double46 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241245900015907E8d + "'", double55 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.3241251100007592E8d + "'", double63 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 112.80514172678478d + "'", double67 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.3241251100007592E8d + "'", double75 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 43001979 + "'", int79 == 43001979);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.3241251100007592E8d + "'", double87 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.3241245900008315E8d + "'", double93 == 1.3241245900008315E8d);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2311033.3802147745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5707963267948966d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(43001988);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection23, false);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection31, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection37, false);
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection45, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection51, false);
        nonMonotonousSequenceException47.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException53);
        nonMonotonousSequenceException39.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException47);
        java.lang.Number number56 = nonMonotonousSequenceException47.getArgument();
        boolean boolean57 = nonMonotonousSequenceException47.getStrict();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException47);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (byte) -1 + "'", number56.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1078001664);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.332621544395286E157d, (java.lang.Number) (-9.338683839135873d), 1994730913);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(100, 873);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87300 + "'", int2 == 87300);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double[] doubleArray5 = new double[] { 608400L, 153.66949979849932d, 52.0d, 0.3180883634683638d, 1.4711276743037347d };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (608,400 >= 153.669)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double[] doubleArray3 = new double[] { 0L, ' ', 10L };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) '4');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray31);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray46);
        java.lang.Class<?> wildcardClass48 = doubleArray46.getClass();
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray56 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 6724520L);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 132412511 + "'", int4 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.3241251100007592E8d + "'", double12 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.99991685582412d + "'", double15 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.3241245900015907E8d + "'", double24 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 112.80514172678478d + "'", double36 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 51.99991685582412d + "'", double49 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.3241251100007592E8d + "'", double57 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.3241245900008315E8d + "'", double60 == 1.3241245900008315E8d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0, 0.793803221553741d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1920319573));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1920319573L) + "'", long1 == (-1920319573L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251568E-16d + "'", double1 == 1.1102230246251568E-16d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 89410548, 1.3241251100000001E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        long long2 = org.apache.commons.math.util.FastMath.min(608400L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.521314196056932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0224060825354249d + "'", double1 == 1.0224060825354249d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.101436247769596d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9126365759632116d + "'", double1 == 0.9126365759632116d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 17533064065275529L, 0.4310759506455924d, (double) 4.300198E7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray14);
        int[] intArray27 = new int[] { 1, 52, (-1), 132412511 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray27);
        int[] intArray32 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray38 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray38);
        int[] intArray43 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray49 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray43);
        int[] intArray55 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray61 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray61);
        try {
            int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 68.93475175845634d + "'", double39 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 68.93475175845634d + "'", double50 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 68.93475175845634d + "'", double62 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116 + "'", int63 == 116);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.000000000000004d + "'", double1 == 22.000000000000004d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1994730913, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1994730913 + "'", int2 == 1994730913);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5042281630190728d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-2034178903));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1654986591645168E11d) + "'", double1 == (-1.1654986591645168E11d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-100L), 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-200L) + "'", long2 == (-200L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double2 = org.apache.commons.math.util.FastMath.min(1.024E13d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int[] intArray25 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray31 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray31);
        int[] intArray38 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray44 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        int[] intArray49 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray55 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray55);
        int[] intArray61 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray67 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray67);
        try {
            int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.93475175845634d + "'", double32 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.93475175845634d + "'", double34 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 68.93475175845634d + "'", double45 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 68.93475175845634d + "'", double56 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 116 + "'", int57 == 116);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 68.93475175845634d + "'", double68 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116 + "'", int69 == 116);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-100L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-65L) + "'", long2 == (-65L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 873);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.773080375655535d + "'", double1 == 6.773080375655535d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        long long2 = org.apache.commons.math.util.MathUtils.pow(132412504L, (long) 22);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.302585092994046d, (double) 1128273093, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1128273093);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double[] doubleArray1 = new double[] { 1.4422495703074083d };
        double[] doubleArray8 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) '4');
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray11);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        java.lang.Class<?> wildcardClass25 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.3241251100007592E8d + "'", double9 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 51.99991685582412d + "'", double12 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.3241251100007592E8d + "'", double20 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.3241245900015907E8d + "'", double21 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43001979 + "'", int22 == 43001979);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.4422499630189163d + "'", double23 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.4422495703074083d + "'", double24 == 1.4422495703074083d);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1222131453), 9409L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1222122044L) + "'", long2 == (-1222122044L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 9700, (-0.8391043258807425d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9092974268256817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7890723435728884d + "'", double1 == 0.7890723435728884d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 7L, 1299.9999999999998d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long1 = org.apache.commons.math.util.FastMath.round((-3.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3L) + "'", long1 == (-3L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100, (double) 52L, 87300);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11012.453125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.0d + "'", double1 == 11013.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1920319573));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9700.0f + "'", float1 == 9700.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-2034178903));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.034178903E9d + "'", double1 == 2.034178903E9d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) -1 + "'", number13.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 123);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 3.52576722732819E-4d, (double) (-6083009866548055583L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.math.util.MathUtils.pow(34, 123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection23, false);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Number number27 = nonMonotonousSequenceException19.getArgument();
        int int28 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        int int30 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) -1 + "'", number13.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) -1 + "'", number27.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(10, 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-107800166400L), 47788297);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.3939501703742397E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.atanh(184756.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(89410548);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1837705465), 2, 132412511);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-2147483648L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.atan((-72.78045395879425d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5570572385648913d) + "'", double1 == (-1.5570572385648913d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-1222122044L), 315);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.222122044E9d) + "'", double2 == (-1.222122044E9d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int1 = org.apache.commons.math.util.MathUtils.hash(10.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.22213146E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1994730913);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.10692217804921d + "'", double1 == 22.10692217804921d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9999999963994413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(8.121929028523127d, (-2034178903), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.acosh(17.576756695854613d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.558914371104247d + "'", double1 == 3.558914371104247d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long2 = org.apache.commons.math.util.FastMath.max((-132412411L), (long) 305);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 305L + "'", long2 == 305L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.5570572385648913d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(123, (-1837705465));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 970, (java.lang.Number) 1.0333147966386297E40d, (int) (byte) 0, orderDirection3, true);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (10,333,147,966,386,297,000,000,000,000,000,000,000,000 <= 970)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (10,333,147,966,386,297,000,000,000,000,000,000,000,000 <= 970)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0333147966386297E40d + "'", number8.equals(1.0333147966386297E40d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1.32412504E8f, 6.283185307179586d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 4.7788296E7f, 0.3183098861837907d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 278.23000718920764d + "'", double2 == 278.23000718920764d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881373587019543d + "'", double1 == 0.881373587019543d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.3156541846684752E35d, 2.4258259770489514E8d, 8.525161361065415d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double[] doubleArray3 = new double[] { 0L, ' ', 10L };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) '4');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray31);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.0d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 132412511 + "'", int4 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.3241251100007592E8d + "'", double12 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.99991685582412d + "'", double15 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.3241245900015907E8d + "'", double24 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 112.80514172678478d + "'", double36 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long long1 = org.apache.commons.math.util.MathUtils.sign(9409L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (byte) 10, 116);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.4288992701045702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.174102103339261d + "'", double1 == 4.174102103339261d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.log1p(6.773080375655535d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0506665305594143d + "'", double1 == 2.0506665305594143d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1128273093);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 305L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 305L + "'", long1 == 305L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7890723435728884d, 2.302585092994046d, (-74.68593339876537d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.15040097899457183d) + "'", double1 == (-0.15040097899457183d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1222131505L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(7.972183027104449E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28235.054501637587d + "'", double1 == 28235.054501637587d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.acosh(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.094423520532044d + "'", double1 == 5.094423520532044d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.0d, 4.23411976465626E222d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.447063905441356E-223d + "'", double2 == 9.447063905441356E-223d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(20L, (-1986186165L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1986186145L) + "'", long2 == (-1986186145L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 1, 9409.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1128273093);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-135L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 116, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray28 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray28);
        double[] doubleArray31 = null;
        double[] doubleArray35 = new double[] { 0L, ' ', 10L };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray54 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray54);
        double[] doubleArray63 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) '4');
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray63);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray63);
        double[] doubleArray75 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) '4');
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray78);
        java.lang.Class<?> wildcardClass80 = doubleArray78.getClass();
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 43001979 + "'", int20 == 43001979);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 51.99991685582412d + "'", double21 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241251100007592E8d + "'", double29 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.3241245900015907E8d + "'", double30 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 132412511 + "'", int36 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 51.99991685582412d + "'", double47 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241251100007592E8d + "'", double55 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.3241245900015907E8d + "'", double56 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.3241251100007592E8d + "'", double64 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 112.80514172678478d + "'", double68 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.3241251100007592E8d + "'", double76 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.3241245900008315E8d + "'", double82 == 1.3241245900008315E8d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException11.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) -1 + "'", number16.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 20, 2.6007432520305066E-10d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(10.0d, 349.9541180407703d, 0.8159972568892158d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-6083009866548055583L), 1303L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6083009866548056886L) + "'", long2 == (-6083009866548056886L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2L, (float) (-132411943L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.32411944E8f) + "'", float2 == (-1.32411944E8f));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 43002014L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.tan(1299.9999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7129411290395627d) + "'", double1 == (-0.7129411290395627d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6658515232507248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.510336418074832d + "'", double1 == 0.510336418074832d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-132412477));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(43001988L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1), (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1222131505L), 0.7890723435728884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963261492441d) + "'", double2 == (-1.5707963261492441d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 4.300198E7f, (-9.338683839135873d), 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection20, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection26, false);
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException28.getDirection();
        java.lang.Number number31 = nonMonotonousSequenceException28.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection35, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection41, false);
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException43.getDirection();
        boolean boolean46 = nonMonotonousSequenceException43.getStrict();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number49 = nonMonotonousSequenceException28.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (byte) -1 + "'", number31.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 1L + "'", number49.equals(1L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.952327990396092E38d + "'", double1 == 2.952327990396092E38d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.22213146E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1837705465), 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-132412477), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 468L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1L, 153L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 154L + "'", long2 == 154L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 9, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 107800166400L, 0.9126365759632116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0035986131973471916d) + "'", double2 == (-0.0035986131973471916d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8934439858858716d + "'", double1 == 2.8934439858858716d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-4593512421086650189L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 512.0d + "'", double1 == 512.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.3956124250860895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (short) -1, (-4.5935124210866504E18d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.atanh(700.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 9700.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.87302834770845d + "'", double1 == 9.87302834770845d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(315, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 873);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 873.0d + "'", double1 == 873.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1078001664, (-1222131453));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-2147483648L), (int) '#', 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1000L, 940900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 941900L + "'", long2 == 941900L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.0f, 29.411230791712423d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.01935156481456992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.17453292519943295d, (double) (-1986186165L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9861861644454296E9d) + "'", double2 == (-1.9861861644454296E9d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.MathUtils.log(873.0d, 1.5139642754265628d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.061242691275714634d + "'", double2 == 0.061242691275714634d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 17533064065275224L, 1.3241251218114516E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3241251E8d + "'", double2 == 1.3241251E8d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 10L, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 48459472266975L, 32, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 305L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2624039418616639d) + "'", double1 == (-0.2624039418616639d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1986186145L), 6724520L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2671229691155080L + "'", long2 == 2671229691155080L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 132412511, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132412511L + "'", long2 == 132412511L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 970, (java.lang.Number) 1.0333147966386297E40d, (int) (byte) 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 970 + "'", number6.equals(970));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 970 + "'", number7.equals(970));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.413328698605074d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9969029422377658d + "'", double1 == 1.9969029422377658d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 154L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 154.0d + "'", double1 == 154.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2034178903), (-0.6420149920119999d), (-1.713283911117653d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9075697598974284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6458300548825572d + "'", double1 == 0.6458300548825572d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int13 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection19, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection25, false);
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        int int29 = nonMonotonousSequenceException27.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        int int31 = nonMonotonousSequenceException11.getIndex();
        java.lang.String str32 = nonMonotonousSequenceException11.toString();
        java.lang.String str33 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str32.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(132412504L, 6724520L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 139137024L + "'", long2 == 139137024L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.4414081882099245E132d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.sin(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 4.7788296E7f, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.05249168451567616E17d + "'", double2 == 2.05249168451567616E17d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) -1, 43001988);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1222131453));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.8159972568892158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9544522916640735d + "'", double1 == 0.9544522916640735d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1994730933L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.99473088E9f + "'", float1 == 1.99473088E9f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 107800166400L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.36652945641663E41d + "'", double2 == 1.36652945641663E41d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9410979135471444d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5604874136486533d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.32371243907207115d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.abs((-572.9577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(47788349);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.972192221896232E8d + "'", double1 == 7.972192221896232E8d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (short) -1, 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 20);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.6458300548825572d, (-0.413328698605074d), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-6083009866548056886L), (-0.9649581189333869d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.atan((-3.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2490457723982544d) + "'", double1 == (-1.2490457723982544d));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 47788349);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int2 = org.apache.commons.math.util.MathUtils.pow(7, 87300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-62537375) + "'", int2 == (-62537375));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.4422495703074083d, (double) 1.32412512E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.089209432343832E-8d + "'", double2 == 1.089209432343832E-8d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double[] doubleArray1 = new double[] { 1.4422495703074083d };
        double[] doubleArray8 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) '4');
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection63, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection69, false);
        nonMonotonousSequenceException65.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = nonMonotonousSequenceException71.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 0.9957901442164847d, (int) (short) 100, orderDirection73, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection73, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.3241251100007592E8d + "'", double9 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 51.99991685582412d + "'", double12 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.3241251100007592E8d + "'", double20 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.3241245900015907E8d + "'", double21 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43001979 + "'", int22 == 43001979);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.4422499630189163d + "'", double23 == 1.4422499630189163d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99991685582412d + "'", double35 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241251100007592E8d + "'", double43 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241245900015907E8d + "'", double44 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 43001979 + "'", int45 == 43001979);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 51.99991685582412d + "'", double46 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241245900015907E8d + "'", double55 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.4422499630189163d + "'", double56 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 32, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9544522916640735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7417920669435751d + "'", double1 == 0.7417920669435751d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1837705465), 132412527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1970117992) + "'", int2 == (-1970117992));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.3183098861837907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(305, (-1920319573));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 13898959032L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.96351692158836E11d + "'", double1 == 7.96351692158836E11d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.abs(155.56861987947772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.56861987947772d + "'", double1 == 155.56861987947772d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(112.80514172678478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.831807591677152d + "'", double1 == 4.831807591677152d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 6724520L);
        double[] doubleArray16 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) '4');
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.45231565944180985d);
        double[] doubleArray33 = new double[] { 1.4422495703074083d };
        double[] doubleArray40 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) '4');
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray51 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray43);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double[] doubleArray63 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) '4');
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 0.45231565944180985d);
        double[] doubleArray85 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) '4');
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        try {
            double double94 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3241251100007592E8d + "'", double17 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 51.99991685582412d + "'", double20 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.3241251100007592E8d + "'", double28 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241245900015907E8d + "'", double29 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.3241251100007592E8d + "'", double41 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 51.99991685582412d + "'", double44 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.3241251100007592E8d + "'", double52 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.3241245900015907E8d + "'", double53 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 43001979 + "'", int54 == 43001979);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.4422499630189163d + "'", double55 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.3241251100007592E8d + "'", double64 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 51.99991685582412d + "'", double67 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.3241251100007592E8d + "'", double75 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.3241245900015907E8d + "'", double76 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.3241251100007592E8d + "'", double86 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 51.99991685582412d + "'", double89 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 43001979 + "'", int90 == 43001979);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 51.99991685582412d + "'", double92 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.845098040014257d + "'", double1 == 2.845098040014257d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(17533064197688031L, 1303L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.141592653589793d, 0.3180883634683638d, 1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.7151846296803903d, 1.3241251100000001E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0505499134295473E-8d + "'", double2 == 2.0505499134295473E-8d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, (-1222131389L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(9.0d, (-2034178903), 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3L, 15.154262241479262d, 51);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.713283911117653d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 153L, 873);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-132412477), 17533064065275529L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17533064065275529L + "'", long2 == 17533064065275529L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 22);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 22.0f + "'", float1 == 22.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.414213562373095d, 116, (-893123829));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.447063905441356E-223d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1994716129) + "'", int1 == (-1994716129));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.8184464592320668d, 1128273093);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0318615147099808E-249d) + "'", double2 == (-2.0318615147099808E-249d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-2034178903));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 337530822 + "'", int1 == 337530822);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-107800166400L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.3001979E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.6334884427656915d + "'", double1 == 7.6334884427656915d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1970117992));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.52576722732819E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5257671542799707E-4d + "'", double1 == 3.5257671542799707E-4d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 1.4422495703074083d };
        double[] doubleArray9 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) '4');
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray20 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection32, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection38, false);
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException40.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20L, (java.lang.Number) 0.4622697990307029d, (int) 'a', orderDirection42, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection42, true);
        try {
            double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.3241251100007592E8d + "'", double10 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 51.99991685582412d + "'", double13 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.3241251100007592E8d + "'", double21 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.3241245900015907E8d + "'", double22 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 43001979 + "'", int23 == 43001979);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.4422499630189163d + "'", double24 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 13898959032L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(47788349, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1222131389L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865476d + "'", double1 == 0.7071067811865476d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 53687091200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int2 = org.apache.commons.math.util.FastMath.min(43001979, 1078001664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43001979 + "'", int2 == 43001979);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5707963058692709d, (double) (-3L), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, (long) 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1272254651 + "'", int2 == 1272254651);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.952327990396092E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9523279903960922E38d + "'", double1 == 2.9523279903960922E38d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.0f + "'", float1 == 7.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.36787944117144233d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), (-132412411));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132412411 + "'", int2 == 132412411);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(132412511L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132412459L + "'", long2 == 132412459L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5430806348152437d, (double) 1222131489L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray28 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray28);
        double[] doubleArray34 = new double[] { 0L, ' ', 10L };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray42 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) '4');
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray53);
        double[] doubleArray62 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) '4');
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray62);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray62);
        double[] doubleArray74 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) '4');
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray77);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray86 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) '4');
        double[] doubleArray90 = null;
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray86);
        int int93 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 43001979 + "'", int20 == 43001979);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 51.99991685582412d + "'", double21 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241251100007592E8d + "'", double29 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.3241245900015907E8d + "'", double30 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 132412511 + "'", int35 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241251100007592E8d + "'", double43 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 51.99991685582412d + "'", double46 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241245900015907E8d + "'", double55 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.3241251100007592E8d + "'", double63 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 112.80514172678478d + "'", double67 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.3241251100007592E8d + "'", double75 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 43001979 + "'", int79 == 43001979);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.3241251100007592E8d + "'", double87 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1222131505) + "'", int93 == (-1222131505));
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 1.3241245900015907E8d + "'", double94 == 1.3241245900015907E8d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double[] doubleArray3 = new double[] { 0L, ' ', 10L };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) '4');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray31);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray46);
        double[] doubleArray54 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) '4');
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray57);
        double[] doubleArray66 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) '4');
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double[] doubleArray86 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) '4');
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray86);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 132412511 + "'", int4 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.3241251100007592E8d + "'", double12 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.99991685582412d + "'", double15 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.3241245900015907E8d + "'", double24 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 112.80514172678478d + "'", double36 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241251100007592E8d + "'", double55 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 51.99991685582412d + "'", double58 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.3241251100007592E8d + "'", double67 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 51.99991685582412d + "'", double70 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.3241251100007592E8d + "'", double78 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.3241245900015907E8d + "'", double79 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.3241251100007592E8d + "'", double87 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1300.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1300.0000000000002d + "'", double1 == 1300.0000000000002d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) '4');
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) '4');
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1222131505L));
        double[] doubleArray30 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) '4');
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 1.0d);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray41);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3241251100007592E8d + "'", double8 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3241251100007592E8d + "'", double31 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 51.99991685582412d + "'", double34 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.3241251100007592E8d + "'", double42 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241245900015907E8d + "'", double43 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-6083009866548055583L), 4593512421086651489L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5042281630190728d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5042281630190726d + "'", double2 == 1.5042281630190726d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(116);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.5570572385648913d), 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection15, false);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        int int19 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection25, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection31, false);
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException33.getDirection();
        java.lang.Number number37 = nonMonotonousSequenceException33.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException33.getDirection();
        int int39 = nonMonotonousSequenceException33.getIndex();
        java.lang.Class<?> wildcardClass40 = nonMonotonousSequenceException33.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection44, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection50, false);
        nonMonotonousSequenceException46.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException52.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = nonMonotonousSequenceException52.getDirection();
        java.lang.Number number56 = nonMonotonousSequenceException52.getArgument();
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection61, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection67, false);
        nonMonotonousSequenceException63.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection74, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection80, false);
        nonMonotonousSequenceException76.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException82);
        java.lang.Number number84 = nonMonotonousSequenceException76.getArgument();
        java.lang.String str85 = nonMonotonousSequenceException76.toString();
        nonMonotonousSequenceException63.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException76);
        java.lang.Number number87 = nonMonotonousSequenceException76.getArgument();
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException76);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException76);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1L + "'", number37.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (byte) -1 + "'", number56.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (byte) -1 + "'", number84.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str85.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + (byte) -1 + "'", number87.equals((byte) -1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1222131453));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.5570572385648913d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.267041196168671d) + "'", double1 == (-2.267041196168671d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1040 + "'", int2 == 1040);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1222131505));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double[] doubleArray16 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) '4');
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.45231565944180985d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray31);
        double[] doubleArray33 = null;
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3241251100007592E8d + "'", double17 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 51.99991685582412d + "'", double20 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.3241251100007592E8d + "'", double28 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3241245900015907E8d + "'", double29 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251054776098E8d + "'", double32 == 1.3241251054776098E8d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 116);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double[] doubleArray3 = new double[] { 0L, ' ', 10L };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) '4');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray31);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.0d);
        double[] doubleArray56 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) '4');
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray67 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray67);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 0.45231565944180985d);
        double[] doubleArray78 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) '4');
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray81);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 132412511 + "'", int4 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.3241251100007592E8d + "'", double12 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.99991685582412d + "'", double15 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.3241245900015907E8d + "'", double24 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 112.80514172678478d + "'", double36 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.3241251100007592E8d + "'", double57 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 51.99991685582412d + "'", double60 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.3241251100007592E8d + "'", double68 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.3241245900015907E8d + "'", double69 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.3241251100007592E8d + "'", double79 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 51.99991685582412d + "'", double82 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 43001979 + "'", int83 == 43001979);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 51.99991685582412d + "'", double85 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(7.972192221896232E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.log1p(608400.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.318589483021414d + "'", double1 == 13.318589483021414d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.lang.Class<?> wildcardClass3 = bigInteger2.getClass();
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) ' ');
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.lang.Class<?> wildcardClass18 = bigInteger17.getClass();
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) ' ');
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger23);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger23);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.lang.Class<?> wildcardClass29 = bigInteger28.getClass();
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) ' ');
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0L);
        java.lang.Class<?> wildcardClass35 = bigInteger34.getClass();
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) (short) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger34);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger34);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 0L);
        java.lang.Class<?> wildcardClass43 = bigInteger42.getClass();
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (int) (short) 10);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 15L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger42);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.lang.Class<?> wildcardClass52 = bigInteger51.getClass();
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0L);
        java.lang.Class<?> wildcardClass56 = bigInteger55.getClass();
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (int) ' ');
        java.math.BigInteger bigInteger59 = null;
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, 0L);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, bigInteger61);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger61);
        java.math.BigInteger bigInteger64 = null;
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0L);
        java.lang.Class<?> wildcardClass67 = bigInteger66.getClass();
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, (int) ' ');
        java.math.BigInteger bigInteger70 = null;
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, 0L);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, bigInteger72);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, bigInteger72);
        java.math.BigInteger bigInteger75 = null;
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 0L);
        java.lang.Class<?> wildcardClass78 = bigInteger77.getClass();
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, (int) ' ');
        java.math.BigInteger bigInteger81 = null;
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, 0L);
        java.lang.Class<?> wildcardClass84 = bigInteger83.getClass();
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger83, (int) (short) 10);
        java.math.BigInteger bigInteger87 = org.apache.commons.math.util.MathUtils.pow(bigInteger80, bigInteger83);
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, bigInteger83);
        java.math.BigInteger bigInteger89 = null;
        java.math.BigInteger bigInteger91 = org.apache.commons.math.util.MathUtils.pow(bigInteger89, 0L);
        java.lang.Class<?> wildcardClass92 = bigInteger91.getClass();
        java.math.BigInteger bigInteger94 = org.apache.commons.math.util.MathUtils.pow(bigInteger91, (int) (short) 10);
        java.math.BigInteger bigInteger96 = org.apache.commons.math.util.MathUtils.pow(bigInteger91, 15L);
        java.math.BigInteger bigInteger97 = org.apache.commons.math.util.MathUtils.pow(bigInteger88, bigInteger91);
        java.math.BigInteger bigInteger98 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger91);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger87);
        org.junit.Assert.assertNotNull(bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger91);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertNotNull(bigInteger94);
        org.junit.Assert.assertNotNull(bigInteger96);
        org.junit.Assert.assertNotNull(bigInteger97);
        org.junit.Assert.assertNotNull(bigInteger98);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection10, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection16, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException18.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection24, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection30, false);
        nonMonotonousSequenceException26.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException32);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        java.lang.Number number35 = nonMonotonousSequenceException26.getArgument();
        java.lang.Number number36 = nonMonotonousSequenceException26.getArgument();
        java.lang.Number number37 = nonMonotonousSequenceException26.getPrevious();
        java.lang.Number number38 = nonMonotonousSequenceException26.getPrevious();
        java.lang.Class<?> wildcardClass39 = nonMonotonousSequenceException26.getClass();
        boolean boolean40 = nonMonotonousSequenceException26.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (byte) -1 + "'", number35.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (byte) -1 + "'", number36.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1L + "'", number37.equals(1L));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1L + "'", number38.equals(1L));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.7890723435728884d, 132412527);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1395431654146069E-275d) + "'", double2 == (-1.1395431654146069E-275d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5001941075779681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5495649879394626d + "'", double1 == 0.5495649879394626d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1.32412408E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-200L), (-132412411), (-1837705465));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection23, false);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number28 = nonMonotonousSequenceException19.getArgument();
        boolean boolean29 = nonMonotonousSequenceException19.getStrict();
        java.lang.String str30 = nonMonotonousSequenceException19.toString();
        java.lang.String str31 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) -1 + "'", number28.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1495188679, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(20.0d, (-1.5638033482883058E-282d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1504440784612413d + "'", double2 == 1.1504440784612413d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int1 = org.apache.commons.math.util.FastMath.round(97.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 132412511);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8194481290907046d) + "'", double1 == (-0.8194481290907046d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1920319573L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.signum(23.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1272254651);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1222131489L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963035401535d, 1.7533064197688032E16d, (-1.713283911117653d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.4622697990307029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0902431171165619d + "'", double1 == 1.0902431171165619d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 101L, (-2034178903), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.3183098861837907d, 47788297);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8871176574010088E79d + "'", double2 == 1.8871176574010088E79d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.679322026700427d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double[] doubleArray3 = new double[] { 0L, ' ', 10L };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) '4');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray22 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) '4');
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray31);
        double[] doubleArray43 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) '4');
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray46);
        double[] doubleArray54 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) '4');
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 1500.8558706328693d);
        java.lang.Class<?> wildcardClass62 = doubleArray57.getClass();
        double[] doubleArray69 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) '4');
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray72);
        java.lang.Class<?> wildcardClass78 = doubleArray72.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 132412511 + "'", int4 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.3241251100007592E8d + "'", double12 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 51.99991685582412d + "'", double15 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3241251100007592E8d + "'", double23 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.3241245900015907E8d + "'", double24 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.3241251100007592E8d + "'", double32 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 112.80514172678478d + "'", double36 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.3241251100007592E8d + "'", double44 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.3241251100007592E8d + "'", double55 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 51.99991685582412d + "'", double58 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.3241251100007592E8d + "'", double70 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 51.99991685582412d + "'", double73 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 43001979 + "'", int74 == 43001979);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(wildcardClass78);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        long long2 = org.apache.commons.math.util.FastMath.min((-13L), 132412411L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-13L) + "'", long2 == (-13L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1), 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9075697598974284d, (double) (-1920319573));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9203195761195264E9d) + "'", double2 == (-1.9203195761195264E9d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.22213146E9f), (java.lang.Number) 4.0d, 116);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection13, false);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 91L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int[] intArray25 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray31 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray31);
        int[] intArray38 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray44 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray38);
        java.lang.Class<?> wildcardClass47 = intArray38.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.93475175845634d + "'", double32 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.93475175845634d + "'", double34 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 68.93475175845634d + "'", double45 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 97L, (-1222131505), 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 47788349);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 47788348 + "'", int1 == 47788348);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.9444990484867315d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number18 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1L + "'", number18.equals(1L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.45231565944180985d);
        double[] doubleArray23 = new double[] { 1.4422495703074083d };
        double[] doubleArray30 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) '4');
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray33);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) '4');
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray64 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray64);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 0.45231565944180985d);
        double[] doubleArray75 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) '4');
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray78);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray56);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3241251100007592E8d + "'", double31 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 51.99991685582412d + "'", double34 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.3241251100007592E8d + "'", double42 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241245900015907E8d + "'", double43 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 43001979 + "'", int44 == 43001979);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4422499630189163d + "'", double45 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 51.99991685582412d + "'", double57 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.3241251100007592E8d + "'", double65 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.3241245900015907E8d + "'", double66 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.3241251100007592E8d + "'", double76 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 51.99991685582412d + "'", double79 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 43001979 + "'", int80 == 43001979);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 51.99991685582412d + "'", double82 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.4422495703074083d + "'", double84 == 1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1994730913 + "'", int85 == 1994730913);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 9409.0f, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9553166181245092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9553166181245093d + "'", double1 == 0.9553166181245093d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 7, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.tan(11013.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.755849220270756d) + "'", double1 == (-6.755849220270756d));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1222131453L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 47788348);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 47788348 + "'", int1 == 47788348);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray14);
        int[] intArray26 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray32 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray32);
        int[] intArray37 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray43 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray37);
        int[] intArray49 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray55 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray55);
        java.lang.Class<?> wildcardClass58 = intArray37.getClass();
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray37);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 68.93475175845634d + "'", double33 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 68.93475175845634d + "'", double44 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 68.93475175845634d + "'", double56 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 116 + "'", int57 == 116);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        int int14 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number16 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) -1 + "'", number13.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) -1 + "'", number16.equals((byte) -1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 87300, (long) 315);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException11.getSuppressed();
        int int18 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.8871176574010088E79d, 1.460139105621001d, (double) (-100L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.math.util.FastMath.cosh(19.802574457953003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9912180430805913E8d + "'", double1 == 1.9912180430805913E8d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int2 = org.apache.commons.math.util.FastMath.max(132412411, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132412411 + "'", int2 == 132412411);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9250416283748899d), (-1.1654986591645168E11d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9553166181245093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.762549891340708d + "'", double1 == 0.762549891340708d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1048576 + "'", int1 == 1048576);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6049088194604227d) + "'", double1 == (-0.6049088194604227d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.3939501703742397E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3939501703742397E20d + "'", double1 == 1.3939501703742397E20d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(10.067661995777765d, (double) 43001979L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection21, false);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        int int25 = nonMonotonousSequenceException23.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 0.9553166181245092d, (-1), orderDirection27, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 3.5257671542799707E-4d, 7, orderDirection27, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 305);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 305L + "'", long1 == 305L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5213141960569319d, 1.3241251100000001E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3241251100000001E8d + "'", double2 == 1.3241251100000001E8d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1040, 47788349);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int1 = org.apache.commons.math.util.MathUtils.sign(700);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        java.lang.Class<?> wildcardClass17 = orderDirection16.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.45231565944180985d);
        double[] doubleArray23 = new double[] { 1.4422495703074083d };
        double[] doubleArray30 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) '4');
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray33);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3241251100007592E8d + "'", double31 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 51.99991685582412d + "'", double34 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.3241251100007592E8d + "'", double42 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241245900015907E8d + "'", double43 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 43001979 + "'", int44 == 43001979);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4422499630189163d + "'", double45 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1994730913 + "'", int47 == 1994730913);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4422495703074083d + "'", double48 == 1.4422495703074083d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-9.338683839135873d), (double) 15L, 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.1102230246251568E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251568E-16d + "'", double1 == 1.1102230246251568E-16d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.3241251E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.05249168451567616E17d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.490116119384766E-8d, (java.lang.Number) 401.07045659157626d, (int) '#');
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5403023058681398d, (double) 47788297);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int2 = org.apache.commons.math.util.FastMath.min((-1970117992), (-1994716129));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1994716129) + "'", int2 == (-1994716129));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(700, (-2034178903));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, (-1986186145L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection20, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection26, false);
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException28.getDirection();
        java.lang.Number number31 = nonMonotonousSequenceException28.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection35, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection41, false);
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException43.getDirection();
        boolean boolean46 = nonMonotonousSequenceException43.getStrict();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection52, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection58, false);
        nonMonotonousSequenceException54.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException60);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = nonMonotonousSequenceException60.getDirection();
        java.lang.String str63 = nonMonotonousSequenceException60.toString();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException60);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (byte) -1 + "'", number31.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str63.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 315);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.74823934929885d + "'", double1 == 17.74823934929885d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(22, (-1222131453));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 1.0d);
        double[] doubleArray25 = new double[] { 0L, ' ', 10L };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) '4');
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double[] doubleArray44 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray44);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) '4');
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray53);
        double[] doubleArray62 = new double[] { 0L, ' ', 10L };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray70 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) '4');
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray81 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray81);
        double[] doubleArray90 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (double) '4');
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray90);
        double double95 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray90);
        double[] doubleArray96 = null;
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray90, doubleArray96);
        double double98 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray90);
        double double99 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 132412511 + "'", int26 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.3241251100007592E8d + "'", double34 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 51.99991685582412d + "'", double37 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.3241251100007592E8d + "'", double45 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.3241245900015907E8d + "'", double46 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 112.80514172678478d + "'", double58 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 132412511 + "'", int63 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.3241251100007592E8d + "'", double71 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 51.99991685582412d + "'", double74 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.3241251100007592E8d + "'", double82 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.3241245900015907E8d + "'", double83 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.3241251100007592E8d + "'", double91 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 112.80514172678478d + "'", double95 == 112.80514172678478d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 1.324127237182818E8d + "'", double99 == 1.324127237182818E8d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.expm1(90.01157663087223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2346135474966603E39d + "'", double1 == 1.2346135474966603E39d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 873, (long) (-1222131505));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1752011872827488d, 1.490116119384766E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1752011872827488d + "'", double2 == 1.1752011872827488d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1837705465), (long) 123);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 226037772195L + "'", long2 == 226037772195L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1837705465), 132412411);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1078001664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.expm1(17.74823934929885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1046080895620726E7d + "'", double1 == 5.1046080895620726E7d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 153L, (float) 1495188679);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.49518874E9f + "'", float2 == 1.49518874E9f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-100L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(155.56861987947772d, 1.0123623933248276d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(608400.0d, 9.0d, 123);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5001941075779681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5001941075779681d + "'", double1 == 0.5001941075779681d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-97));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int[] intArray25 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray31 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray25);
        int[] intArray37 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray43 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray43);
        int[] intArray49 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray55 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray55);
        int[] intArray60 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray66 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray66);
        int[] intArray71 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray77 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray77);
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray77);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray77);
        java.lang.Class<?> wildcardClass82 = intArray77.getClass();
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray77);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.93475175845634d + "'", double32 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 68.93475175845634d + "'", double44 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 116 + "'", int45 == 116);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 68.93475175845634d + "'", double56 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 68.93475175845634d + "'", double67 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 68.93475175845634d + "'", double78 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 52 + "'", int80 == 52);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 52 + "'", int81 == 52);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 116 + "'", int83 == 116);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 17533064065275224L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray24 = new double[] { 0L, ' ', 10L };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray24);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 43001979 + "'", int20 == 43001979);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 132412511 + "'", int25 == 132412511);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 43001979 + "'", int27 == 43001979);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5604874136486533d, (double) 1300L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7312157338841215E251d + "'", double2 == 1.7312157338841215E251d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.4622697990307029d, 0.9544522916640735d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47880509392651033d + "'", double2 == 0.47880509392651033d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-132412477));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.32412408E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        long long2 = org.apache.commons.math.util.FastMath.min(1303L, 17533064065275529L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1303L + "'", long2 == 1303L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1222131489L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 43001988);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43001988 + "'", int2 == 43001988);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4097167441090804d + "'", double2 == 0.4097167441090804d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.45231565944180985d);
        double[] doubleArray23 = new double[] { 1.4422495703074083d };
        double[] doubleArray30 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) '4');
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray33);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        double[] doubleArray53 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) '4');
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray64 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray64);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 0.45231565944180985d);
        double[] doubleArray75 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) '4');
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray78);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray56);
        java.lang.Class<?> wildcardClass84 = doubleArray23.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.3241251100007592E8d + "'", double31 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 51.99991685582412d + "'", double34 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.3241251100007592E8d + "'", double42 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.3241245900015907E8d + "'", double43 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 43001979 + "'", int44 == 43001979);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4422499630189163d + "'", double45 == 1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.3241251100007592E8d + "'", double54 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 51.99991685582412d + "'", double57 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.3241251100007592E8d + "'", double65 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.3241245900015907E8d + "'", double66 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.3241251100007592E8d + "'", double76 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 51.99991685582412d + "'", double79 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 43001979 + "'", int80 == 43001979);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 51.99991685582412d + "'", double82 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(wildcardClass84);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(132412527);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.cosh(29.411230791712423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9655499481215005E12d + "'", double1 == 2.9655499481215005E12d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.10876299084872d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2096816306 + "'", int1 == 2096816306);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(47788348, (-808182895));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-760394547) + "'", int2 == (-760394547));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double[] doubleArray1 = new double[] { 1.4422495703074083d };
        double[] doubleArray8 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) '4');
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray11);
        double[] doubleArray27 = new double[] { 0L, ' ', 10L };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray35 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) '4');
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray46 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) '4');
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray55);
        double[] doubleArray67 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) '4');
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray70);
        double[] doubleArray78 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) '4');
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray81);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray70);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) 2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.3241251100007592E8d + "'", double9 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 51.99991685582412d + "'", double12 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.3241251100007592E8d + "'", double20 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.3241245900015907E8d + "'", double21 == 1.3241245900015907E8d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43001979 + "'", int22 == 43001979);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.4422499630189163d + "'", double23 == 1.4422499630189163d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 132412511 + "'", int28 == 132412511);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3241251100007592E8d + "'", double36 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 51.99991685582412d + "'", double39 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.3241251100007592E8d + "'", double47 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.3241245900015907E8d + "'", double48 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.3241251100007592E8d + "'", double56 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 112.80514172678478d + "'", double60 == 112.80514172678478d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.3241251100007592E8d + "'", double68 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.3241251100007592E8d + "'", double79 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 51.99991685582412d + "'", double82 == 51.99991685582412d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.4422499630189163d + "'", double84 == 1.4422499630189163d);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5042281630190726d, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 940900.0f, 132412511, (-1970117992));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double1 = org.apache.commons.math.util.FastMath.asin(97.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.1318339846881509d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1278857561 + "'", int1 == 1278857561);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 17L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 17.0f + "'", float1 == 17.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-62537375), 43001979);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 8.525161361065415d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.4422499630189163d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12819263587802546d + "'", double1 == 0.12819263587802546d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 9700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.326712355058866d + "'", double1 == 21.326712355058866d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.9075697598974284d, (-0.9250416283748899d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.6061573028564453d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 87300, 1222131453L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-13L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9912180430805913E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796321772845d + "'", double1 == 1.570796321772845d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6483608274590866d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection23, false);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number28 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number29 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number30 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Class<?> wildcardClass32 = nonMonotonousSequenceException19.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) -1 + "'", number28.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) -1 + "'", number29.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1L + "'", number30.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(17533064197688031L, 132412511L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        java.lang.String str17 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9129452507276277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.30790979320581d + "'", double1 == 52.30790979320581d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.881373587019543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.lang.Class<?> wildcardClass3 = bigInteger2.getClass();
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) ' ');
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.lang.Class<?> wildcardClass9 = bigInteger8.getClass();
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 10);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.lang.Class<?> wildcardClass16 = bigInteger15.getClass();
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.lang.Class<?> wildcardClass20 = bigInteger19.getClass();
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (int) ' ');
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger25);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger25);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 100);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger29);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.lang.Class<?> wildcardClass34 = bigInteger33.getClass();
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.lang.Class<?> wildcardClass38 = bigInteger37.getClass();
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (int) ' ');
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger43);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger43);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (int) (byte) 100);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0L);
        java.lang.Class<?> wildcardClass51 = bigInteger50.getClass();
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (int) ' ');
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, bigInteger56);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger57);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger57);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, 35);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 9700);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-100L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.3241251218114516E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1072693148L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07269312E9f + "'", float1 == 1.07269312E9f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.174102103339261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5126658775009793d) + "'", double1 == (-0.5126658775009793d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection23, false);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number28 = nonMonotonousSequenceException19.getArgument();
        boolean boolean29 = nonMonotonousSequenceException19.getStrict();
        int int30 = nonMonotonousSequenceException19.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection40, false);
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException42);
        java.lang.Number number44 = nonMonotonousSequenceException36.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection48, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection54, false);
        nonMonotonousSequenceException50.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException56);
        java.lang.Number number58 = nonMonotonousSequenceException50.getArgument();
        int int59 = nonMonotonousSequenceException50.getIndex();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection64, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection70, false);
        nonMonotonousSequenceException66.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException72);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException72.getDirection();
        java.lang.Number number75 = nonMonotonousSequenceException72.getArgument();
        nonMonotonousSequenceException50.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException72);
        int int77 = nonMonotonousSequenceException72.getIndex();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException72);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) -1 + "'", number28.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (byte) -1 + "'", number44.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (byte) -1 + "'", number58.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + (byte) -1 + "'", number75.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(2096816306, 43001988);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.MathUtils.sign(15575.063329081366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3241267271828105E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6319676051555495d + "'", double1 == 0.6319676051555495d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 1078001664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078001664 + "'", int2 == 1078001664);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-760394547), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 760394547L + "'", long2 == 760394547L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1222131453), 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1222131462) + "'", int2 == (-1222131462));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 132412527);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.7151846296803903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.107399088685112d + "'", double1 == 15.107399088685112d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 107800166400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-84624214L), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.lang.Class<?> wildcardClass4 = bigInteger3.getClass();
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 10);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 15L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection16, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection22, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection28, false);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        int int32 = nonMonotonousSequenceException30.getIndex();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException18.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 0.9553166181245092d, (-1), orderDirection34, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 91L, (java.lang.Number) bigInteger3, 1994730913, orderDirection34, false);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 100);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(bigInteger40);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        int int17 = nonMonotonousSequenceException11.getIndex();
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection22, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection28, false);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException30.getDirection();
        java.lang.Number number34 = nonMonotonousSequenceException30.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection45, false);
        nonMonotonousSequenceException41.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection52, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection58, false);
        nonMonotonousSequenceException54.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException60);
        java.lang.Number number62 = nonMonotonousSequenceException54.getArgument();
        java.lang.String str63 = nonMonotonousSequenceException54.toString();
        nonMonotonousSequenceException41.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException54);
        java.lang.Number number65 = nonMonotonousSequenceException54.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException54);
        java.lang.Throwable[] throwableArray67 = nonMonotonousSequenceException54.getSuppressed();
        boolean boolean68 = nonMonotonousSequenceException54.getStrict();
        boolean boolean69 = nonMonotonousSequenceException54.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) -1 + "'", number34.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + (byte) -1 + "'", number62.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)" + "'", str63.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (1 < -1)"));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + (byte) -1 + "'", number65.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection9, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        int int17 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.lang.Class<?> wildcardClass4 = bigInteger3.getClass();
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) ' ');
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) 1L, (int) (short) 10, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 13898959032L, (java.lang.Number) bigInteger10, 132412527, orderDirection20, false);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.lang.Class<?> wildcardClass26 = bigInteger25.getClass();
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) ' ');
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.lang.Class<?> wildcardClass32 = bigInteger31.getClass();
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 10);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.lang.Class<?> wildcardClass39 = bigInteger38.getClass();
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 0L);
        java.lang.Class<?> wildcardClass43 = bigInteger42.getClass();
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (int) ' ');
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger48);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger48);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (int) (byte) 100);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger52);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.lang.Class<?> wildcardClass57 = bigInteger56.getClass();
        java.math.BigInteger bigInteger58 = null;
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, 0L);
        java.lang.Class<?> wildcardClass61 = bigInteger60.getClass();
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (int) ' ');
        java.math.BigInteger bigInteger64 = null;
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger66);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, bigInteger66);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (int) (byte) 100);
        java.math.BigInteger bigInteger71 = null;
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 0L);
        java.lang.Class<?> wildcardClass74 = bigInteger73.getClass();
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, (int) ' ');
        java.math.BigInteger bigInteger77 = null;
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, 0L);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, bigInteger79);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, bigInteger80);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger80);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5099947966568112d, (double) 1L, 1.389895903181042E10d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.016953006535383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8933105109430091d + "'", double1 == 0.8933105109430091d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int[] intArray3 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray9 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray9);
        int[] intArray14 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray20 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray20);
        int[] intArray26 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray32 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray32);
        int[] intArray37 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray43 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray43);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray43);
        int[] intArray50 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray56 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray56);
        int[] intArray61 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray67 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray67);
        int[] intArray73 = new int[] { (byte) 0, '4', (byte) 0 };
        int[] intArray79 = new int[] { ' ', (byte) 0, ' ', 100, (byte) 100 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray79);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray79);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.93475175845634d + "'", double10 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 68.93475175845634d + "'", double21 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 116 + "'", int22 == 116);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 68.93475175845634d + "'", double33 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 68.93475175845634d + "'", double44 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 116 + "'", int45 == 116);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 68.93475175845634d + "'", double57 == 68.93475175845634d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 68.93475175845634d + "'", double68 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116 + "'", int69 == 116);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 68.93475175845634d + "'", double80 == 68.93475175845634d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-6083009866548056886L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double[] doubleArray6 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) '4');
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { (short) -1, (byte) 100, 100.0f, 132412511, 2.718281828459045d, (byte) 10 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.45231565944180985d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3241251100007592E8d + "'", double7 == 1.3241251100007592E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.99991685582412d + "'", double10 == 51.99991685582412d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3241251100007592E8d + "'", double18 == 1.3241251100007592E8d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3241245900015907E8d + "'", double19 == 1.3241245900015907E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 0, 47788297, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5099947966568112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9069381275727912d + "'", double1 == 0.9069381275727912d);
    }
}

