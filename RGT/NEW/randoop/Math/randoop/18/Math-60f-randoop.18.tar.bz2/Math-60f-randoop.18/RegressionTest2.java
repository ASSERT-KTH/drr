import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.cos(41.495947860226735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.792899657456953d) + "'", double1 == (-0.792899657456953d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int2 = org.apache.commons.math.util.FastMath.min(37, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable9, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
        int int27 = randomDataImpl24.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { "hi!", int27, (-1L) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30, localizable31, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException20, "", objArray37);
        mathException8.addSuppressed((java.lang.Throwable) convergenceException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException40.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) (-0.8104715564835727d));
        java.lang.Number number45 = notStrictlyPositiveException44.getMin();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 21, (float) 13);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.7809618602685398d), (java.lang.Number) 45.54377006014086d, (java.lang.Number) 2.5519562803930635d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.5519562803930635d + "'", number4.equals(2.5519562803930635d));
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = randomDataImpl0.nextGaussian(0.4031876995883735d, (double) 97.0f);
//        double double22 = randomDataImpl0.nextBeta(0.10832802164921763d, 1.5574077246549023d);
//        randomDataImpl0.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "88c8f076824d34725363635da4f7be2e99962d6978efc5f4f1fb748149954673bd32eb118d1d74bc14803150e75103bd8735" + "'", str2.equals("88c8f076824d34725363635da4f7be2e99962d6978efc5f4f1fb748149954673bd32eb118d1d74bc14803150e75103bd8735"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 38L + "'", long5 == 38L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22 + "'", int11 == 22);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0394740951740392d + "'", double13 == 0.0394740951740392d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.29339951529820063d + "'", double15 == 0.29339951529820063d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.8899964667206558d + "'", double16 == 0.8899964667206558d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 154.8642657903753d + "'", double19 == 154.8642657903753d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.3634533646983972E-9d + "'", double22 == 1.3634533646983972E-9d);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = randomDataImpl0.nextGaussian(0.4031876995883735d, (double) 97.0f);
//        double double21 = randomDataImpl0.nextT(0.44345298997665233d);
//        try {
//            double double24 = randomDataImpl0.nextWeibull(1.9439199172433264d, (-34.88911058046016d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -34.889 is smaller than, or equal to, the minimum (0): scale (-34.889)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f492a76605f137a3c00c19c20e5511cf4f61153019009568c5802061a65c914676fa834526d540f18b1021053f03fd61a176" + "'", str2.equals("f492a76605f137a3c00c19c20e5511cf4f61153019009568c5802061a65c914676fa834526d540f18b1021053f03fd61a176"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 38L + "'", long5 == 38L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28 + "'", int11 == 28);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6461035016973468d + "'", double13 == 0.6461035016973468d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2854383542691082d + "'", double15 == 0.2854383542691082d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.19620612055064d + "'", double16 == 0.19620612055064d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 56.64596024696382d + "'", double19 == 56.64596024696382d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-2.1674243953271004d) + "'", double21 == (-2.1674243953271004d));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.594700892207039d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double2 = org.apache.commons.math.util.FastMath.min(6.156208236477714d, (-0.39216512435927603d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.39216512435927603d) + "'", double2 == (-0.39216512435927603d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 4.198520144579203d);
        boolean boolean16 = notStrictlyPositiveException15.getBoundIsAllowed();
        java.lang.Number number17 = notStrictlyPositiveException15.getMin();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0 + "'", number17.equals(0));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextSecureInt(1, 34);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) ' ');
//        long long15 = randomDataImpl0.nextSecureLong((long) (byte) 0, 44L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "d690ba35554f232103dca66c20bdcb4e2fe7512439d1d5723e342f643f00c42cf2440e36a07ecf74cbcb1e77090ed0d30" + "'", str7.equals("d690ba35554f232103dca66c20bdcb4e2fe7512439d1d5723e342f643f00c42cf2440e36a07ecf74cbcb1e77090ed0d30"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "99664ee6cc6b8c6de10a1eefd560839c" + "'", str12.equals("99664ee6cc6b8c6de10a1eefd560839c"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 40L + "'", long15 == 40L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-44.60847139446158d), 1.5063364779351482d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.1610486171893641d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 24.586464529014513d, (java.lang.Number) 53L, true);
        java.lang.Number number14 = numberIsTooSmallException13.getMin();
        boolean boolean15 = numberIsTooSmallException13.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 53L + "'", number14.equals(53L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.apache.commons.math.util.FastMath.max(71L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 71L + "'", long2 == 71L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9149994957367078d, 1.4435779744158224d, 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 13, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Object[] objArray7 = outOfRangeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number9 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 19.31004779531512d + "'", number9.equals(19.31004779531512d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-0.1357258829059472d), (java.lang.Number) 34, false);
        java.lang.Number number31 = numberIsTooLargeException30.getMax();
        java.lang.Number number32 = numberIsTooLargeException30.getMax();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 34 + "'", number31.equals(34));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 34 + "'", number32.equals(34));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.0d), 231.3681718779007d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Object[] objArray7 = outOfRangeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) (-0.21931231246647523d), (java.lang.Number) 27.990841778891753d, true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        java.lang.Object[] objArray14 = numberIsTooLargeException12.getArguments();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 27.990841778891753d + "'", number13.equals(27.990841778891753d));
        org.junit.Assert.assertNotNull(objArray14);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        double double11 = randomDataImpl0.nextBeta((double) '#', 9.999999995E-10d);
//        randomDataImpl0.reSeed(36L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.15950638065002d + "'", double3 == 29.15950638065002d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 16.39717724004771d + "'", double6 == 16.39717724004771d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 92.47420271269168d + "'", double8 == 92.47420271269168d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999984097356d + "'", double11 == 0.9999999984097356d);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        double double5 = randomDataImpl0.nextGamma(1.5574077246549023d, 0.13313701469396122d);
//        try {
//            double double8 = randomDataImpl0.nextWeibull(88.84450792549285d, (-1.1311957035940396d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.131 is smaller than, or equal to, the minimum (0): scale (-1.131)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6261474448307754d + "'", double2 == 0.6261474448307754d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.19121545104038518d + "'", double5 == 0.19121545104038518d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.22965464497339058d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2276412493626667d) + "'", double1 == (-0.2276412493626667d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.8281684713331012d, 0.0d, 38.63013193866858d, (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextBinomial((int) 'a', 0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
        int int22 = randomDataImpl19.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", int22, (-1L) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25, localizable26, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl();
        int int46 = randomDataImpl43.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!", int46, (-1L) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable50, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException39, "", objArray56);
        java.lang.Object[] objArray60 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable12, objArray60);
        java.lang.String str63 = mathException8.getPattern();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.9520968095674806d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(114.51462084900638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6561.204467188889d + "'", double1 == 6561.204467188889d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, localizable15, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0.5154521927312391d, notStrictlyPositiveException4 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("2e18a7ba7330c788b8588f56134283cb865540a7b3a20bee0ff4e3df283474fa99bb6d289549961e88505d89781c9f2b1", objArray26);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(number4, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number8 = outOfRangeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
        int int15 = randomDataImpl12.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!", int15, (-1L) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
        int int29 = randomDataImpl26.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray31 = new java.lang.Object[] { "hi!", int29, (-1L) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException32, localizable33, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException22, "", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException18, "", objArray39);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray39);
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray50);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl55 = new org.apache.commons.math.random.RandomDataImpl();
        int int58 = randomDataImpl55.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray60 = new java.lang.Object[] { "hi!", int58, (-1L) };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("hi!", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException51, "hi!", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 0.7021737992805399d, (java.lang.Number) 158.45303120453724d, false);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.7383781754813599d, (java.lang.Number) 1.6618714637431034E-4d, (java.lang.Number) 0.8669774938157775d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.0608955130137179d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.814451218646091d, 0.997955783106022d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.81445121864609d + "'", double2 == 10.81445121864609d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(33);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number24 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl28 = new org.apache.commons.math.random.RandomDataImpl();
        int int31 = randomDataImpl28.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray33 = new java.lang.Object[] { "hi!", int31, (-1L) };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("hi!", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
        int int44 = randomDataImpl41.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", int44, (-1L) };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47, localizable48, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37, "", objArray54);
        mathException34.addSuppressed((java.lang.Throwable) convergenceException57);
        convergenceException25.addSuppressed((java.lang.Throwable) convergenceException57);
        org.apache.commons.math.exception.util.Localizable localizable60 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) 0.0d, (java.lang.Number) 6.2564893518218625E35d, (java.lang.Number) (-0.17902745162659536d));
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable60, objArray65);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl();
        int int73 = randomDataImpl70.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray75 = new java.lang.Object[] { "hi!", int73, (-1L) };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("hi!", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        java.lang.Object[] objArray78 = convergenceException77.getArguments();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable60, objArray78);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.8727929238079155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.061938999182515d) + "'", double1 == (-2.061938999182515d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0509717751430945d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.48165303880515864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3931583825986487d + "'", double1 == 0.3931583825986487d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number27 = notStrictlyPositiveException2.getMin();
        java.lang.Throwable[] throwableArray28 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0 + "'", number27.equals(0));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 31, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5955744642915115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1685277374430874d + "'", double1 == 1.1685277374430874d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double2 = org.apache.commons.math.util.FastMath.max(1.2407449316226176d, (-0.11345319074519535d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2407449316226176d + "'", double2 == 1.2407449316226176d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.2729967908999662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2729967908999664d + "'", double1 == 1.2729967908999664d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 39L, (java.lang.Number) 0.5901731071143256d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 39L + "'", number4.equals(39L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 24.586464529014513d, (java.lang.Number) 3.552713678800501E-15d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.552713678800501E-15d + "'", number4.equals(3.552713678800501E-15d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.000829913680131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7619424781675701d + "'", double1 == 0.7619424781675701d);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl0.nextExponential(231.3681718779007d);
//        int int16 = randomDataImpl0.nextInt(23, 97);
//        int int19 = randomDataImpl0.nextZipf(34, (double) 9.0f);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7449205446199664d + "'", double8 == 0.7449205446199664d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8565003934574225d + "'", double10 == 0.8565003934574225d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.856176445853103d + "'", double11 == 0.856176445853103d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 18.711157281620427d + "'", double13 == 18.711157281620427d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 74 + "'", int16 == 74);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 26, (java.lang.Number) 27.990841778891753d, true);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException13);
        java.lang.Number number15 = numberIsTooLargeException13.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 27.990841778891753d + "'", number15.equals(27.990841778891753d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
        double double4 = normalDistributionImpl0.density((double) 100L);
        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10.0f, (double) (short) 10);
        double[] doubleArray9 = normalDistributionImpl0.sample(21);
        normalDistributionImpl0.reseedRandomGenerator((long) 16);
        double double12 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-2.0017920840907606d), 0.3028848683749714d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Throwable[] throwableArray35 = convergenceException0.getSuppressed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        java.lang.Class<?> wildcardClass8 = localizable5.getClass();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(number9, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number13 = outOfRangeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException12.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
        int int20 = randomDataImpl17.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", int20, (-1L) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl();
        int int34 = randomDataImpl31.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!", int34, (-1L) };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable38, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException27, "", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException23, "", objArray44);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable14, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable5, objArray44);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl53 = new org.apache.commons.math.random.RandomDataImpl();
        int int56 = randomDataImpl53.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray58 = new java.lang.Object[] { "hi!", int56, (-1L) };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable60, number61, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Throwable throwable67 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray75);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", objArray75);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(throwable67, "hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable60, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = mathIllegalArgumentException79.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNull(localizable80);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0674342759877273d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36521149876911524d + "'", double1 == 0.36521149876911524d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.6321205588285577d), (double) 97);
        double[] doubleArray4 = normalDistributionImpl2.sample(3);
        double[] doubleArray6 = normalDistributionImpl2.sample(15);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", objArray1);
        java.lang.Object[] objArray3 = convergenceException2.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.cos(16.47639359377014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7190024902496504d) + "'", double1 == (-0.7190024902496504d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.744562646538029d + "'", double1 == 5.744562646538029d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
        try {
            long long8 = randomDataImpl0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int1 = org.apache.commons.math.util.FastMath.abs(33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(6, 20);
//        double double20 = randomDataImpl0.nextCauchy(101.03598257045044d, 718.7273164823139d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.9221125140750464d + "'", double3 == 3.9221125140750464d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13.970319846618759d + "'", double6 == 13.970319846618759d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 95.7427785664471d + "'", double8 == 95.7427785664471d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-3854.9585876684882d) + "'", double20 == (-3854.9585876684882d));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.060299188382886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7493710836706104d + "'", double1 == 1.7493710836706104d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 74L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.198336453808408d + "'", double1 == 4.198336453808408d);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        double double11 = randomDataImpl0.nextBeta((double) '#', 9.999999995E-10d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl12.inverseCumulativeProbability(0.019416865714155625d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        int int18 = randomDataImpl0.nextBinomial((int) (short) 1, 0.7528484484071774d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.812999438857393d + "'", double3 == 4.812999438857393d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.879823560090678d + "'", double6 == 11.879823560090678d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 88.07791398281495d + "'", double8 == 88.07791398281495d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999987417619d + "'", double11 == 0.9999999987417619d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.06594438297966d) + "'", double14 == (-2.06594438297966d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.18119920414044682d + "'", double15 == 0.18119920414044682d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-23.640787536460714d), (java.lang.Number) 0.7915571081062319d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -23.641 is smaller than, or equal to, the minimum (0.792)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -23.641 is smaller than, or equal to, the minimum (0.792)"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 25.10345653640629d, (java.lang.Number) 4.034253688303048d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        int int9 = randomDataImpl0.nextZipf(34, 0.5772156649015329d);
//        double double12 = randomDataImpl0.nextWeibull((double) 19, 0.839207242521137d);
//        try {
//            long long15 = randomDataImpl0.nextSecureLong(62L, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 62 is larger than, or equal to, the maximum (1): lower bound (62) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.639390724283379d + "'", double3 == 4.639390724283379d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8806052994913083d + "'", double12 == 0.8806052994913083d);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray12 = new java.lang.Object[] { "hi!", int10, (-1L) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, localizable14, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl();
        int int34 = randomDataImpl31.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!", int34, (-1L) };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean42 = numberIsTooLargeException41.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException41.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable43, objArray44);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl();
        int int51 = randomDataImpl48.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", int51, (-1L) };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("hi!", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl62 = new org.apache.commons.math.random.RandomDataImpl();
        int int65 = randomDataImpl62.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray67 = new java.lang.Object[] { "hi!", int65, (-1L) };
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("hi!", objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray75);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68, localizable69, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException58, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, localizable43, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(21, localizable24, objArray75);
        int int82 = maxIterationsExceededException81.getMaxIterations();
        java.lang.String str83 = maxIterationsExceededException81.getPattern();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 21 + "'", int82 == 21);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "{0} is smaller than, or equal to, the minimum ({1})" + "'", str83.equals("{0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(30.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.000000000000004d + "'", double1 == 30.000000000000004d);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = normalDistributionImpl12.sample();
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double20 = normalDistributionImpl12.cumulativeProbability(133.85817249205053d, 55.06745193980615d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e" + "'", str5.equals("e"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.2946242251409616d) + "'", double13 == (-0.2946242251409616d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-2.3614599591009755d) + "'", double15 == (-2.3614599591009755d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.238620389161563d + "'", double16 == 1.238620389161563d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2845422933561012d + "'", double17 == 0.2845422933561012d);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int2 = org.apache.commons.math.util.FastMath.min(33, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.451707610305872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0743629600790263d + "'", double1 == 3.0743629600790263d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9330999544581028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7320359252576271d + "'", double1 == 0.7320359252576271d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(27.298142486105444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0110019175812983d + "'", double1 == 3.0110019175812983d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int2 = org.apache.commons.math.util.FastMath.max(6, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number8 = outOfRangeException3.getHi();
        java.lang.Number number9 = outOfRangeException3.getLo();
        java.lang.Number number10 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 19.31004779531512d + "'", number8.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10 + "'", number9.equals(10));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 26, (java.lang.Number) 27.990841778891753d, true);
        java.lang.Number number14 = numberIsTooLargeException13.getMax();
        boolean boolean15 = numberIsTooLargeException13.getBoundIsAllowed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 27.990841778891753d + "'", number14.equals(27.990841778891753d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed((long) 10);
//        randomDataImpl0.reSeedSecure();
//        double double7 = randomDataImpl0.nextBeta((double) '#', 0.4031876995883735d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl8.reSeedSecure((long) (byte) -1);
//        int int13 = randomDataImpl8.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double15 = normalDistributionImpl14.sample();
//        double double16 = normalDistributionImpl14.getStandardDeviation();
//        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double18 = normalDistributionImpl14.sample();
//        double double20 = normalDistributionImpl14.density(57.29577951308232d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9991539623862512d + "'", double7 == 0.9991539623862512d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5597879397157868d + "'", double15 == 0.5597879397157868d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-2.040353642553441d) + "'", double17 == (-2.040353642553441d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.8741492238387552d + "'", double18 == 0.8741492238387552d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.6501341356232105d) + "'", double21 == (-0.6501341356232105d));
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.5519562803930635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 10.0f, (-0.3375322770451441d));
        double double6 = normalDistributionImpl3.cumulativeProbability(1.1247031214354666d, 1.9439199172433264d);
        double double8 = normalDistributionImpl3.density((-0.14785322473355786d));
        double double9 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.032290773920338856d + "'", double6 == 0.032290773920338856d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0398898677244122d + "'", double8 == 0.0398898677244122d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        int int12 = randomDataImpl0.nextBinomial(22, 4.428880147757328E-216d);
//        double double15 = randomDataImpl0.nextUniform((-2.0736961533991303d), (-0.43603583720984146d));
//        double double17 = randomDataImpl0.nextChiSquare(29.43627312320436d);
//        try {
//            double double20 = randomDataImpl0.nextBeta((double) 33.0f, (-0.3861148979231357d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.103");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 26 + "'", int5 == 26);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3788457519514825d + "'", double7 == 1.3788457519514825d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.7474936064305517d) + "'", double9 == (-1.7474936064305517d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.7458297493675676d) + "'", double15 == (-0.7458297493675676d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 28.816094252184485d + "'", double17 == 28.816094252184485d);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.7110158499104279d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-40.73820736677471d) + "'", double1 == (-40.73820736677471d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.8634957860258078d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.37645985686056d + "'", double1 == 56.37645985686056d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.738451285961637d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6731434268168067d) + "'", double1 == (-0.6731434268168067d));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double9 = normalDistributionImpl6.cumulativeProbability((double) 100.0f);
//        double double10 = normalDistributionImpl6.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-24.367566591549533d) + "'", double7 == (-24.367566591549533d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9975420988248034d + "'", double9 == 0.9975420988248034d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.0070644672492906d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.exp((-9.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2340980408667956E-4d + "'", double1 == 1.2340980408667956E-4d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 53);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.724275869600789d + "'", double1 == 1.724275869600789d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl();
        int int32 = randomDataImpl29.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray34 = new java.lang.Object[] { "hi!", int32, (-1L) };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable4, objArray34);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 31, (java.lang.Number) 1.2280285764566843d, (java.lang.Number) 1.3476590368841372d);
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(throwable41, "hi!", objArray49);
        java.lang.String str53 = mathException52.toString();
        java.lang.String str54 = mathException52.getPattern();
        outOfRangeException40.addSuppressed((java.lang.Throwable) mathException52);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str53.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.getStandardDeviation();
//        double double3 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0296679385123764d) + "'", double1 == (-1.0296679385123764d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        double double8 = randomDataImpl0.nextGaussian(0.5156123319920012d, (double) 2);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3d8a782b5a2e82d7a5d681b86cee607eba1bc5c089934a31f5fc69b8700bfe1a0767be2f344792eb9994a4370349ea47c94d" + "'", str2.equals("3d8a782b5a2e82d7a5d681b86cee607eba1bc5c089934a31f5fc69b8700bfe1a0767be2f344792eb9994a4370349ea47c94d"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 16L + "'", long5 == 16L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8762043125916289d + "'", double8 == 0.8762043125916289d);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test095");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        double double5 = randomDataImpl0.nextGamma(1.5574077246549023d, 0.13313701469396122d);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) 'a');
//        try {
//            double double10 = randomDataImpl0.nextGaussian((-1.6656987256453453d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.433450260853769d + "'", double2 == 4.433450260853769d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2898322602252815d + "'", double5 == 0.2898322602252815d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "c839c51e982262f180507882bda0a0efad37a79b83333ee42abcac178d383ffccf7c145a9ade1dfcbe1c33b36b03ad4d9" + "'", str7.equals("c839c51e982262f180507882bda0a0efad37a79b83333ee42abcac178d383ffccf7c145a9ade1dfcbe1c33b36b03ad4d9"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 26.0f, (double) 1.0f, (double) 28);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double14 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = normalDistributionImpl13.cumulativeProbability((double) 100.0f);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        long long20 = randomDataImpl0.nextSecureLong((long) (short) 1, (long) (short) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.13927243638401d + "'", double3 == 51.13927243638401d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-20.205075205988603d) + "'", double14 == (-20.205075205988603d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9975420988248034d + "'", double16 == 0.9975420988248034d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-77.7079767108231d) + "'", double17 == (-77.7079767108231d));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 78L + "'", long20 == 78L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(55.06745193980615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.420744702508378d + "'", double1 == 7.420744702508378d);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextPascal((int) ' ', 0.5856749831752239d);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(99);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        double double16 = randomDataImpl0.nextChiSquare(0.997955783106022d);
//        long long19 = randomDataImpl0.nextSecureLong(0L, 36L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "88aae0581fb0885c60ee7be2f5d4127fba85518ae11c243cc81267ff4a06856fbb2c58f592d6a3bf059d4dbb73b65d67e" + "'", str7.equals("88aae0581fb0885c60ee7be2f5d4127fba85518ae11c243cc81267ff4a06856fbb2c58f592d6a3bf059d4dbb73b65d67e"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2af0b6c3f944831064b9e1f6718820e5d7d704edd2dbc64ae6fbc507a311c18c79ce0c16049259d5779887660d81cf4cd91" + "'", str12.equals("2af0b6c3f944831064b9e1f6718820e5d7d704edd2dbc64ae6fbc507a311c18c79ce0c16049259d5779887660d81cf4cd91"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.3064659737133075d + "'", double16 == 5.3064659737133075d);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 19L + "'", long19 == 19L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
        int int28 = randomDataImpl25.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!", int28, (-1L) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31, localizable32, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable21, "", objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable20, objArray38);
        java.lang.Object[] objArray49 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray49);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl54 = new org.apache.commons.math.random.RandomDataImpl();
        int int57 = randomDataImpl54.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray59 = new java.lang.Object[] { "hi!", int57, (-1L) };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("hi!", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException50, "hi!", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException42, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray59);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.6282049005574863d, (java.lang.Number) 1.641199643448661d, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8125268827955464d), (java.lang.Number) 0.3432933379273535d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.2465279712559802d), number6, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 5.935562855836009d, (java.lang.Number) 2.3271925131717274E-8d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.02589647021471255d), (java.lang.Number) 7.69459862670642E-23d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable0, "hi!", objArray8);
        java.lang.Throwable[] throwableArray12 = mathException11.getSuppressed();
        java.lang.String str13 = mathException11.getPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.198520144579203d, (java.lang.Number) Double.POSITIVE_INFINITY, false);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(29, "c5a421857bdaccbb17d03bbbdc29a4a23a820890e56ffc9cf22eb06837de920d21c9ee5d1f2a2d146293beb40444f6e6cb6b", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "f033a63e215b27253e2e79a1f0ce11f795824c000b2063c07d8359440c9d4f56f651478e217b001402973a32a9ac18c3d8a", objArray22);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(21.475972553240776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.634217577244381d + "'", double1 == 4.634217577244381d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.2306448979566536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric(23, 31, 33);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 31 is larger than the maximum (23): number of successes (31) must be less than or equal to population size (23)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "c960326a2b7ddf0490974808d360f531ae7718fac29d0cccca24db5e251abf466782d157661e53ddf32ead78e2e74e53e" + "'", str7.equals("c960326a2b7ddf0490974808d360f531ae7718fac29d0cccca24db5e251abf466782d157661e53ddf32ead78e2e74e53e"));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.353883253316498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.8622678875613657d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3021198670065903d) + "'", double1 == (-1.3021198670065903d));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure((long) 10);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4e0e034a9f76c99a700d601ea656b6a03e2dc49bc5e89c058f642d94b87973d9d0f7b30cd12fbf454638d4230ecdac6ca0ae" + "'", str2.equals("4e0e034a9f76c99a700d601ea656b6a03e2dc49bc5e89c058f642d94b87973d9d0f7b30cd12fbf454638d4230ecdac6ca0ae"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8125268827955464d), (java.lang.Number) 0.3432933379273535d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.2465279712559802d), number6, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 5.935562855836009d, (java.lang.Number) 2.3271925131717274E-8d, true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 4.198520144579203d);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, number16, (java.lang.Number) 1.1300537735746263d, (java.lang.Number) 0.27829965900511133d);
        java.lang.Number number20 = outOfRangeException19.getArgument();
        java.lang.Number number21 = outOfRangeException19.getHi();
        org.apache.commons.math.exception.util.Localizable localizable22 = outOfRangeException19.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.27829965900511133d + "'", number21.equals(0.27829965900511133d));
        org.junit.Assert.assertNotNull(localizable22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        randomDataImpl0.reSeedSecure();
        double double7 = randomDataImpl0.nextGamma(0.4879227341906365d, 0.11202938476215606d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.06627143002793373d + "'", double7 == 0.06627143002793373d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 19L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05404090603762599d + "'", double1 == 0.05404090603762599d);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        int int10 = randomDataImpl0.nextInt((int) (short) 1, 52);
//        try {
//            double double13 = randomDataImpl0.nextF(0.0d, (-3.318928600414486d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9b21baeb9c79f4aa21597410ee569f93a4e57628553b12b6b27ea03d6c67c46ca88d5278dfd06df281389181863a1ece044b" + "'", str2.equals("9b21baeb9c79f4aa21597410ee569f93a4e57628553b12b6b27ea03d6c67c46ca88d5278dfd06df281389181863a1ece044b"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.7634205270784418d + "'", double5 == 1.7634205270784418d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18211735336443668d + "'", double7 == 0.18211735336443668d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 7L, 0.3098365735476644d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3098365735476644d + "'", double2 == 0.3098365735476644d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-0.1357258829059472d), (java.lang.Number) 34, false);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable throwable33 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(throwable33, "hi!", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException30, "82a008dd5bac9f43deb4dd3c9427737d07e8c51f37a400eff71d3616c3e04519b7b0a0856d5aa14a205638f9752e6f9a92d9", objArray41);
        boolean boolean46 = numberIsTooLargeException30.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.exp(24.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.648912212984347E10d + "'", double1 == 2.648912212984347E10d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable45, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable5, objArray46);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 372.97946888568896d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 21.144427133186632d);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7809618602685398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 23L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 23.0f + "'", float2 == 23.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.04753671340204302d, (double) 99);
        normalDistributionImpl2.reseedRandomGenerator((long) 476);
        double double5 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04753671340204302d + "'", double5 == 0.04753671340204302d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(51.13927243638401d, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.139272436384005d + "'", double2 == 51.139272436384005d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        java.lang.Object[] objArray23 = convergenceException22.getArguments();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-1.7809618602685398d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.037713565301495d + "'", double1 == 24.037713565301495d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.acos(37.53036172719677d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException12.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable14, objArray15);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
        int int22 = randomDataImpl19.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", int22, (-1L) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math.random.RandomDataImpl();
        int int36 = randomDataImpl33.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray38 = new java.lang.Object[] { "hi!", int36, (-1L) };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable40, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException29, "", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException25, "", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable14, objArray46);
        java.lang.Object[] objArray52 = convergenceException51.getArguments();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray52);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        try {
//            int int16 = randomDataImpl0.nextInt(10, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1): lower bound (10) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 51L + "'", long6 == 51L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
        int int18 = randomDataImpl15.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!", int18, (-1L) };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(9, localizable11, objArray20);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
        int int29 = randomDataImpl26.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray31 = new java.lang.Object[] { "hi!", int29, (-1L) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, number34, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 4.198520144579203d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 0L, (java.lang.Number) (-1.4183144013928657d), false);
        java.lang.Throwable throwable46 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(throwable46, "hi!", objArray54);
        java.lang.Throwable[] throwableArray58 = mathException57.getSuppressed();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7", (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable33, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable11, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray58);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        java.lang.String str11 = randomDataImpl0.nextHexString(34);
//        try {
//            randomDataImpl0.setSecureAlgorithm("0311c3c92b92f0d8731dffce48befde3e711bb03e4f3653613ed4bf02d2ac2a4a4f89e42b444b3243b4565a2303607bd5", "841cabfc3ae2b9c1e0acb05645f4cf89cb41f2b70a762b90c079340ec7d6305e9b517bdc159eca722220d8e12939cfa51db");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 841cabfc3ae2b9c1e0acb05645f4cf89cb41f2b70a762b90c079340ec7d6305e9b517bdc159eca722220d8e12939cfa51db");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "b0fd852338b59cb0ab60b82b051c251439bde542ba12b3b79f244dc0fae44d5e2b1fb4d5c669b8adc47f0185380ad4448" + "'", str7.equals("b0fd852338b59cb0ab60b82b051c251439bde542ba12b3b79f244dc0fae44d5e2b1fb4d5c669b8adc47f0185380ad4448"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "e6a0c98c13d6986ca273f3925e3251" + "'", str9.equals("e6a0c98c13d6986ca273f3925e3251"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "75c5573416abb2b5c9f60cd98b36d4ab80" + "'", str11.equals("75c5573416abb2b5c9f60cd98b36d4ab80"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(108.01798396338886d, 0.0d, (-2.040353642553441d), 99);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) -1);
        java.lang.Number number12 = notStrictlyPositiveException11.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) -1 + "'", number12.equals((byte) -1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.016209371736996388d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.587006408434302d + "'", double1 == 1.587006408434302d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(number8, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number12 = outOfRangeException11.getArgument();
        java.lang.String str13 = outOfRangeException11.toString();
        java.lang.Number number14 = outOfRangeException11.getLo();
        java.lang.Object[] objArray15 = outOfRangeException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException11.getGeneralPattern();
        java.lang.Throwable throwable19 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable19, "hi!", objArray27);
        java.lang.Throwable[] throwableArray31 = mathException30.getSuppressed();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7", (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable16, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(throwable0, localizable5, (java.lang.Object[]) throwableArray31);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str13.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 10 + "'", number14.equals(10));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9043022375118978d, (java.lang.Number) (byte) 100, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 100 + "'", number4.equals((byte) 100));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        java.lang.Object[] objArray14 = numberIsTooLargeException13.getArguments();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.sample();
//        double double14 = normalDistributionImpl7.cumulativeProbability(5.240494635784616E-177d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.224700224085675d + "'", double8 == 0.224700224085675d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3789687246215651d + "'", double10 == 0.3789687246215651d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.37222186489933057d + "'", double11 == 0.37222186489933057d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.6410398913016524d) + "'", double12 == (-0.6410398913016524d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 30L, (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
//        long long9 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 1);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(2);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 99 + "'", int6 == 99);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "22" + "'", str11.equals("22"));
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test142");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        int int19 = randomDataImpl0.nextSecureInt(20, 78);
//        randomDataImpl0.reSeed((long) 2);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46d45c587529e01769ee2eecd1e6e63438f3e512fb27ee4ac8e6be3229707e766530fd70a014a9c292f8e99c81c895cf5144" + "'", str2.equals("46d45c587529e01769ee2eecd1e6e63438f3e512fb27ee4ac8e6be3229707e766530fd70a014a9c292f8e99c81c895cf5144"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 39L + "'", long5 == 39L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3926694958855053d + "'", double13 == 0.3926694958855053d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.42990315989908756d + "'", double15 == 0.42990315989908756d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.8330209996251114d + "'", double16 == 1.8330209996251114d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 54 + "'", int19 == 54);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3789687246215651d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.388681642864583d + "'", double1 == 0.388681642864583d);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        double double5 = randomDataImpl0.nextGamma(1.5574077246549023d, 0.13313701469396122d);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) 'a');
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl8.reSeedSecure((long) (byte) -1);
//        int int13 = randomDataImpl8.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double15 = normalDistributionImpl14.sample();
//        double double16 = normalDistributionImpl14.getStandardDeviation();
//        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double18 = normalDistributionImpl14.sample();
//        double double20 = normalDistributionImpl14.density(57.29577951308232d);
//        normalDistributionImpl14.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl14.reseedRandomGenerator((long) 10);
//        double double26 = normalDistributionImpl14.cumulativeProbability((-0.24510465435485307d));
//        double double28 = normalDistributionImpl14.density(103.0d);
//        double double29 = normalDistributionImpl14.getStandardDeviation();
//        double double30 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9165561310243364d + "'", double2 == 0.9165561310243364d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.048940306259109174d + "'", double5 == 0.048940306259109174d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "7c461493a5602ee53a9b25d4c764e16026a69c0155cd6f0382bf85fcc49a8cc5cf1bf4afc08ae2951d144ac480a32979c" + "'", str7.equals("7c461493a5602ee53a9b25d4c764e16026a69c0155cd6f0382bf85fcc49a8cc5cf1bf4afc08ae2951d144ac480a32979c"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9567676242100112d + "'", double15 == 0.9567676242100112d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.4230173037890559d + "'", double17 == 0.4230173037890559d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.2479450048003715d + "'", double18 == 1.2479450048003715d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.4031876995883735d + "'", double26 == 0.4031876995883735d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.49060752417543807d + "'", double30 == 0.49060752417543807d);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextExponential(25.0d);
//        try {
//            double double12 = randomDataImpl0.nextF((-0.8122995035639646d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.812 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.812)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7" + "'", str5.equals("7"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.39442039833217d + "'", double9 == 10.39442039833217d);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        randomDataImpl0.reSeedSecure();
//        double double9 = randomDataImpl0.nextCauchy(0.023936202886934075d, 3.1742815528252627E-106d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7d0ed69ef783c3262ae88c50e33bc0fb63dd0185da458b0ecf722759ae3bf5709364f5b40d480f195754fe89dac03602e758" + "'", str2.equals("7d0ed69ef783c3262ae88c50e33bc0fb63dd0185da458b0ecf722759ae3bf5709364f5b40d480f195754fe89dac03602e758"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 11L + "'", long5 == 11L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.023936202886934075d + "'", double9 == 0.023936202886934075d);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        int int10 = randomDataImpl0.nextInt(3, 24);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl0.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 85L + "'", long3 == 85L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9221748447319554d + "'", double6 == 0.9221748447319554d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 22 + "'", int10 == 22);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 0.4955126114429672d, (java.lang.Number) 1.2997277948552883d, (java.lang.Number) 0.3931583825986487d);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        double double8 = randomDataImpl0.nextCauchy(18.711157281620427d, 1.7809618602685398d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e4c204a58aa77612f709e6749eeb36ace184226fad644ee53b32395f0ad7e8b57f79c174142fc359ca4b81bb9f671ff9060b" + "'", str2.equals("e4c204a58aa77612f709e6749eeb36ace184226fad644ee53b32395f0ad7e8b57f79c174142fc359ca4b81bb9f671ff9060b"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 42L + "'", long5 == 42L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 25.294250714707076d + "'", double8 == 25.294250714707076d);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.23044395339514506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test153");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        randomDataImpl0.reSeedSecure();
//        int int9 = randomDataImpl0.nextZipf(97, 0.6954783528958071d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "630847bfe1bd2abb828ae29500c13b7eba2a5f15645e9d103744fecd9b247c4b078605e43dd36f81fd067cfb371b368e8d8e" + "'", str2.equals("630847bfe1bd2abb828ae29500c13b7eba2a5f15645e9d103744fecd9b247c4b078605e43dd36f81fd067cfb371b368e8d8e"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 26 + "'", int9 == 26);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.05993438318962159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4339872044851463d + "'", double1 == 3.4339872044851463d);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test156");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure(12L);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8" + "'", str5.equals("8"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-0.1357258829059472d), (java.lang.Number) 34, false);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Number number32 = numberIsTooLargeException30.getArgument();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-0.1357258829059472d) + "'", number32.equals((-0.1357258829059472d)));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
        int int7 = randomDataImpl4.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", int7, (-1L) };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number12, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
        int int30 = randomDataImpl27.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray32 = new java.lang.Object[] { "hi!", int30, (-1L) };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException33, localizable34, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(throwable23, "", objArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable22, objArray40);
        java.lang.Object[] objArray51 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray51);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl56 = new org.apache.commons.math.random.RandomDataImpl();
        int int59 = randomDataImpl56.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!", int59, (-1L) };
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("hi!", objArray61);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException52, "hi!", objArray61);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException44, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(23, "", objArray61);
        int int67 = maxIterationsExceededException66.getMaxIterations();
        int int68 = maxIterationsExceededException66.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 23 + "'", int67 == 23);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 23 + "'", int68 == 23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.8622678875613657d), (double) 60L, (double) 1L, 74);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.198336453808408d, 0.028063469160860017d, (double) 476, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.136525454233818E-9d + "'", double4 == 9.136525454233818E-9d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.3019527653887148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test162");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextBinomial(1, 0.0d);
//        double double5 = randomDataImpl0.nextChiSquare(32.0d);
//        try {
//            double double8 = randomDataImpl0.nextCauchy((-2.9586939154951337d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 26.271563127237435d + "'", double5 == 26.271563127237435d);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(29.863988276146284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1025296132427354d + "'", double1 == 3.1025296132427354d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.Object[] objArray7 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("9a0c756219dced58e9b6ab7b8911ac5dd18df274b9a051799185a368863ac010f12707b51c421e188145fb6eae84b4c791aa", objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, number1, false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-5.180883098029916d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextGamma(19.31004779531512d, 36.264664323635685d);
//        double double9 = randomDataImpl0.nextF(0.9952353147692228d, (double) 13);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl10.reSeedSecure((long) (byte) -1);
//        int int15 = randomDataImpl10.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double17 = normalDistributionImpl16.sample();
//        double double18 = normalDistributionImpl16.getStandardDeviation();
//        double double19 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        double double20 = normalDistributionImpl16.sample();
//        double double22 = normalDistributionImpl16.density(57.29577951308232d);
//        normalDistributionImpl16.reseedRandomGenerator((long) (byte) 0);
//        double double25 = normalDistributionImpl16.getStandardDeviation();
//        double double26 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6969182340962563d + "'", double2 == 2.6969182340962563d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1072.3282598174585d + "'", double6 == 1072.3282598174585d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6004484031774369d + "'", double9 == 0.6004484031774369d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8847537480666492d + "'", double17 == 0.8847537480666492d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.2933527151010527d + "'", double19 == 1.2933527151010527d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.1617872778494822d + "'", double20 == 0.1617872778494822d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.9886958201044078d + "'", double26 == 0.9886958201044078d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.8615248364376218d, (java.lang.Number) (-5.321160198215146d), (java.lang.Number) 8);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable15, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable15.getClass();
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable15, objArray24);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl();
        int int33 = randomDataImpl30.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray35 = new java.lang.Object[] { "hi!", int33, (-1L) };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("hi!", objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53, localizable54, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException43, "", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = notStrictlyPositiveException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable65, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl71 = new org.apache.commons.math.random.RandomDataImpl();
        int int74 = randomDataImpl71.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray76 = new java.lang.Object[] { "hi!", int74, (-1L) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("hi!", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray84);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException77, localizable78, objArray84);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException67, "", objArray84);
        java.lang.Object[] objArray88 = notStrictlyPositiveException67.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable40, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("4", objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, objArray88);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException96 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0.8120613450333635d, (java.lang.Number) 97L, false);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
        double double3 = normalDistributionImpl2.getMean();
        double double4 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        java.lang.Object[] objArray11 = convergenceException10.getArguments();
        java.lang.String str12 = convergenceException10.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str12.equals("org.apache.commons.math.ConvergenceException: hi!"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(57.29577951308232d, 1.0383542454659476d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.483758447589274d), 3.1742815528252627E-106d, 29.43627312320436d, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        org.apache.commons.math.random.RandomDataImpl randomDataImpl36 = new org.apache.commons.math.random.RandomDataImpl();
        int int39 = randomDataImpl36.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray41 = new java.lang.Object[] { "hi!", int39, (-1L) };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("hi!", objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("26e492a1dcd93e30c5dacecba0797c", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray41);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException45);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(objArray41);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test174");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, 0.9625236616387699d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("62ca13386fb90c56c5a35c9bc02546561f598caf75c6a8e0ac1b4dc4d18d2da5a6a621b2139b3edb87b11a44c9ef7c5875d", "bd191a87c032ad8cfa0393b36ca5bcb5e9b2b37f030d86750b4d8e6a6f16f5e049e54c39378b69a80292e9aff78712c7f094");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: bd191a87c032ad8cfa0393b36ca5bcb5e9b2b37f030d86750b4d8e6a6f16f5e049e54c39378b69a80292e9aff78712c7f094");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 47L + "'", long6 == 47L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.22064591947069098d + "'", double9 == 0.22064591947069098d);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2479450048003715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
        int int7 = randomDataImpl4.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", int7, (-1L) };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
        int int20 = randomDataImpl17.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", int20, (-1L) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, localizable24, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException13, "", objArray30);
        mathException10.addSuppressed((java.lang.Throwable) convergenceException33);
        java.lang.Object[] objArray35 = convergenceException33.getArguments();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl();
        int int51 = randomDataImpl48.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray53 = new java.lang.Object[] { "hi!", int51, (-1L) };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("hi!", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException44, "hi!", objArray53);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(0, "f44cf69664241d78836e46ec18e6352d9196bf70b97e243dbc51e04fb36b2674ec29d966f4895c671bbff19df568723297f4", objArray53);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(number36, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number40 = outOfRangeException39.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException39.getGeneralPattern();
        convergenceException32.addSuppressed((java.lang.Throwable) outOfRangeException39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.29588497520587087d) + "'", number5.equals((-0.29588497520587087d)));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.551115123125783E-17d, 36.264664323635685d, 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.839207242521137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3732921440448527d + "'", double1 == 1.3732921440448527d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 0.0d, (java.lang.Number) 6.2564893518218625E35d, (java.lang.Number) (-0.17902745162659536d));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.9049299941346214d), (java.lang.Number) 1.9867717342662448d, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(6.942898894086964d, (double) 15, 3.141592653589793d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a0b578c620152c26aa8a9653404a1a67cf916295129a123686cbf5e6c02794c01dbb306b1b4bf03242e3db1a064708cf8" + "'", str7.equals("a0b578c620152c26aa8a9653404a1a67cf916295129a123686cbf5e6c02794c01dbb306b1b4bf03242e3db1a064708cf8"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "f89a39cce5da8d30c00b09c49b4ba8" + "'", str9.equals("f89a39cce5da8d30c00b09c49b4ba8"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-14.057101105913036d) + "'", double14 == (-14.057101105913036d));
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test183");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str4 = randomDataImpl0.nextHexString(8);
//        try {
//            randomDataImpl0.setSecureAlgorithm("9adbcea2f3a3cd3f119bd76ce03aab46b5a517ca188316f6cebf1d99211e3e8aab2a7c57278241eecd0132e9f16b7794e0c9", "4df8c9d1a2d2f739b0e1cb6597d64d0126063968bf8e49affa1e19a786a97d4c8c2217371bea214858573e4b2cd1c8a8488");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 4df8c9d1a2d2f739b0e1cb6597d64d0126063968bf8e49affa1e19a786a97d4c8c2217371bea214858573e4b2cd1c8a8488");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b32c7846c610b043cda35b9c77c3ab0a201ef6ca0c5e8bcf236d1b9042042b7e3ccb36e83dbacfbcd350a9f7fad8fccd23f2" + "'", str2.equals("b32c7846c610b043cda35b9c77c3ab0a201ef6ca0c5e8bcf236d1b9042042b7e3ccb36e83dbacfbcd350a9f7fad8fccd23f2"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "12d25c94" + "'", str4.equals("12d25c94"));
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test184");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        java.lang.String str13 = randomDataImpl0.nextHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.9282479137597773d) + "'", double7 == (-0.9282479137597773d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.2818900854040933d) + "'", double9 == (-1.2818900854040933d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.10627406468494753d + "'", double11 == 0.10627406468494753d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "43288db93c" + "'", str13.equals("43288db93c"));
//    }
//}

