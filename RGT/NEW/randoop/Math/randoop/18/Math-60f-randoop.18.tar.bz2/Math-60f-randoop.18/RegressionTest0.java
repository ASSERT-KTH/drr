import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.27829965900511133d + "'", double2 == 0.27829965900511133d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019416865714155625d + "'", double1 == 0.019416865714155625d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), (double) (-1L), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 72L + "'", long3 == 72L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        try {
//            double double9 = randomDataImpl0.nextF(0.019416865714155625d, Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 2 p = 0.574");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 71L + "'", long3 == 71L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8955497845165324d + "'", double6 == 0.8955497845165324d);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0, 19.31004779531512d, (double) 10, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.763708549589213d + "'", double3 == 13.763708549589213d);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        try {
//            double double9 = randomDataImpl0.nextWeibull((double) 38L, (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8932943874642476d + "'", double6 == 0.8932943874642476d);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10L, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3028848683749714d + "'", double2 == 0.3028848683749714d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
        try {
            double double6 = randomDataImpl0.nextF(0.0d, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
        try {
            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
        try {
            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        try {
//            int int9 = randomDataImpl0.nextPascal((int) (byte) 100, Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3153920894809077d + "'", double3 == 3.3153920894809077d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.2525894250466925d + "'", double6 == 2.2525894250466925d);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100.0f, 0.3028848683749714d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0654109334640752E-210d + "'", double2 == 1.0654109334640752E-210d);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        try {
//            int int8 = randomDataImpl0.nextBinomial((int) (short) 10, (double) 100.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0654109334640752E-210d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.428880147757328E-216d + "'", double2 == 4.428880147757328E-216d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0654109334640752E-210d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0654109334640752E-210d + "'", double1 == 1.0654109334640752E-210d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594700892207039d + "'", double1 == 4.594700892207039d);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.getStandardDeviation();
//        try {
//            double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5514739427750865d) + "'", double1 == (-0.5514739427750865d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            long long6 = randomDataImpl0.nextSecureLong((long) 100, (long) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        try {
//            int int9 = randomDataImpl0.nextPascal((int) (short) 0, (double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 35 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 51L + "'", long6 == 51L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999995E-10d + "'", double1 == 9.999999995E-10d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0654109334640752E-210d, Double.NEGATIVE_INFINITY, (double) '#', (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 48L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.0f + "'", float2 == 48.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        try {
//            double double9 = randomDataImpl0.nextF((double) 100.0f, (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.790768105177145d + "'", double3 == 12.790768105177145d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 10, (-0.6931326168456545d), 5.000994718583564d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.693 is smaller than, or equal to, the minimum (0): standard deviation (-0.693)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.max(2.718281828459045d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4275739764777582d + "'", double0 == 0.4275739764777582d);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 48L, (double) (byte) 100, 0.0d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 100 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        int int7 = maxIterationsExceededException6.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric(0, 1, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 38L + "'", long3 == 38L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((int) '#', (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 10, (-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6931326168456545d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6470315115747067d) + "'", double1 == (-0.6470315115747067d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        try {
//            double double8 = randomDataImpl0.nextChiSquare((-0.6470315115747067d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.324 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.272314793302634d + "'", double3 == 25.272314793302634d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.730899518315947d + "'", double6 == 8.730899518315947d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        java.lang.Number number23 = notStrictlyPositiveException2.getArgument();
        java.lang.Class<?> wildcardClass24 = notStrictlyPositiveException2.getClass();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10.0f + "'", number23.equals(10.0f));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-0.8125268827955464d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.724594607551417d, (java.lang.Number) (-0.7478398134896268d), false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9043022375118978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.428880147757328E-216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.428880147757328E-216d + "'", double1 == 4.428880147757328E-216d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(6.942898894086964d, 1.0654109334640752E-210d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.7110158499104279d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3617381425941484d + "'", double1 == 2.3617381425941484d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, (long) 29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.594700892207039d, (-1.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.log(0.3028848683749714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1944025180403872d) + "'", double1 == (-1.1944025180403872d));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        try {
//            double double14 = randomDataImpl0.nextUniform(2.0d, 0.3028848683749714d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (0.303): lower bound (2) must be strictly less than upper bound (0.303)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.20770834781067815d) + "'", double7 == (-0.20770834781067815d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.40042337534171063d) + "'", double9 == (-0.40042337534171063d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.39381574277778414d) + "'", double11 == (-0.39381574277778414d));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable9, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
        int int27 = randomDataImpl24.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { "hi!", int27, (-1L) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30, localizable31, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException20, "", objArray37);
        mathException8.addSuppressed((java.lang.Throwable) convergenceException40);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Throwable throwable47 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl();
        int int54 = randomDataImpl51.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray56 = new java.lang.Object[] { "hi!", int54, (-1L) };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException57, localizable58, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(throwable47, "", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable46, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable72, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl78 = new org.apache.commons.math.random.RandomDataImpl();
        int int81 = randomDataImpl78.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray83 = new java.lang.Object[] { "hi!", int81, (-1L) };
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException("hi!", objArray83);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray91 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException84, localizable85, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException74, "", objArray91);
        boolean boolean95 = notStrictlyPositiveException74.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException74);
        java.lang.Object[] objArray97 = new java.lang.Object[] { 1.724594607551417d, 2.718281828459045d, mathException96 };
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", objArray97);
        org.apache.commons.math.ConvergenceException convergenceException99 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable46, objArray97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.log10(9.999999995E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.000000000217147d) + "'", double1 == (-9.000000000217147d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 1, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999546000702375d + "'", double2 == 0.9999546000702375d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.7478398134896268d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            double double6 = randomDataImpl0.nextCauchy(7.69459862670642E-23d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        try {
//            double double5 = randomDataImpl0.nextWeibull(5.000994718583564d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "bea1cd308b45dc1a21a534b0d4ba1be4d4d3549110fd994a6d2ff3324eb813f53ab93ee94df48593262a80180af58c4c8567" + "'", str2.equals("bea1cd308b45dc1a21a534b0d4ba1be4d4d3549110fd994a6d2ff3324eb813f53ab93ee94df48593262a80180af58c4c8567"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.39216512435927603d), (double) (byte) 100, (double) 38L, (int) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        java.lang.String str7 = maxIterationsExceededException6.getPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        try {
//            double double13 = randomDataImpl0.nextBeta(0.0d, 81.1203032558295d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.732");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.04139483130202d + "'", double3 == 20.04139483130202d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.7056599937442893d) + "'", double6 == (-2.7056599937442893d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 110.99700477033099d + "'", double8 == 110.99700477033099d);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 0, (double) 42L, (double) 13, (int) (byte) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.rint(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.0d + "'", double1 == 57.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4275739764777582d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0654109334640752E-210d, (double) 42L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.536692698723989E-212d + "'", double2 == 2.536692698723989E-212d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-9.000000000217147d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextSecureInt(10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.7113050055174964d), (java.lang.Number) (-0.033625453575000484d), (java.lang.Number) 57.29577951308232d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.3098365735476644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.882893437260871d, (double) 1L, (-0.7478398134896268d), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (52) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl0.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.35310959850007d) + "'", double7 == (-0.35310959850007d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4062595351302614d) + "'", double9 == (-0.4062595351302614d));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double2 = org.apache.commons.math.util.FastMath.pow(100.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E20d + "'", double2 == 1.0E20d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.29588497520587087d) + "'", number4.equals((-0.29588497520587087d)));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9025352261814413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01575221131209788d + "'", double1 == 0.01575221131209788d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        try {
//            double double6 = randomDataImpl0.nextUniform(2.3617381425941484d, 7.105427357601002E-15d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2.362 is larger than, or equal to, the maximum (0): lower bound (2.362) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.87775462973898d + "'", double3 == 12.87775462973898d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((int) '#', 1.4435779744158224d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.444 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        double double11 = randomDataImpl0.nextBeta((double) '#', 9.999999995E-10d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", "1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.782347565668683d + "'", double3 == 13.782347565668683d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.625044298002686d + "'", double6 == 9.625044298002686d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.64725617454583d + "'", double8 == 82.64725617454583d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.999999998623865d + "'", double11 == 0.999999998623865d);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextBinomial(1, 0.0d);
        try {
            java.lang.String str5 = randomDataImpl0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.getStandardDeviation();
//        try {
//            double[] doubleArray4 = normalDistributionImpl0.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7048032819753671d) + "'", double1 == (-0.7048032819753671d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        try {
//            double double9 = randomDataImpl0.nextExponential((-2.06594438297966d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2.066 is smaller than, or equal to, the minimum (0): mean (-2.066)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7ddfd6fb37bb31f27fe1617168e498b8dad255e4f2d040a59fb24eaa49bdca85a1367f0aa53ae16cf03fdd6ce4b156f9b50e" + "'", str2.equals("7ddfd6fb37bb31f27fe1617168e498b8dad255e4f2d040a59fb24eaa49bdca85a1367f0aa53ae16cf03fdd6ce4b156f9b50e"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.exp(7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.536692698723989E-212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.536692698723989E-212d + "'", double1 == 2.536692698723989E-212d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.7113050055174964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5089969824666987d) + "'", double1 == (-0.5089969824666987d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
        try {
            double double6 = randomDataImpl0.nextBeta((-1.7809618602685398d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.246");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.rint(103.2536697595297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 103.0d + "'", double1 == 103.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.033625453575000484d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double5 = randomDataImpl0.nextChiSquare((double) 22);
//        try {
//            long long7 = randomDataImpl0.nextPoisson((-0.6931326168456545d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.693 is smaller than, or equal to, the minimum (0): mean (-0.693)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 85L + "'", long3 == 85L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 20.63011483031114d + "'", double5 == 20.63011483031114d);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6261509044766869d) + "'", double1 == (-1.6261509044766869d));
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        try {
//            int int14 = randomDataImpl0.nextBinomial(29, (double) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 52 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 51L + "'", long6 == 51L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.asin(82.42409747617464d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.6470315115747067d), (java.lang.Number) 10.0f, true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.2658560769022296d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5156123319920012d + "'", double1 == 0.5156123319920012d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.428880147757328E-216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.428880147757328E-216d + "'", double1 == 4.428880147757328E-216d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.special.Erf.erf(16.87876954085938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-44.60847139446158d), Double.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean24 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.asin(88.84450792549285d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d0838168bae7aa8ef70059b6f7b3e4a5ad04c9540ee687a5c61ccafd52a46b7c8c7407351b831270342c3c973a471b0a2d9b" + "'", str2.equals("d0838168bae7aa8ef70059b6f7b3e4a5ad04c9540ee687a5c61ccafd52a46b7c8c7407351b831270342c3c973a471b0a2d9b"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 36L + "'", long5 == 36L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11.909995696461953d + "'", double10 == 11.909995696461953d);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
        double[] doubleArray4 = normalDistributionImpl2.sample((int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 48L, 0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 48.0d + "'", double2 == 48.0d);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl0.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.1023887883615d + "'", double3 == 23.1023887883615d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13.868779197957274d + "'", double6 == 13.868779197957274d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 105.97313661718614d + "'", double8 == 105.97313661718614d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(3, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (3): permutation size (100) exceeds permuation domain (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.01101614067165d + "'", double3 == 23.01101614067165d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-369.30950307883023d) + "'", double6 == (-369.30950307883023d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.60120492155845d + "'", double8 == 82.60120492155845d);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
        int int38 = randomDataImpl35.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!", int38, (-1L) };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable42, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException31, "", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl59 = new org.apache.commons.math.random.RandomDataImpl();
        int int62 = randomDataImpl59.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray64 = new java.lang.Object[] { "hi!", int62, (-1L) };
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("hi!", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray72);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException65, localizable66, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException55, "", objArray72);
        java.lang.Object[] objArray76 = notStrictlyPositiveException55.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException27, localizable28, objArray76);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 1, 35.762112861443455d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.4064059332662353d), (double) 1.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.expm1(82.42409747617464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.2564893518218625E35d + "'", double1 == 6.2564893518218625E35d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.02120909795200876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.841449015201038d + "'", double1 == 3.841449015201038d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5856749831752239d + "'", double1 == 0.5856749831752239d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        try {
//            double double5 = randomDataImpl0.nextT((double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 74L + "'", long3 == 74L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9999999958776927d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0113154145053396d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10.0f + "'", number3.equals(10.0f));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.exp(6.2564893518218625E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.special.Erf.erf(48.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        double double18 = normalDistributionImpl6.cumulativeProbability((-0.24510465435485307d));
//        double double20 = normalDistributionImpl6.cumulativeProbability(1.0E-9d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3110421742117833d + "'", double7 == 0.3110421742117833d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9208917123488402d + "'", double9 == 0.9208917123488402d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.3375322770451441d) + "'", double10 == (-0.3375322770451441d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.4031876995883735d + "'", double18 == 0.4031876995883735d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5000000003989423d + "'", double20 == 0.5000000003989423d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.exp(19.954590094035403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.636266228115197E8d + "'", double1 == 4.636266228115197E8d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.floor(25.10345653640629d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        try {
//            int int8 = randomDataImpl0.nextBinomial(18, (double) 36L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 36 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aba28e22f010837b83484eada707b000653e31b1d092400494339e22a6c81a98a647894b3967547c6a84880ff3a8b5c1572" + "'", str2.equals("4aba28e22f010837b83484eada707b000653e31b1d092400494339e22a6c81a98a647894b3967547c6a84880ff3a8b5c1572"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 41L + "'", long5 == 41L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextT(103.0d);
//        try {
//            int[] intArray15 = randomDataImpl0.nextPermutation(33, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (33): permutation size (97) exceeds permuation domain (33)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "83b8220e792558adfafdfd7cf48a7e0c0107a65e245f11f998b77ea79bb28a74a9c650e9c08a5e1baa79f17906fbfe72ecf9" + "'", str2.equals("83b8220e792558adfafdfd7cf48a7e0c0107a65e245f11f998b77ea79bb28a74a9c650e9c08a5e1baa79f17906fbfe72ecf9"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 41L + "'", long5 == 41L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-14.463421020388624d) + "'", double10 == (-14.463421020388624d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8556131217762564d + "'", double12 == 0.8556131217762564d);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        double double17 = normalDistributionImpl6.sample();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.0736961533991303d) + "'", double7 == (-2.0736961533991303d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9625236616387699d + "'", double9 == 0.9625236616387699d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.22965464497339058d) + "'", double10 == (-0.22965464497339058d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8746788966462123d + "'", double17 == 0.8746788966462123d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean26 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.418314401392866d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4183144013928657d) + "'", double1 == (-1.4183144013928657d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.20261683735638392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        double double9 = randomDataImpl0.nextT((double) 8);
//        double double11 = randomDataImpl0.nextChiSquare(1.0758167588358958d);
//        try {
//            long long13 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 43.812070557447164d + "'", double3 == 43.812070557447164d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-32.98720718825208d) + "'", double6 == (-32.98720718825208d));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.17748428455417353d + "'", double9 == 0.17748428455417353d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.22506996564836707d + "'", double11 == 0.22506996564836707d);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        long long1 = org.apache.commons.math.util.FastMath.abs(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Class<?> wildcardClass35 = convergenceException32.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        try {
//            double double5 = randomDataImpl0.nextGaussian(25.10345653640629d, (-0.7110158499104279d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.711 is smaller than, or equal to, the minimum (0): standard deviation (-0.711)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4544001638784045d + "'", double2 == 1.4544001638784045d);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        try {
//            int int6 = randomDataImpl0.nextHypergeometric(21, (int) (byte) 10, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (21): sample size (32) must be less than or equal to population size (21)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "414751f543e6999cf80731144b7d10b90e5e8eb2787d8a83e4cb8f52b72b5ecd82d1f13ab6c983b9dd816bfb56219c65eec6" + "'", str2.equals("414751f543e6999cf80731144b7d10b90e5e8eb2787d8a83e4cb8f52b72b5ecd82d1f13ab6c983b9dd816bfb56219c65eec6"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int2 = org.apache.commons.math.util.FastMath.min(29, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) (-0.7478398134896268d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator(0L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0576428125930508d + "'", double7 == 1.0576428125930508d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7956013766453628d + "'", double9 == 0.7956013766453628d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.6481398906637532d) + "'", double10 == (-0.6481398906637532d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl0.nextExponential(231.3681718779007d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("82a008dd5bac9f43deb4dd3c9427737d07e8c51f37a400eff71d3616c3e04519b7b0a0856d5aa14a205638f9752e6f9a92d9", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.927598634279941d + "'", double8 == 0.927598634279941d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7993046148091836d + "'", double10 == 0.7993046148091836d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7993046148091836d + "'", double11 == 0.7993046148091836d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 133.8288863868113d + "'", double13 == 133.8288863868113d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.43866754701966326d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int int6 = randomDataImpl0.nextZipf((int) (short) 10, 10.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 40.84244924807754d + "'", double3 == 40.84244924807754d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        java.lang.Number number11 = numberIsTooLargeException9.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0f + "'", number11.equals(100.0f));
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        double double18 = normalDistributionImpl6.cumulativeProbability((-0.24510465435485307d));
//        try {
//            double double20 = normalDistributionImpl6.inverseCumulativeProbability(25.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 25 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.16153097916819248d + "'", double7 == 0.16153097916819248d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.41865009085135535d + "'", double9 == 0.41865009085135535d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.4423274578953337d) + "'", double10 == (-0.4423274578953337d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.4031876995883735d + "'", double18 == 0.4031876995883735d);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        try {
//            long long11 = randomDataImpl0.nextSecureLong((long) 34, (long) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 34 is larger than, or equal to, the maximum (10): lower bound (34) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 50L + "'", long6 == 50L);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        randomDataImpl0.reSeedSecure((long) 3);
//        try {
//            double double12 = randomDataImpl0.nextExponential((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 51L + "'", long6 == 51L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException2.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.6931326168456545d), (double) 36L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6931326168456545d) + "'", double2 == (-0.6931326168456545d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 98L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 98.0f + "'", float1 == 98.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.6481398906637532d), 3.4424325245802145d, 0.02120909795200876d, 30);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        long long2 = org.apache.commons.math.util.FastMath.max(48L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 21, (-0.816373817280005d), (double) 0L, (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextBeta(1.0674342759877273d, 7.105427357601002E-15d);
        try {
            int[] intArray7 = randomDataImpl1.nextPermutation(10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        try {
//            double double7 = randomDataImpl0.nextExponential((-0.5772029940076152d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.577 is smaller than, or equal to, the minimum (0): mean (-0.577)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 9, (float) 98L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        try {
//            double double14 = randomDataImpl0.nextGaussian((-1.7809618602685398d), (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed(39L);
//        try {
//            int int10 = randomDataImpl0.nextInt(8, 7);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 8 is larger than, or equal to, the maximum (7): lower bound (8) must be strictly less than upper bound (7)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f" + "'", str5.equals("f"));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.24510465435485307d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2501338698970547d) + "'", double1 == (-0.2501338698970547d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.20261683735638392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3667668759598282d + "'", double1 == 1.3667668759598282d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.special.Gamma.digamma(57.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.034253688303048d + "'", double1 == 4.034253688303048d);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = normalDistributionImpl12.sample();
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double18 = normalDistributionImpl12.getStandardDeviation();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6040903237761033d + "'", double13 == 0.6040903237761033d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.008146492901006d + "'", double15 == 1.008146492901006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.46284165083621587d) + "'", double16 == (-0.46284165083621587d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.8850188279773964d) + "'", double17 == (-0.8850188279773964d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl0.nextBeta(0.6040903237761033d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.34");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2384530189020388d + "'", double8 == 1.2384530189020388d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9951674396667902d + "'", double10 == 0.9951674396667902d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9951674396667902d + "'", double11 == 0.9951674396667902d);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        java.lang.Object[] objArray23 = notStrictlyPositiveException2.getArguments();
        java.lang.Number number24 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10.0f + "'", number24.equals(10.0f));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.882893437260871d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1325.7669470624392d + "'", double1 == 1325.7669470624392d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed(39L);
//        try {
//            int int10 = randomDataImpl0.nextPascal(21, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        java.lang.String str27 = maxIterationsExceededException26.getPattern();
        java.lang.Object[] objArray28 = maxIterationsExceededException26.getArguments();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.8727929238079155d), (double) (-1L), 16.975649656605654d, (int) (byte) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 38L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.0d + "'", double1 == 38.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.4424325245802145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.997955783106022d + "'", double1 == 0.997955783106022d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6954783528958071d, 10.626714569240598d, 9.999999999999998d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 10.627 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36658256098571557d + "'", double8 == 0.36658256098571557d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5901731071143256d + "'", double10 == 0.5901731071143256d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.58990586268745d + "'", double11 == 0.58990586268745d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        long long11 = randomDataImpl0.nextSecureLong((long) (-1), 45L);
//        try {
//            double double14 = randomDataImpl0.nextF(0.0d, (double) 39L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.7496563856361d + "'", double3 == 37.7496563856361d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 16.446380011325417d + "'", double6 == 16.446380011325417d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.28676104021103d + "'", double8 == 100.28676104021103d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed(39L);
//        try {
//            double double10 = randomDataImpl0.nextGaussian((-0.7478398134896268d), (-0.5359799741755117d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.536 is smaller than, or equal to, the minimum (0): standard deviation (-0.536)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = randomDataImpl0.nextGaussian(0.4031876995883735d, (double) 97.0f);
//        try {
//            int[] intArray22 = randomDataImpl0.nextPermutation(0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0): permutation size (100) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0ad5726c59f473eda0d270d06efdabef817aad1e79ca39742e02473cef7be9a898e737a1ed7787d39d6c6303afa1abc15782" + "'", str2.equals("0ad5726c59f473eda0d270d06efdabef817aad1e79ca39742e02473cef7be9a898e737a1ed7787d39d6c6303afa1abc15782"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 39L + "'", long5 == 39L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.13100306307315124d + "'", double13 == 0.13100306307315124d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5760665378999025d + "'", double15 == 0.5760665378999025d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.13381958739597585d) + "'", double16 == (-0.13381958739597585d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.60921883165913d + "'", double19 == 32.60921883165913d);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        try {
//            double double11 = randomDataImpl0.nextGaussian(57.0d, (-0.2501338698970547d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.25 is smaller than, or equal to, the minimum (0): standard deviation (-0.25)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.64000905641644d + "'", double3 == 37.64000905641644d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 20.08383263349421d + "'", double6 == 20.08383263349421d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 89.04367876990172d + "'", double8 == 89.04367876990172d);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 9.0f, 36.264664323635685d, 4.428880147757328E-216d, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 36.265 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 8, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07982998571223732d + "'", double2 == 0.07982998571223732d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray8);
        java.lang.String str11 = mathException10.getPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d" + "'", str11.equals("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d"));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        double double11 = randomDataImpl0.nextT(25.10345653640629d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.MathException: hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6aa221254675d13d6682e54144ba837cb677a95a5d7fbd225a88692d75b05098e39832fa6be2f638aff41699881e693fb" + "'", str7.equals("6aa221254675d13d6682e54144ba837cb677a95a5d7fbd225a88692d75b05098e39832fa6be2f638aff41699881e693fb"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "5cee8f608a5548feff1ec8553da5fb" + "'", str9.equals("5cee8f608a5548feff1ec8553da5fb"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.621543827030772d + "'", double11 == 0.621543827030772d);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.997955783106022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7843750095329144d + "'", double1 == 0.7843750095329144d);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        try {
//            int int9 = randomDataImpl0.nextPascal(0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 37L + "'", long6 == 37L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.034253688303048d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3366148380992204d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        try {
//            double double14 = randomDataImpl0.nextWeibull((-0.7853981633974483d), 38.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0): shape (-0.785)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29 + "'", int5 == 29);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.680296316732292d + "'", double7 == 1.680296316732292d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6456201019680475d + "'", double9 == 0.6456201019680475d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08949959859402752d + "'", double11 == 0.08949959859402752d);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.3110421742117833d, 0.0d, 27.990841778891753d, (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        double double8 = randomDataImpl0.nextT(36.264664323635685d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 42L + "'", long6 == 42L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.23806859454006649d + "'", double8 == 0.23806859454006649d);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.7113050055174964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8630646514623409d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9520968095674806d) + "'", double1 == (-0.9520968095674806d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextBeta(1.0674342759877273d, 7.105427357601002E-15d);
        try {
            int int7 = randomDataImpl1.nextPascal(1, 1.3096728250148222d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.31 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(19.38216099078707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.052947673676738645d + "'", double1 == 0.052947673676738645d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.String str9 = mathException8.getPattern();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
//        long long9 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("2d1a500ccb54575149a37650ba9679702f5234f42548ea988ede9c9a9babe6ec64149a32619e5368e017495c4244e49531f0", "7d0386425bc6159fb13ad79fc691f264b354d3f226c6c4c845fd2c095d04ed6245231b25d4993feb19bb779fbd340e4a62ab");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 7d0386425bc6159fb13ad79fc691f264b354d3f226c6c4c845fd2c095d04ed6245231b25d4993feb19bb779fbd340e4a62ab");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 88.84450792549285d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5901731071143256d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5901731071143256d + "'", double1 == 0.5901731071143256d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9149994957367078d + "'", double1 == 0.9149994957367078d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            double double5 = randomDataImpl1.nextCauchy((double) 9.0f, (-0.17902745162659536d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.179 is smaller than, or equal to, the minimum (0): scale (-0.179)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        long long8 = randomDataImpl0.nextLong(17L, 40L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "adc8d041e16a7b645bce84a6e2059410b671b7a6b8df171f9e28da12ebe98e2e6be188098ce03bde63082ce8d458ff5eadc4" + "'", str2.equals("adc8d041e16a7b645bce84a6e2059410b671b7a6b8df171f9e28da12ebe98e2e6be188098ce03bde63082ce8d458ff5eadc4"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24L + "'", long8 == 24L);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        try {
//            long long5 = randomDataImpl0.nextPoisson((double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 37L + "'", long3 == 37L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.14731976327079624d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14731976327079624d + "'", double1 == 0.14731976327079624d);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 84L + "'", long3 == 84L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.832707186828588d + "'", double6 == 0.832707186828588d);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((double) (short) 10);
        double double4 = normalDistributionImpl0.density((double) 22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.69459862670642E-23d + "'", double2 == 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.1742815528252627E-106d + "'", double4 == 3.1742815528252627E-106d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.29588497520587087d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3050036944853915d) + "'", double1 == (-0.3050036944853915d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        java.lang.Number number23 = notStrictlyPositiveException2.getMin();
        boolean boolean24 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 99 + "'", int6 == 99);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.sin(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9287285890885333d) + "'", double1 == (-0.9287285890885333d));
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        randomDataImpl0.reSeed(48L);
//        try {
//            double double10 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.29569795315873d + "'", double3 == 51.29569795315873d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.5519562803930635d, 1.0113154145053396d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.551956280393063d + "'", double2 == 2.551956280393063d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Throwable[] throwableArray7 = outOfRangeException3.getSuppressed();
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, "", objArray22);
        boolean boolean26 = notStrictlyPositiveException5.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 1.724594607551417d, 2.718281828459045d, mathException27 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", objArray28);
        java.lang.String str30 = mathException29.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math.random.RandomDataImpl();
        int int37 = randomDataImpl34.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!", int37, (-1L) };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53, localizable54, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException43, "", objArray60);
        mathException40.addSuppressed((java.lang.Throwable) convergenceException63);
        convergenceException31.addSuppressed((java.lang.Throwable) convergenceException63);
        mathException29.addSuppressed((java.lang.Throwable) convergenceException63);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed" + "'", str30.equals("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 41.495947860226735d, (java.lang.Number) (-0.2501338698970547d), (java.lang.Number) (-13.798894071760017d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(19.38216099078707d, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.005460786486874557d + "'", double2 == 0.005460786486874557d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(4.034253688303048d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28110737144886916d + "'", double1 == 0.28110737144886916d);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int9 = randomDataImpl0.nextZipf((int) 'a', 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.27829965900511133d, (-0.46284165083621587d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable0, "hi!", objArray8);
        java.lang.Throwable[] throwableArray12 = mathException11.getSuppressed();
        java.lang.String str13 = mathException11.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str13.equals("org.apache.commons.math.MathException: hi!"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 98L, (java.lang.Number) 0L, (java.lang.Number) 3.1742815528252627E-106d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number25 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.floor(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        long long3 = randomDataImpl0.nextPoisson(0.6040903237761033d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.46284165083621587d), 1.724594607551417d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) 0, 0.6040903237761033d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (-0.39216512435927603d), (double) 48L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.392 is smaller than, or equal to, the minimum (0): standard deviation (-0.392)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.2697061456155927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9559125998300264d + "'", double1 == 0.9559125998300264d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.0102271666701927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6655273582452867d + "'", double1 == 3.6655273582452867d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        java.lang.Number number23 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number24 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10.0f + "'", number23.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10.0f + "'", number24.equals(10.0f));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.7809618602685398d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7809618602685398d + "'", double1 == 1.7809618602685398d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9287285890885333d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.016209371736996388d) + "'", double1 == (-0.016209371736996388d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.6321205588285577d), (double) 97);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6321205588285577d) + "'", double3 == (-0.6321205588285577d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            double double5 = randomDataImpl1.nextCauchy((-1.0d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.58990586268745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.768053294171342d + "'", double1 == 0.768053294171342d);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextT(103.0d);
//        try {
//            int[] intArray15 = randomDataImpl0.nextPermutation(1, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): permutation size (100) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "20e9608223747161c36741e1c13e65f121959ce8123bcde52518c372255b33bafaf35eafc25eb69cb7180586192f3f0b02f4" + "'", str2.equals("20e9608223747161c36741e1c13e65f121959ce8123bcde52518c372255b33bafaf35eafc25eb69cb7180586192f3f0b02f4"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 42L + "'", long5 == 42L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-18.748191374075372d) + "'", double10 == (-18.748191374075372d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6184388357944465d + "'", double12 == 0.6184388357944465d);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray34 = convergenceException32.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray42);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException43, "hi!", objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0E20d, (double) 38L, (-0.1905934664251d), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.6481398906637532d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6406520265206169d) + "'", double1 == (-0.6406520265206169d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 5L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        try {
//            double double12 = normalDistributionImpl6.cumulativeProbability((double) 10L, (double) (-1.0f));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.36863279703745466d) + "'", double7 == (-0.36863279703745466d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.7138457026793927d + "'", double9 == 1.7138457026793927d);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) 0.5156123319920012d, false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.23806859454006649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4879227341906365d + "'", double1 == 0.4879227341906365d);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        java.lang.String str9 = randomDataImpl0.nextHexString(3);
//        try {
//            double double12 = randomDataImpl0.nextF((-1.7809618602685398d), Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.781 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.781)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.53962935090246d + "'", double7 == 20.53962935090246d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4f5" + "'", str9.equals("4f5"));
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextPascal((int) ' ', 0.5856749831752239d);
//        try {
//            double double12 = randomDataImpl0.nextT((-0.8727929238079155d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.873 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.873)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "60e8378df0d88379ba90ddbf52f0dd7ddffee9655e257de80668e22171b56feecc44550d9481c1a23651f8bfcc6d57915" + "'", str7.equals("60e8378df0d88379ba90ddbf52f0dd7ddffee9655e257de80668e22171b56feecc44550d9481c1a23651f8bfcc6d57915"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.0d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
//        try {
//            long long9 = randomDataImpl0.nextSecureLong((long) 100, 98L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (98): lower bound (100) must be strictly less than upper bound (98)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable45, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable5, objArray46);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 0.9025352261814413d, (java.lang.Number) 6.2564893518218625E35d, (java.lang.Number) 45.54377006014086d);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            double double6 = randomDataImpl0.nextF(3.1742815528252627E-106d, (-0.8850188279773964d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.885 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.885)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.718281828459045d, 1.7809618602685398d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.935562855836009d + "'", double2 == 5.935562855836009d);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        double double11 = randomDataImpl0.nextT(25.10345653640629d);
//        try {
//            int int14 = randomDataImpl0.nextPascal(22, 97.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 97 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 28 + "'", int5 == 28);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "b8691cc73a9873c1a0cfa2e9c8b2999454ec419e90fbd1394acc9c2c7bae7d9dd0d0c16f596d8edce871cc46e0592c047" + "'", str7.equals("b8691cc73a9873c1a0cfa2e9c8b2999454ec419e90fbd1394acc9c2c7bae7d9dd0d0c16f596d8edce871cc46e0592c047"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "96a00f04f2bb239a42ca008733be3d" + "'", str9.equals("96a00f04f2bb239a42ca008733be3d"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.5773883803042115d) + "'", double11 == (-0.5773883803042115d));
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        randomDataImpl0.reSeedSecure((long) 3);
//        try {
//            java.lang.String str12 = randomDataImpl0.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 50L + "'", long6 == 50L);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double2 = org.apache.commons.math.util.FastMath.min(6.942898894086964d, 0.6040903237761033d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6040903237761033d + "'", double2 == 0.6040903237761033d);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        try {
//            double double10 = randomDataImpl0.nextBeta(0.0d, 2.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.658");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8844a91c6fea151e345de552a6432d7a3167d21db6504a54dfefe30188fe2a0f0f541dac6f9a628d966a5b6159b423ba5c0b" + "'", str2.equals("8844a91c6fea151e345de552a6432d7a3167d21db6504a54dfefe30188fe2a0f0f541dac6f9a628d966a5b6159b423ba5c0b"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 33L + "'", long5 == 33L);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        double double18 = normalDistributionImpl6.cumulativeProbability((-0.24510465435485307d));
//        double double19 = normalDistributionImpl6.sample();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.8840756671754414d) + "'", double7 == (-0.8840756671754414d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.1311957035940396d) + "'", double9 == (-1.1311957035940396d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.34919429961968834d) + "'", double10 == (-0.34919429961968834d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.4031876995883735d + "'", double18 == 0.4031876995883735d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.8746788966462123d + "'", double19 == 0.8746788966462123d);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-1.418314401392866d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.038779776149324d + "'", double1 == 10.038779776149324d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.5359799741755117d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8122995035639646d) + "'", double1 == (-0.8122995035639646d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray34 = convergenceException32.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray42);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException43, "hi!", objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("4", objArray52);
        java.lang.String str57 = convergenceException56.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.ConvergenceException: 4" + "'", str57.equals("org.apache.commons.math.ConvergenceException: 4"));
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl0.nextGaussian(2.718281828459045d, (-0.6931326168456545d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.693 is smaller than, or equal to, the minimum (0): standard deviation (-0.693)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.253510400095788d) + "'", double8 == (-1.253510400095788d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.26619911605540647d) + "'", double10 == (-0.26619911605540647d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.26619911605540647d) + "'", double11 == (-0.26619911605540647d));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
        double double4 = normalDistributionImpl0.density((double) 100L);
        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10.0f, (double) (short) 10);
        normalDistributionImpl0.reseedRandomGenerator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13313701469396122d + "'", double1 == 0.13313701469396122d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-8.176904988673762d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1427139146751068d) + "'", double1 == (-0.1427139146751068d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13.0f + "'", float1 == 13.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable22, objArray23);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
        int int30 = randomDataImpl27.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray32 = new java.lang.Object[] { "hi!", int30, (-1L) };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
        int int44 = randomDataImpl41.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", int44, (-1L) };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47, localizable48, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37, "", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException33, "", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, localizable22, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable5, objArray54);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray54);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        try {
//            int int10 = randomDataImpl0.nextBinomial(24, (-0.21931231246647523d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.219 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "20d49a48ae2466c07b10c615de931fd265a30f652520d0879482f6952cb9fa5ce829a249b1ae6d53cace63771aff39b25664" + "'", str2.equals("20d49a48ae2466c07b10c615de931fd265a30f652520d0879482f6952cb9fa5ce829a249b1ae6d53cace63771aff39b25664"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 38L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 38 + "'", int1 == 38);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        long long11 = randomDataImpl0.nextSecureLong((long) (-1), 45L);
//        try {
//            double double13 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.657276332346793d + "'", double3 == 18.657276332346793d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.0354878865664663d) + "'", double6 == (-3.0354878865664663d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 112.90845658804827d + "'", double8 == 112.90845658804827d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25L + "'", long11 == 25L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.8125268827955464d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9049299941346214d) + "'", double1 == (-0.9049299941346214d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1.0f, 4.198520144579203d, (double) 34);
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability((double) 13.0f, 5.000994718583564d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.2697061456155927d, (-0.8727929238079155d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2697061456155923d + "'", double2 == 3.2697061456155923d);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double9 = randomDataImpl0.nextF(0.0d, (double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8" + "'", str5.equals("8"));
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        randomDataImpl0.reSeed(48L);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(0, 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3 is larger than the maximum (0): permutation size (3) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.12560858593808d + "'", double3 == 10.12560858593808d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.9287285890885333d), (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.18365271015776613d) + "'", double2 == (-0.18365271015776613d));
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            int int20 = randomDataImpl0.nextHypergeometric((int) (short) 10, (int) (short) -1, 34);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "22c1893b69e04f461d4ec161cc992cde6a3e907a4bfd74dd570a156966805ca32014030e5c85ec91ed6b1d3f192729a445d8" + "'", str2.equals("22c1893b69e04f461d4ec161cc992cde6a3e907a4bfd74dd570a156966805ca32014030e5c85ec91ed6b1d3f192729a445d8"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 33L + "'", long5 == 33L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.2982131313118446d) + "'", double13 == (-1.2982131313118446d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.9370560599868504d) + "'", double15 == (-0.9370560599868504d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.35885774792912656d) + "'", double16 == (-0.35885774792912656d));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.5679423644440202d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.451707610305872d + "'", double1 == 9.451707610305872d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        try {
//            double double4 = randomDataImpl0.nextExponential((-0.39216512435927603d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.392 is smaller than, or equal to, the minimum (0): mean (-0.392)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06672725904209667d + "'", double2 == 0.06672725904209667d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
        int int7 = randomDataImpl4.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", int7, (-1L) };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
        int int24 = randomDataImpl21.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray26 = new java.lang.Object[] { "hi!", int24, (-1L) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27, localizable28, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException17, "", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math.random.RandomDataImpl();
        int int48 = randomDataImpl45.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray50 = new java.lang.Object[] { "hi!", int48, (-1L) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51, localizable52, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException41, "", objArray58);
        java.lang.Object[] objArray62 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10, localizable14, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("4", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("5eae1714baba40af9a64548b758e4ef8c717ade920069b0f91413ba60307dc6e90a538fa93bce8e5d0c708eeb086c06bbcd7", objArray62);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException3.getArgument();
        java.lang.Number number7 = outOfRangeException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0758167588358958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6367030434169783d + "'", double1 == 1.6367030434169783d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        java.lang.Throwable[] throwableArray36 = convergenceException32.getSuppressed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", objArray1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5679423644440202d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8430095582228464d + "'", double1 == 0.8430095582228464d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        int int12 = randomDataImpl0.nextZipf(30, 1.0674342759877273d);
//        try {
//            double double15 = randomDataImpl0.nextWeibull(0.0d, 0.839207242521137d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.52035053679695d + "'", double3 == 22.52035053679695d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24L + "'", long9 == 24L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        long long9 = randomDataImpl0.nextPoisson(81.1203032558295d);
//        java.lang.String str11 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "cbc9f8f4547dd5e27b063502c7ac8980896bb1075c4ebdf63e6dd4f46f8d415a3b955a76479adb99f898855ecc88e428d" + "'", str7.equals("cbc9f8f4547dd5e27b063502c7ac8980896bb1075c4ebdf63e6dd4f46f8d415a3b955a76479adb99f898855ecc88e428d"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 80L + "'", long9 == 80L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl0.nextF(0.0d, (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1019959654410776d + "'", double8 == 1.1019959654410776d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.3542124388584602d) + "'", double10 == (-0.3542124388584602d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.3542124388584602d) + "'", double11 == (-0.3542124388584602d));
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextT(103.0d);
//        try {
//            double double15 = randomDataImpl0.nextGaussian(19.954590094035403d, (-1.7809618602685398d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.781 is smaller than, or equal to, the minimum (0): standard deviation (-1.781)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0dbc104725a6567ab27aefb0122f092c9f93d71ce897e8eeab7fb519ba52234d5f2dbaa4ea921b06cb993511472333be11e1" + "'", str2.equals("0dbc104725a6567ab27aefb0122f092c9f93d71ce897e8eeab7fb519ba52234d5f2dbaa4ea921b06cb993511472333be11e1"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-25.956408176289735d) + "'", double10 == (-25.956408176289735d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.7573235954116276d) + "'", double12 == (-0.7573235954116276d));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(103.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 372.97946888568896d + "'", double1 == 372.97946888568896d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 30, 0.2658560769022296d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        java.lang.Number number36 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, number36, (java.lang.Number) (-1.0f), number38);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(19.954590094035403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1143.3137943017891d + "'", double1 == 1143.3137943017891d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9867717342662448d + "'", double1 == 1.9867717342662448d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.6655273582452867d, (-0.816373817280005d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.789936343236129d + "'", double2 == 1.789936343236129d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.20261683735638392d, 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999639609743824d + "'", double2 == 0.9999639609743824d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        long long1 = org.apache.commons.math.util.FastMath.abs(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        long long12 = randomDataImpl0.nextSecureLong((long) 7, 40L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.6397777546482646d) + "'", double7 == (-0.6397777546482646d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.46963627049625d) + "'", double9 == (-0.46963627049625d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextChiSquare(108.01798396338886d);
//        try {
//            double double15 = randomDataImpl0.nextBeta((double) (byte) -1, Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.133");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35cb7107cb64508df56d72da366100f9bca555cffcaff165faebf0877e4a582ce35c4ffa1193067a5c680b14025702c2a6d4" + "'", str2.equals("35cb7107cb64508df56d72da366100f9bca555cffcaff165faebf0877e4a582ce35c4ffa1193067a5c680b14025702c2a6d4"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 21.005658420827494d + "'", double10 == 21.005658420827494d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 96.80123306035804d + "'", double12 == 96.80123306035804d);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.sinh(82.42409747617464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1282446759109312E35d + "'", double1 == 3.1282446759109312E35d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        double double9 = randomDataImpl0.nextT((double) 8);
//        try {
//            int[] intArray12 = randomDataImpl0.nextPermutation(14, 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (14): permutation size (97) exceeds permuation domain (14)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.777559984543984d + "'", double3 == 16.777559984543984d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-112.20187066791246d) + "'", double6 == (-112.20187066791246d));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5983249800140921d + "'", double9 == 0.5983249800140921d);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.atan(37.53036172719677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.544157536197713d + "'", double1 == 1.544157536197713d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3366148380992204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1015446173918673d + "'", double1 == 1.1015446173918673d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            int int6 = randomDataImpl0.nextInt(34, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 34 is larger than, or equal to, the maximum (5): lower bound (34) must be strictly less than upper bound (5)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-2.0736961533991303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-2.71779385040451d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.4879227341906365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6289289845937014d + "'", double1 == 1.6289289845937014d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 17L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.6481398906637532d), 37.53036172719677d, (-0.1905934664251d), 38);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        int int12 = randomDataImpl0.nextZipf(30, 1.0674342759877273d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.95627162350246d + "'", double3 == 17.95627162350246d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.7478398134896268d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        try {
//            double double10 = randomDataImpl0.nextCauchy(4.428880147757328E-216d, (-1.7809618602685398d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.781 is smaller than, or equal to, the minimum (0): scale (-1.781)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "06d6ee1ef3f49f50c004b208a724fbd010c2f99987275f20a754a80b050bdba4da80ecb1b7f42c71d45feeb82ac3e990ca3c" + "'", str2.equals("06d6ee1ef3f49f50c004b208a724fbd010c2f99987275f20a754a80b050bdba4da80ecb1b7f42c71d45feeb82ac3e990ca3c"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.special.Erf.erf(38.89638657195819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7390357405091602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        java.lang.Class<?> wildcardClass18 = maxIterationsExceededException6.getClass();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
        int int38 = randomDataImpl35.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!", int38, (-1L) };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable42, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException31, "", objArray48);
        mathException28.addSuppressed((java.lang.Throwable) convergenceException51);
        java.lang.Object[] objArray53 = convergenceException51.getArguments();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51);
        java.lang.Throwable[] throwableArray55 = mathException54.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNull(localizable58);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextT(103.0d);
//        try {
//            double double15 = randomDataImpl0.nextGamma((-0.9449566763087935d), (-13.798894071760017d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.945 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e4d71c4a646b8c529006e5b717e2388498e8b5046c25e229a70a4d214a227281be9f6bf6eea703dd33f6ee048905c565cb4f" + "'", str2.equals("e4d71c4a646b8c529006e5b717e2388498e8b5046c25e229a70a4d214a227281be9f6bf6eea703dd33f6ee048905c565cb4f"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.717551597083883d) + "'", double10 == (-5.717551597083883d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.3622617272627197d) + "'", double12 == (-0.3622617272627197d));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9559125998300264d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.405331196646276d) + "'", double1 == (-6.405331196646276d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.3667668759598282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8615248364376218d + "'", double1 == 0.8615248364376218d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int1 = org.apache.commons.math.util.FastMath.abs(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        try {
            int int6 = randomDataImpl0.nextPascal(3, (double) 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 99 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.9E-324d, 0.9625236616387699d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.log(6.2564893518218625E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 82.42409747617464d + "'", double1 == 82.42409747617464d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(19.81753074252102d, 4.636266228115197E8d, (double) 24L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.2480912893363008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8100815403422811d + "'", double1 == 0.8100815403422811d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5359799741755117d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4899389301809507d) + "'", double1 == (-0.4899389301809507d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(97);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException9.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable17, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6, "", objArray23);
        java.lang.Object[] objArray27 = notStrictlyPositiveException6.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(21, "", objArray27);
        java.lang.Throwable[] throwableArray30 = maxIterationsExceededException29.getSuppressed();
        int int31 = maxIterationsExceededException29.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 21 + "'", int31 == 21);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.016209371736996388d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.34919429961968834d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.36452587191444596d) + "'", double1 == (-0.36452587191444596d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl0.nextWeibull(0.0d, (-1.5473193940752017d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.8286899808116163d) + "'", double8 == (-0.8286899808116163d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.3502996758406334d) + "'", double10 == (-1.3502996758406334d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.3502996758406334d) + "'", double11 == (-1.3502996758406334d));
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.2697061456155927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.269706145615593d + "'", double1 == 3.269706145615593d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-5.321160198215146d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8727929238079155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0608955130137179d) + "'", double1 == (-1.0608955130137179d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            int int6 = randomDataImpl0.nextPascal((int) (byte) 0, 0.3098365735476644d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
        } catch (org.apache.commons.math.MathException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9287285890885333d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.6412600009550813d) + "'", double1 == (-2.6412600009550813d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.1311957035940396d), 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1311957035940396d) + "'", double2 == (-1.1311957035940396d));
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 10.0f, (-0.3375322770451441d));
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.4398529392568697d) + "'", double4 == (-3.4398529392568697d));
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.10832802164921763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9999639609743824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.761579020074279d + "'", double1 == 0.761579020074279d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int1 = org.apache.commons.math.util.FastMath.abs(38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 38 + "'", int1 == 38);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 97, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException9);
        java.lang.Number number11 = numberIsTooLargeException9.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0f + "'", number11.equals(100.0f));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(81.1203032558295d, (-0.055284269790036866d), 1.3667668759598282d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.055 is smaller than, or equal to, the minimum (0): standard deviation (-0.055)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6197751905438615d + "'", double1 == 1.6197751905438615d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 51.67946398540717d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7956013766453628d, 9.999999995E-10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7956013766453627d + "'", double2 == 0.7956013766453627d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long2 = org.apache.commons.math.util.FastMath.min(45L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-0.1357258829059472d), (java.lang.Number) 34, false);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException30.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) (-0.9449566763087935d));
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(localizable32);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.033625453575000484d), (java.lang.Number) 0.5856749831752239d, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 98.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.899494936611665d + "'", double1 == 9.899494936611665d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.4031876995883735d, (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.927402988423584E-8d + "'", double2 == 7.927402988423584E-8d);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        try {
//            long long8 = randomDataImpl0.nextLong((long) 38, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 38 is larger than, or equal to, the maximum (0): lower bound (38) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("b6e20d25b5a319e392cab1245fe27364fa334a45cb8297ffb161d33fba72a27a8eecaede34bf5f88fdb4650395a816880f60", "7a");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 7a");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 44L + "'", long6 == 44L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        int int12 = randomDataImpl0.nextZipf(30, 1.0674342759877273d);
//        try {
//            double double15 = randomDataImpl0.nextGamma((-0.5068608141629324d), (double) 100.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.507 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.60816823360485d + "'", double3 == 15.60816823360485d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.06594438297966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2736190370090261d) + "'", double1 == (-1.2736190370090261d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.rint(15.59119787057521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6094379124341003d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-3.4398529392568697d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException9);
        boolean boolean12 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Number number13 = numberIsTooLargeException9.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 88.84450792549285d + "'", number13.equals(88.84450792549285d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.36452587191444596d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9439199172433264d + "'", double1 == 1.9439199172433264d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable12, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable20, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable20.getClass();
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(number24, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number28 = outOfRangeException27.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException27.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl();
        int int35 = randomDataImpl32.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray37 = new java.lang.Object[] { "hi!", int35, (-1L) };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl46 = new org.apache.commons.math.random.RandomDataImpl();
        int int49 = randomDataImpl46.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray51 = new java.lang.Object[] { "hi!", int49, (-1L) };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52, localizable53, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException42, "", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, "", objArray59);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable29, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable20, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(34, localizable6, objArray59);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
        int int22 = randomDataImpl19.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", int22, (-1L) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25, localizable26, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl();
        int int46 = randomDataImpl43.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!", int46, (-1L) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable50, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException39, "", objArray56);
        java.lang.Object[] objArray60 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable12, objArray60);
        java.lang.String str63 = mathException62.getPattern();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample(97);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.6931326168456545d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9774410046509527d) + "'", double1 == (-1.9774410046509527d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(19.81753074252102d, 1.6197751905438615d);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double5 = randomDataImpl0.nextChiSquare((double) 22);
//        randomDataImpl0.reSeed((long) (short) -1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.144427133186632d + "'", double5 == 21.144427133186632d);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.14731976327079624d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14785322473355786d) + "'", double1 == (-0.14785322473355786d));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        try {
//            int[] intArray5 = randomDataImpl0.nextPermutation((int) (byte) -1, 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 23 is larger than the maximum (-1): permutation size (23) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45740583043668753d + "'", double2 == 0.45740583043668753d);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.4879227341906365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46879203422680543d + "'", double1 == 0.46879203422680543d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        java.lang.Number number32 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, number32, number33, (java.lang.Number) 0.997955783106022d);
        java.lang.Number number36 = outOfRangeException35.getHi();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.997955783106022d + "'", number36.equals(0.997955783106022d));
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        randomDataImpl0.reSeedSecure((long) 3);
//        try {
//            double double13 = randomDataImpl0.nextGaussian(69.17391486639119d, (-1.4183144013928657d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.418 is smaller than, or equal to, the minimum (0): standard deviation (-1.418)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 51L + "'", long6 == 51L);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.special.Erf.erf(0.7956013766453627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7394746322833242d + "'", double1 == 0.7394746322833242d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double5 = randomDataImpl0.nextChiSquare((double) 22);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", "7");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 7");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 75L + "'", long3 == 75L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.4381003281496d + "'", double5 == 21.4381003281496d);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.10832802164921763d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 26);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 26.0f + "'", float1 == 26.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.724594607551417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.610246217177267d + "'", double1 == 5.610246217177267d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5089969824666987d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.1905934664251d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5754876432123086d) + "'", double1 == (-0.5754876432123086d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6);
        int int19 = maxIterationsExceededException6.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 108.01798396338886d);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, number24, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl39 = new org.apache.commons.math.random.RandomDataImpl();
        int int42 = randomDataImpl39.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", int42, (-1L) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, localizable46, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(throwable35, "", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable34, objArray52);
        java.lang.Object[] objArray63 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray63);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl68 = new org.apache.commons.math.random.RandomDataImpl();
        int int71 = randomDataImpl68.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray73 = new java.lang.Object[] { "hi!", int71, (-1L) };
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("hi!", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException64, "hi!", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException56, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("26e492a1dcd93e30c5dacecba0797c", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable10, objArray73);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 26.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.0d + "'", double1 == 26.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.1955975309844473d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6974768667811515d) + "'", double1 == (-0.6974768667811515d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.20261683735638392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20261683735638394d + "'", double1 == 0.20261683735638394d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = org.apache.commons.math.util.FastMath.min(32, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = normalDistributionImpl6.density((-0.7110158499104279d));
//        double double14 = normalDistributionImpl6.cumulativeProbability(0.0d, 41.495947860226735d);
//        normalDistributionImpl6.reseedRandomGenerator(32L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.148392767891138d + "'", double7 == 1.148392767891138d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.19408910267266494d + "'", double9 == 0.19408910267266494d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3098365735476644d + "'", double11 == 0.3098365735476644d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.2480912893363008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8477475417515761d + "'", double1 == 0.8477475417515761d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(6.942898894086964d, 0.9999999958776927d, 9.899494936611665d, 34);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.187772121133279E-5d + "'", double4 == 8.187772121133279E-5d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.acos((-2.06594438297966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        long long1 = org.apache.commons.math.util.FastMath.round(0.36658256098571557d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getArgument();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.4183144013928657d) + "'", number10.equals((-1.4183144013928657d)));
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        try {
//            randomDataImpl0.setSecureAlgorithm("2", "2d1a500ccb54575149a37650ba9679702f5234f42548ea988ede9c9a9babe6ec64149a32619e5368e017495c4244e49531f0");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 2d1a500ccb54575149a37650ba9679702f5234f42548ea988ede9c9a9babe6ec64149a32619e5368e017495c4244e49531f0");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 50L + "'", long6 == 50L);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(16.975649656605654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.60361156502505d + "'", double1 == 30.60361156502505d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.8133501605839204d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24018248431558664d) + "'", double1 == (-0.24018248431558664d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.2644165654189337d, 5.298292365610485d, (-0.24510465435485307d));
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 14);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9952353147692228d + "'", double5 == 0.9952353147692228d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 5L, (-1.1944025180403872d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1944025180403872d) + "'", double2 == (-1.1944025180403872d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 98.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.0d + "'", double1 == 98.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5068608141629324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5068608141629324d + "'", double1 == 0.5068608141629324d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.1282446759109312E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.10832802164921763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10811726189064005d + "'", double1 == 0.10811726189064005d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.9287285890885333d), 15.59119787057521d, 0.20261683735638394d, 52);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        try {
//            long long11 = randomDataImpl0.nextPoisson((-0.016209371736996388d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.016 is smaller than, or equal to, the minimum (0): mean (-0.016)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "7ec4fcd348eff5db083007d2685dbd4fdd0296253b73cf592815f53c4e7a6b4e5626130383931343420ffb48aff0df1b6" + "'", str7.equals("7ec4fcd348eff5db083007d2685dbd4fdd0296253b73cf592815f53c4e7a6b4e5626130383931343420ffb48aff0df1b6"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "288e4c43141bf5816557205291d390" + "'", str9.equals("288e4c43141bf5816557205291d390"));
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        randomDataImpl0.reSeedSecure();
        double double7 = randomDataImpl0.nextBeta((double) '#', 0.4031876995883735d);
        try {
            double double10 = randomDataImpl0.nextF(Double.POSITIVE_INFINITY, 114.51462084900638d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.018 p = 0.258");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9991539623862512d + "'", double7 == 0.9991539623862512d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.9541042821996493d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8227616911243721d) + "'", double1 == (-0.8227616911243721d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl();
        int int40 = randomDataImpl37.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray42 = new java.lang.Object[] { "hi!", int40, (-1L) };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43, localizable44, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException33, "", objArray50);
        boolean boolean54 = notStrictlyPositiveException33.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException33);
        java.lang.Object[] objArray56 = new java.lang.Object[] { 1.724594607551417d, 2.718281828459045d, mathException55 };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26, "adc8d041e16a7b645bce84a6e2059410b671b7a6b8df171f9e28da12ebe98e2e6be188098ce03bde63082ce8d458ff5eadc4", objArray56);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 38);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

