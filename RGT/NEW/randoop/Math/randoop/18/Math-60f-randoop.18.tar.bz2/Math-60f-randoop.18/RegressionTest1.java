import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        long long1 = org.apache.commons.math.util.FastMath.abs(38L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 38L + "'", long1 == 38L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.3375322770451441d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.428880147757328E-216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1044904722419934E-108d + "'", double1 == 2.1044904722419934E-108d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9449566763087935d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9813048965663718d) + "'", double1 == (-0.9813048965663718d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.44345298997665233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36703815289615943d + "'", double1 == 0.36703815289615943d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.3050036944853915d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 30.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable0, "hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 40L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.0d + "'", double1 == 40.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.0f + "'", float1 == 33.0f);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl0.nextT((double) 99);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 44L + "'", long6 == 44L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.8634957860258078d) + "'", double15 == (-0.8634957860258078d));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.6197751905438615d, 4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.170265157763989d + "'", double2 == 9.170265157763989d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.07982998571223732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0978339484578357d) + "'", double1 == (-1.0978339484578357d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2, (java.lang.Number) (short) 1, (java.lang.Number) 33);
        java.lang.Throwable[] throwableArray20 = outOfRangeException19.getSuppressed();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) 1 + "'", number21.equals((short) 1));
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        randomDataImpl0.reSeed((long) '4');
//        double double18 = randomDataImpl0.nextBeta((double) 30, (double) 15);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.7111597330556501d + "'", double18 == 0.7111597330556501d);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
//        double double5 = normalDistributionImpl0.getStandardDeviation();
//        double double6 = normalDistributionImpl0.getMean();
//        try {
//            double[] doubleArray8 = normalDistributionImpl0.sample((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6931420232578547d) + "'", double1 == (-1.6931420232578547d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        try {
//            int int10 = randomDataImpl0.nextZipf(7, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7a87e6f2c380294d20564c47ed65e3aaac19bfe10ec698ef7415372ad837c4630ffab629265b889f366a09c6310b380c7d19" + "'", str2.equals("7a87e6f2c380294d20564c47ed65e3aaac19bfe10ec698ef7415372ad837c4630ffab629265b889f366a09c6310b380c7d19"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.6409546159613835d + "'", double5 == 1.6409546159613835d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.780325945789497d) + "'", double7 == (-0.780325945789497d));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextSecureInt(1, 34);
//        try {
//            double double13 = randomDataImpl0.nextCauchy(0.23806859454006649d, (-0.36452587191444596d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.365 is smaller than, or equal to, the minimum (0): scale (-0.365)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "b346c52529bcd53e5ebd80cac5be5d238d82468c9c196796fc1de519bfe8623ff1527e54eb24003ed7748dd96508b84fe" + "'", str7.equals("b346c52529bcd53e5ebd80cac5be5d238d82468c9c196796fc1de519bfe8623ff1527e54eb24003ed7748dd96508b84fe"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        java.lang.Class<?> wildcardClass18 = maxIterationsExceededException6.getClass();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
        int int38 = randomDataImpl35.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!", int38, (-1L) };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable42, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException31, "", objArray48);
        mathException28.addSuppressed((java.lang.Throwable) convergenceException51);
        java.lang.Object[] objArray53 = convergenceException51.getArguments();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51);
        java.lang.Throwable[] throwableArray55 = mathException54.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6);
        int int58 = maxIterationsExceededException6.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl11.reSeedSecure((long) (byte) -1);
//        int int16 = randomDataImpl11.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl17.sample();
//        double double19 = normalDistributionImpl17.getStandardDeviation();
//        double double20 = randomDataImpl11.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double21 = normalDistributionImpl17.sample();
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double25 = randomDataImpl0.nextCauchy((-0.9708788351485366d), 0.3028848683749714d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d352b9c770d3ac335f6d8e30f0c1cc0c2a2782352a36b2a633e0d052813b0383128670aace5b45c31a8f9747241fe9417b66" + "'", str2.equals("d352b9c770d3ac335f6d8e30f0c1cc0c2a2782352a36b2a633e0d052813b0383128670aace5b45c31a8f9747241fe9417b66"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 16.397736320911534d + "'", double10 == 16.397736320911534d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28 + "'", int16 == 28);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.2775108988240696d) + "'", double18 == (-0.2775108988240696d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.5260476988902739d) + "'", double20 == (-0.5260476988902739d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.5622799064034203d) + "'", double21 == (-0.5622799064034203d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.54188646820458d + "'", double22 == 0.54188646820458d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.483758447589274d) + "'", double25 == (-1.483758447589274d));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 9.0f, 0.9025352261814413d, 26.0d, 31);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.440668485391159E-7d + "'", double4 == 4.440668485391159E-7d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-1), (java.lang.Number) (-0.19666828883033707d), false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.636266228115197E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", "8e83347d2535a71985a942b1872bfde5956d624fd185066d33b9c46deabf479eccf0fa6fe7d549e38fbb3397197d303b6");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 8e83347d2535a71985a942b1872bfde5956d624fd185066d33b9c46deabf479eccf0fa6fe7d549e38fbb3397197d303b6");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        int int9 = randomDataImpl0.nextZipf(34, 0.5772156649015329d);
//        randomDataImpl0.reSeed(89L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.47639359377014d + "'", double3 == 16.47639359377014d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3382624359377144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23044395339514506d + "'", double1 == 0.23044395339514506d);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextSecureInt(1, 34);
//        try {
//            java.lang.String str12 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4e3cfd298789a980d0526a94c14c3a5a16eb743777b07a90b1c7cdc9b1a352566ad04ca8fc8f636110c9e3e5669d9d83a" + "'", str7.equals("4e3cfd298789a980d0526a94c14c3a5a16eb743777b07a90b1c7cdc9b1a352566ad04ca8fc8f636110c9e3e5669d9d83a"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
        normalDistributionImpl0.reseedRandomGenerator((long) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.3432933379273535d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33041437229078297d + "'", double1 == 0.33041437229078297d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.018117385826449905d), 25.10345653640629d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 38);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.028089990678399235d + "'", double1 == 0.028089990678399235d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97, (float) 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8125268827955464d), (java.lang.Number) 0.3432933379273535d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 97.0f, (java.lang.Number) 5.551115123125783E-17d, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = normalDistributionImpl6.density((-0.7110158499104279d));
//        double double14 = normalDistributionImpl6.cumulativeProbability(0.0d, 41.495947860226735d);
//        double double15 = normalDistributionImpl6.sample();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.0017920840907606d) + "'", double7 == (-2.0017920840907606d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.448905707036035d) + "'", double9 == (-0.448905707036035d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3098365735476644d + "'", double11 == 0.3098365735476644d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.40367083980443336d + "'", double15 == 0.40367083980443336d);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.pow(19.38216099078707d, 0.023918480938191995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0734769038258434d + "'", double2 == 1.0734769038258434d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5446249945261114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2639024314211741d) + "'", double1 == (-0.2639024314211741d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.5519562803930635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.377126762797792d + "'", double1 == 6.377126762797792d);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed(39L);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b" + "'", str5.equals("b"));
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        try {
//            double double12 = randomDataImpl0.nextWeibull(0.0d, 0.4275739764777582d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.81844699612916d + "'", double3 == 32.81844699612916d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.483758447589274d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9777586211026399d) + "'", double1 == (-0.9777586211026399d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5430806348152437d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.000829913680131d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 30.274984543394233d, (java.lang.Number) (-0.6481398906637532d), true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 39L, (java.lang.Number) 7.105427357601002E-15d, true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            int[] intArray5 = randomDataImpl1.nextPermutation((int) (short) 0, 27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 27 is larger than the maximum (0): permutation size (27) exceeds permuation domain (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = randomDataImpl0.nextCauchy((double) 53L, 0.3110421742117833d);
//        int int13 = randomDataImpl0.nextBinomial(31, 9.999999995E-10d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-34.88911058046016d) + "'", double7 == (-34.88911058046016d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 53.08834833768392d + "'", double10 == 53.08834833768392d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.448905707036035d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007834882618771886d) + "'", double1 == (-0.007834882618771886d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(82.42409747617464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 82.42409747617465d + "'", double1 == 82.42409747617465d);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        randomDataImpl0.reSeedSecure((long) 3);
//        try {
//            double double12 = randomDataImpl0.nextChiSquare((-13.798894071760017d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -6.899 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 42L + "'", long6 == 42L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9520968095674806d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.016617224124685984d) + "'", double1 == (-0.016617224124685984d));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        double double14 = randomDataImpl0.nextGaussian((double) '4', 95.18738847087556d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 10.0f, (-0.3375322770451441d));
//        double double21 = normalDistributionImpl18.cumulativeProbability(1.1247031214354666d, 1.9439199172433264d);
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.15234600700358245d) + "'", double7 == (-0.15234600700358245d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.03818190073519069d) + "'", double9 == (-0.03818190073519069d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.522788904814426d) + "'", double11 == (-0.522788904814426d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.03598257045044d + "'", double14 == 101.03598257045044d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.032290773920338856d + "'", double21 == 0.032290773920338856d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.256420960809727d + "'", double22 == 8.256420960809727d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 10.0f, (-0.3375322770451441d));
        double double6 = normalDistributionImpl3.cumulativeProbability((-1.1944025180403872d), 5.551115123125783E-17d);
        double double8 = normalDistributionImpl3.cumulativeProbability((double) 32);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04753671340204302d + "'", double6 == 0.04753671340204302d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9993128620620841d + "'", double8 == 0.9993128620620841d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
        int int7 = randomDataImpl4.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", int7, (-1L) };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
        int int24 = randomDataImpl21.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray26 = new java.lang.Object[] { "hi!", int24, (-1L) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27, localizable28, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException17, "", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math.random.RandomDataImpl();
        int int48 = randomDataImpl45.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray50 = new java.lang.Object[] { "hi!", int48, (-1L) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51, localizable52, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException41, "", objArray58);
        java.lang.Object[] objArray62 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10, localizable14, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("4", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("9adbcea2f3a3cd3f119bd76ce03aab46b5a517ca188316f6cebf1d99211e3e8aab2a7c57278241eecd0132e9f16b7794e0c9", objArray62);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9149994957367078d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2997277948552883d + "'", double1 == 1.2997277948552883d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray33);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl();
        int int41 = randomDataImpl38.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray43 = new java.lang.Object[] { "hi!", int41, (-1L) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException34, "hi!", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException26);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(objArray43);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 39L + "'", long3 == 39L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9353656293327904d + "'", double6 == 0.9353656293327904d);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(36.264664323635685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6329377945779652d + "'", double1 == 0.6329377945779652d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.000000000000004d + "'", double1 == 23.000000000000004d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        randomDataImpl0.reSeed(37L);
        randomDataImpl0.reSeedSecure();
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        normalDistributionImpl6.reseedRandomGenerator((long) 16);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2280285764566843d + "'", double7 == 1.2280285764566843d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7041750014236432d + "'", double9 == 0.7041750014236432d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7229707585169192d + "'", double10 == 0.7229707585169192d);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.0d), 37.53036172719677d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl0.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.621164517356036d + "'", double3 == 39.621164517356036d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.6547676657206d + "'", double6 == 11.6547676657206d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 104.41482856581185d + "'", double8 == 104.41482856581185d);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        try {
//            double double10 = randomDataImpl0.nextGaussian((-1.1311957035940396d), (-0.8727929238079155d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.873 is smaller than, or equal to, the minimum (0): standard deviation (-0.873)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c" + "'", str5.equals("c"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.46963627049625d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number24 = notStrictlyPositiveException2.getMin();
        java.lang.Number number25 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = normalDistributionImpl6.density((-0.7110158499104279d));
//        double double14 = normalDistributionImpl6.cumulativeProbability((-1.9774410046509527d), (-0.34919429961968834d));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5186670408461083d + "'", double7 == 1.5186670408461083d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7096524435590275d + "'", double9 == 0.7096524435590275d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3098365735476644d + "'", double11 == 0.3098365735476644d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.33947582128132453d + "'", double14 == 0.33947582128132453d);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        int int13 = randomDataImpl0.nextHypergeometric((int) '4', 1, 22);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.91355790191462d + "'", double3 == 39.91355790191462d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18L + "'", long9 == 18L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.6040903237761033d);
        double double5 = normalDistributionImpl2.cumulativeProbability(9.899494936611665d, (double) 100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        int int9 = randomDataImpl0.nextZipf(34, 0.5772156649015329d);
//        double double12 = randomDataImpl0.nextWeibull((double) 19, 0.839207242521137d);
//        java.lang.String str14 = randomDataImpl0.nextHexString(31);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.29328951778261d + "'", double3 == 41.29328951778261d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8928992299732386d + "'", double12 == 0.8928992299732386d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "771cdd22b9f42808b795a19e3a01053" + "'", str14.equals("771cdd22b9f42808b795a19e3a01053"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7041750014236432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 37L, (float) 18L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.9E-324d, 98.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        randomDataImpl0.reSeed(48L);
//        try {
//            int int11 = randomDataImpl0.nextBinomial(26, (-0.522788904814426d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.523 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.18364218856294d + "'", double3 == 41.18364218856294d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        java.lang.String str9 = randomDataImpl0.nextHexString(3);
//        int int12 = randomDataImpl0.nextSecureInt(18, 100);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-51.16820020508656d) + "'", double7 == (-51.16820020508656d));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "624" + "'", str9.equals("624"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int2 = org.apache.commons.math.util.FastMath.max(37, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.4352001569325787d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1582728106299016d) + "'", double1 == (-1.1582728106299016d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0978339484578357d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 22);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.17902745162659536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.8133501605839204d), (java.lang.Number) 9.0f, false);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        double double5 = randomDataImpl0.nextGamma(1.5574077246549023d, 0.13313701469396122d);
//        try {
//            double double7 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1241070426726407d + "'", double2 == 1.1241070426726407d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.07351253371476818d + "'", double5 == 0.07351253371476818d);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray30);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
        int int38 = randomDataImpl35.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray40 = new java.lang.Object[] { "hi!", int38, (-1L) };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException31, "hi!", objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2, "b5612923fa902b557ce89d456db0618023d246eba06c5b0b54e2de2b27ce0749bd1558dfdc6313f1741260f29750f564bbaf", objArray40);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 7, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1325.7669470624392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 13.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.cos(40.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6669380616522619d) + "'", double1 == (-0.6669380616522619d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4339872044851463d + "'", double1 == 3.4339872044851463d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
        randomDataImpl0.reSeedSecure();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str6 = randomDataImpl4.nextSecureHexString((int) (short) 100);
//        long long9 = randomDataImpl4.nextLong((long) ' ', 42L);
//        randomDataImpl4.reSeedSecure(38L);
//        double double14 = randomDataImpl4.nextGaussian((double) 1, 16.975649656605654d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl15.reSeedSecure((long) (byte) -1);
//        int int20 = randomDataImpl15.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl21 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double22 = normalDistributionImpl21.sample();
//        double double23 = normalDistributionImpl21.getStandardDeviation();
//        double double24 = randomDataImpl15.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl21);
//        double double25 = normalDistributionImpl21.sample();
//        double double27 = normalDistributionImpl21.density(57.29577951308232d);
//        normalDistributionImpl21.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl21.reseedRandomGenerator((long) 10);
//        double double32 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl21);
//        double double33 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl21);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2729967908999662d + "'", double2 == 1.2729967908999662d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3f3f62013a606d06a7573d233975e18b3f13d818eb8a3de6b0bf27674f7991a1e77a51a0fa298488fbc5e5f82fff8661daba" + "'", str6.equals("3f3f62013a606d06a7573d233975e18b3f13d818eb8a3de6b0bf27674f7991a1e77a51a0fa298488fbc5e5f82fff8661daba"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 40L + "'", long9 == 40L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.156208236477714d + "'", double14 == 6.156208236477714d);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 28 + "'", int20 == 28);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.6963961173271749d + "'", double22 == 1.6963961173271749d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.6527284105274372d + "'", double24 == 0.6527284105274372d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.06811751509804602d + "'", double25 == 0.06811751509804602d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.8687125781652096d + "'", double32 == 1.8687125781652096d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.66936533620998d + "'", double33 == 0.66936533620998d);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl0.nextExponential(231.3681718779007d);
//        int int16 = randomDataImpl0.nextInt(23, 97);
//        try {
//            int int20 = randomDataImpl0.nextHypergeometric(37, (-1), (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2530120669752076d + "'", double8 == 1.2530120669752076d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6366961079234125d + "'", double10 == 0.6366961079234125d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6441388135852545d + "'", double11 == 0.6441388135852545d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 61.78675787310725d + "'", double13 == 61.78675787310725d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26 + "'", int16 == 26);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        double double14 = randomDataImpl0.nextF(9.999999999999998d, (double) 48L);
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3672034076027686d + "'", double7 == 1.3672034076027686d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.47162384188669426d + "'", double9 == 0.47162384188669426d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0633954056519717d) + "'", double11 == (-1.0633954056519717d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.2805167699026694d + "'", double14 == 1.2805167699026694d);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(number1, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl();
        int int26 = randomDataImpl23.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray28 = new java.lang.Object[] { "hi!", int26, (-1L) };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, localizable30, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException19, "", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15, "", objArray36);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable6, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException47.getGeneralPattern();
        java.lang.Throwable throwable49 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl53 = new org.apache.commons.math.random.RandomDataImpl();
        int int56 = randomDataImpl53.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray58 = new java.lang.Object[] { "hi!", int56, (-1L) };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59, localizable60, objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable49, "", objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable48, objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(33, localizable43, objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(31, localizable6, objArray66);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(number18, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number22 = outOfRangeException21.getArgument();
        java.lang.String str23 = outOfRangeException21.toString();
        java.lang.Number number24 = outOfRangeException21.getLo();
        java.lang.Object[] objArray25 = outOfRangeException21.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable26 = outOfRangeException21.getGeneralPattern();
        java.lang.Throwable throwable29 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(throwable29, "hi!", objArray37);
        java.lang.Throwable[] throwableArray41 = mathException40.getSuppressed();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7", (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable26, (java.lang.Object[]) throwableArray41);
        java.lang.Throwable throwable47 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl();
        int int54 = randomDataImpl51.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray56 = new java.lang.Object[] { "hi!", int54, (-1L) };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException57, localizable58, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(throwable47, "", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", objArray64);
        java.lang.Throwable[] throwableArray69 = maxIterationsExceededException68.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable26, (java.lang.Object[]) throwableArray69);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str23.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10 + "'", number24.equals(10));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray69);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
        int int7 = randomDataImpl4.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", int7, (-1L) };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
        int int20 = randomDataImpl17.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", int20, (-1L) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, localizable24, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException13, "", objArray30);
        mathException10.addSuppressed((java.lang.Throwable) convergenceException33);
        convergenceException1.addSuppressed((java.lang.Throwable) convergenceException33);
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException33.getGeneralPattern();
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray42);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException43, "hi!", objArray52);
        java.lang.Class<?> wildcardClass55 = maxIterationsExceededException43.getClass();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl59 = new org.apache.commons.math.random.RandomDataImpl();
        int int62 = randomDataImpl59.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray64 = new java.lang.Object[] { "hi!", int62, (-1L) };
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("hi!", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl72 = new org.apache.commons.math.random.RandomDataImpl();
        int int75 = randomDataImpl72.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray77 = new java.lang.Object[] { "hi!", int75, (-1L) };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("hi!", objArray77);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException78, localizable79, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException68, "", objArray85);
        mathException65.addSuppressed((java.lang.Throwable) convergenceException88);
        java.lang.Object[] objArray90 = convergenceException88.getArguments();
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException88);
        java.lang.Throwable[] throwableArray92 = mathException91.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException43, "6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", (java.lang.Object[]) throwableArray92);
        java.lang.Object[] objArray94 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(38, localizable36, objArray94);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(throwableArray92);
        org.junit.Assert.assertNotNull(objArray94);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8615248364376218d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.36173707357429d + "'", double1 == 49.36173707357429d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        try {
//            int int16 = randomDataImpl0.nextSecureInt(97, 9);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (9): lower bound (97) must be strictly less than upper bound (9)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.81672986313352d + "'", double3 == 37.81672986313352d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-10.198157250933345d) + "'", double6 == (-10.198157250933345d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 85.4886067449114d + "'", double8 == 85.4886067449114d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable5, objArray6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.3432933379273535d, (java.lang.Number) (-0.008956896167359377d), (java.lang.Number) 7L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = randomDataImpl0.nextGaussian(0.4031876995883735d, (double) 97.0f);
//        try {
//            int int22 = randomDataImpl0.nextZipf(0, (-0.7110158499104279d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a45ffce1efa4b5b29c6de161f2752762884fb87487ace26a29d00747c93fc0b661c6f60340a8eb7dd6730d75705bb2077600" + "'", str2.equals("a45ffce1efa4b5b29c6de161f2752762884fb87487ace26a29d00747c93fc0b661c6f60340a8eb7dd6730d75705bb2077600"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 40L + "'", long5 == 40L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5370765811312103d + "'", double13 == 0.5370765811312103d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.6331360438552217d + "'", double15 == 0.6331360438552217d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-2.884166567036691d) + "'", double16 == (-2.884166567036691d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 19.680639135263355d + "'", double19 == 19.680639135263355d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.6481398906637532d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5704164211292636d) + "'", double1 == (-0.5704164211292636d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 11, 36.443023495887374d, 0.7956013766453628d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 36.443 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 16.0d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        long long9 = randomDataImpl0.nextPoisson(36.443023495887374d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.46844544589991d + "'", double3 == 35.46844544589991d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.3509128184107633d + "'", double6 == 2.3509128184107633d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 37L + "'", long9 == 37L);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int1 = org.apache.commons.math.util.FastMath.abs(28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.6321205588285577d), (double) 97);
        double[] doubleArray4 = normalDistributionImpl2.sample(3);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        java.lang.Class<?> wildcardClass8 = localizable5.getClass();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable9, "hi!", objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray17);
        java.lang.Class<?> wildcardClass22 = objArray17.getClass();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        long long5 = randomDataImpl0.nextPoisson(10.0d);
//        try {
//            java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e6a405aac8ebd474dbfcca00154d1ce97064c5c63754aeff9f76e3502f77308b98946889950ced5f60cf13892550af44f1e7" + "'", str2.equals("e6a405aac8ebd474dbfcca00154d1ce97064c5c63754aeff9f76e3502f77308b98946889950ced5f60cf13892550af44f1e7"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9355093251460914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6603705089759571d + "'", double1 == 0.6603705089759571d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, number14, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl();
        int int32 = randomDataImpl29.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray34 = new java.lang.Object[] { "hi!", int32, (-1L) };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, localizable36, objArray42);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(throwable25, "", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable24, objArray42);
        java.lang.Object[] objArray53 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray53);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl();
        int int61 = randomDataImpl58.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray63 = new java.lang.Object[] { "hi!", int61, (-1L) };
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException54, "hi!", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException46, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(23, "", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(13, "1b1eb52ea411fd8e86a40106c36dbd4ac053d7241b82807c7acff828427d1d083c59d41a08004cf8097d46d832bdbbf3f23a", objArray63);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "b", objArray6);
        java.lang.Number number8 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 19.31004779531512d + "'", number8.equals(19.31004779531512d));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(3);
//        try {
//            double double8 = randomDataImpl0.nextUniform((double) 33L, (-0.6406520265206169d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 33 is larger than, or equal to, the maximum (-0.641): lower bound (33) must be strictly less than upper bound (-0.641)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d6f" + "'", str5.equals("d6f"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0, (java.lang.Number) (-0.6397777546482646d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0654109334640752E-210d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.6406520265206169d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.023464074489784d) + "'", double1 == (-1.023464074489784d));
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
//        double double4 = normalDistributionImpl0.density((double) 100L);
//        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10.0f, (double) (short) 10);
//        double[] doubleArray9 = normalDistributionImpl0.sample(21);
//        double double10 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2976669412820843d + "'", double10 == 0.2976669412820843d);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        double double11 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 98L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        try {
//            double double16 = randomDataImpl0.nextF(0.0d, (double) 17L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 36L + "'", long6 == 36L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 81.1203032558295d + "'", double11 == 81.1203032558295d);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
        try {
            int int6 = randomDataImpl0.nextSecureInt((int) 'a', 37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (37): lower bound (97) must be strictly less than upper bound (37)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextSecureLong((long) 21, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 21 is larger than, or equal to, the maximum (0): lower bound (21) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.acosh(38.89638657195819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.353883253316498d + "'", double1 == 4.353883253316498d);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double13 = randomDataImpl0.nextF(1.0113154145053396d, (double) 22);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4b033e8f665165a894444b17a388dd90a9e4c03d5706a3688df1b6e2e3685d8e0f2acf091529997e64d23ae42a66cafe7b6b" + "'", str2.equals("4b033e8f665165a894444b17a388dd90a9e4c03d5706a3688df1b6e2e3685d8e0f2acf091529997e64d23ae42a66cafe7b6b"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 38L + "'", long5 == 38L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-8.702396016835069d) + "'", double10 == (-8.702396016835069d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.12084452134334615d + "'", double13 == 0.12084452134334615d);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 26);
//        try {
//            int int13 = randomDataImpl0.nextHypergeometric(0, (-1), 14);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 43.99354258180114d + "'", double3 == 43.99354258180114d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24L + "'", long9 == 24L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        double double16 = normalDistributionImpl6.density(10.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17499478150316938d + "'", double7 == 0.17499478150316938d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9932097587068806d + "'", double9 == 0.9932097587068806d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.43603583720984146d) + "'", double10 == (-0.43603583720984146d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 7.69459862670642E-23d + "'", double16 == 7.69459862670642E-23d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(number36, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number40 = outOfRangeException39.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException39.getGeneralPattern();
        convergenceException32.addSuppressed((java.lang.Throwable) outOfRangeException39);
        java.lang.Throwable[] throwableArray43 = convergenceException32.getSuppressed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        java.lang.Class<?> wildcardClass8 = localizable5.getClass();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(number9, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number13 = outOfRangeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException12.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
        int int20 = randomDataImpl17.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", int20, (-1L) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl();
        int int34 = randomDataImpl31.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!", int34, (-1L) };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable38, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException27, "", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException23, "", objArray44);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable14, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable5, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 0.5d);
        boolean boolean53 = notStrictlyPositiveException52.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.special.Erf.erf(105.66479655265388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution8 = null;
//        try {
//            double double9 = randomDataImpl0.nextInversionDeviate(continuousDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c7eebc61ade197ee0af6cb47ce9c8d85b37a851360193386f9bd64da0df63aef680bfe15183e68825736d81fdb7b2e846305" + "'", str2.equals("c7eebc61ade197ee0af6cb47ce9c8d85b37a851360193386f9bd64da0df63aef680bfe15183e68825736d81fdb7b2e846305"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.77226786386852d + "'", double5 == 1.77226786386852d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.1154718694889667d) + "'", double7 == (-1.1154718694889667d));
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str4 = randomDataImpl0.nextHexString(8);
//        try {
//            int int7 = randomDataImpl0.nextBinomial(34, 9.899494936611665d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 9.899 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f5c48aeddd9f03774fdd6df5ece46033d7a79e9b44c281cf737e3a4313493d9e7671dc0bbb545836a422ee176a3f774a2e31" + "'", str2.equals("f5c48aeddd9f03774fdd6df5ece46033d7a79e9b44c281cf737e3a4313493d9e7671dc0bbb545836a422ee176a3f774a2e31"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "f95b5c4b" + "'", str4.equals("f95b5c4b"));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, localizable15, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray26 = notStrictlyPositiveException4.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable1, objArray26);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        java.lang.Object[] objArray29 = maxIterationsExceededException27.getArguments();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(23.161508129241746d, 3.269706145615593d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.161508129241742d + "'", double2 == 23.161508129241742d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.3366148380992204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.156120598423547d + "'", double1 == 1.156120598423547d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.04753671340204302d, (double) 99);
//        double double3 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 133.85817249205053d + "'", double3 == 133.85817249205053d);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.acos(16.975649656605654d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9588480084541022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8185303347036061d + "'", double1 == 0.8185303347036061d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable13, objArray14);
        java.lang.Class<?> wildcardClass16 = localizable13.getClass();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(number17, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number21 = outOfRangeException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = outOfRangeException20.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
        int int28 = randomDataImpl25.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!", int28, (-1L) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl39 = new org.apache.commons.math.random.RandomDataImpl();
        int int42 = randomDataImpl39.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", int42, (-1L) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, localizable46, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException35, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31, "", objArray52);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable22, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable13, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathIllegalArgumentException59.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeedSecure();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.008956896167359377d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.008956776409040643d) + "'", double1 == (-0.008956776409040643d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((double) (short) 10);
        normalDistributionImpl0.reseedRandomGenerator(52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.69459862670642E-23d + "'", double2 == 7.69459862670642E-23d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-9.000000000217147d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeedSecure((long) 14);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "916909a62cc78353a9156841e950b565f40db850cdd57726e53470daffe7f9590629240480667d43067b02c3b148e41f1bfb" + "'", str2.equals("916909a62cc78353a9156841e950b565f40db850cdd57726e53470daffe7f9590629240480667d43067b02c3b148e41f1bfb"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 40L + "'", long5 == 40L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 26 + "'", int11 == 26);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5955744642915115d + "'", double13 == 1.5955744642915115d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7021737992805399d + "'", double15 == 0.7021737992805399d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.13496746192907177d) + "'", double16 == (-0.13496746192907177d));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.483758447589274d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02589647021471255d) + "'", double1 == (-0.02589647021471255d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.0608955130137179d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        double double18 = normalDistributionImpl6.density((double) 45L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5910801990374204d + "'", double7 == 1.5910801990374204d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6870259253551788d + "'", double9 == 0.6870259253551788d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.316765434388886d) + "'", double10 == (-0.316765434388886d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double14 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = normalDistributionImpl13.cumulativeProbability((double) 100.0f);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        normalDistributionImpl13.reseedRandomGenerator((long) 33);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 40.40258514025471d + "'", double3 == 40.40258514025471d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.0070644672492906d) + "'", double14 == (-2.0070644672492906d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9975420988248034d + "'", double16 == 0.9975420988248034d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-18.782731759839095d) + "'", double17 == (-18.782731759839095d));
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution4 = null;
        try {
            double double5 = randomDataImpl0.nextInversionDeviate(continuousDistribution4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl6.getStandardDeviation();
//        double double16 = normalDistributionImpl6.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4602208663713303d + "'", double7 == 0.4602208663713303d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7163231604446159d + "'", double9 == 0.7163231604446159d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.6018816188266752d) + "'", double10 == (-0.6018816188266752d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.floor((-2.0017920840907606d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7956013766453628d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3382624359377144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.222656248356812d + "'", double1 == 4.222656248356812d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7956013766453628d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.215773110412946d + "'", double1 == 1.215773110412946d);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        double double11 = randomDataImpl0.nextT(25.10345653640629d);
//        try {
//            double double14 = randomDataImpl0.nextF(0.0d, 0.9149994957367078d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29 + "'", int5 == 29);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "476fde7776b7a23227c17a5eb9ea6b1ab734d4d34b15fd0c081306f2f1dfec32243528ff14e6ca5af9abf62d91ccecf06" + "'", str7.equals("476fde7776b7a23227c17a5eb9ea6b1ab734d4d34b15fd0c081306f2f1dfec32243528ff14e6ca5af9abf62d91ccecf06"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3a5f2e900c8c078bcbe0928b745ae5" + "'", str9.equals("3a5f2e900c8c078bcbe0928b745ae5"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8007453850381766d + "'", double11 == 0.8007453850381766d);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException9);
        boolean boolean12 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Number number13 = numberIsTooLargeException9.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0f + "'", number13.equals(100.0f));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8281684713331012d + "'", double1 == 3.8281684713331012d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable10, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
        int int28 = randomDataImpl25.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!", int28, (-1L) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31, localizable32, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException21, "", objArray38);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException41.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9043022375118978d, (java.lang.Number) (byte) 100, number46);
        java.lang.Throwable[] throwableArray48 = outOfRangeException47.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable43, (java.lang.Object[]) throwableArray48);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray48);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 17L, (java.lang.Number) 35.762112861443455d, (java.lang.Number) 2.807060261307188d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.floor((-8.73503430125458d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.0d) + "'", double1 == (-9.0d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 2, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.636266228115197E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = org.apache.commons.math.util.FastMath.min(7, 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextGamma(19.31004779531512d, 36.264664323635685d);
//        double double9 = randomDataImpl0.nextWeibull((double) 29, 53.08834833768392d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.012019222659382659d + "'", double2 == 0.012019222659382659d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 718.3807058861689d + "'", double6 == 718.3807058861689d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 55.06745193980615d + "'", double9 == 55.06745193980615d);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 89L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.464745095584537d + "'", double1 == 4.464745095584537d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2480912893363008d, 0.4275739764777582d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2407449316226176d + "'", double2 == 1.2407449316226176d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.6655273582452867d, 0.0d, (double) (short) 100, 9);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextSecureInt(1, 34);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) ' ');
//        long long15 = randomDataImpl0.nextSecureLong(10L, (long) 17);
//        try {
//            double double18 = randomDataImpl0.nextWeibull((double) 37, (-0.21931231246647523d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.219 is smaller than, or equal to, the minimum (0): scale (-0.219)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "db01ca81382c308bfc7a5ec5a6068fecc5d689f660b3640767fc843b3bfd60b25304c56ec7e10a5bd8e377ddcc803f623" + "'", str7.equals("db01ca81382c308bfc7a5ec5a6068fecc5d689f660b3640767fc843b3bfd60b25304c56ec7e10a5bd8e377ddcc803f623"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5f72837deb7955faf64f7de8cab52428" + "'", str12.equals("5f72837deb7955faf64f7de8cab52428"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 13L + "'", long15 == 13L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.log10(88.84450792549285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.948630586318326d + "'", double1 == 1.948630586318326d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.0d + "'", double1 == 26.0d);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.393387457044462d + "'", double3 == 6.393387457044462d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.039739945499182d + "'", double6 == 15.039739945499182d);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (-0.6397777546482646d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 10L, 0.8430095582228464d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3271925131717274E-8d + "'", double2 == 2.3271925131717274E-8d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13934441400413447d + "'", double1 == 0.13934441400413447d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.2729967908999662d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3019527653887148d, (-0.5359799741755117d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.FastMath.max(0.710941967759605d, (-3.445304508260566d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.710941967759605d + "'", double2 == 0.710941967759605d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl11.reSeedSecure((long) (byte) -1);
//        int int16 = randomDataImpl11.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl17.sample();
//        double double19 = normalDistributionImpl17.getStandardDeviation();
//        double double20 = randomDataImpl11.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double21 = normalDistributionImpl17.sample();
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double24 = normalDistributionImpl17.inverseCumulativeProbability((double) 1.0f);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "155f24bf8b938bdf0c0dae89308615715520e6c7c5c7614092ebb2398eca6117d648f103fa0364435296ee0b13b3ef168b34" + "'", str2.equals("155f24bf8b938bdf0c0dae89308615715520e6c7c5c7614092ebb2398eca6117d648f103fa0364435296ee0b13b3ef168b34"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-11.940655088625531d) + "'", double10 == (-11.940655088625531d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.6972920850782146d) + "'", double18 == (-0.6972920850782146d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.9562293807301598d) + "'", double20 == (-1.9562293807301598d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.4955126114429672d + "'", double21 == 0.4955126114429672d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-0.5078767061029263d) + "'", double22 == (-0.5078767061029263d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray34 = convergenceException32.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathException35.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable36);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, localizable15, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, "", objArray21);
        java.lang.Object[] objArray25 = notStrictlyPositiveException4.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray25);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1.148392767891138d, true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable45, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable5, objArray46);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 372.97946888568896d);
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int2 = org.apache.commons.math.util.FastMath.min(13, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.440668485391159E-7d, (java.lang.Number) (-0.24510465435485307d), true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-15.064498446609786d), 0.016700813656305023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-15.064498446609784d) + "'", double2 == (-15.064498446609784d));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        int int11 = randomDataImpl0.nextSecureInt(10, 28);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.01098609108488d + "'", double3 == 51.01098609108488d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.066463880671819d + "'", double6 == 10.066463880671819d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 84.56221591242928d + "'", double8 == 84.56221591242928d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.6974768667811515d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3426668195909772d + "'", double1 == 2.3426668195909772d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.13496746192907177d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12625565881914202d) + "'", double1 == (-0.12625565881914202d));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextPascal((int) ' ', 0.5856749831752239d);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(99);
//        double double15 = randomDataImpl0.nextGaussian(0.9025352261814413d, (double) 53L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1ad7ab86d76f946fad1f5a7ce131780388b85c38642dc20a47e18d1f6e2f92f0f4cfb61044f005feeef7939b8caa9b740" + "'", str7.equals("1ad7ab86d76f946fad1f5a7ce131780388b85c38642dc20a47e18d1f6e2f92f0f4cfb61044f005feeef7939b8caa9b740"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "e0d829eabaa916ccbc0c72b1e70e2b2b92768c02b8e48166a26dff3281d03d7355d34c71d6fb06a87f691f50732f75e4ad0" + "'", str12.equals("e0d829eabaa916ccbc0c72b1e70e2b2b92768c02b8e48166a26dff3281d03d7355d34c71d6fb06a87f691f50732f75e4ad0"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 84.07738063324993d + "'", double15 == 84.07738063324993d);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        try {
//            int int6 = randomDataImpl0.nextInt(32, 19);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (19): lower bound (32) must be strictly less than upper bound (19)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "22d7a0a35378f74478ca56ff0d0111f40f72f6c11be2adf3bca81a4ba5a65dcb6d8051f47ed065836a9351b8fda5c8ed4a25" + "'", str2.equals("22d7a0a35378f74478ca56ff0d0111f40f72f6c11be2adf3bca81a4ba5a65dcb6d8051f47ed065836a9351b8fda5c8ed4a25"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException3.getArgument();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(number6);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        long long9 = randomDataImpl0.nextPoisson(81.1203032558295d);
//        randomDataImpl0.reSeed((long) (short) 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97a94d6b472ef588d4b7306d8c4ec0cc0339159ad61759dcb972991f9de8924b1e0708c5b34757c6e83dc8f4c873774ce" + "'", str7.equals("97a94d6b472ef588d4b7306d8c4ec0cc0339159ad61759dcb972991f9de8924b1e0708c5b34757c6e83dc8f4c873774ce"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 88L + "'", long9 == 88L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.6655273582452867d, (java.lang.Number) (-44.60847139446158d), true);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray9 = randomDataImpl0.nextPermutation(22, 7);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution10 = null;
//        try {
//            double double11 = randomDataImpl0.nextInversionDeviate(continuousDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b" + "'", str5.equals("b"));
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextPascal((int) ' ', 0.5856749831752239d);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(99);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        double double16 = randomDataImpl0.nextChiSquare(0.997955783106022d);
//        try {
//            int int19 = randomDataImpl0.nextBinomial(30, 100.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e8c01c86d7bbef780f363fe683db8cee6496812f89930178e2082df905adc50527922ae4a6d9c0138ae85064e795203c0" + "'", str7.equals("e8c01c86d7bbef780f363fe683db8cee6496812f89930178e2082df905adc50527922ae4a6d9c0138ae85064e795203c0"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "96420d46c0ef2fce385ab74c150f55cf876c0c98b3192cd3b6fcfef67c8b3f6d99adc7ddc417991dbbde37e959633a016d1" + "'", str12.equals("96420d46c0ef2fce385ab74c150f55cf876c0c98b3192cd3b6fcfef67c8b3f6d99adc7ddc417991dbbde37e959633a016d1"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.1034266205643009d + "'", double16 == 0.1034266205643009d);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10 + "'", number7.equals(10));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 26, number42, false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-1.1944025180403872d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.43627312320436d + "'", double1 == 29.43627312320436d);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.getMean();
//        double[] doubleArray14 = normalDistributionImpl7.sample(32);
//        double double16 = normalDistributionImpl7.density(0.9999639609743824d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.1966995402003695d) + "'", double8 == (-1.1966995402003695d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.5930187995896585d) + "'", double10 == (-0.5930187995896585d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.5930187995896585d) + "'", double11 == (-0.5930187995896585d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.24197944490827925d + "'", double16 == 0.24197944490827925d);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 37, (double) 37, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        randomDataImpl0.reSeedSecure((long) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.968739207193453d + "'", double3 == 14.968739207193453d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "797649b27537b0e58520d39d13f28f278593dfeffbcee82dbc53f9934f766f55f471785a44c53fb41274cf8f4e4259d93de0" + "'", str2.equals("797649b27537b0e58520d39d13f28f278593dfeffbcee82dbc53f9934f766f55f471785a44c53fb41274cf8f4e4259d93de0"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.613093898691733d + "'", double5 == 1.613093898691733d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4622230019705406d) + "'", double7 == (-0.4622230019705406d));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException13.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable15, objArray16);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
        int int23 = randomDataImpl20.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray25 = new java.lang.Object[] { "hi!", int23, (-1L) };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math.random.RandomDataImpl();
        int int37 = randomDataImpl34.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!", int37, (-1L) };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException40, localizable41, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException30, "", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26, "", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, localizable15, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl61 = new org.apache.commons.math.random.RandomDataImpl();
        int int64 = randomDataImpl61.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray66 = new java.lang.Object[] { "hi!", int64, (-1L) };
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("hi!", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException67, localizable68, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException57, "", objArray74);
        java.lang.Object[] objArray78 = notStrictlyPositiveException57.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException(10, "2d1a500ccb54575149a37650ba9679702f5234f42548ea988ede9c9a9babe6ec64149a32619e5368e017495c4244e49531f0", objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable15, objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("hi!", objArray78);
        org.apache.commons.math.exception.util.Localizable localizable82 = convergenceException81.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNull(localizable82);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.21931231246647523d), 0.24197944490827925d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.21931231246647523d) + "'", double2 == (-0.21931231246647523d));
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        double double12 = randomDataImpl0.nextChiSquare(108.01798396338886d);
//        randomDataImpl0.reSeedSecure((long) 21);
//        try {
//            int int17 = randomDataImpl0.nextInt(3, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3 is larger than, or equal to, the maximum (1): lower bound (3) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ddce2c60b68a7d871fae072eda9faf9add63bcc5aac2303e891a2b785e298583741ab7777220a5613e53848f0fe3d540f285" + "'", str2.equals("ddce2c60b68a7d871fae072eda9faf9add63bcc5aac2303e891a2b785e298583741ab7777220a5613e53848f0fe3d540f285"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.508741926738686d) + "'", double10 == (-9.508741926738686d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 125.24448534276235d + "'", double12 == 125.24448534276235d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.39216512435927603d), (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.392165124359276d) + "'", double2 == (-0.392165124359276d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8420357896973979d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9451274352513981d + "'", double1 == 0.9451274352513981d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.9287285890885333d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1909687824216308d) + "'", double1 == (-1.1909687824216308d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double2 = org.apache.commons.math.util.FastMath.max(82.42409747617464d, (-0.8122995035639646d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 82.42409747617464d + "'", double2 == 82.42409747617464d);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        double double11 = randomDataImpl0.nextBeta((double) '#', 9.999999995E-10d);
//        int[] intArray14 = randomDataImpl0.nextPermutation(20, 11);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.585804347191082d + "'", double3 == 7.585804347191082d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.66397677232139d + "'", double6 == 6.66397677232139d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 101.48919704002253d + "'", double8 == 101.48919704002253d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.999999998689378d + "'", double11 == 0.999999998689378d);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9043022375118978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.799059446794603d + "'", double1 == 0.799059446794603d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
        int int22 = randomDataImpl19.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", int22, (-1L) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25, localizable26, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl();
        int int46 = randomDataImpl43.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!", int46, (-1L) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable50, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException39, "", objArray56);
        java.lang.Object[] objArray60 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable12, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException62);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable13, objArray14);
        java.lang.Class<?> wildcardClass16 = localizable13.getClass();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(number17, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number21 = outOfRangeException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = outOfRangeException20.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
        int int28 = randomDataImpl25.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!", int28, (-1L) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl39 = new org.apache.commons.math.random.RandomDataImpl();
        int int42 = randomDataImpl39.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", int42, (-1L) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, localizable46, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException35, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31, "", objArray52);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable22, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable13, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray52);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 97L, (java.lang.Number) 1.0255378718757038d, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9043022375118978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.81270161366869d + "'", double1 == 51.81270161366869d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 19.31004779531512d + "'", number7.equals(19.31004779531512d));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double14 = randomDataImpl0.nextGamma(16.47639359377014d, 0.6954783528958071d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 17 + "'", int6 == 17);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7915571081062319d + "'", double8 == 0.7915571081062319d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4060390591285599d + "'", double10 == 1.4060390591285599d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4060390591285599d + "'", double11 == 1.4060390591285599d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.717585555467458d + "'", double14 == 11.717585555467458d);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.6481398906637532d), (java.lang.Number) (-0.9813048965663718d), false);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.46284165083621587d), 3.4424325245802145d, 0.5901731071143256d);
//        normalDistributionImpl15.reseedRandomGenerator(0L);
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.47252372244948687d + "'", double7 == 0.47252372244948687d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4926624494607477d + "'", double9 == 1.4926624494607477d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48280445540011485d + "'", double11 == 0.48280445540011485d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.8300637648074578d) + "'", double18 == (-1.8300637648074578d));
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.getMean();
//        try {
//            double double14 = normalDistributionImpl7.inverseCumulativeProbability((double) 78);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 78 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.10797279692942446d + "'", double8 == 0.10797279692942446d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.5036986364292326d + "'", double10 == 1.5036986364292326d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.5036986364292326d + "'", double11 == 1.5036986364292326d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Object[] objArray7 = outOfRangeException3.getArguments();
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 97.0d, number1, true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
        int int14 = randomDataImpl11.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray16 = new java.lang.Object[] { "hi!", int14, (-1L) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, "4", objArray16);
        java.lang.String str19 = convergenceException7.getPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0}" + "'", str19.equals("{0}"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.String str5 = outOfRangeException3.toString();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19.31004779531512d + "'", number6.equals(19.31004779531512d));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 74L, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 74.0f + "'", float2 == 74.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray12 = new java.lang.Object[] { "hi!", int10, (-1L) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, localizable14, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl31 = new org.apache.commons.math.random.RandomDataImpl();
        int int34 = randomDataImpl31.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!", int34, (-1L) };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable38, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException27, "", objArray44);
        java.lang.Object[] objArray48 = notStrictlyPositiveException27.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray48);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8125268827955464d), (java.lang.Number) 0.3432933379273535d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        java.lang.String str11 = randomDataImpl0.nextHexString(34);
//        int[] intArray14 = randomDataImpl0.nextPermutation(26, 26);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e55296692f05d553ff3b4172d1f7653e40be8234b4a40c7f26265ccbe8b12c98c5ab75003a5ba9e4e5ef56c108a3833c3" + "'", str7.equals("e55296692f05d553ff3b4172d1f7653e40be8234b4a40c7f26265ccbe8b12c98c5ab75003a5ba9e4e5ef56c108a3833c3"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "77e23cf5f45cf066b54c7157251ab0" + "'", str9.equals("77e23cf5f45cf066b54c7157251ab0"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9cdf1963d50461bcac300ce69fa072ffbd" + "'", str11.equals("9cdf1963d50461bcac300ce69fa072ffbd"));
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 24.586464529014513d, (java.lang.Number) 53L, true);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable3, objArray14);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
        int int22 = randomDataImpl19.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray24 = new java.lang.Object[] { "hi!", int22, (-1L) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, number27, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) (-0.7853981633974483d));
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        java.lang.Throwable throwable38 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl42 = new org.apache.commons.math.random.RandomDataImpl();
        int int45 = randomDataImpl42.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray47 = new java.lang.Object[] { "hi!", int45, (-1L) };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException48, localizable49, objArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(throwable38, "", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable37, objArray55);
        java.lang.Object[] objArray66 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray66);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl71 = new org.apache.commons.math.random.RandomDataImpl();
        int int74 = randomDataImpl71.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray76 = new java.lang.Object[] { "hi!", int74, (-1L) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("hi!", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException67, "hi!", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException59, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray76);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("26e492a1dcd93e30c5dacecba0797c", objArray76);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(localizable3, objArray76);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double2 = org.apache.commons.math.util.FastMath.max(25.0d, 0.4879227341906365d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25.0d + "'", double2 == 25.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.10832802164921763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10854101919891847d + "'", double1 == 0.10854101919891847d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0654109334640752E-210d + "'", number4.equals(1.0654109334640752E-210d));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.10832802164921763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.462255307595978d + "'", double1 == 1.462255307595978d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(23.000000000000004d, 3.1282446759109312E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
        double double4 = normalDistributionImpl0.density((double) 100L);
        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10.0f, (double) (short) 10);
        double[] doubleArray9 = normalDistributionImpl0.sample(21);
        double double10 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential((double) 80L);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 158.45303120453724d + "'", double8 == 158.45303120453724d);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        int int10 = randomDataImpl0.nextSecureInt(1, 34);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) ' ');
//        long long15 = randomDataImpl0.nextSecureLong(10L, (long) 17);
//        try {
//            randomDataImpl0.setSecureAlgorithm("310b1200", "9adbcea2f3a3cd3f119bd76ce03aab46b5a517ca188316f6cebf1d99211e3e8aab2a7c57278241eecd0132e9f16b7794e0c9");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 9adbcea2f3a3cd3f119bd76ce03aab46b5a517ca188316f6cebf1d99211e3e8aab2a7c57278241eecd0132e9f16b7794e0c9");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "b5c4b9397b56159999b763f0c605ec4a785881aeecff73d9872c92252100719ae060d6238df886fcabd6fc27e2261eeee" + "'", str7.equals("b5c4b9397b56159999b763f0c605ec4a785881aeecff73d9872c92252100719ae060d6238df886fcabd6fc27e2261eeee"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "fbb497c28117481f7ca8bc4614cf025c" + "'", str12.equals("fbb497c28117481f7ca8bc4614cf025c"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 11L + "'", long15 == 11L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.special.Erf.erf(82.42409747617465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.710941967759605d, 1.9439199172433264d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08314988485238449d + "'", double2 == 0.08314988485238449d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(number1, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl();
        int int26 = randomDataImpl23.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray28 = new java.lang.Object[] { "hi!", int26, (-1L) };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, localizable30, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException19, "", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15, "", objArray36);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable6, objArray36);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable46, objArray47);
        java.lang.Class<?> wildcardClass49 = localizable46.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable46, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (-0.6481398906637532d));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-3.318928600414486d), (-1.1610486171893641d), 10.626714569240598d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.161 is smaller than, or equal to, the minimum (0): standard deviation (-1.161)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
        int int20 = randomDataImpl17.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", int20, (-1L) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, localizable24, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException13, "", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        java.lang.Number number43 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, number43, number44, (java.lang.Number) 0.997955783106022d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 1.724594607551417d, (java.lang.Number) (-0.3876485994045636d), false);
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable34, objArray51);
        java.lang.Number number53 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException(number53, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number57 = outOfRangeException56.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable58 = outOfRangeException56.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl61 = new org.apache.commons.math.random.RandomDataImpl();
        int int64 = randomDataImpl61.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray66 = new java.lang.Object[] { "hi!", int64, (-1L) };
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("hi!", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl75 = new org.apache.commons.math.random.RandomDataImpl();
        int int78 = randomDataImpl75.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray80 = new java.lang.Object[] { "hi!", int78, (-1L) };
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("hi!", objArray80);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException81, localizable82, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException71, "", objArray88);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException67, "", objArray88);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException(localizable58, objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable34, objArray88);
        int int95 = maxIterationsExceededException94.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number57);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 10 + "'", int95 == 10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.1742815528252627E-106d, (-1.418314401392866d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        java.lang.String str18 = convergenceException17.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5068608141629324d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextGamma(19.31004779531512d, 36.264664323635685d);
//        double double9 = randomDataImpl0.nextF(0.9952353147692228d, (double) 13);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(38);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010280938335128656d + "'", double2 == 0.010280938335128656d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 718.7273164823139d + "'", double6 == 718.7273164823139d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.8778691153454368d + "'", double9 == 1.8778691153454368d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "faca149c4bd1269bede705b506aae5e2da3362" + "'", str11.equals("faca149c4bd1269bede705b506aae5e2da3362"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 48L, (java.lang.Number) (-0.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.0d) + "'", number4.equals((-0.0d)));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(45.54377006014086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.543770060140865d + "'", double1 == 45.543770060140865d);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        double double11 = randomDataImpl0.nextT(25.10345653640629d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double15 = normalDistributionImpl14.getMean();
//        normalDistributionImpl14.reseedRandomGenerator(0L);
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "936e7e116a518633504cc9b5f804fe723c2dc921e59a42930abb80c55d4c806033e7ddac2948e8814adda60df39afda4f" + "'", str7.equals("936e7e116a518633504cc9b5f804fe723c2dc921e59a42930abb80c55d4c806033e7ddac2948e8814adda60df39afda4f"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "93642f65ddd33e7251c3ba246cec2b" + "'", str9.equals("93642f65ddd33e7251c3ba246cec2b"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.463307046230522d) + "'", double11 == (-1.463307046230522d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-88.91708429981146d) + "'", double18 == (-88.91708429981146d));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        double double9 = randomDataImpl0.nextT((double) 8);
//        double double11 = randomDataImpl0.nextChiSquare(1.0758167588358958d);
//        randomDataImpl0.reSeed();
//        long long14 = randomDataImpl0.nextPoisson((double) 98L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.073229583484366d + "'", double3 == 5.073229583484366d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2406134847420311d + "'", double6 == 1.2406134847420311d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.023936202886934075d + "'", double9 == 0.023936202886934075d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.04344437188991348d + "'", double11 == 0.04344437188991348d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 88L + "'", long14 == 88L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 48.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.Throwable throwable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(number1, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl();
        int int26 = randomDataImpl23.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray28 = new java.lang.Object[] { "hi!", int26, (-1L) };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, localizable30, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException19, "", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15, "", objArray36);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable6, objArray36);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable46, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable6, objArray47);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 372.97946888568896d);
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException55.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable56, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable0, localizable6, objArray57);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0758167588358958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4750136716150394d + "'", double1 == 0.4750136716150394d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9043022375118978d, 1.5955744642915115d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9043022375118979d + "'", double2 == 0.9043022375118979d);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        double double14 = randomDataImpl0.nextF(9.999999999999998d, (double) 48L);
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        double double18 = randomDataImpl0.nextCauchy((-1.2736190370090261d), 82.42409747617464d);
//        try {
//            long long21 = randomDataImpl0.nextSecureLong(84L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 84 is larger than, or equal to, the maximum (0): lower bound (84) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.36383498256192837d) + "'", double7 == (-0.36383498256192837d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.67567108292944d) + "'", double9 == (-1.67567108292944d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4343112095529435d + "'", double11 == 0.4343112095529435d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.8087805356829413d + "'", double14 == 0.8087805356829413d);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1219.116617307535d) + "'", double18 == (-1219.116617307535d));
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.1610486171893641d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9907962350088091d) + "'", double1 == (-0.9907962350088091d));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextExponential(25.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("c5a421857bdaccbb17d03bbbdc29a4a23a820890e56ffc9cf22eb06837de920d21c9ee5d1f2a2d146293beb40444f6e6cb6b", "30c0ee1316520d7c62debba4914172ba");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 30c0ee1316520d7c62debba4914172ba");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c" + "'", str5.equals("c"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 77.31795262446254d + "'", double9 == 77.31795262446254d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.9449566763087935d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8104715564835727d) + "'", double1 == (-0.8104715564835727d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(101.03598257045044d, 0.6954783528958071d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.240494635784616E-177d + "'", double2 == 5.240494635784616E-177d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.6481398906637532d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.044521599033359d) + "'", double1 == (-1.044521599033359d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 6.942898894086964d, (java.lang.Number) 0.5856749831752239d, false);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException30.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable31);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Object[] objArray9 = mathException8.getArguments();
        java.lang.Object[] objArray10 = mathException8.getArguments();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.019416865714155625d);
//        double double4 = normalDistributionImpl0.density((double) 100L);
//        double double5 = normalDistributionImpl0.sample();
//        double double8 = normalDistributionImpl0.cumulativeProbability((-1.9774410046509527d), 0.761579020074279d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.06594438297966d) + "'", double2 == (-2.06594438297966d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.18160259654525562d) + "'", double5 == (-0.18160259654525562d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7528484484071774d + "'", double8 == 0.7528484484071774d);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        double double8 = randomDataImpl0.nextChiSquare(4.594700892207039d);
//        double double10 = randomDataImpl0.nextT(0.3019527653887148d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 41L + "'", long6 == 41L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.219159808395267d + "'", double8 == 4.219159808395267d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-6.099894771024918d) + "'", double10 == (-6.099894771024918d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 95.18738847087556d, (java.lang.Number) (-0.340135700899202d), (java.lang.Number) 1.0E20d);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 22, 0.47162384188669426d, 10.0d);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 21.71632467423502d + "'", double4 == 21.71632467423502d);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 37L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 37.0f + "'", float1 == 37.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.3426668195909772d, (java.lang.Number) (-0.340135700899202d), false);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(97);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(30);
//        double double11 = randomDataImpl0.nextT(25.10345653640629d);
//        try {
//            int[] intArray14 = randomDataImpl0.nextPermutation(0, 27);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 27 is larger than the maximum (0): permutation size (27) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53a18322bbff0494a9f7c082d57f02159df07d1edd481238ad39b995a8daa0ef59b417102a4aff0a43d997f8404bed75b" + "'", str7.equals("53a18322bbff0494a9f7c082d57f02159df07d1edd481238ad39b995a8daa0ef59b417102a4aff0a43d997f8404bed75b"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "64c37263e843496612ea6661ac5846" + "'", str9.equals("64c37263e843496612ea6661ac5846"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.39972012231757864d) + "'", double11 == (-0.39972012231757864d));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4926624494607477d, (-0.8122995035639646d), 6.156208236477714d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.812 is smaller than, or equal to, the minimum (0): standard deviation (-0.812)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7956013766453627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 17.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 974.0282517223994d + "'", double1 == 974.0282517223994d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long long2 = org.apache.commons.math.util.FastMath.min(7L, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.3667668759598282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1185126851660605d + "'", double1 == 1.1185126851660605d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.000994718583564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.2770653155902d + "'", double1 == 74.2770653155902d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0654109334640752E-210d + "'", number4.equals(1.0654109334640752E-210d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.29588497520587087d) + "'", number5.equals((-0.29588497520587087d)));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        try {
//            int int5 = randomDataImpl0.nextBinomial(0, 11.512500788759661d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11.513 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e95498dea92b71792535d0db1f09e7405aa2bc45df2557122b817ca25e51bd22567b8f58176daa889a7d14b50c32abd4ed20" + "'", str2.equals("e95498dea92b71792535d0db1f09e7405aa2bc45df2557122b817ca25e51bd22567b8f58176daa889a7d14b50c32abd4ed20"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.1909687824216308d), (-1.0608955130137179d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1909687824216306d) + "'", double2 == (-1.1909687824216306d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.8615248364376218d, (java.lang.Number) (-5.321160198215146d), (java.lang.Number) 8);
        java.lang.Number number11 = outOfRangeException10.getHi();
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException10.getGeneralPattern();
        java.lang.Number number13 = outOfRangeException10.getArgument();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 8 + "'", number11.equals(8));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.8615248364376218d + "'", number13.equals(0.8615248364376218d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.016700813656305023d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(36);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            java.lang.String str18 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "79a7b158fee2a0a78d087a71c7ebe0d278c5bd8cef871370c8d52627960504fd01b29c9f92a991efebffb3c7579ec14ab8cd" + "'", str2.equals("79a7b158fee2a0a78d087a71c7ebe0d278c5bd8cef871370c8d52627960504fd01b29c9f92a991efebffb3c7579ec14ab8cd"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.358999827284579d + "'", double13 == 1.358999827284579d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.6298241601700489d) + "'", double15 == (-0.6298241601700489d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9945377076974815d + "'", double16 == 0.9945377076974815d);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.27608530520106733d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0383542454659476d + "'", double1 == 1.0383542454659476d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException3.getArgument();
        java.lang.Number number7 = outOfRangeException3.getLo();
        java.lang.Number number8 = outOfRangeException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10 + "'", number7.equals(10));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.54188646820458d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4944146245587065d + "'", double1 == 0.4944146245587065d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray33);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl();
        int int41 = randomDataImpl38.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray43 = new java.lang.Object[] { "hi!", int41, (-1L) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException34, "hi!", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, "24b28f793febfaf49f02a6904b0dc73496c5956e9ae1549c66918ae7097e7f6016ce1aada509fb07276f8e7197b6f7448", objArray43);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
        int int53 = randomDataImpl50.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", int53, (-1L) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable58, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl64 = new org.apache.commons.math.random.RandomDataImpl();
        int int67 = randomDataImpl64.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray69 = new java.lang.Object[] { "hi!", int67, (-1L) };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("hi!", objArray69);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70, localizable71, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException60, "", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException56, "", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "hi!", objArray77);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray77);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str4 = randomDataImpl0.nextHexString(8);
//        double double7 = randomDataImpl0.nextUniform(0.0d, (double) 40L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f5a37f20ad59972c4cd8d6d3df95c0603d6bbfb3ebebff8933157a509dc759964cc7cb394d6a59943b789e8c69c7204a5f6d" + "'", str2.equals("f5a37f20ad59972c4cd8d6d3df95c0603d6bbfb3ebebff8933157a509dc759964cc7cb394d6a59943b789e8c69c7204a5f6d"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5da91506" + "'", str4.equals("5da91506"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 17.94239528214877d + "'", double7 == 17.94239528214877d);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        java.lang.Number number32 = outOfRangeException31.getHi();
        java.lang.Number number33 = outOfRangeException31.getLo();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-0.2797748653068142d) + "'", number32.equals((-0.2797748653068142d)));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 0 + "'", number33.equals((short) 0));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(4.222656248356812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2670487453307605d + "'", double1 == 0.2670487453307605d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.15509166652580547d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7265165687315926d + "'", double1 == 1.7265165687315926d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double2 = org.apache.commons.math.util.FastMath.min(0.66936533620998d, 0.6870259253551788d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.66936533620998d + "'", double2 == 0.66936533620998d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 21L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3188157344832146E9d + "'", double1 == 1.3188157344832146E9d);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        try {
//            double double8 = randomDataImpl0.nextWeibull((-0.5754876432123086d), (double) 18);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.575 is smaller than, or equal to, the minimum (0): shape (-0.575)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.2644165654189337d, 5.298292365610485d, (-0.24510465435485307d));
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 100);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray5);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable24, objArray25);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl();
        int int33 = randomDataImpl30.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray35 = new java.lang.Object[] { "hi!", int33, (-1L) };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("hi!", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19, localizable24, objArray35);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.000994718583564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.28379656356057d + "'", double1 == 74.28379656356057d);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        randomDataImpl0.reSeed((long) 15);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a7c1e38c6e3b5bb7665f8ccef8998ca5d0175b87fdb1d80087a8f16ce4d6ea3b85d39b1f52e6b35a8dcf8e35cbe2284f1c" + "'", str2.equals("35a7c1e38c6e3b5bb7665f8ccef8998ca5d0175b87fdb1d80087a8f16ce4d6ea3b85d39b1f52e6b35a8dcf8e35cbe2284f1c"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 37L + "'", long5 == 37L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-23.640787536460714d) + "'", double10 == (-23.640787536460714d));
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number24 = notStrictlyPositiveException2.getMin();
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.getMean();
//        normalDistributionImpl7.reseedRandomGenerator((long) (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 26 + "'", int6 == 26);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.07941981413075168d) + "'", double8 == (-0.07941981413075168d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.04064490906756674d) + "'", double10 == (-0.04064490906756674d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.04064490906756674d) + "'", double11 == (-0.04064490906756674d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8630646514623409d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0413060717188798d) + "'", double1 == (-1.0413060717188798d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-88.91708429981146d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.180883098029916d) + "'", double1 == (-5.180883098029916d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.610246217177267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 272.21149908810236d + "'", double1 == 272.21149908810236d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.2797748653068142d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9611176311985449d + "'", double1 == 0.9611176311985449d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 98L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 19.31004779531512d + "'", number4.equals(19.31004779531512d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 19.31004779531512d + "'", number5.equals(19.31004779531512d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.24510465435485307d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 108.01798396338886d);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math.random.RandomDataImpl();
        int int17 = randomDataImpl14.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!", int17, (-1L) };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException20, localizable21, objArray27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable10, "", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", objArray27);
        java.lang.Throwable[] throwableArray32 = maxIterationsExceededException31.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable5, (java.lang.Object[]) throwableArray32);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(number35, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number39 = outOfRangeException38.getArgument();
        java.lang.String str40 = outOfRangeException38.toString();
        java.lang.Number number41 = outOfRangeException38.getLo();
        java.lang.Object[] objArray42 = outOfRangeException38.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("6573705f764ee553baa8dd4f2b80e0363ab449697dfd1c23eb04bacae122864cf3df3d5abe91ad18a5e2f5ecf015f1c096ed", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(17, localizable1, objArray42);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range" + "'", str40.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range"));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 10 + "'", number41.equals(10));
        org.junit.Assert.assertNotNull(objArray42);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        int int12 = randomDataImpl0.nextBinomial(22, 4.428880147757328E-216d);
//        randomDataImpl0.reSeed((long) '#');
//        try {
//            long long17 = randomDataImpl0.nextLong((long) 16, (long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than, or equal to, the maximum (10): lower bound (16) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.026600464662955254d + "'", double7 == 0.026600464662955254d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0020302143110930487d + "'", double9 == 0.0020302143110930487d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.atanh(8.256420960809727d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        java.lang.Number number32 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, number32, number33, (java.lang.Number) 0.997955783106022d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.3432933379273535d, (java.lang.Number) 1325.7669470624392d, true);
        java.lang.Object[] objArray45 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray45);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
        int int53 = randomDataImpl50.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray55 = new java.lang.Object[] { "hi!", int53, (-1L) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException46, "hi!", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException46);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58);
        numberIsTooLargeException39.addSuppressed((java.lang.Throwable) mathException59);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.678982327128295d + "'", double1 == 4.678982327128295d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-23.640787536460714d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6603705089759571d, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018865490390896942d + "'", double2 == 0.018865490390896942d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.04344437188991348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04341707030361805d + "'", double1 == 0.04341707030361805d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.7809618602685398d), (java.lang.Number) 45.54377006014086d, (java.lang.Number) 2.5519562803930635d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.7809618602685398d) + "'", number4.equals((-1.7809618602685398d)));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) 23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5359799741755117d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long2 = org.apache.commons.math.util.FastMath.min(42L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-44.60847139446158d), (-0.522788904814426d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.523 is smaller than, or equal to, the minimum (0): standard deviation (-0.523)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int10 = randomDataImpl0.nextInt(22, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 22 is larger than, or equal to, the maximum (1): lower bound (22) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f" + "'", str5.equals("f"));
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0383542454659476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int6 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double13 = normalDistributionImpl7.inverseCumulativeProbability(3.4424325245802145d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.442 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5527855592030957d) + "'", double8 == (-0.5527855592030957d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.1082086466401647d) + "'", double10 == (-0.1082086466401647d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.10843455366306483d) + "'", double11 == (-0.10843455366306483d));
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7848230096318725E8d + "'", double1 == 1.7848230096318725E8d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException10.getGeneralPattern();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.807060261307188d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42705849779333005d + "'", double1 == 0.42705849779333005d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Throwable[] throwableArray1 = mathException0.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray1);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = normalDistributionImpl6.sample();
//        double double12 = normalDistributionImpl6.density(57.29577951308232d);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl6.reseedRandomGenerator((long) 10);
//        normalDistributionImpl6.reseedRandomGenerator((long) (byte) -1);
//        double double20 = normalDistributionImpl6.density(0.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.4681871249074345d) + "'", double7 == (-1.4681871249074345d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.2303768178828743d) + "'", double9 == (-0.2303768178828743d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.7536660571933156d) + "'", double10 == (-1.7536660571933156d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.3989422804014327d + "'", double20 == 0.3989422804014327d);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        randomDataImpl0.reSeed();
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(3);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.917835207994834d + "'", double3 == 21.917835207994834d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-8.077965617960356d) + "'", double6 == (-8.077965617960356d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 110.81748972921783d + "'", double8 == 110.81748972921783d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5ad" + "'", str16.equals("5ad"));
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-8.176904988673762d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1778.913185937383d + "'", double1 == 1778.913185937383d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.log1p(45.54377006014086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.840393161472098d + "'", double1 == 3.840393161472098d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        long long10 = randomDataImpl0.nextLong((long) ' ', (long) 78);
//        randomDataImpl0.reSeedSecure(13L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9b1370a1956155e398e8cb1085f414c462700160b8d034d2e20d936b52ed8e87fb609e52940d26ac369ff672a74e1d3486ac" + "'", str2.equals("9b1370a1956155e398e8cb1085f414c462700160b8d034d2e20d936b52ed8e87fb609e52940d26ac369ff672a74e1d3486ac"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5959294753087974d + "'", double5 == 1.5959294753087974d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.217448656632419d + "'", double7 == 7.217448656632419d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 71L + "'", long10 == 71L);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl6.reSeedSecure((long) (byte) -1);
//        int int11 = randomDataImpl6.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl12.sample();
//        double double14 = normalDistributionImpl12.getStandardDeviation();
//        double double15 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double19 = randomDataImpl0.nextGaussian(0.4031876995883735d, (double) 97.0f);
//        try {
//            double double22 = randomDataImpl0.nextUniform((double) 0, (-0.19666828883033707d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-0.197): lower bound (0) must be strictly less than upper bound (-0.197)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f7dca2302e624375126332bfd5f52923d22fb1f8476a0d6bdc64349ffe2f9418b2a31403dbd6c4e4f8684240bd490a417d76" + "'", str2.equals("f7dca2302e624375126332bfd5f52923d22fb1f8476a0d6bdc64349ffe2f9418b2a31403dbd6c4e4f8684240bd490a417d76"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 27 + "'", int11 == 27);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.7651022769767396d) + "'", double13 == (-0.7651022769767396d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.7270671776015267d) + "'", double15 == (-0.7270671776015267d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.08642323462406365d) + "'", double16 == (-0.08642323462406365d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 91.47671285917252d + "'", double19 == 91.47671285917252d);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.00000000000001d + "'", double1 == 34.00000000000001d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.4899389301809507d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4555664061402788d) + "'", double1 == (-0.4555664061402788d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3382624359377144d, 1.4060390591285599d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5063364779351482d + "'", double2 == 1.5063364779351482d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 108.01798396338886d);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
        int int16 = randomDataImpl13.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!", int16, (-1L) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19, localizable20, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(throwable9, "", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", objArray26);
        java.lang.Throwable[] throwableArray31 = maxIterationsExceededException30.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable4, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.10854101919891847d, (java.lang.Number) (-1.6261509044766869d), false);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5068608141629324d), number1, true);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(number2, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number6 = outOfRangeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
        int int13 = randomDataImpl10.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!", int13, (-1L) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
        int int27 = randomDataImpl24.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { "hi!", int27, (-1L) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30, localizable31, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException20, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, "", objArray37);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable7, objArray37);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable47, objArray48);
        java.lang.Class<?> wildcardClass50 = localizable47.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable47, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable7, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException65.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 108.01798396338886d);
        java.lang.Throwable throwable71 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl75 = new org.apache.commons.math.random.RandomDataImpl();
        int int78 = randomDataImpl75.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray80 = new java.lang.Object[] { "hi!", int78, (-1L) };
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("hi!", objArray80);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException81, localizable82, objArray88);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(throwable71, "", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", objArray88);
        java.lang.Throwable[] throwableArray93 = maxIterationsExceededException92.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable66, (java.lang.Object[]) throwableArray93);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", (java.lang.Object[]) throwableArray93);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", (java.lang.Object[]) throwableArray93);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray93);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray93);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9353656293327904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8151031005318028d + "'", double1 == 1.8151031005318028d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) 11L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2, (java.lang.Number) (short) 1, (java.lang.Number) 33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-0.29588497520587087d));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) Double.NaN);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1015446173918673d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2602422146365806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2602422146365806d + "'", double1 == 1.2602422146365806d);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        int int12 = randomDataImpl0.nextBinomial(22, 4.428880147757328E-216d);
//        double double15 = randomDataImpl0.nextUniform((-0.6669380616522619d), 57.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0571528906762069d) + "'", double7 == (-1.0571528906762069d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0016576262447598d) + "'", double9 == (-1.0016576262447598d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 41.379601229211204d + "'", double15 == 41.379601229211204d);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.special.Erf.erf(0.018865490390896942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02128490115767033d + "'", double1 == 0.02128490115767033d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 48L, (java.lang.Number) (-0.0d), true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
        int int14 = randomDataImpl11.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray16 = new java.lang.Object[] { "hi!", int14, (-1L) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, localizable18, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException7, "", objArray24);
        boolean boolean28 = notStrictlyPositiveException7.getBoundIsAllowed();
        java.lang.Number number29 = notStrictlyPositiveException7.getMin();
        java.lang.Object[] objArray30 = notStrictlyPositiveException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "", objArray30);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0 + "'", number29.equals(0));
        org.junit.Assert.assertNotNull(objArray30);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        long long5 = randomDataImpl0.nextPoisson(16.47639359377014d);
//        try {
//            double double7 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0459924507586295d + "'", double2 == 0.0459924507586295d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 20L + "'", long5 == 20L);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 97, 1.2805167699026694d, 0.6040903237761033d, 2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.633881872029139E-143d + "'", double4 == 7.633881872029139E-143d);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double14 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = normalDistributionImpl13.cumulativeProbability((double) 100.0f);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = normalDistributionImpl13.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.715158440535006d + "'", double3 == 9.715158440535006d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 37.80532641913933d + "'", double14 == 37.80532641913933d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9975420988248034d + "'", double16 == 0.9975420988248034d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 21.300559565589744d + "'", double17 == 21.300559565589744d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        try {
//            double double16 = randomDataImpl0.nextGamma(36.443023495887374d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.08765163592895d + "'", double3 == 6.08765163592895d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3857805495589943d + "'", double6 == 0.3857805495589943d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.65665535358514d + "'", double8 == 82.65665535358514d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
        int int11 = randomDataImpl8.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", int11, (-1L) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "", objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable5, objArray35);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 11.512500788759661d, (java.lang.Number) 0.23806859454006649d, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 18L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 18L + "'", long1 == 18L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0113154145053396d, (java.lang.Number) 2.551956280393063d, true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 2.0102271666701927d, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.6321205588285577d), (double) 97);
        normalDistributionImpl2.reseedRandomGenerator((long) 78);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
        int int8 = randomDataImpl5.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!", int8, (-1L) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException28, localizable29, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(throwable18, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable17, objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2, localizable12, objArray35);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl();
        int int46 = randomDataImpl43.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!", int46, (-1L) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray48);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean54 = numberIsTooLargeException53.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException53.getGeneralPattern();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable55, objArray56);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl60 = new org.apache.commons.math.random.RandomDataImpl();
        int int63 = randomDataImpl60.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!", int63, (-1L) };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("hi!", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable68, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl74 = new org.apache.commons.math.random.RandomDataImpl();
        int int77 = randomDataImpl74.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray79 = new java.lang.Object[] { "hi!", int77, (-1L) };
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray79);
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray87);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException80, localizable81, objArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException70, "", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException66, "", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, localizable55, objArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray87);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.47252372244948687d, 1.0734769038258434d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8669774938157775d + "'", double2 == 0.8669774938157775d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(9, localizable12, objArray21);
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable12, objArray30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 23.000000000000004d);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean25 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number27 = notStrictlyPositiveException2.getMin();
        java.lang.Number number28 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0 + "'", number27.equals(0));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
        int int12 = randomDataImpl9.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", int12, (-1L) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable5, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable4, objArray22);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl();
        int int32 = randomDataImpl29.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray34 = new java.lang.Object[] { "hi!", int32, (-1L) };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable4, objArray34);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 31, (java.lang.Number) 1.2280285764566843d, (java.lang.Number) 1.3476590368841372d);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException40.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable41);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double2 = org.apache.commons.math.util.FastMath.min(0.58990586268745d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        int int6 = randomDataImpl0.nextSecureInt(97, (int) (byte) 100);
//        long long9 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 1);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(2);
//        randomDataImpl0.reSeed();
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "80" + "'", str11.equals("80"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5fb3f" + "'", str14.equals("5fb3f"));
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test395");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double10 = randomDataImpl0.nextCauchy((double) 53L, 0.3110421742117833d);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt(36, 21);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 36 is larger than, or equal to, the maximum (21): lower bound (36) must be strictly less than upper bound (21)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-12.547112839588204d) + "'", double7 == (-12.547112839588204d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 53.32169103341648d + "'", double10 == 53.32169103341648d);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 13L, 974.0282517223994d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 10);
        randomDataImpl0.reSeed(37L);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.2644165654189337d, 5.298292365610485d, (-0.24510465435485307d));
        double double10 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.4737560881049907d + "'", double10 == 3.4737560881049907d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.032290773920338856d, 14.968739207193453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03229077392033886d + "'", double2 == 0.03229077392033886d);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        double double5 = randomDataImpl0.nextGamma(1.5574077246549023d, 0.13313701469396122d);
//        double double8 = randomDataImpl0.nextCauchy(1.8151031005318028d, (double) 21L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4517277597824279d + "'", double2 == 0.4517277597824279d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2107869616060954d + "'", double5 == 0.2107869616060954d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 21.475972553240776d + "'", double8 == 21.475972553240776d);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.8615248364376218d, (java.lang.Number) (-5.321160198215146d), (java.lang.Number) 8);
        java.lang.Number number11 = outOfRangeException10.getHi();
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException10.getGeneralPattern();
        java.lang.Number number13 = outOfRangeException10.getHi();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 8 + "'", number11.equals(8));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 8 + "'", number13.equals(8));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
        int int8 = randomDataImpl5.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!", int8, (-1L) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("hi!", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("26e492a1dcd93e30c5dacecba0797c", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("797649b27537b0e58520d39d13f28f278593dfeffbcee82dbc53f9934f766f55f471785a44c53fb41274cf8f4e4259d93de0", objArray10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(number4, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number8 = outOfRangeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
        int int15 = randomDataImpl12.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!", int15, (-1L) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
        int int29 = randomDataImpl26.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray31 = new java.lang.Object[] { "hi!", int29, (-1L) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException32, localizable33, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException22, "", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException18, "", objArray39);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 80L, (java.lang.Number) 40L, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException49.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(localizable50);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.2775108988240696d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextGamma(19.31004779531512d, 36.264664323635685d);
//        randomDataImpl0.reSeed();
//        java.lang.String str9 = randomDataImpl0.nextHexString(15);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8049735734213035d + "'", double2 == 1.8049735734213035d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 658.3769845752458d + "'", double6 == 658.3769845752458d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "77519f52f61e08b" + "'", str9.equals("77519f52f61e08b"));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.217448656632419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 681.5031939671679d + "'", double1 == 681.5031939671679d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.440668485391159E-7d, (double) (short) 0, 4.464745095584537d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 6.377126762797792d, (java.lang.Number) (-0.18365271015776613d), (java.lang.Number) (-0.9945631849203883d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(24, "18a92f9a7063b3957e763f8bc2c0b37b0a442e80c0f065781c38793b639c856fabd240aead6e48fd9869c7d4f9c0540af00f", objArray19);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-13.798894071760017d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 33, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test414");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        double double9 = randomDataImpl0.nextT((double) 8);
//        double double11 = randomDataImpl0.nextChiSquare(1.0758167588358958d);
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextF(8.187772121133279E-5d, 1.3667668759598282d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 38.63013193866858d + "'", double3 == 38.63013193866858d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.95729956766809d + "'", double6 == 12.95729956766809d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4307493927718529d + "'", double9 == 1.4307493927718529d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.6766019139774064d + "'", double11 == 2.6766019139774064d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.3754315841157226E-9d + "'", double15 == 1.3754315841157226E-9d);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.6350616965174275d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5658019961729208d) + "'", double1 == (-0.5658019961729208d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.rint(23.161508129241742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.0d + "'", double1 == 23.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 14L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 14.0f + "'", float1 == 14.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(throwable2, "hi!", objArray10);
        java.lang.Throwable[] throwableArray14 = mathException13.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("1b84a5b226e5b7a0351f4bfd91cec006b241be87f51d57f535945f9e8b55c40af1aa9958c68484c8db450afc5319fde2e8a7", (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
        int int25 = randomDataImpl22.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!", int25, (-1L) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl39 = new org.apache.commons.math.random.RandomDataImpl();
        int int42 = randomDataImpl39.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", int42, (-1L) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, localizable46, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(throwable35, "", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable34, objArray52);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException19, localizable29, objArray52);
        mathException16.addSuppressed((java.lang.Throwable) mathException57);
        java.lang.String str59 = mathException57.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException57.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertNull(localizable60);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.2805167699026694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19152028005401345d) + "'", double1 == (-0.19152028005401345d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 74L, 0.14731976327079624d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        java.lang.Class<?> wildcardClass8 = localizable5.getClass();
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable9, "hi!", objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray17);
        java.lang.Object[] objArray27 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray27);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl32 = new org.apache.commons.math.random.RandomDataImpl();
        int int35 = randomDataImpl32.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray37 = new java.lang.Object[] { "hi!", int35, (-1L) };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28, "hi!", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40);
        mathException21.addSuppressed((java.lang.Throwable) mathException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException21.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNull(localizable43);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5156123319920012d, 0.02120909795200876d, (-2.6412600009550813d), 23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (23) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.exp((-8.702396016835069d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6618714637431034E-4d + "'", double1 == 1.6618714637431034E-4d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.9287285890885333d), 687.235718705944d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0013513966146385076d) + "'", double2 == (-0.0013513966146385076d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int2 = org.apache.commons.math.util.FastMath.max(34, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1325.7669470624392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.882893437260871d + "'", double1 == 7.882893437260871d);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test429");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl11.reSeedSecure((long) (byte) -1);
//        int int16 = randomDataImpl11.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl17.sample();
//        double double19 = normalDistributionImpl17.getStandardDeviation();
//        double double20 = randomDataImpl11.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double21 = normalDistributionImpl17.sample();
//        double double23 = normalDistributionImpl17.density(57.29577951308232d);
//        normalDistributionImpl17.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl17.reseedRandomGenerator((long) 10);
//        double double28 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double31 = randomDataImpl0.nextWeibull(1.5574077246549023d, 0.5068608141629324d);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "bd191a87c032ad8cfa0393b36ca5bcb5e9b2b37f030d86750b4d8e6a6f16f5e049e54c39378b69a80292e9aff78712c7f094" + "'", str2.equals("bd191a87c032ad8cfa0393b36ca5bcb5e9b2b37f030d86750b4d8e6a6f16f5e049e54c39378b69a80292e9aff78712c7f094"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 39L + "'", long5 == 39L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.33257644298825d + "'", double10 == 9.33257644298825d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 27 + "'", int16 == 27);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.060382090350750026d + "'", double18 == 0.060382090350750026d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5035088911887083d + "'", double20 == 0.5035088911887083d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.14354671536661318d) + "'", double21 == (-0.14354671536661318d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-0.31995079288399886d) + "'", double28 == (-0.31995079288399886d));
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.3923103643241164d + "'", double31 == 0.3923103643241164d);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test430");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        randomDataImpl0.reSeed(100L);
//        randomDataImpl0.reSeedSecure((long) 3);
//        double double12 = randomDataImpl0.nextChiSquare((double) 40L);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 36L + "'", long6 == 36L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 44.783935684369006d + "'", double12 == 44.783935684369006d);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(24.586464529014513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.46544524980822d + "'", double1 == 53.46544524980822d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.8615248364376218d, (java.lang.Number) (-5.321160198215146d), (java.lang.Number) 8);
        java.lang.Number number11 = outOfRangeException10.getHi();
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (-0.055284269790036866d));
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 1.8049735734213035d, (java.lang.Number) 19.31004779531512d, false);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 8 + "'", number11.equals(8));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 24.586464529014513d, (java.lang.Number) 3.552713678800501E-15d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 24.586464529014513d + "'", number4.equals(24.586464529014513d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double2 = org.apache.commons.math.util.FastMath.min((-8.73503430125458d), (-9.000000000217147d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.000000000217147d) + "'", double2 == (-9.000000000217147d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) 0.023936202886934075d, (java.lang.Number) 0.5844901182120892d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.9025352261814413d, 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 9.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.841449015201038d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9990791481402291d + "'", double1 == 0.9990791481402291d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.8634957860258078d), (java.lang.Number) (-0.12625565881914202d), false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextBinomial(1, 0.0d);
        try {
            double double6 = randomDataImpl0.nextBeta(9.899494936611665d, (-0.6018816188266752d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.852");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(658.3769845752458d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.49084610018996d + "'", double1 == 11.49084610018996d);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        double double6 = randomDataImpl0.nextCauchy((double) (byte) 10, (double) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare((double) 98L);
//        randomDataImpl0.reSeed((long) 30);
//        double double13 = randomDataImpl0.nextWeibull((double) '#', 1.0674342759877273d);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextInt(9, 32);
//        try {
//            long long20 = randomDataImpl0.nextSecureLong(98L, (long) 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 98 is larger than, or equal to, the maximum (6): lower bound (98) must be strictly less than upper bound (6)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.55193104812409d + "'", double3 == 37.55193104812409d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13.388797691929394d + "'", double6 == 13.388797691929394d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.15954142364299d + "'", double8 == 97.15954142364299d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0758167588358958d + "'", double13 == 1.0758167588358958d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 26 + "'", int17 == 26);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-6.405331196646276d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-302.5302536663236d) + "'", double1 == (-302.5302536663236d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
        int int9 = randomDataImpl6.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", int9, (-1L) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable13, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray19);
        boolean boolean23 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number24 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl28 = new org.apache.commons.math.random.RandomDataImpl();
        int int31 = randomDataImpl28.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray33 = new java.lang.Object[] { "hi!", int31, (-1L) };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("hi!", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
        int int44 = randomDataImpl41.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", int44, (-1L) };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47, localizable48, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37, "", objArray54);
        mathException34.addSuppressed((java.lang.Throwable) convergenceException57);
        convergenceException25.addSuppressed((java.lang.Throwable) convergenceException57);
        org.apache.commons.math.exception.util.Localizable localizable60 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) 0.0d, (java.lang.Number) 6.2564893518218625E35d, (java.lang.Number) (-0.17902745162659536d));
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable60, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.198520144579203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 65.58771789703562d + "'", double1 == 65.58771789703562d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable0, "hi!", objArray8);
        java.lang.Throwable[] throwableArray12 = mathException11.getSuppressed();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(number13, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number17 = outOfRangeException16.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable18 = outOfRangeException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 88.84450792549285d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 26, (java.lang.Number) 27.990841778891753d, true);
        java.lang.Number number27 = numberIsTooLargeException26.getMax();
        mathException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException26);
        java.lang.String str29 = numberIsTooLargeException26.toString();
        java.lang.String str30 = numberIsTooLargeException26.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 27.990841778891753d + "'", number27.equals(27.990841778891753d));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 26 is larger than the maximum (27.991): 26 out of [27.991, {2}] range" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 26 is larger than the maximum (27.991): 26 out of [27.991, {2}] range"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 26 is larger than the maximum (27.991): 26 out of [27.991, {2}] range" + "'", str30.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 26 is larger than the maximum (27.991): 26 out of [27.991, {2}] range"));
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test450");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        double double14 = randomDataImpl0.nextF(9.999999999999998d, (double) 48L);
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        double double18 = randomDataImpl0.nextCauchy((-1.2736190370090261d), 82.42409747617464d);
//        long long21 = randomDataImpl0.nextLong(0L, (long) 7);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.41190620949165035d + "'", double7 == 0.41190620949165035d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.42201567241119636d + "'", double9 == 0.42201567241119636d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.5016867924616497d) + "'", double11 == (-0.5016867924616497d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6675273215784158d + "'", double14 == 0.6675273215784158d);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-131.08522026776666d) + "'", double18 == (-131.08522026776666d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4L + "'", long21 == 4L);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.2465279712559802d), number1, false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10L, (-0.19666828883033707d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1185126851660605d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.060299188382886d + "'", double1 == 3.060299188382886d);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test455");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double5 = randomDataImpl0.nextWeibull(16.975649656605654d, 1.724594607551417d);
//        double double7 = randomDataImpl0.nextT(0.6040903237761033d);
//        double double10 = randomDataImpl0.nextUniform(0.23044395339514506d, 718.3807058861689d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a6c07ebfd4f5e28d6a5e4a53a8651850b13007f6a9e7f1348a3e12eb508d3bcda9ecb1499b389b295fe21ee5149e7ee0d46" + "'", str2.equals("1a6c07ebfd4f5e28d6a5e4a53a8651850b13007f6a9e7f1348a3e12eb508d3bcda9ecb1499b389b295fe21ee5149e7ee0d46"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.7383781754813599d + "'", double5 == 1.7383781754813599d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.177182090723048d + "'", double7 == 6.177182090723048d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 345.871575732658d + "'", double10 == 345.871575732658d);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        convergenceException0.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 0.0d, (java.lang.Number) 6.2564893518218625E35d, (java.lang.Number) (-0.17902745162659536d));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.2303768178828743d), (java.lang.Number) 25.10345653640629d, true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable35);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test457");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3398378464310265d + "'", double7 == 1.3398378464310265d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.03820948947984593d + "'", double9 == 0.03820948947984593d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08607102978309605d + "'", double11 == 0.08607102978309605d);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 26);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.27829965900511133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double2 = org.apache.commons.math.util.FastMath.max(0.3432933379273535d, (double) 42L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.0d + "'", double2 == 42.0d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare((double) 1L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47977831730278975d + "'", double2 == 0.47977831730278975d);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9043022375118979d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8120613450333635d + "'", double1 == 0.8120613450333635d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.2406134847420311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8923755214481076d + "'", double1 == 0.8923755214481076d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
        int int6 = randomDataImpl3.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", int6, (-1L) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
        int int19 = randomDataImpl16.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!", int19, (-1L) };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray29);
        mathException9.addSuppressed((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray34 = convergenceException32.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32);
        java.lang.Object[] objArray42 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray42);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
        int int50 = randomDataImpl47.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { "hi!", int50, (-1L) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException43, "hi!", objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, "org.apache.commons.math.exception.OutOfRangeException: null out of [10, 19.31] range", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("4", objArray52);
        java.lang.String str57 = convergenceException56.getPattern();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "4" + "'", str57.equals("4"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.4955126114429672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7039265667972529d + "'", double1 == 0.7039265667972529d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.023918480938191995d, (-12.230358474879816d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 38, (java.lang.Number) 101.03598257045044d, true);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        long long6 = randomDataImpl0.nextLong((long) '#', (long) '4');
//        double double8 = randomDataImpl0.nextChiSquare(1.2729967908999662d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 40L + "'", long6 == 40L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.00396511416939455d + "'", double8 == 0.00396511416939455d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.997955783106022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.550427434492091d + "'", double1 == 1.550427434492091d);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test470");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int9 = randomDataImpl0.nextBinomial(35, (-0.5016867924616497d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.502 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "340ecf870b4819fadaf1e0991bf11233f461a0b82bd092fd442bc70c22dbadfedb6718b3261ea3164198a88d47c88ab8e280" + "'", str2.equals("340ecf870b4819fadaf1e0991bf11233f461a0b82bd092fd442bc70c22dbadfedb6718b3261ea3164198a88d47c88ab8e280"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 37L + "'", long5 == 37L);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 108.01798396338886d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (-1.4183144013928657d), (java.lang.Number) 9.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
        int int18 = randomDataImpl15.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!", int18, (-1L) };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("a6050214699003663810a00decc5f83e755517e1867289721069303310fc5fe3726f44deb1034da6ec53ae3ce677645a4c9d", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(9, localizable11, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl();
        int int33 = randomDataImpl30.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray35 = new java.lang.Object[] { "hi!", int33, (-1L) };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("hi!", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable37, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException26, "", objArray43);
        boolean boolean47 = notStrictlyPositiveException26.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException26);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0654109334640752E-210d, (java.lang.Number) (-0.29588497520587087d), false);
        boolean boolean54 = numberIsTooLargeException53.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException53.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl();
        int int61 = randomDataImpl58.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray63 = new java.lang.Object[] { "hi!", int61, (-1L) };
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray63);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl72 = new org.apache.commons.math.random.RandomDataImpl();
        int int75 = randomDataImpl72.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray77 = new java.lang.Object[] { "hi!", int75, (-1L) };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("hi!", objArray77);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException78, localizable79, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException68, "", objArray85);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64, "", objArray85);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException(localizable55, objArray85);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException26, "d654665399e1ff30791a2c8b0aa3df873687d2cd6e95e3985fb28fc76a94e88a6a4debc8f536000b3a7b6bb8d6225d69b", objArray85);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable11, objArray85);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        float float2 = org.apache.commons.math.util.FastMath.max(37.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.522788904814426d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.576270945910846d) + "'", double1 == (-0.576270945910846d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) 53L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 6.942898894086964d, (java.lang.Number) (-0.24510465435485307d), true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6367030434169783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2793369546046023d + "'", double1 == 1.2793369546046023d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, 0.799059446794603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double2 = org.apache.commons.math.util.FastMath.max((-15.064498446609784d), (double) 24L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.0d + "'", double2 == 24.0d);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test479");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        try {
//            double double9 = randomDataImpl0.nextUniform(3.1282446759109312E35d, 16.87876954085938d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 312,824,467,591,093,120,000,000,000,000,000,000 is larger than, or equal to, the maximum (16.879): lower bound (312,824,467,591,093,120,000,000,000,000,000,000) must be strictly less than upper bound (16.879)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 59L + "'", long3 == 59L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9034573879000594d + "'", double6 == 0.9034573879000594d);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.841449015201038d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.07941981413075168d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07634791915576562d) + "'", double1 == (-0.07634791915576562d));
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test482");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 100, 100);
//        java.lang.String str5 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray9 = randomDataImpl0.nextPermutation(33, 5);
//        double double12 = randomDataImpl0.nextCauchy((double) 39L, 0.8430095582228464d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 38.033517445212965d + "'", double12 == 38.033517445212965d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray12 = new java.lang.Object[] { "hi!", int10, (-1L) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, localizable14, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) -1, (java.lang.Number) 1.5574077246549023d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 48.0d, (java.lang.Number) (short) 0, (java.lang.Number) (-0.2797748653068142d));
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(number33, (java.lang.Number) 10, (java.lang.Number) 19.31004779531512d);
        java.lang.Number number37 = outOfRangeException36.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException36.getGeneralPattern();
        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
        int int44 = randomDataImpl41.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", int44, (-1L) };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 10.0f);
        org.apache.commons.math.random.RandomDataImpl randomDataImpl55 = new org.apache.commons.math.random.RandomDataImpl();
        int int58 = randomDataImpl55.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray60 = new java.lang.Object[] { "hi!", int58, (-1L) };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("hi!", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (short) 10, (short) 100, 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException61, localizable62, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException51, "", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47, "", objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(localizable38, objArray68);
        java.lang.Object[] objArray76 = null;
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException77.getGeneralPattern();
        java.lang.Object[] objArray79 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable78, objArray79);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable38, objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray79);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("1a6c07ebfd4f5e28d6a5e4a53a8651850b13007f6a9e7f1348a3e12eb508d3bcda9ecb1499b389b295fe21ee5149e7ee0d46", objArray79);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(localizable78);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(69.17391486639119d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3963.3733742414765d + "'", double1 == 3963.3733742414765d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 37, (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed(98L);
        int int6 = randomDataImpl1.nextInt(22, 99);
        try {
            int int9 = randomDataImpl1.nextInt(19, 18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 19 is larger than, or equal to, the maximum (18): lower bound (19) must be strictly less than upper bound (18)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 78 + "'", int6 == 78);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long5 = randomDataImpl0.nextLong((long) ' ', 42L);
//        randomDataImpl0.reSeedSecure(38L);
//        double double10 = randomDataImpl0.nextGaussian((double) 1, 16.975649656605654d);
//        try {
//            int int13 = randomDataImpl0.nextInt(22, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 22 is larger than, or equal to, the maximum (0): lower bound (22) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acc8ade615e53ddf66437099e20e99d5d8064a74ea1c21578a09670aea813908110ca6f7cb9e6ac5852c5d3832fce6fe0830" + "'", str2.equals("acc8ade615e53ddf66437099e20e99d5d8064a74ea1c21578a09670aea813908110ca6f7cb9e6ac5852c5d3832fce6fe0830"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 39L + "'", long5 == 39L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0620056486767282d) + "'", double10 == (-0.0620056486767282d));
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-5.180883098029916d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3963.3733742414765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.285103082296065d + "'", double1 == 8.285103082296065d);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) '#', (long) (short) 100);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 100, (double) (short) 10);
//        randomDataImpl0.reSeedSecure(48L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60L + "'", long3 == 60L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9221929257579087d + "'", double6 == 0.9221929257579087d);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-2.71779385040451d), 51.01098609108488d, 0.14046728854509286d, 30);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.4339872044851463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05993438318962159d + "'", double1 == 0.05993438318962159d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.atan(89.88663066756469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5596716607627874d + "'", double1 == 1.5596716607627874d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.5844901182120892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7966339731889303d + "'", double1 == 3.7966339731889303d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl();
        int int5 = randomDataImpl2.nextZipf((int) ' ', (double) '4');
        java.lang.Object[] objArray7 = new java.lang.Object[] { "hi!", int5, (-1L) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, number10, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2, (java.lang.Number) (short) 1, (java.lang.Number) 33);
        java.lang.Throwable[] throwableArray20 = outOfRangeException19.getSuppressed();
        java.lang.Number number21 = outOfRangeException19.getHi();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 33 + "'", number21.equals(33));
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test497");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) 1L, (double) '4');
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextZipf((int) ' ', (double) '4');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, (double) ' ');
//        double double14 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = normalDistributionImpl13.cumulativeProbability((double) 100.0f);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        try {
//            int[] intArray20 = randomDataImpl0.nextPermutation(15, 17);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 17 is larger than the maximum (15): permutation size (17) exceeds permuation domain (15)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.274790888256152d + "'", double3 == 31.274790888256152d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.188413838187642d) + "'", double14 == (-2.188413838187642d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9975420988248034d + "'", double16 == 0.9975420988248034d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-19.036662199461134d) + "'", double17 == (-19.036662199461134d));
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 39L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test499");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.sample();
//        double double8 = normalDistributionImpl6.getStandardDeviation();
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double11 = randomDataImpl0.nextT((double) (byte) 10);
//        double double14 = randomDataImpl0.nextF(9.999999999999998d, (double) 48L);
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        double double18 = randomDataImpl0.nextCauchy((-1.2736190370090261d), 82.42409747617464d);
//        int int21 = randomDataImpl0.nextZipf(26, 0.060382090350750026d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5116995037925172d + "'", double7 == 0.5116995037925172d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2306448979566536d + "'", double9 == 0.2306448979566536d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7329708472712329d + "'", double11 == 0.7329708472712329d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.244622575923368d + "'", double14 == 1.244622575923368d);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-358.7305246245065d) + "'", double18 == (-358.7305246245065d));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 26 + "'", int21 == 26);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((double) (short) 10);
        double double3 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.69459862670642E-23d + "'", double2 == 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }
}

