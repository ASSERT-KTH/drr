import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-11L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1301095401);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.9999546000702375d), (double) (-672517978019777775L), (double) 5L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-16L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.log(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7456418720467646d) + "'", double1 == (-1.7456418720467646d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-669822273L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.053671212772351E-8d, (-40590));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.533981912513346E103d + "'", double2 == 2.533981912513346E103d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 100, (double) 1149987972776840228L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-27), 1073741859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741886) + "'", int2 == (-1073741886));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8414709848078965d, 3.5549250982832153E11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5549250982714264E11d + "'", double2 == 3.5549250982714264E11d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.6900760708753189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1418058772L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.418058772E9d + "'", double1 == 1.418058772E9d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.705026843555238d + "'", double1 == 0.705026843555238d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1410065408);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.410065408E9d + "'", double1 == 1.410065408E9d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.6d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 214958080 + "'", int1 == 214958080);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        int int21 = nonMonotonousSequenceException17.getIndex();
        java.lang.String str22 = nonMonotonousSequenceException17.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long2 = org.apache.commons.math.util.FastMath.max((-36L), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3781636423089436E12d + "'", double1 == 1.3781636423089436E12d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 4063339876L, 32, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-65), 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2001245951) + "'", int2 == (-2001245951));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 86423632256L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.52587890625E-5d + "'", double1 == 1.52587890625E-5d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1107);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 1418058948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1418058948 + "'", int2 == 1418058948);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100, (java.lang.Number) 0.9844946338415412d, 27, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.9844946338415412d + "'", number6.equals(0.9844946338415412d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-102083904936L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) -1, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000284d + "'", double1 == 1.0000000000000284d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.474446222051669E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 65.0d + "'", double1 == 65.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection18, true);
        java.lang.Number number25 = nonMonotonousSequenceException24.getPrevious();
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException24.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) 10 + "'", number25.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int int1 = org.apache.commons.math.util.FastMath.abs((-40590));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40590 + "'", int1 == 40590);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-16L), (java.lang.Number) (-669822273L), 0, orderDirection15, false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1107, (long) 1931908993);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2138623255251L + "'", long2 == 2138623255251L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-102083904936L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-2.9023762589785425d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 48.50515463917526d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(32, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1963152018L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.String str21 = nonMonotonousSequenceException19.toString();
        java.lang.String str22 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1661992908, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1661992908L + "'", long2 == 1661992908L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-41));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-40.99999999999999d) + "'", double1 == (-40.99999999999999d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 35L, 887503681, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-16L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray69 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 0.0d);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.54402111088937d + "'", double70 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 887503681 + "'", int74 == 887503681);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1661992928, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 210933207 + "'", int25 == 210933207);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.asinh(186.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.924262946527149d + "'", double1 == 5.924262946527149d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 26L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1787535542062797d + "'", double1 == 1.1787535542062797d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.0787619161000124d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, 27L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2665L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.332621544395465E155d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1418058772L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-672517978019777791L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-672517978019777891L) + "'", long2 == (-672517978019777891L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5108256237659907d) + "'", double1 == (-0.5108256237659907d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 210933207 + "'", int11 == 210933207);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.06642803824623132d, 1661992964, 1931908993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1107));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.4129651365067377d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1800171439 + "'", int1 == 1800171439);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        long long2 = org.apache.commons.math.util.FastMath.max(1072693248L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray68 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray68);
        java.lang.Class<?> wildcardClass70 = doubleArray68.getClass();
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) 0);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.54402111088937d + "'", double69 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 116.940155635265d + "'", double73 == 116.940155635265d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-99), (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(22.07492164711474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1264.799843461654d + "'", double1 == 1264.799843461654d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1074790400));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2700, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long2 = org.apache.commons.math.util.MathUtils.pow(100L, (long) 1073741859);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(22.07492164711474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.074921647114742d + "'", double1 == 22.074921647114742d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1107);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.002192308688104244d + "'", double1 == 0.002192308688104244d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-99), 39.99627207622075d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 11, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1100L + "'", long2 == 1100L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9961652815068444d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.1068263745867423E39d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number18 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number20 = nonMonotonousSequenceException7.getArgument();
        int int21 = nonMonotonousSequenceException7.getIndex();
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1661992964, 0.5861601948888234d, (double) 1661992964);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 1301095401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6565195560162134d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-41));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1661992927);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.92443045821455d + "'", double1 == 21.92443045821455d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(99, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.1622776601683795d, 0.6900760708753189d, 4.032908758547247E67d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(2.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.149548905166106d + "'", double1 == 1.149548905166106d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1149987972776840228L, (-65));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1072693248, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 192.8299711564793d + "'", double2 == 192.8299711564793d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.0d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray33);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection51, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (116.94 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 210933207 + "'", int37 == 210933207);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection19, false);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        int int23 = nonMonotonousSequenceException14.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection36, true);
        java.lang.Number number39 = nonMonotonousSequenceException38.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException53.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = nonMonotonousSequenceException57.getDirection();
        nonMonotonousSequenceException47.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException57);
        java.lang.Number number61 = nonMonotonousSequenceException57.getArgument();
        nonMonotonousSequenceException38.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException57);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException57);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1963152018) + "'", number15.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 10.0d + "'", number39.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + 0 + "'", number61.equals(0));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 11L, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (-405900));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.5527136788005016E-16d, 1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.393542617697865d, (-1107));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.5902767940013953E283d) + "'", double2 == (-2.5902767940013953E283d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.4129651365067377d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4129651365067377d + "'", double2 == 1.4129651365067377d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0216848814370751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.log10(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0413926851582251d + "'", double1 == 1.0413926851582251d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1123.4784426498145d, number1, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        java.lang.Class<?> wildcardClass30 = orderDirection21.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-41), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.705026843555238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5335808546322118d + "'", double1 == 0.5335808546322118d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6603636613738071d + "'", double1 == 0.6603636613738071d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1149987972776840228L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0723749217399856E9d + "'", double1 == 1.0723749217399856E9d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        float float1 = org.apache.commons.math.util.MathUtils.sign(2.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1787535542062797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020573130590485034d + "'", double1 == 0.020573130590485034d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-672517978019777791L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-669822263));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963253019632d) + "'", double1 == (-1.5707963253019632d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.FastMath.pow(27.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.418058772E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.765701891865987d + "'", double1 == 21.765701891865987d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-176L), 1301095401L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(52, 1073741859);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray32 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray39 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray39);
        double[] doubleArray42 = null;
        double[] doubleArray44 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray51 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 0.0d);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray54);
        double[] doubleArray57 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray64 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray64);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (-0.009999666686665238d));
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.54402111088937d + "'", double40 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 218.05962487356527d + "'", double41 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 10.54402111088937d + "'", double52 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 10.54402111088937d + "'", double65 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 218.05962487356527d + "'", double66 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1301095401 + "'", int69 == 1301095401);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.009999666686665238d + "'", double70 == 0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.5440211108893698d + "'", double71 == 0.5440211108893698d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1.02083903E11f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37209260 + "'", int1 == 37209260);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 1410065435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection25, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection25, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-65), (java.lang.Number) (-0.008508692317092035d), 100, orderDirection25, false);
        boolean boolean32 = nonMonotonousSequenceException31.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        int int34 = nonMonotonousSequenceException31.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException31.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.06652753112764034d), (double) (-2001245951));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.1909233824906622d), (-0.9999546000702375d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.190923382490662d) + "'", double2 == (-1.190923382490662d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.432414667665563E25d + "'", double2 == 4.432414667665563E25d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(110.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.03696730494863232d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 10, 2132);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9342813113834067E26d) + "'", double2 == (-1.9342813113834067E26d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        long long2 = org.apache.commons.math.util.FastMath.max((-669822328L), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Number number37 = nonMonotonousSequenceException33.getArgument();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException33.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str44 = nonMonotonousSequenceException43.toString();
        java.lang.String str45 = nonMonotonousSequenceException43.toString();
        boolean boolean46 = nonMonotonousSequenceException43.getStrict();
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number48 = nonMonotonousSequenceException33.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str45.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.7615941559557649d + "'", number48.equals(0.7615941559557649d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1410065435);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.066901948770283d + "'", double1 == 21.066901948770283d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-176L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9974939203271522d + "'", double1 == 0.9974939203271522d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(11, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4844415983612418d + "'", double1 == 1.4844415983612418d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.4213683167726168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4213683167726168d + "'", double1 == 2.4213683167726168d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection30, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (11 >= 11)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 1, (long) (-65));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-65L) + "'", long2 == (-65L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6156614753256583d + "'", double1 == 0.6156614753256583d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-36L), 1.418058772E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.418058772702454E9d + "'", double2 == 1.418058772702454E9d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 27L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 27.0f + "'", float2 == 27.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 187L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.263765701229396d + "'", double1 == 3.263765701229396d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1072693248, (long) 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.008508692317092035d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9915274041549061d + "'", double1 == 0.9915274041549061d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1074790400), (float) (-672517978019777775L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.7251801E17f) + "'", float2 == (-6.7251801E17f));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9371005412963566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5525696082358775d + "'", double1 == 1.5525696082358775d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.454727522118143E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.4547275221E10d + "'", double1 == 7.4547275221E10d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.015640944658330335d), (java.lang.Number) 1.5628821893349888E-18d, (-405900));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.5628821893349888E-18d + "'", number4.equals(1.5628821893349888E-18d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1516653350344987d + "'", double1 == 1.1516653350344987d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, (java.lang.Number) 17.502307845873887d, (-669822263));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.465190328815662E-32d, (java.lang.Number) bigInteger10, 0, orderDirection16, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.64647696539407d, (java.lang.Number) 27.0f, 99, orderDirection16, true);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1661992928L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.661992928E9d + "'", double1 == 1.661992928E9d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1963152018), (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.963152E9f) + "'", float2 == (-1.963152E9f));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-41), 1800171439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-669822263));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.tanh(17.47371683219511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999987d + "'", double1 == 0.9999999999999987d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection19, false);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        int int23 = nonMonotonousSequenceException14.getIndex();
        java.lang.String str24 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1963152018) + "'", number15.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException71.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = nonMonotonousSequenceException75.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection77, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963262855118d), (java.lang.Number) 4.9E-324d, (int) (short) 0, orderDirection77, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection77, false);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 887503681 + "'", int84 == 887503681);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-669822263), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-669822263L) + "'", long2 == (-669822263L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int2 = org.apache.commons.math.util.FastMath.min(1661992964, (-405900));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-405900) + "'", int2 == (-405900));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.FastMath.rint(17.47371683219511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.0d + "'", double1 == 17.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4063339876L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2138623255251L, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1100L, (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4116413837030013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.102683959079267d + "'", double1 == 3.102683959079267d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection18, true);
        java.lang.String str25 = nonMonotonousSequenceException24.toString();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10 >= -1)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10 >= -1)"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-669822263L), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.698222629999999E8d) + "'", double2 == (-6.698222629999999E8d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-32L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (-40590));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int2 = org.apache.commons.math.util.FastMath.min(1931908993, 1301095401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1301095401 + "'", int2 == 1301095401);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1787535542062797d, 2.1068263745867423E39d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        long long2 = org.apache.commons.math.util.MathUtils.pow(125994627894135L, 1661992908);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3091341803513813791L) + "'", long2 == (-3091341803513813791L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.atan((-26.04220809005457d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5324159816508551d) + "'", double1 == (-1.5324159816508551d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.5926105942853135d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1.25994627E14f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9345243693399503d + "'", double1 == 0.9345243693399503d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1301095401, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.10104611264248807d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.7615941559557649d + "'", number10.equals(0.7615941559557649d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 86423632256L, (int) ' ', (-1107));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 3L, 1.4844222297453329d, 0.9345243693399503d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3822760448662243961L, (java.lang.Number) 0.706984600967196d, 37209260, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.6313083693369503E35d, 4.64647696539407d, 65.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', (-210934314));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.9844946338415412d, (double) (-1963152018), (double) (-65L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.004425697988050785d, (-1.1909233824906624d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.7800704536839147d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04852138285419683d) + "'", double1 == (-0.04852138285419683d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-65.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.989326805819546d + "'", double1 == 3.989326805819546d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1.02083903E11f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-26.042208075870157d) + "'", double1 == (-26.042208075870157d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException22.getPrevious();
        boolean boolean30 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36L, (java.lang.Number) 17.502307845873887d, (int) (short) -1, orderDirection31, true);
        boolean boolean34 = nonMonotonousSequenceException33.getStrict();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException33.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException33.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) -1 + "'", number29.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1661992928L, 0.0d, 0.5756631887840653d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(187L, (long) 887503681);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-887503494L) + "'", long2 == (-887503494L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(99, (-65));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6435) + "'", int2 == (-6435));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 210933207 + "'", int12 == 210933207);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-669822263));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1514403414 + "'", int1 == 1514403414);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', 1410065408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065408 + "'", int2 == 1410065408);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 35L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger22);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger29);
        java.lang.Class<?> wildcardClass31 = bigInteger30.getClass();
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.FastMath.cos(198.7133320691794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7017147302463427d) + "'", double1 == (-0.7017147302463427d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.7970747335500249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.797074733550025d + "'", double1 == 0.797074733550025d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6156614753256583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6156614753256584d + "'", double1 == 0.6156614753256584d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.9915274041549061d, 37209260, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-40590.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 27);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.math.util.FastMath.min(2700, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 10L, 27);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-32L), 1.5707963267948966d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', 1931908993L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 666362403 + "'", int2 == 666362403);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1661992928L, (float) (-40590));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-40590.0f) + "'", float2 == (-40590.0f));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.10955952677394434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.2772984895975545d + "'", double1 == 6.2772984895975545d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1073741886), (-6435));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9165215479156338d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1252.1354469888358d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1107));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1107 + "'", int2 == 1107);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 214958080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1091.6993387601956d, (double) (-1.02083903E11f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926428956555d + "'", double2 == 3.1415926428956555d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.math.util.MathUtils.round((-6.6982227E8f), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.6982227E8f) + "'", float2 == (-6.6982227E8f));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.cos((-31.608149544718025d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.981581974056114d + "'", double1 == 0.981581974056114d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11014.0d + "'", double1 == 11014.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection19, false);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str23 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1963152018) + "'", number15.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(21.066901948770283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3676868022008512d + "'", double1 == 0.3676868022008512d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-41), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5335808546322118d, (-0.04852138285419683d), (-6.768723683405125E214d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(40590, 40590);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40590 + "'", int2 == 40590);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4488968507373257d, number1, 1661992961, orderDirection15, false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.Class<?> wildcardClass19 = nonMonotonousSequenceException17.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 887503681, (java.lang.Number) 3.469446951953614E-18d, (-2001245951), orderDirection20, true);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1963152018) + "'", number18.equals((-1963152018)));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.3043045862358962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8347789329832497d + "'", double1 == 0.8347789329832497d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-11L), 48.50515463917526d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 48.50515463917526d + "'", double2 == 48.50515463917526d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 2131430883, (long) 1800171439);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1800171439L + "'", long2 == 1800171439L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.lang.Class<?> wildcardClass22 = bigInteger21.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1301095401);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1931908993);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger47);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger48);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 0L);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger55);
        java.lang.Class<?> wildcardClass57 = bigInteger56.getClass();
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger40);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1556157735575975E15d + "'", double1 == 2.1556157735575975E15d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1418058772L, (-672517978019777775L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long1 = org.apache.commons.math.util.MathUtils.sign(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.665284718471351d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1066.4997655883733d + "'", double1 == 1066.4997655883733d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray22 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection41, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection41, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection50, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection50, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (10 > 0.996)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.844281201823303d + "'", double19 == 28.844281201823303d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-4165L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 1073741859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 6305L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.1447298858494002d, 7.4547275221E10d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5403023058681398d, (double) (-1072693212L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653086106d + "'", double2 == 3.141592653086106d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException22.getPrevious();
        boolean boolean30 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36L, (java.lang.Number) 17.502307845873887d, (int) (short) -1, orderDirection31, true);
        boolean boolean34 = nonMonotonousSequenceException33.getStrict();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException33.getSuppressed();
        java.lang.Number number36 = nonMonotonousSequenceException33.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) -1 + "'", number29.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 36L + "'", number36.equals(36L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 37209260);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37209260 + "'", int1 == 37209260);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.10104611264248807d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7418880614464484d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-405900), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1073741859, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 192.83974187896146d + "'", double2 == 192.83974187896146d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long2 = org.apache.commons.math.util.FastMath.max(1301095401L, (-4100L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1301095401L + "'", long2 == 1301095401L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-36L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int2 = org.apache.commons.math.util.FastMath.min((-210934314), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-210934314) + "'", int2 == (-210934314));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.0054818376819687d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.FastMath.max((-65.0d), (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7237368419565787d + "'", double1 == 0.7237368419565787d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1184.521805548193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.9165215479156338d), (java.lang.Number) 1072693248, 1072693248);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-40590));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 1.8464165146410991d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1661992908);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5258789063110623E-5d + "'", double1 == 1.5258789063110623E-5d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 2131430912);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (byte) 100);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger32);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.275957614183426E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1688166320878607E-10d + "'", double1 == 4.1688166320878607E-10d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.atan(11.54402111088937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.484387102546669d + "'", double1 == 1.484387102546669d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.sin(1184.521805548193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14090467269408166d) + "'", double1 == (-0.14090467269408166d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', 1418058948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1418058948 + "'", int2 == 1418058948);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-4059), 1073741824, (-65));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = org.apache.commons.math.util.FastMath.min(37209260, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.4795239416637515E91d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        long long2 = org.apache.commons.math.util.FastMath.min(42L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(7.724300159037486E-5d, 7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.89629601826798E13d + "'", double2 == 7.89629601826798E13d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 20L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5707963193593657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(Double.NaN, 1.6929693744344998d, 187.41829408123718d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int1 = org.apache.commons.math.util.MathUtils.hash(39.99627207622075d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1750377691) + "'", int1 == (-1750377691));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        double[] doubleArray63 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray70 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.54402111088937d + "'", double71 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 218.05962487356527d + "'", double73 == 218.05962487356527d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 26L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6469193223286404d + "'", double1 == 0.6469193223286404d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-887503494L), (float) (-1750377691));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.75037773E9f) + "'", float2 == (-1.75037773E9f));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.log1p(27.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.332204510175204d + "'", double1 == 3.332204510175204d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.06652753112764034d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-876128.819252256d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-0.5440211108893698d) + "'", number15.equals((-0.5440211108893698d)));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5258789063110623E-5d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1056096256 + "'", int1 == 1056096256);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 20L, 1.2599462723584112E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.000000000000004d + "'", double2 == 20.000000000000004d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.lang.Class<?> wildcardClass22 = bigInteger21.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1301095401);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 1661992964);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 100, (long) 1661992927);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1661992827L) + "'", long2 == (-1661992827L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1418058948);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.072554835419368d + "'", double1 == 21.072554835419368d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (-0.5440211108893698d));
        double[] doubleArray63 = null;
        try {
            double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1107, (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-405900.0d), (double) 1040L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1043.062790100288d + "'", double2 == 1043.062790100288d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1410065508, (-27));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (byte) 0);
        double[] doubleArray65 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException78.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException82);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = nonMonotonousSequenceException82.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection84, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection84, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException90 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection84, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection84, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection93 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection93, false);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection93 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection93.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-18.714973875118524d) + "'", double1 == (-18.714973875118524d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException22.getPrevious();
        boolean boolean30 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36L, (java.lang.Number) 17.502307845873887d, (int) (short) -1, orderDirection31, true);
        boolean boolean34 = nonMonotonousSequenceException33.getStrict();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException33.getSuppressed();
        java.lang.String str36 = nonMonotonousSequenceException33.toString();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) -1 + "'", number29.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (17.502 >= 36)" + "'", str36.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (17.502 >= 36)"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-40.99999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2349.126960036375d) + "'", double1 == (-2349.126960036375d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(21.066901948770283d, 97.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-10.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException25.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        int int29 = nonMonotonousSequenceException25.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException25.getDirection();
        java.lang.Number number32 = nonMonotonousSequenceException25.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0 + "'", number32.equals(0));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.017874927409903d + "'", double1 == 10.017874927409903d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 666362403, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.66362403E8d + "'", double2 == 6.66362403E8d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-2331815227L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.9165215479156338d), 1.2599462723584112E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.274290721937348E-15d) + "'", double2 == (-7.274290721937348E-15d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.724300159037486E-5d, 21.231283298111975d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.942793602681539E-88d + "'", double2 == 4.942793602681539E-88d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, (java.lang.Number) 17.502307845873887d, (-669822263));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = nonMonotonousSequenceException46.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.465190328815662E-32d, (java.lang.Number) bigInteger41, 0, orderDirection47, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection47, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1661992908, 0.981581974056114d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.75582948023793E-4d) + "'", double2 == (-8.75582948023793E-4d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        long long2 = org.apache.commons.math.util.FastMath.min(1661992928L, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.017874927409903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.469446951953615E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray20 = null;
        double[] doubleArray22 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray29 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray32);
        double[] doubleArray38 = new double[] { (byte) 100, '#', '#', '#' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray41 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray48 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 0.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray51);
        double[] doubleArray54 = null;
        double[] doubleArray56 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray63 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 0.0d);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray66);
        double[] doubleArray69 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray76 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray76);
        double[] doubleArray81 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray88 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray81, doubleArray88);
        java.lang.Class<?> wildcardClass90 = doubleArray88.getClass();
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray88);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray88);
        int int93 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.844281201823303d + "'", double19 == 28.844281201823303d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10.54402111088937d + "'", double30 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 116.940155635265d + "'", double39 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.54402111088937d + "'", double49 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 116.940155635265d + "'", double52 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.54402111088937d + "'", double64 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10.54402111088937d + "'", double77 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 218.05962487356527d + "'", double78 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 10.54402111088937d + "'", double89 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 210933207 + "'", int93 == 210933207);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.4129651365067377d, (double) 1800171439L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.849058739047897E-10d + "'", double2 == 7.849058739047897E-10d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.49993310426429d, 4.3291424275971494E24d, (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.floor(21.397817190913194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.0d + "'", double1 == 21.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-11L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1514403414);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1107), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1106) + "'", int2 == (-1106));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number26 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number27 = nonMonotonousSequenceException19.getPrevious();
        int int28 = nonMonotonousSequenceException19.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection41, true);
        java.lang.Number number44 = nonMonotonousSequenceException43.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException48.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException52.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException58.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = nonMonotonousSequenceException62.getDirection();
        nonMonotonousSequenceException52.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        java.lang.Number number66 = nonMonotonousSequenceException62.getArgument();
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) -1 + "'", number26.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) -1 + "'", number27.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10.0d + "'", number44.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 0 + "'", number66.equals(0));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.421368316772617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.421368316772617d + "'", double1 == 2.421368316772617d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 1410065435);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7970747335500249d, 0.7237368419565787d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8335837007921815d + "'", double2 == 0.8335837007921815d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.5707963253019632d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05870302123982315d + "'", double1 == 0.05870302123982315d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int2 = org.apache.commons.math.util.MathUtils.pow(40590, (long) 1661992908);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(52L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.abs(26.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.0d + "'", double1 == 26.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-41));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.0d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray33);
        double[] doubleArray39 = null;
        double[] doubleArray41 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray48 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 0.0d);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray51);
        double[] doubleArray57 = new double[] { (byte) 100, '#', '#', '#' };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double[] doubleArray60 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray67 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 0.0d);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 210933207 + "'", int37 == 210933207);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.54402111088937d + "'", double49 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 116.940155635265d + "'", double58 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 10.54402111088937d + "'", double68 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 116.940155635265d + "'", double71 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 116.940155635265d + "'", double73 == 116.940155635265d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.rint(17.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.0d + "'", double1 == 17.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 1073741859);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 36L, (double) 1661992961);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6358599286615808d) + "'", double1 == (-0.6358599286615808d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray17 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray22 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray26 = new int[] { 36, (byte) 0 };
        int[] intArray31 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray38 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray44 = new int[] { 36, (byte) 0 };
        int[] intArray49 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray49);
        int[] intArray56 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray56);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray56);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1072693248 + "'", int23 == 1072693248);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 27 + "'", int32 == 27);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-669822263) + "'", int39 == (-669822263));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1661992928 + "'", int40 == 1661992928);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 22.11334438749598d + "'", double41 == 22.11334438749598d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 27 + "'", int50 == 27);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-669822263) + "'", int57 == (-669822263));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1661992961 + "'", int58 == 1661992961);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 402870831 + "'", int59 == 402870831);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-27), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-17) + "'", int2 == (-17));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.661992928E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2673631790022216d) + "'", double1 == (-0.2673631790022216d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.lang.Class<?> wildcardClass22 = bigInteger21.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 36);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger41);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger48);
        java.lang.Class<?> wildcardClass50 = bigInteger49.getClass();
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger49);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 36);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 187L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.997171023392149d) + "'", double1 == (-0.997171023392149d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1410065408);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double1 = org.apache.commons.math.util.FastMath.ulp(175.7189355621376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1800171439L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long1 = org.apache.commons.math.util.FastMath.abs(1040L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1040L + "'", long1 == 1040L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 4063339876L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63744.332108823604d + "'", double1 == 63744.332108823604d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2001245951), 1661992928L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-870129663) + "'", int2 == (-870129663));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9075712110370514d, (java.lang.Number) (-405900.0d), (-669822263), orderDirection6, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-17));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-15.951677119795225d), 1066.4997655883733d, 1.963152018E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException26.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection28, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection28, false);
        java.lang.Number number33 = nonMonotonousSequenceException32.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = nonMonotonousSequenceException37.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection39, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.0f + "'", number33.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(21.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1203.2113697747288d + "'", double1 == 1203.2113697747288d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 32, (double) (-672517978019777791L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (byte) 0);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.009999666686665238d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.3372756085821291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2625600113053684d + "'", double1 == 0.2625600113053684d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (-0.9999546000702375d));
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 218.05962487356527d + "'", double14 == 218.05962487356527d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5707963193593657d, 2.2250738585072014E-308d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double2 = org.apache.commons.math.util.MathUtils.round(6.8588484959636515d, 12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.858848495964d + "'", double2 == 6.858848495964d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-6435));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.469446951953614E-18d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray33);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1252.1354469888358d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-36.0f), 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.982297150257104d + "'", double2 == 7.982297150257104d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1661992928L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9007248738461055E7d + "'", double1 == 2.9007248738461055E7d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2700.0f + "'", float1 == 2700.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int int1 = org.apache.commons.math.util.FastMath.round((-10.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray81 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray88 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray81, doubleArray88);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection94 = nonMonotonousSequenceException93.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81, orderDirection94, false);
        try {
            double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 28.844281201823303d + "'", double78 == 28.844281201823303d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1418058948 + "'", int79 == 1418058948);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 10.54402111088937d + "'", double89 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + orderDirection94 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection94.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.666310772197643E157d + "'", double1 == 4.666310772197643E157d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1661992927);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.661992927E9d + "'", double1 == 1.661992927E9d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-16L), (-2665L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42640L + "'", long2 == 42640L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6089355255591363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8384733489293721d + "'", double1 == 0.8384733489293721d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 887503681, 0.8384733489293721d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.008550433842447854d) + "'", double2 == (-0.008550433842447854d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-41), (double) 1149987972776840193L, 0.9526653195309732d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Number number37 = nonMonotonousSequenceException33.getArgument();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException33.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str44 = nonMonotonousSequenceException43.toString();
        java.lang.String str45 = nonMonotonousSequenceException43.toString();
        boolean boolean46 = nonMonotonousSequenceException43.getStrict();
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number48 = nonMonotonousSequenceException43.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str45.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-42L) + "'", number48.equals((-42L)));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1661992927);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.231283277654608d + "'", double1 == 21.231283277654608d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.FastMath.log(1.131564088471395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12360082476266057d + "'", double1 == 0.12360082476266057d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.atan(64.55753862700634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.555307507794838d + "'", double1 == 1.555307507794838d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.33181523E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.069785331164885E7d) + "'", double1 == (-4.069785331164885E7d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.17632698070846498d, (-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1056096256, 26L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1056096230L + "'", long2 == 1056096230L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1661992927);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', (double) 187L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.00000000000001d + "'", double2 == 52.00000000000001d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.String str21 = nonMonotonousSequenceException19.toString();
        boolean boolean22 = nonMonotonousSequenceException19.getStrict();
        java.lang.String str23 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray35);
        try {
            double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 1.1447298858494002d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 887503681 + "'", int34 == 887503681);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.942793602681539E-88d, (java.lang.Number) 59, 36);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double2 = org.apache.commons.math.util.FastMath.max(363.7393755555636d, 3.1415926428956555d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 363.7393755555636d + "'", double2 == 363.7393755555636d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.418058772E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.418058772E9d + "'", double1 == 1.418058772E9d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1149987972776840193L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1514403414);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-17), (-669822272L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11386978624L + "'", long2 == 11386978624L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.lang.Class<?> wildcardClass22 = bigInteger21.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 36);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36, (java.lang.Number) (-2.33181517E9f), 52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray35);
        try {
            double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 887503681 + "'", int34 == 887503681);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.12796368962740468d), 3.5549250982832153E11d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11.54402111088937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger13);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1418058948L);
        java.lang.Class<?> wildcardClass17 = bigInteger13.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5143952585235492d, 3.469446951953615E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double2 = org.apache.commons.math.util.FastMath.min(156.3608363030788d, (-26.04220809005457d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-26.04220809005457d) + "'", double2 == (-26.04220809005457d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1661992960L, 86423632256L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.6358599286615808d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7381284594278902d) + "'", double1 == (-0.7381284594278902d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(402870831, 40590);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 414125.39347515884d + "'", double2 == 414125.39347515884d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-669822263));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1073741859);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray18 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray13);
        int[] intArray21 = null;
        try {
            int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1072693248 + "'", int19 == 1072693248);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5282839739597525d) + "'", double1 == (-0.5282839739597525d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074266112 + "'", int1 == 1074266112);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8253356149096783d + "'", double1 == 0.8253356149096783d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 10);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger23);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger24);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.lang.Class<?> wildcardClass33 = bigInteger32.getClass();
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger32);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger34);
        double[] doubleArray40 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException53.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = nonMonotonousSequenceException57.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection59, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection59, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection59, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection59, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection68, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger34, (java.lang.Number) 0.5440211108893698d, (int) 'a', orderDirection68, false);
        java.lang.Class<?> wildcardClass73 = bigInteger34.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1661992961, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = org.apache.commons.math.util.FastMath.min((-2001245951), 1056096256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2001245951) + "'", int2 == (-2001245951));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9896835559265444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.427031023580173d + "'", double1 == 1.427031023580173d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1056096256, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) (-10));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-36.0f), (-0.9999999999999999d), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1963152018));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.963152E9f + "'", float1 == 1.963152E9f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6565195560162134d, 0.2625600113053684d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9999546000702375d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(210933207);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double1 = org.apache.commons.math.util.FastMath.ceil(263.856815596594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 264.0d + "'", double1 == 264.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.log(263.856815596594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.575406590848711d + "'", double1 == 5.575406590848711d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8533353190484737d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.5399929762484854E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.539992976248486E-5d + "'", double1 == 4.539992976248486E-5d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1963152018L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.850212812423706d + "'", double2 == 1.850212812423706d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(22.11334438749598d, (double) 1.25994627E14f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2599462723583897E14d + "'", double2 == 1.2599462723583897E14d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-4059), 1661992928, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number27 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (-42L) + "'", number27.equals((-42L)));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-10), (-32L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 320L + "'", long2 == 320L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.02083903E11f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1514403414);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str27 = nonMonotonousSequenceException12.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str27.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3822760448662243961L, (float) 4063339876L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.06333978E9f + "'", float2 == 4.06333978E9f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(3, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5879663704475468d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5546700480995831d + "'", double1 == 0.5546700480995831d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        try {
            double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.5384786408469177d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }
}

