import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8347789329832497d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3043045862358962d + "'", double1 == 1.3043045862358962d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        double[] doubleArray63 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray70 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = nonMonotonousSequenceException75.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection76, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection76, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.54402111088937d + "'", double71 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9371005412963566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7137050048665134d + "'", double1 == 1.7137050048665134d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1750377691));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-669822263));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-669822263) + "'", int2 == (-669822263));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 36L, 0.3708024742879816d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5604966222911154d + "'", double2 == 1.5604966222911154d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.6929693744344998d, (java.lang.Number) 0.8347789329832497d, 1661992960);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray68 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray68);
        java.lang.Class<?> wildcardClass70 = doubleArray68.getClass();
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray68);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException78.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException82);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = nonMonotonousSequenceException82.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection84, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68, orderDirection84, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.54402111088937d + "'", double69 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 21.765701891865987d, (java.lang.Number) 0.18011193621618946d, 1410065435);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1410065435 + "'", int4 == 1410065435);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3781636423089436E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4053493189568493E10d + "'", double1 == 2.4053493189568493E10d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1410065508, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 218.05962487356527d);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 218.05962487356527d + "'", double62 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 210933207 + "'", int63 == 210933207);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.2599462723584112E14d, (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2599462723584112E14d + "'", double2 == 1.2599462723584112E14d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray69 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 0.0d);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (11 >= 11)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.54402111088937d + "'", double70 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException7.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException7.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1410065435, (long) (-40590));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1410106025L + "'", long2 == 1410106025L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double2 = org.apache.commons.math.util.FastMath.max(5.575406590848711d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.575406590848711d + "'", double2 == 5.575406590848711d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection30, false);
        java.lang.Class<?> wildcardClass33 = orderDirection30.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-6.768723683405125E214d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-27));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1252.1354469888358d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.1688166320878607E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.379987207158132d) + "'", double1 == (-9.379987207158132d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        java.lang.Class<?> wildcardClass78 = doubleArray5.getClass();
        double[] doubleArray83 = new double[] { (byte) 100, '#', '#', '#' };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray83);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray83);
        double[] doubleArray87 = null;
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 116.940155635265d + "'", double84 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1931908993 + "'", int85 == 1931908993);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0025763677110515215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0025763620107141683d + "'", double1 == 0.0025763620107141683d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(52, 214958080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 214958132 + "'", int2 == 214958132);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(39.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3242605952174955d + "'", double1 == 6.3242605952174955d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1073741886));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.073741886E9d) + "'", double1 == (-1.073741886E9d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5525696082358775d, 40590, 1074266112);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 16.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464757906675863d + "'", double1 == 3.464757906675863d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = org.apache.commons.math.util.FastMath.min(1301095401, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection12, true);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException14.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException26.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection28, true);
        java.lang.Number number31 = nonMonotonousSequenceException30.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection35, false);
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        java.lang.Number number39 = nonMonotonousSequenceException37.getArgument();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException37.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1963152018) + "'", number31.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0 + "'", number39.equals(0));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.653559774527022d) + "'", double1 == (-15.653559774527022d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-210934314), 1661992964);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(36.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2062.6480624709634d + "'", double1 == 2062.6480624709634d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1418058948, 2132);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(37209260, (-1073741886));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1110951146 + "'", int2 == 1110951146);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-870129663));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, (float) 3L);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.149548905166106d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.FastMath.sin(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5860134523134308E15d, (-0.9165577160638908d), 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1514403414, (long) 402870831);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 402870831L + "'", long2 == 402870831L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 12, 11386978624L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34160935872L + "'", long2 == 34160935872L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 0, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 10, 1661992961);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0038848218538872d) + "'", double1 == (-1.0038848218538872d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(52, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 402870831L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray12 = new int[] { 36, (byte) 0 };
        int[] intArray17 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        int[] intArray24 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray24);
        int[] intArray30 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray34 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray39 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray39);
        int[] intArray43 = new int[] { 36, (byte) 0 };
        int[] intArray48 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray48);
        int[] intArray55 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray34);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray34);
        java.lang.Class<?> wildcardClass60 = intArray34.getClass();
        int[] intArray61 = null;
        try {
            int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 27 + "'", int18 == 27);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-669822263) + "'", int25 == (-669822263));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1661992928 + "'", int26 == 1661992928);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1072693248 + "'", int40 == 1072693248);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 27 + "'", int49 == 27);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-669822263) + "'", int56 == (-669822263));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1661992928 + "'", int57 == 1661992928);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 22.11334438749598d + "'", double58 == 22.11334438749598d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1800171439);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.42748218540391386d) + "'", double1 == (-0.42748218540391386d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-2.33181517E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.331815168E9d + "'", double1 == 2.331815168E9d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 1056096230L, 11.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double2 = org.apache.commons.math.util.FastMath.min(6.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (-210934314));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.5707963253019632d), (double) (-1.75037773E9f), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.10955952677394434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11d + "'", double1 == 0.11d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 2131430883);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 887503681 + "'", int34 == 887503681);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 887503681 + "'", int35 == 887503681);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 2700);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1084561408 + "'", int1 == 1084561408);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1410065408);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 1.1447298858494002d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2001245951), (float) 45L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 45.0f + "'", float2 == 45.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 50);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 50L + "'", long1 == 50L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-672517978019777791L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.5756631887840654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1072693248, (-1107));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection13, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { (byte) 100, '#', '#', '#' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray8 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray15 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 116.940155635265d + "'", double6 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.54402111088937d + "'", double16 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-2.33181523E9d), (double) 2700.0f, 116.940155635265d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger29);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger30);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0L);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger37);
        java.lang.Class<?> wildcardClass39 = bigInteger38.getClass();
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger38);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 36);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.02083903E11f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11800054246683428d + "'", double1 == 0.11800054246683428d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1661992927, 27L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.FastMath.tan(35.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.750470905698713d + "'", double1 == 7.750470905698713d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-405900), 1931908993);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1410065435, (-669822328L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 1661992960L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11014.0d, 1.427031023580173d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1661992961);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.661992961E9d + "'", double1 == 1.661992961E9d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.04852138285419683d), 7.750470905698713d, 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        long long2 = org.apache.commons.math.util.FastMath.min((-16L), 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-16L) + "'", long2 == (-16L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(10.0d, 0, 1410065408);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = org.apache.commons.math.util.FastMath.max(37209260, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37209260 + "'", int2 == 37209260);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.190923382490662d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02078553416344984d) + "'", double1 == (-0.02078553416344984d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-0.009999666686665238d));
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray27);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray38 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.0d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray41);
        double[] doubleArray47 = new double[] { (byte) 100, '#', '#', '#' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray50 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray57 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 0.0d);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray41);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.54402111088937d + "'", double39 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 116.940155635265d + "'", double48 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 10.54402111088937d + "'", double58 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 116.940155635265d + "'", double61 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0025763677110515215d + "'", double63 == 0.0025763677110515215d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-669822231L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-669822231L) + "'", long1 == (-669822231L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection13, false);
        double[] doubleArray17 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray24 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 0.0d);
        double[] doubleArray29 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray36 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 0.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray36);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.54402111088937d + "'", double25 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.54402111088937d + "'", double37 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 210933207 + "'", int41 == 210933207);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 218.05962487356527d + "'", double42 == 218.05962487356527d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double2 = org.apache.commons.math.util.FastMath.max(64.55753862700634d, 21.072554835419368d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 64.55753862700634d + "'", double2 == 64.55753862700634d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1100L, (long) (-27));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3877787807814457E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1056096256, 320L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-17), 186.99999999999997d, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 3.0054818376819687d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 17, 99, (-669822263));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.String str21 = nonMonotonousSequenceException17.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection34, true);
        int int37 = nonMonotonousSequenceException36.getIndex();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7970747335500249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8841974228761557d + "'", double1 == 0.8841974228761557d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1410065508, 887503681);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.5399929762484854E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-0.009999666686665238d));
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray27);
        try {
            double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1107, (float) (-2001245951));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.00124595E9f) + "'", float2 == (-2.00124595E9f));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 37209260, 1.015269573507533d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 36L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.432414667665563E25d, 2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.592610594285313d, 0.6900760708753189d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5926105942853126d + "'", double2 == 2.5926105942853126d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6.66362403E8d, (double) (-2665L), 1123.4784426498145d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1149987972776840193L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.ulp(264.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double2 = org.apache.commons.math.util.FastMath.max(1.9522212262964344E114d, 0.06652591967083796d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9522212262964344E114d + "'", double2 == 1.9522212262964344E114d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1074790400L) + "'", long1 == (-1074790400L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1106));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1106L + "'", long1 == 1106L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(15.556349186104045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2851061.689605622d + "'", double1 == 2851061.689605622d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray68 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray68);
        java.lang.Class<?> wildcardClass70 = doubleArray68.getClass();
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray68);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.54402111088937d + "'", double69 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 11.54402111088937d);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.4779141078433703d);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 838887586 + "'", int21 == 838887586);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int1 = org.apache.commons.math.util.FastMath.abs(1514403414);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1514403414 + "'", int1 == 1514403414);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-65), (-4165L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100L, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        java.lang.Number number21 = nonMonotonousSequenceException20.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 4.574710978503383d, (int) '4', orderDirection25, false);
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException27.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1963152018) + "'", number21.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 4.574710978503383d + "'", number29.equals(4.574710978503383d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 6305L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 6305L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-65));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.073741886E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, 2.1556157735575978E15d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 2132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray8 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray15 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray8);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray22 = new double[] { 4.3112315471151645E15d, 0.8384733489293721d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.54402111088937d + "'", double16 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1418058948 + "'", int18 == 1418058948);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.12796368962740468d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-35), (-65), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.NEGATIVE_INFINITY + "'", float3 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1073741859, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1073741859L + "'", long2 == 1073741859L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.ceil(21.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.0d + "'", double1 == 21.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1410106025L, 42640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60126920906000L + "'", long2 == 60126920906000L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.6843418860808015E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.7615941559557649d + "'", number4.equals(0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1661992908);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection25, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection25, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-65), (java.lang.Number) (-0.008508692317092035d), 100, orderDirection25, false);
        boolean boolean32 = nonMonotonousSequenceException31.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        boolean boolean34 = nonMonotonousSequenceException31.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        long long2 = org.apache.commons.math.util.FastMath.max(60126920906000L, (-669822328L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60126920906000L + "'", long2 == 60126920906000L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.tan(22.07492164711474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08396959479549634d + "'", double1 == 0.08396959479549634d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, 1301095401);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1410065408, 1110951146);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1123.4784426498145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.51832995019016d + "'", double1 == 33.51832995019016d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.469446951953615E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5138636130983349E-6d + "'", double1 == 1.5138636130983349E-6d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-17), (-1106));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18802 + "'", int2 == 18802);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-40590));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1106), 1056096256);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-40590), 1410065508);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.4779141078433703d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 35, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(5, 1410065408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065413 + "'", int2 == 1410065413);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.225073858507202E-308d, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int int1 = org.apache.commons.math.util.FastMath.abs(1661992908);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1661992908 + "'", int1 == 1661992908);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.06652753112764034d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5607966601082315d, (java.lang.Number) 3.141592653589793d, 36);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 36 + "'", int4 == 36);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.5607966601082315d + "'", number7.equals(1.5607966601082315d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 666362403);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-666362403L) + "'", long2 == (-666362403L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.log(7.724300159037486E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.468554240589684d) + "'", double1 == (-9.468554240589684d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1056096256, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-666362403L), 27.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.6636243E8f) + "'", float2 == (-6.6636243E8f));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        float float2 = org.apache.commons.math.util.FastMath.max(2700.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1514403414, (-1750377691));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1418058948L, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 63812652660L + "'", long2 == 63812652660L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-2.33181517E9f), 0.981581974056114d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (byte) 100);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 10);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger41);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger48);
        java.lang.Class<?> wildcardClass50 = bigInteger49.getClass();
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger49);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger51);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1661992928);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.66199296E9f + "'", float1 == 1.66199296E9f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5707963261932094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int2 = org.apache.commons.math.util.FastMath.min(1107, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1410106025L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.053671212772351E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.053671212772351E-8d + "'", double1 == 1.053671212772351E-8d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.706984600967196d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Number number37 = nonMonotonousSequenceException33.getArgument();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.String str39 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10 >= 3,628,800)" + "'", str39.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10 >= 3,628,800)"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 887503681, 0.05870302123982315d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05870302123982315d + "'", double2 == 0.05870302123982315d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        java.lang.Class<?> wildcardClass78 = doubleArray5.getClass();
        double[] doubleArray83 = new double[] { (byte) 100, '#', '#', '#' };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray83);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray83);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.410065408E9d);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 116.940155635265d + "'", double84 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1931908993 + "'", int85 == 1931908993);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 28.844281201823303d + "'", double87 == 28.844281201823303d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-590163608) + "'", int90 == (-590163608));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-870129663), 9.332621544395465E155d, 52.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-6435), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-643500) + "'", int2 == (-643500));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-35));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 21.765701891865987d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, (java.lang.Number) 17.502307845873887d, (-669822263));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Number number32 = nonMonotonousSequenceException17.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.7615941559557649d + "'", number32.equals(0.7615941559557649d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 27L, 4.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9896835559265444d, (-40.99999999999999d), (double) (-1661992827L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(4063339876L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-669822263), (long) (-4059));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 247164415047L + "'", long2 == 247164415047L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 27, 21.231283297510288d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 27.0d + "'", double2 == 27.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(214958080);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1410065508);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1410065536 + "'", int1 == 1410065536);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-2001245951), (-48.99814438503587d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.570796351278716d) + "'", double2 == (-1.570796351278716d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 1410065508);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065508 + "'", int2 == 1410065508);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 10, (-643500), 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.306943617238488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.102683959079267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03892834085677523d) + "'", double1 == (-0.03892834085677523d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1410065408);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray12 = new int[] { 36, (byte) 0 };
        int[] intArray17 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        int[] intArray24 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray24);
        int[] intArray29 = new int[] { 36, (byte) 0 };
        int[] intArray34 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray34);
        try {
            int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 27 + "'", int18 == 27);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-669822263) + "'", int25 == (-669822263));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1661992928 + "'", int26 == 1661992928);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 27 + "'", int35 == 27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        java.lang.String str11 = nonMonotonousSequenceException7.toString();
        java.lang.Number number12 = nonMonotonousSequenceException7.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.7615941559557649d + "'", number12.equals(0.7615941559557649d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int int2 = org.apache.commons.math.util.FastMath.max(1410065413, (-6435));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065413 + "'", int2 == 1410065413);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8384733489293721d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9402316462574543d + "'", double1 == 0.9402316462574543d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.9023762589785425d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.238989199317325d) + "'", double1 == (-1.238989199317325d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1410065435);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double double1 = org.apache.commons.math.util.MathUtils.sign(27.28991719712775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2700);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5604966222911154d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8426391596357579d) + "'", double1 == (-0.8426391596357579d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9896835559265444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.263765701229396d, 7.665284718471351d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double2 = org.apache.commons.math.util.FastMath.atan2(116.940155635265d, (-0.997171023392149d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5793233109598845d + "'", double2 == 1.5793233109598845d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9165215479156338d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3038291548191727d) + "'", double1 == (-1.3038291548191727d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.1556157735575975E15d, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1073741886));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException12.getSuppressed();
        int int28 = nonMonotonousSequenceException12.getIndex();
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, number30, 0);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray33);
        java.lang.Class<?> wildcardClass36 = doubleArray33.getClass();
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 218.05962487356527d + "'", double37 == 218.05962487356527d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray25 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray38 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.0d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray41);
        double[] doubleArray47 = new double[] { (byte) 100, '#', '#', '#' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray50 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray57 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 0.0d);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray60);
        double[] doubleArray63 = null;
        double[] doubleArray65 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray72 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 0.0d);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray75);
        double[] doubleArray78 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray85 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray75, doubleArray85);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (-0.009999666686665238d));
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray85);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray85);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray25);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.54402111088937d + "'", double26 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.54402111088937d + "'", double39 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 116.940155635265d + "'", double48 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 10.54402111088937d + "'", double58 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 116.940155635265d + "'", double61 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.54402111088937d + "'", double73 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 10.54402111088937d + "'", double86 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 218.05962487356527d + "'", double87 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 175.7189355621376d + "'", double92 == 175.7189355621376d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int1 = org.apache.commons.math.util.MathUtils.hash(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591489 + "'", int1 == 1078591489);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1750377691), 1800171439);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1301095401);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1091.6993387601956d + "'", double1 == 1091.6993387601956d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) Float.NEGATIVE_INFINITY, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100L, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection22, false);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException26.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.Number number33 = nonMonotonousSequenceException26.getPrevious();
        boolean boolean34 = nonMonotonousSequenceException26.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (100 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (100 >= null)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0f + "'", number27.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (byte) -1 + "'", number33.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-669822231L), (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException7.getDirection();
        java.lang.Number number22 = nonMonotonousSequenceException7.getPrevious();
        boolean boolean23 = nonMonotonousSequenceException7.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.7615941559557649d + "'", number22.equals(0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.8464165146410993d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3727629417827345d + "'", double1 == 1.3727629417827345d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        double[] doubleArray63 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray70 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray70);
        double[] doubleArray77 = new double[] { (byte) 100, '#', '#', '#' };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray80 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray87 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray80, doubleArray87);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, 0.0d);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.54402111088937d + "'", double71 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 116.940155635265d + "'", double78 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 10.54402111088937d + "'", double88 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 116.940155635265d + "'", double91 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 453.88031127053d + "'", double92 == 453.88031127053d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 666362403);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) (-870129663));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1963152018L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.963152E9f + "'", float1 == 1.963152E9f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5440211108893698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5440211108893699d + "'", double1 == 0.5440211108893699d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1931908993);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.math.util.FastMath.pow(64.55753862700634d, (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9846221478564965E-104d + "'", double2 == 1.9846221478564965E-104d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-6.6636243E8f), 0.0d, 0.5756631887840654d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (-2001245951));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int[] intArray2 = new int[] { 36, (byte) 0 };
        int[] intArray7 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray7);
        int[] intArray11 = new int[] { 36, (byte) 0 };
        int[] intArray16 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray16);
        int[] intArray23 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray23);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 27 + "'", int17 == 27);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-669822263) + "'", int24 == (-669822263));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.661992924E9d + "'", double25 == 1.661992924E9d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(20L, (long) 1074266112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21485322240L + "'", long2 == 21485322240L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-36.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6283185307179586d) + "'", double1 == (-0.6283185307179586d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.16397872798119623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0134746644453547d + "'", double1 == 1.0134746644453547d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1800171439L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.0f, 4.666310772197643E157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 11.54402111088937d);
        double[] doubleArray24 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 1.0333147966386297E40d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-65));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1661992928, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992928 + "'", int2 == 1661992928);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5756631887840654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45467625589540794d + "'", double1 == 0.45467625589540794d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 35L, 2131430883, 1073741859);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1661992927, 1264.799843461654d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1264.799843461654d + "'", double2 == 1264.799843461654d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double2 = org.apache.commons.math.util.FastMath.min(52.0d, 7.750470905698713d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.750470905698713d + "'", double2 == 7.750470905698713d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray16 = new double[] { (byte) 100, '#', '#', '#' };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 1149987972776840228L);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 116.940155635265d + "'", double17 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray6 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray11 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray11);
        int[] intArray15 = new int[] { 36, (byte) 0 };
        int[] intArray20 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray20);
        int[] intArray27 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray27);
        int[] intArray33 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray37 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray42 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray42);
        int[] intArray46 = new int[] { 36, (byte) 0 };
        int[] intArray51 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray58 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray37);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray37);
        int[] intArray66 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray71 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray71);
        int[] intArray75 = new int[] { 36, (byte) 0 };
        int[] intArray80 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray80);
        int[] intArray87 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray87);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray66);
        try {
            int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1072693248 + "'", int12 == 1072693248);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 27 + "'", int21 == 27);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-669822263) + "'", int28 == (-669822263));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1661992928 + "'", int29 == 1661992928);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1072693248 + "'", int43 == 1072693248);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 27 + "'", int52 == 27);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-669822263) + "'", int59 == (-669822263));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1661992928 + "'", int60 == 1661992928);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 22.11334438749598d + "'", double61 == 22.11334438749598d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1072693248 + "'", int72 == 1072693248);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 27 + "'", int81 == 27);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-669822263) + "'", int88 == (-669822263));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1661992928 + "'", int89 == 1661992928);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-15.951677119795225d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4233458.9656065535d + "'", double1 == 4233458.9656065535d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.42748218540391386d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 214958080, (long) (-4059));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 214962139L + "'", long2 == 214962139L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray22 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection41, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection41, false);
        double[] doubleArray52 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException65.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = nonMonotonousSequenceException69.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection71, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection71, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection71, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection71, false);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray52);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (byte) 0);
        try {
            double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.844281201823303d + "'", double19 == 28.844281201823303d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (-669822263L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 669822263L + "'", long2 == 669822263L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.678982327128295d + "'", double1 == 4.678982327128295d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2, number17, 35);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1040L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083195392 + "'", int1 == 1083195392);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 214958132, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.atanh(21.765701891865987d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9371005412963566d, (double) 1800171439, 50);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1661992960, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.66199296E9d + "'", double2 == 1.66199296E9d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(34160935872L, (long) (-1750377691));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32410558181L + "'", long2 == 32410558181L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray35 = null;
        try {
            double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 887503681 + "'", int34 == 887503681);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(156.3608363030788d, 363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 363.70595144000515d + "'", double2 == 363.70595144000515d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.1688166320878607E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        double[] doubleArray63 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray70 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray70);
        double[] doubleArray74 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray81 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(doubleArray74, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, 0.0d);
        double[] doubleArray86 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray93 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray86, doubleArray93);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray93, 0.0d);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray93);
        int int98 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        double double99 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.54402111088937d + "'", double71 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 10.54402111088937d + "'", double82 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 10.54402111088937d + "'", double94 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 210933207 + "'", int98 == 210933207);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.3038291548191727d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.022756111635089456d) + "'", double1 == (-0.022756111635089456d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 18802, (long) 1073741824);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1073760626L + "'", long2 == 1073760626L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100L, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        long long1 = org.apache.commons.math.util.FastMath.abs(1800171439L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1800171439L + "'", long1 == 1800171439L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(125994627894135L, 1301095401L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.12250105341831324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12250105341831324d + "'", double1 == 0.12250105341831324d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-41));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-42.0d) + "'", double1 == (-42.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-41), (-1.5707963262855118d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 45L, (float) 1074266112);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 45.0f + "'", float2 == 45.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-0.009999666686665238d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray56);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException71.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = nonMonotonousSequenceException75.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection77, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963262855118d), (java.lang.Number) 4.9E-324d, (int) (short) 0, orderDirection77, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = nonMonotonousSequenceException81.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection82, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number30 = nonMonotonousSequenceException24.getPrevious();
        int int31 = nonMonotonousSequenceException24.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 10 + "'", number30.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-6435), 2131430912);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2131437347) + "'", int2 == (-2131437347));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 40590);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.61130164613947d + "'", double1 == 10.61130164613947d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.008508692317092035d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000361991408677d + "'", double1 == 1.0000361991408677d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5525696082358775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027097451530114534d + "'", double1 == 0.027097451530114534d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1418058948, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 214962139L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.14962139E8d + "'", double1 == 2.14962139E8d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 218.05962487356527d);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (-31.608149544718025d));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray68 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray68);
        java.lang.Class<?> wildcardClass70 = doubleArray68.getClass();
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray68);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.54402111088937d + "'", double69 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 218.05962487356527d + "'", double72 == 218.05962487356527d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1327242822) + "'", int1 == (-1327242822));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1301095401, (long) 50);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9915274041549061d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5756631887840654d, (java.lang.Number) 100.0d, 1661992928);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-6435), (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 229.1831180523293d + "'", double1 == 229.1831180523293d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4.06333978E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.091865771844886E7d + "'", double1 == 7.091865771844886E7d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double[] doubleArray4 = new double[] { (byte) 100, '#', '#', '#' };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.0d);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        try {
            double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 2.592610594285313d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 116.940155635265d + "'", double5 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 116.940155635265d + "'", double18 == 116.940155635265d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1074790400L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.752220392306214d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.924262946527149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 373.00267377767625d + "'", double1 == 373.00267377767625d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 214958080, (long) (-1963152018));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2178110098L + "'", long2 == 2178110098L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 3822760448662243961L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray15 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray22 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray22);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.0d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray33);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (116.94 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.54402111088937d + "'", double23 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 218.05962487356527d + "'", double24 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 210933207 + "'", int37 == 210933207);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2.0f, 6.3242605952174955d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number10 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.54402111088937d + "'", number8.equals(10.54402111088937d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-42L) + "'", number9.equals((-42L)));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.54402111088937d + "'", number10.equals(10.54402111088937d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray18 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray13);
        int[] intArray21 = new int[] {};
        int[] intArray22 = null;
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray22);
        int[] intArray27 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray31 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray36 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray40 = new int[] { 36, (byte) 0 };
        int[] intArray45 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int[] intArray52 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray31);
        int[] intArray58 = new int[] { 36, (byte) 0 };
        int[] intArray63 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray70 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray70);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray70);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1072693248 + "'", int19 == 1072693248);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1072693248 + "'", int37 == 1072693248);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 27 + "'", int46 == 27);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-669822263) + "'", int53 == (-669822263));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1661992928 + "'", int54 == 1661992928);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 22.11334438749598d + "'", double55 == 22.11334438749598d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 27 + "'", int64 == 27);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-669822263) + "'", int71 == (-669822263));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1661992961 + "'", int72 == 1661992961);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1661992928 + "'", int74 == 1661992928);
    }
}

