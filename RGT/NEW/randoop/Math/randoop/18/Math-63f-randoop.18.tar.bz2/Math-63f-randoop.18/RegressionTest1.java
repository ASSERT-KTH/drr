import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        java.lang.Number number11 = nonMonotonousSequenceException7.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-11L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(36, 1661992928);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992964 + "'", int2 == 1661992964);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.acos(116.940155635265d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(11, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1661992964);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.66199296E9f + "'", float1 == 1.66199296E9f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.pow((-405900.0d), 218.05962487356527d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-31.17011361997944d), (-0.02078553416344985d), 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        double[] doubleArray14 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray21 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 0.0d);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        try {
            double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.54402111088937d + "'", double22 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection21, true);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray60 = new double[] {};
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int2 = org.apache.commons.math.util.FastMath.min(99, (-405900));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-405900) + "'", int2 == (-405900));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(11L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 36L, 1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1418058948, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.MathUtils.sign(10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 100, (int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 110.0f + "'", float3 == 110.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1963152018), 1301095401);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9075712110370514d, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4844222297453329d + "'", double1 == 1.4844222297453329d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-41));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5628821893349888E-18d + "'", double1 == 1.5628821893349888E-18d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray8 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray15 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray8);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 2131430883);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.54402111088937d + "'", double16 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.004425697988050785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06652591967083796d + "'", double1 == 0.06652591967083796d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.3291424275971494E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray18 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray22 = new int[] { 36, (byte) 0 };
        int[] intArray27 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray27);
        int[] intArray34 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray34);
        int[] intArray40 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray44 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray49 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray53 = new int[] { 36, (byte) 0 };
        int[] intArray58 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray58);
        int[] intArray65 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray44);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray13);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1072693248 + "'", int19 == 1072693248);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 27 + "'", int28 == 27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-669822263) + "'", int35 == (-669822263));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1661992928 + "'", int36 == 1661992928);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1072693248 + "'", int50 == 1072693248);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 27 + "'", int59 == 27);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-669822263) + "'", int66 == (-669822263));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1661992928 + "'", int67 == 1661992928);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 22.11334438749598d + "'", double68 == 22.11334438749598d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray69 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 0.0d);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.54402111088937d + "'", double70 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100L, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.6900760708753189d, 0.17453292519943295d, 2.1556157735575978E15d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 263.856815596594d + "'", double1 == 263.856815596594d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-4059));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 35.0f, 0.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-11L), (long) (-4059));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 1, (-672517978019777775L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-65), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6305L + "'", long2 == 6305L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-41), 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1107) + "'", int2 == (-1107));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1931908993L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.07492164711474d + "'", double1 == 22.07492164711474d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 3.948148009134034E13d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100, (-0.02078553416344985d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int2 = org.apache.commons.math.util.FastMath.max((-1107), 1301095401);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1301095401 + "'", int2 == 1301095401);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(6.8588484959636515d, (double) 1.25994627E14f, 3.469446951953615E-18d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray10 = null;
        double[] doubleArray12 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray19 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.0d);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray22);
        double[] doubleArray28 = new double[] { (byte) 100, '#', '#', '#' };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray31 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray38 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.0d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray41);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.54402111088937d + "'", double20 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 116.940155635265d + "'", double29 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.54402111088937d + "'", double39 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 116.940155635265d + "'", double42 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.sin(116.940155635265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6451560091111291d) + "'", double1 == (-0.6451560091111291d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1072693248, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1301095401);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.454727522118143E10d + "'", double1 == 7.454727522118143E10d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 27, 1931908993L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.772465531683503d + "'", double1 == 0.772465531683503d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1301095401L, (int) '4', 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray19 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException36.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection38, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection38, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection38, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection38, false);
        double[] doubleArray49 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException62.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection68, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection68, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection68, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection68, false);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray49);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (11 >= 11)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 11.54402111088937d + "'", double78 == 11.54402111088937d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1072693248);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 11.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray19 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException36.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection38, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection38, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection38, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection38, false);
        double[] doubleArray49 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException62.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection68, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection68, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection68, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection68, false);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray49);
        double[] doubleArray79 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray86 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray79, doubleArray86);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, 0.0d);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10.54402111088937d + "'", double87 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 39.99627207622075d + "'", double91 == 39.99627207622075d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-65), (double) 1.66199296E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-65.0d) + "'", double2 == (-65.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-669822263), (long) 1661992964);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2331815227L) + "'", long2 == (-2331815227L));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.454727522118143E10d, (double) 1301095401);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 125994627894135L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-405900));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-16L), (-672517978019777775L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-672517978019777791L) + "'", long2 == (-672517978019777791L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1963152018L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.397817190913194d + "'", double1 == 21.397817190913194d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, 1661992960);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 0L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) -1, (-1107));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1107 + "'", int2 == 1107);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1931908993, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.log10(263.856815596594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4213683167726168d + "'", double1 == 2.4213683167726168d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.3708024742879816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray8 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray13 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray13);
        int[] intArray17 = new int[] { 36, (byte) 0 };
        int[] intArray22 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray22);
        int[] intArray29 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        try {
            int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1072693248 + "'", int14 == 1072693248);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 27 + "'", int23 == 27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-669822263) + "'", int30 == (-669822263));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1661992928 + "'", int31 == 1661992928);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 22.11334438749598d + "'", double32 == 22.11334438749598d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-2331815227L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.33181523E9d) + "'", double2 == (-2.33181523E9d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.8588484959636515d, (double) 36L, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.MathUtils.sign(21.231283297510288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 2131430883, (long) 1931908993);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4063339876L + "'", long2 == 4063339876L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10, (-4059));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-40590) + "'", int2 == (-40590));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1931908993, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.8464165146410991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 187.41829408123718d + "'", double1 == 187.41829408123718d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9961652815068444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.6451560091111291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-10.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999546000702375d) + "'", double1 == (-0.9999546000702375d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-672517978019777791L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1107);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1963152018L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.963152018E9d + "'", double1 == 1.963152018E9d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.sin(22.11334438749598d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12189193841656394d) + "'", double1 == (-0.12189193841656394d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1107));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9165577160638908d) + "'", double1 == (-0.9165577160638908d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.8464165146410991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8464165146410993d + "'", double1 == 1.8464165146410993d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.8533353190484737d), (double) (-10.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8533353190484737d) + "'", double2 == (-0.8533353190484737d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1418058948, (-2331815227L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-672517978019777775L), (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.cosh(27.28991719712775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5549250982832153E11d + "'", double1 == 3.5549250982832153E11d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9526653195309732d + "'", double1 == 0.9526653195309732d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-4059));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.951677119795225d) + "'", double1 == (-15.951677119795225d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        long long1 = org.apache.commons.math.util.FastMath.round(187.41829408123718d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 187L + "'", long1 == 187L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1931908993);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        java.lang.Class<?> wildcardClass78 = doubleArray5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection79, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1072693212L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.619275968248924E151d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', (-1252.1354469888358d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1072693248, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        java.lang.Class<?> wildcardClass16 = nonMonotonousSequenceException14.getClass();
        java.lang.Number number17 = nonMonotonousSequenceException14.getArgument();
        java.lang.String str18 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1963152018) + "'", number15.equals((-1963152018)));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-0.5440211108893698d) + "'", number17.equals((-0.5440211108893698d)));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1931908993L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = org.apache.commons.math.util.FastMath.max((-65), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35.0f, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NaN, (-405900.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.6929693744344998d, (java.lang.Number) 0.027244409944047088d, 27, orderDirection3, false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0787619161000124d) + "'", double1 == (-1.0787619161000124d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2131430912);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.5707963262855118d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20787957645665261d + "'", double1 == 0.20787957645665261d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.sin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.17453292519943295d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.log1p(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306943617238488d + "'", double1 == 9.306943617238488d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) (short) 0);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 887503681 + "'", int13 == 887503681);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.008508692317092035d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long1 = org.apache.commons.math.util.FastMath.round(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float2 = org.apache.commons.math.util.MathUtils.round(110.0f, 99);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-10.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.FastMath.pow(21.397817190913194d, (double) 1301095401);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-669822263), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.220446049250313E-16d, 11.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.06652753112764034d) + "'", double2 == (-0.06652753112764034d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1661992960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1418058948, 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963193593657d + "'", double2 == 1.5707963193593657d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1963152018L), (float) (-669822263));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.6982227E8f) + "'", float2 == (-6.6982227E8f));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = org.apache.commons.math.util.FastMath.abs(887503681);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 887503681 + "'", int1 == 887503681);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.4213683167726168d, 187.41829408123718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.421368316772617d + "'", double2 == 2.421368316772617d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-42L), (-65), 887503681);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1107));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1107 + "'", int1 == 1107);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-41), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4100L) + "'", long2 == (-4100L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.4129651365067377d, 116.940155635265d, 0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1301095401, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.004425697988050785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.724300159037486E-5d + "'", double1 == 7.724300159037486E-5d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray4 = new double[] { (byte) 100, '#', '#', '#' };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.0d);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 116.940155635265d + "'", double5 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 116.940155635265d + "'", double18 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(27, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-27) + "'", int2 == (-27));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray13 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray20 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 0.0d);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray20);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.17453292519943295d);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = nonMonotonousSequenceException37.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection39, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection39, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (0.045 > 0.004)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.54402111088937d + "'", double21 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1661992961, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1068263745867423E39d + "'", double2 == 2.1068263745867423E39d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-672517978019777791L), (double) (-1107));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.7251797801977779E17d) + "'", double2 == (-6.7251797801977779E17d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-41));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        try {
            double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-10.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-10L) + "'", long1 == (-10L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395465E155d + "'", double1 == 9.332621544395465E155d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', 1149987972776840193L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1149987972776840228L + "'", long2 == 1149987972776840228L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        long long1 = org.apache.commons.math.util.FastMath.round(1.963152018E9d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1963152018L + "'", long1 == 1963152018L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(27.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 32, 0.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.17632698070846498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.393542617697865d + "'", double1 == 1.393542617697865d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8464165146410991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2233617218518336d + "'", double1 == 1.2233617218518336d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0d, 2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1556157735575975E15d + "'", double2 == 2.1556157735575975E15d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.12189193841656394d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12250105341831324d) + "'", double1 == (-0.12250105341831324d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.12250105341831324d), (-1.0787619161000124d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger14);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException7.getDirection();
        java.lang.Number number22 = nonMonotonousSequenceException7.getPrevious();
        java.lang.Number number23 = nonMonotonousSequenceException7.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.7615941559557649d + "'", number22.equals(0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.7615941559557649d + "'", number23.equals(0.7615941559557649d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-4059));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1072693212L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.48658552415009d) + "'", double1 == (-21.48658552415009d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 36L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1301095401, 4.3291424275971494E24d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 4.806217383955856E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.806217383955856E-6d + "'", double2 == 4.806217383955856E-6d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 1, 1149987972776840228L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.3708024742879816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6089355255591363d + "'", double1 == 0.6089355255591363d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.015640944658330335d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.729859824100839E-4d) + "'", double1 == (-2.729859824100839E-4d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-405900));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double2 = org.apache.commons.math.util.FastMath.atan2(187.41829408123718d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.util.FastMath.min(97.0d, 11.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.9165577160638908d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7418880614464484d) + "'", double1 == (-0.7418880614464484d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.930380657631324E-32d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number26 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number27 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException19.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) -1 + "'", number26.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) -1 + "'", number27.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) -1 + "'", number28.equals((byte) -1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-4059), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2599462723584112E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-99) + "'", int2 == (-99));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-10L), (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1661992964);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.9999999999999999d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1418058948, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1418058948L + "'", long2 == 1418058948L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1072693248, 1418058948);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1661992928, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86423632256L + "'", long2 == 86423632256L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.0d, 9.332621544395465E155d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-16L), (long) (-65));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1040L + "'", long2 == 1040L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection22, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection22, false);
        double[] doubleArray33 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException46.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection52, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection52, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection52, false);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray33);
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1410065408, 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065435 + "'", int2 == 1410065435);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray6 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray11 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray17 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray22 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray26 = new int[] { 36, (byte) 0 };
        int[] intArray31 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray38 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray38);
        int[] intArray44 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray48 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray53 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray53);
        int[] intArray57 = new int[] { 36, (byte) 0 };
        int[] intArray62 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray62);
        int[] intArray69 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray48);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray48);
        java.lang.Class<?> wildcardClass74 = intArray48.getClass();
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray48);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1072693248 + "'", int12 == 1072693248);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1072693248 + "'", int23 == 1072693248);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 27 + "'", int32 == 27);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-669822263) + "'", int39 == (-669822263));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1661992928 + "'", int40 == 1661992928);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1072693248 + "'", int54 == 1072693248);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 27 + "'", int63 == 27);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-669822263) + "'", int70 == (-669822263));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1661992928 + "'", int71 == 1661992928);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 22.11334438749598d + "'", double72 == 22.11334438749598d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1661992928, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992927 + "'", int2 == 1661992927);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.55753862700634d + "'", double1 == 64.55753862700634d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long2 = org.apache.commons.math.util.FastMath.min(26L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.17632698070846498d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray19 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException36.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection38, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection38, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection38, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection38, false);
        double[] doubleArray49 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException62.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection68, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection68, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection68, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection68, false);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray49);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 11.54402111088937d + "'", double78 == 11.54402111088937d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-6.7251797801977779E17d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.apache.commons.math.util.FastMath.max(2131430883, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2131430883 + "'", int2 == 2131430883);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5399929762484854E-5d + "'", double1 == 4.5399929762484854E-5d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1963152018), (-669822231L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1963152018L) + "'", long2 == (-1963152018L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 12);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 2131430883);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.rint(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, 1661992960);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9165215479156338d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-65.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.474446222051669E27d + "'", double1 == 8.474446222051669E27d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        try {
            int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long1 = org.apache.commons.math.util.FastMath.round((-175.65064452618424d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-176L) + "'", long1 == (-176L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (-27));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-27) + "'", int2 == (-27));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-21.48658552415009d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.7800704536839147d) + "'", double1 == (-2.7800704536839147d));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(15.556349186104045d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1418058948, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0674691200256348d + "'", double2 == 1.0674691200256348d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 187L, (-21.48658552415009d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 186.99999999999997d + "'", double2 == 186.99999999999997d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1301095401, 887503681);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(64.55753862700634d, (double) (-27));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(263.856815596594d, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03696730494863232d) + "'", double2 == (-0.03696730494863232d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.5707963267948966d), (-669822263));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.768723683405125E214d) + "'", double2 == (-6.768723683405125E214d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.015269573507533d + "'", double1 == 1.015269573507533d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 1, 52, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-405900), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 4063339876L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.49993310426429d + "'", double1 == 4.49993310426429d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        boolean boolean16 = nonMonotonousSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1963152018) + "'", number15.equals((-1963152018)));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1661992961);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.231283298111975d + "'", double1 == 21.231283298111975d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3708024742879816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9320368583578248d + "'", double1 == 0.9320368583578248d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray9 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray9);
        int[] intArray13 = new int[] { 36, (byte) 0 };
        int[] intArray18 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray25 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray25);
        try {
            double double28 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1072693248 + "'", int10 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 27 + "'", int19 == 27);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-669822263) + "'", int26 == (-669822263));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1661992928 + "'", int27 == 1661992928);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 0, 1149987972776840193L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.474446222051669E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.474446222051669E27d + "'", double1 == 8.474446222051669E27d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5384786408469177d + "'", double1 == 0.5384786408469177d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (-40590));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1661992964, 1931908993L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3593901957L + "'", long2 == 3593901957L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.0d, (double) (-10L), 6.8588484959636515d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.String str21 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        long long2 = org.apache.commons.math.util.FastMath.max(3593901957L, (-669822231L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3593901957L + "'", long2 == 3593901957L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, 887503681);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 887503681 + "'", int2 == 887503681);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1), 100, 887503681);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, (-99));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1418058948);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-40590));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection22, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection22, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        java.lang.Class<?> wildcardClass78 = doubleArray5.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0.996)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(wildcardClass78);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1661992928);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.706984600967196d + "'", double1 == 0.706984600967196d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.421368316772617d, (java.lang.Number) 1184.521805548193d, (int) '4');
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(27, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2700 + "'", int2 == 2700);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1418058948, (-176L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1418058772L + "'", long2 == 1418058772L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5143952585235492d + "'", double1 == 0.5143952585235492d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.554662817565385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.47371683219511d + "'", double1 == 17.47371683219511d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-669822263), (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-669822273L) + "'", long2 == (-669822273L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.String str21 = nonMonotonousSequenceException19.toString();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException19.getSuppressed();
        int int23 = nonMonotonousSequenceException19.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (-1 > 0)"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1661992961, (double) (-176L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-176.0d) + "'", double2 == (-176.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-176L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int1 = org.apache.commons.math.util.FastMath.abs(36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.FastMath.max(26.0d, (-37.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.0d + "'", double2 == 26.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray69 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 0.0d);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray72);
        double[] doubleArray74 = null;
        double[] doubleArray76 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray83 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray76, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, 0.0d);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray86);
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray72, doubleArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.54402111088937d + "'", double70 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 10.54402111088937d + "'", double84 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean21 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str26 = nonMonotonousSequenceException25.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException40.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = nonMonotonousSequenceException44.getDirection();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException44);
        nonMonotonousSequenceException25.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.49993310426429d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1107));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.552713678800501E-15d, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5527136788005016E-16d + "'", double2 == 3.5527136788005016E-16d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1418058772L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1123.4784426498145d + "'", double1 == 1123.4784426498145d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1418058948);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1418058948L + "'", long1 == 1418058948L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        float float1 = org.apache.commons.math.util.FastMath.abs(11.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5756631887840653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1703206519040228d + "'", double1 == 1.1703206519040228d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.3291424275971494E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9371005412963566d + "'", double1 == 0.9371005412963566d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException7.getDirection();
        java.lang.String str22 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (0.762 >= 0)"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52, (float) (-40590));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-40590.0f) + "'", float2 == (-40590.0f));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3628800.0d, 1931908993);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.1328169501319585E-32d) + "'", double2 == (-2.1328169501319585E-32d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(1.66199296E9f, (-99), (-1107));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray12 = new int[] { 36, (byte) 0 };
        int[] intArray17 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        int[] intArray24 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray24);
        int[] intArray29 = new int[] { 36, (byte) 0 };
        int[] intArray34 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray34);
        int[] intArray41 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray41);
        try {
            int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 27 + "'", int18 == 27);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-669822263) + "'", int25 == (-669822263));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1661992928 + "'", int26 == 1661992928);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 27 + "'", int35 == 27);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-669822263) + "'", int42 == (-669822263));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.06652591967083796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06642803824623132d + "'", double1 == 0.06642803824623132d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9440892412430648d + "'", double1 == 0.9440892412430648d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-6.6982227E8f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1963152018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7970747335500249d + "'", double1 == 0.7970747335500249d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.FastMath.min(1301095401, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1661992960, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992908 + "'", int2 == 1661992908);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.665284718471351d + "'", double1 == 7.665284718471351d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1301095401);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 263.856815596594d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1107), 210933207);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-210934314) + "'", int2 == (-210934314));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800.0d, (java.lang.Number) 10.0d, (int) (short) 1, orderDirection12, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException29.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Number number37 = nonMonotonousSequenceException33.getArgument();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException33.getSuppressed();
        java.lang.Throwable[] throwableArray40 = nonMonotonousSequenceException33.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray40);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection12, true);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 10 and 11 are not strictly increasing (-1,963,152,018 >= -0.544)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1963152018) + "'", number16.equals((-1963152018)));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 116618.90399762259d + "'", double1 == 116618.90399762259d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        boolean boolean26 = nonMonotonousSequenceException24.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.053671212772351E-8d + "'", double1 == 1.053671212772351E-8d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-65), 1661992964);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1963152018), 1410065435);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 100, (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int2 = org.apache.commons.math.util.FastMath.max(1931908993, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1931908993 + "'", int2 == 1931908993);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2599462723584112E14d, (-175.65064452618424d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267962908d + "'", double2 == 1.5707963267962908d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-672517978019777775L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-876128.819252256d) + "'", double1 == (-876128.819252256d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0.996)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.844281201823303d + "'", double19 == 28.844281201823303d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(263.856815596594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9522212262964344E114d + "'", double1 == 1.9522212262964344E114d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5804096620472413d, (-0.009999666686665238d), (double) 1040L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (-405900));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (-669822263));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-40590.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.275957614183426E-12d + "'", double1 == 7.275957614183426E-12d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-42L), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-42.0d) + "'", double2 == (-42.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray28 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.0d);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray43 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray46);
        double[] doubleArray49 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray56 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray56);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 1.1447298858494002d);
        double[] doubleArray63 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray70 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = nonMonotonousSequenceException75.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection76, false);
        try {
            double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.54402111088937d + "'", double29 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 116.940155635265d + "'", double32 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.54402111088937d + "'", double57 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 218.05962487356527d + "'", double58 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.54402111088937d + "'", double71 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2132, 86423632256L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-27));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-26.04220809005457d), 0.6089355255591363d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.547417948824773d) + "'", double2 == (-1.547417948824773d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection18, true);
        java.lang.Number number25 = nonMonotonousSequenceException24.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException24.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) 10 + "'", number25.equals((short) 10));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray25 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray38 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.0d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray41);
        double[] doubleArray47 = new double[] { (byte) 100, '#', '#', '#' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray50 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray57 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 0.0d);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray60);
        double[] doubleArray63 = null;
        double[] doubleArray65 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray72 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 0.0d);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray75);
        double[] doubleArray78 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray85 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray75, doubleArray85);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (-0.009999666686665238d));
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray85);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray85);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray25);
        int int93 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.54402111088937d + "'", double26 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.54402111088937d + "'", double39 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 116.940155635265d + "'", double48 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 10.54402111088937d + "'", double58 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 116.940155635265d + "'", double61 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.54402111088937d + "'", double73 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 10.54402111088937d + "'", double86 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 218.05962487356527d + "'", double87 == 218.05962487356527d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 175.7189355621376d + "'", double92 == 175.7189355621376d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 210933207 + "'", int93 == 210933207);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (-4059));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9526653195309732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.592610594285313d + "'", double1 == 2.592610594285313d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1107));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1107.0f + "'", float1 == 1107.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 35, (long) 2700);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2665L) + "'", long2 == (-2665L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) (-102083904936L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.02083903E11f) + "'", float2 == (-1.02083903E11f));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-6.6982227E8f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-669822272L) + "'", long1 == (-669822272L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double[] doubleArray23 = new double[] { (byte) 100, '#', '#', '#' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray26 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray33 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.0d);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray36);
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 116.940155635265d + "'", double24 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.54402111088937d + "'", double34 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 116.940155635265d + "'", double37 == 116.940155635265d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 27, 6305L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(12, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(42L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5756631887840653d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5756631887840654d + "'", double2 == 0.5756631887840654d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9896835559265444d + "'", double1 == 0.9896835559265444d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-41), (long) (-27));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.50515463917526d + "'", double1 == 48.50515463917526d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9961652815068444d, 1.8464165146410993d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray9 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 100, '#', '#', '#' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        try {
            double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.54402111088937d + "'", double10 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 116.940155635265d + "'", double19 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1931908993 + "'", int20 == 1931908993);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1072693248, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693248 + "'", int2 == 1072693248);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1184.521805548193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.673805568484003d + "'", double1 == 20.673805568484003d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.cosh(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.032908758547247E67d + "'", double1 == 4.032908758547247E67d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1410065408, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065508 + "'", int2 == 1410065508);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.03696730494863232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03697572533064276d) + "'", double1 == (-0.03697572533064276d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.FastMath.atan2(6.8588484959636515d, 4.49993310426429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9901608690402786d + "'", double2 == 0.9901608690402786d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1661992908, (float) (-2331815227L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.33181517E9f) + "'", float2 == (-2.33181517E9f));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double2 = org.apache.commons.math.util.FastMath.max(2005.3522829578812d, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.072693248E9d + "'", double2 == 1.072693248E9d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.930380657631324E-32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 0, (-405900));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray17 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray22 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray26 = new int[] { 36, (byte) 0 };
        int[] intArray31 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray38 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray44 = new int[] { 36, (byte) 0 };
        int[] intArray49 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray49);
        int[] intArray56 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray56);
        try {
            int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1072693248 + "'", int23 == 1072693248);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 27 + "'", int32 == 27);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-669822263) + "'", int39 == (-669822263));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1661992928 + "'", int40 == 1661992928);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 22.11334438749598d + "'", double41 == 22.11334438749598d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 27 + "'", int50 == 27);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-669822263) + "'", int57 == (-669822263));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1661992928 + "'", int58 == 1661992928);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double2 = org.apache.commons.math.util.FastMath.max(0.20787957645665261d, (double) (-42L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20787957645665261d + "'", double2 == 0.20787957645665261d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-4100L), (long) (-65));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4165L) + "'", long2 == (-4165L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(35, 1073741824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741859 + "'", int2 == 1073741859);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1301095401L, (double) (-1107));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1107.0d) + "'", double2 == (-1107.0d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        long long1 = org.apache.commons.math.util.FastMath.round(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(39.99627207622075d, 2131430912, (-669822263));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.20787957645665261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0216848814370751d + "'", double1 == 1.0216848814370751d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.3291424275971494E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1301095401L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1091.6993387601956d + "'", double1 == 1091.6993387601956d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1661992960, (double) 36L, 99);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2131430912, 45L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 125994627894135L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5879663704475468d + "'", double1 == 0.5879663704475468d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1073741824, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.4795239416637515E91d + "'", double2 == 5.4795239416637515E91d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.0333147966386297E40d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (2,870,616,141,723,300,400,000,000,000,000,000,000,000 >= 285,991,470,354,747,100,000,000,000,000,000,000,000)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.7970747335500249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5861601948888234d + "'", double1 == 0.5861601948888234d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray26 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 0.0d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray29);
        double[] doubleArray35 = new double[] { (byte) 100, '#', '#', '#' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray38 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray45 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray48);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray60 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double[] doubleArray66 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray73 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray73);
        try {
            double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, Double.NaN);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.54402111088937d + "'", double27 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 116.940155635265d + "'", double36 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.54402111088937d + "'", double46 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 116.940155635265d + "'", double49 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.54402111088937d + "'", double61 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.54402111088937d + "'", double74 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 218.05962487356527d + "'", double75 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 2700);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-21.48658552415009d), (double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1963152018), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1963152018L + "'", long2 == 1963152018L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8813735870195429d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double2 = org.apache.commons.math.util.FastMath.pow(27.28991719712775d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03664357032586561d + "'", double2 == 0.03664357032586561d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.03696730494863232d), 3.948148009134034E13d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(10L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.592610594285313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5926105942853135d + "'", double1 == 2.5926105942853135d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection18, false);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException22.getPrevious();
        boolean boolean30 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36L, (java.lang.Number) 17.502307845873887d, (int) (short) -1, orderDirection31, true);
        boolean boolean34 = nonMonotonousSequenceException33.getStrict();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException33.getSuppressed();
        java.lang.Number number36 = nonMonotonousSequenceException33.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) -1 + "'", number29.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 17.502307845873887d + "'", number36.equals(17.502307845873887d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.0333147966386297E40d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0.996)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5607966601082315d, (java.lang.Number) 3.141592653589793d, 36);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.5607966601082315d + "'", number4.equals(1.5607966601082315d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.232920103324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1073741859, (double) 1931908993);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.028245997998335d + "'", double2 == 1.028245997998335d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1149987972776840193L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.3708024742879816d, (-1963152018), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-2331815227L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', 1963152018L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1963152018L + "'", long2 == 1963152018L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.exp(35.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.3112315471151645E15d + "'", double1 == 4.3112315471151645E15d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-6.768723683405125E214d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-65), (long) (-669822263));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-669822328L) + "'", long2 == (-669822328L));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-669822328L), Double.NEGATIVE_INFINITY, 2700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.1068263745867423E39d, (double) 6305L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-65));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1963152018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.465190328815662E-32d, 5.4795239416637515E91d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.9023762589785425d) + "'", double2 == (-2.9023762589785425d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 36L, 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.284467373628997d) + "'", double2 == (-9.284467373628997d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, (double) 1418058948);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection15, false);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number26 = nonMonotonousSequenceException19.getPrevious();
        boolean boolean27 = nonMonotonousSequenceException19.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException19.getDirection();
        java.lang.Class<?> wildcardClass29 = orderDirection28.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) -1 + "'", number26.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, 2132);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 10.54402111088937d, (int) '#');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (10.544 >= -42)"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.248291097914389d, (double) (-4100L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4116413837030013d + "'", double1 == 1.4116413837030013d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.552713678800501E-15d, 28.844281201823303d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.10104611264248807d) + "'", double2 == (-0.10104611264248807d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10L, 6305L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.2233617218518336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6565195560162134d + "'", double1 == 0.6565195560162134d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double[] doubleArray1 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray8 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray13 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray20 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 0.0d);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray20);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.17453292519943295d);
        double[] doubleArray27 = null;
        try {
            double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.54402111088937d + "'", double9 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.54402111088937d + "'", double21 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5756631887840654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6134149713761078d + "'", double1 == 0.6134149713761078d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0216848814370751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009316966879073124d + "'", double1 == 0.009316966879073124d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5756631887840653d, 0.027244409944047088d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.027244409944047088d + "'", double2 == 0.027244409944047088d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray13 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray18 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray13);
        int[] intArray21 = new int[] {};
        int[] intArray22 = null;
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray22);
        int[] intArray27 = new int[] { 10, (short) 1, (short) 1 };
        int[] intArray31 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray36 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray40 = new int[] { 36, (byte) 0 };
        int[] intArray45 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int[] intArray52 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray31);
        int[] intArray58 = new int[] { 36, (byte) 0 };
        int[] intArray63 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray70 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray70);
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1072693248 + "'", int19 == 1072693248);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1072693248 + "'", int37 == 1072693248);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 27 + "'", int46 == 27);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-669822263) + "'", int53 == (-669822263));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1661992928 + "'", int54 == 1661992928);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 22.11334438749598d + "'", double55 == 22.11334438749598d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 27 + "'", int64 == 27);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-669822263) + "'", int71 == (-669822263));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1661992961 + "'", int72 == 1661992961);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0333147966386297E40d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-405900), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.1909233824906624d), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1909233824906622d) + "'", double2 == (-1.1909233824906622d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double2 = org.apache.commons.math.util.FastMath.max((-2.7800704536839147d), (-176.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7800704536839147d) + "'", double2 == (-2.7800704536839147d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.131564088471395d, (double) 1410065435, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double[] doubleArray2 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection21, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection21, false);
        double[] doubleArray32 = new double[] { 11, 11L };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 0.7615941559557649d, 11);
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException49.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) (-1963152018), 11, orderDirection51, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (byte) -1, (int) (byte) -1, orderDirection51, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) (short) 10, (int) (byte) 1, orderDirection51, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection51, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (byte) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection63, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.554662817565385d, (java.lang.Number) (byte) 1, (-405900), orderDirection3, true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 2131430883);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray20 = null;
        double[] doubleArray22 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray29 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray32);
        double[] doubleArray38 = new double[] { (byte) 100, '#', '#', '#' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray41 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray48 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 0.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray51);
        double[] doubleArray54 = null;
        double[] doubleArray56 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray63 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 0.0d);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray66);
        double[] doubleArray69 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray76 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray76);
        double[] doubleArray81 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray88 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray81, doubleArray88);
        java.lang.Class<?> wildcardClass90 = doubleArray88.getClass();
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray88);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray88);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.844281201823303d + "'", double19 == 28.844281201823303d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10.54402111088937d + "'", double30 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 116.940155635265d + "'", double39 == 116.940155635265d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.54402111088937d + "'", double49 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 116.940155635265d + "'", double52 == 116.940155635265d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.54402111088937d + "'", double64 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10.54402111088937d + "'", double77 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 218.05962487356527d + "'", double78 == 218.05962487356527d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 10.54402111088937d + "'", double89 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 28.844281201823303d + "'", double93 == 28.844281201823303d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1661992964, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double[] doubleArray5 = new double[] { (-1.0d), 10L, 0.99627207622075d, (-1L), 27 };
        double[] doubleArray7 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray14 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray18 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray25 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        double[] doubleArray30 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray37 = new double[] { (short) 10, 116.940155635265d, (byte) 10, 116.940155635265d, 100.0f, 100 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 0.0d);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray37);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.17453292519943295d);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.54402111088937d + "'", double15 == 10.54402111088937d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.54402111088937d + "'", double26 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 10.54402111088937d + "'", double38 == 10.54402111088937d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.54402111088937d + "'", double44 == 10.54402111088937d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.706984600967196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int[] intArray3 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray8 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray12 = new int[] { 36, (byte) 0 };
        int[] intArray17 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        int[] intArray24 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray24);
        int[] intArray30 = new int[] { ' ', (byte) -1, (short) 0 };
        int[] intArray35 = new int[] { (byte) 100, (byte) 10, 1072693248, (byte) 0 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray39 = new int[] { 36, (byte) 0 };
        int[] intArray44 = new int[] { (short) 10, (byte) -1, (byte) 1, '4' };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int[] intArray51 = new int[] { 1661992960, (byte) 10, (-1), (-1963152018), '#' };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray51);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1072693248 + "'", int9 == 1072693248);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 27 + "'", int18 == 27);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-669822263) + "'", int25 == (-669822263));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1661992928 + "'", int26 == 1661992928);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1072693248 + "'", int36 == 1072693248);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 27 + "'", int45 == 27);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-669822263) + "'", int52 == (-669822263));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1661992928 + "'", int53 == 1661992928);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.661992928E9d + "'", double54 == 1.661992928E9d);
    }
}

