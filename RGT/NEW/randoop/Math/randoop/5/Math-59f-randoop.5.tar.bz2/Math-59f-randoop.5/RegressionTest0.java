import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5727423566060875d + "'", double0 == 0.5727423566060875d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean1 = mersenneTwister0.nextBoolean();
        boolean boolean2 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 10, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10.0f, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.775560745114035d + "'", double2 == 5.775560745114035d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3209711346238147d + "'", double1 == 0.3209711346238147d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.775560745114035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.090354888726294d + "'", double1 == 11.090354888726294d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.apache.commons.math.util.FastMath.abs(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.3209711346238147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32760, (java.lang.Number) 32.0d, false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.rint(11.090354888726294d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.232595164407831E-32d + "'", double1 == 1.232595164407831E-32d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double2 = org.apache.commons.math.util.FastMath.min(5.775560745114035d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.775560745114035d + "'", double2 == 5.775560745114035d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, 0.5727423566060875d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5650689658538883d + "'", double2 == 1.5650689658538883d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2490457723982544d + "'", double1 == 1.2490457723982544d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.3209711346238147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3784657903858746d + "'", double1 == 1.3784657903858746d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5727423566060875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.asin(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.477888730288475d + "'", double1 == 2.477888730288475d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.cos(5.775560745114035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8739016789872457d + "'", double1 == 0.8739016789872457d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            boolean boolean8 = dfp5.greaterThan(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.636130838093536d) + "'", double1 == (-43.636130838093536d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.log(5.775560745114035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7536353504151265d + "'", double1 == 1.7536353504151265d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7536353504151265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.012921984283177d + "'", double1 == 1.012921984283177d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5727423566060875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.81571978190556d + "'", double1 == 32.81571978190556d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 2, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            boolean boolean11 = dfp5.lessThan(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
        mersenneTwister1.setSeed((int) 'a');
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2415644752704905d) + "'", double1 == (-0.2415644752704905d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8384595794609528779L) + "'", long2 == (-8384595794609528779L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5308176396716067d + "'", double1 == 1.5308176396716067d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-43.636130838093536d));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        int int3 = mersenneTwister0.nextInt(10000);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3069 + "'", int3 == 3069);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2239800905693157d + "'", double1 == 2.2239800905693157d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.585786437626905d) + "'", double1 == (-0.585786437626905d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-7858310631209755687L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 16, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.775560745114035d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-43.636130838093536d));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.atanh(32.81571978190556d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-43.636130838093536d), (double) (-7858310631209755687L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592653589793d) + "'", double2 == (-3.141592653589793d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField2.newDfp((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K(100);
        int int20 = dfp17.log10K();
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp11, dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0889699048446033d + "'", double1 == 3.0889699048446033d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5727423566060875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45282081956497505d + "'", double1 == 0.45282081956497505d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.ceil(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 573.0d + "'", double1 == 573.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        java.lang.Throwable throwable15 = null;
        try {
            mathIllegalArgumentException13.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        java.lang.Throwable[] throwableArray19 = mathRuntimeException18.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.log10(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2041199826559248d + "'", double1 == 1.2041199826559248d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.atanh(32.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        java.lang.Object[] objArray15 = mathIllegalArgumentException13.getArguments();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField23.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable20, localizable21, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Class<?> wildcardClass32 = mathRuntimeException31.getClass();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        boolean boolean5 = mersenneTwister0.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean7 = mersenneTwister6.nextBoolean();
//        long long8 = mersenneTwister6.nextLong();
//        byte[] byteArray11 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister6.nextBytes(byteArray11);
//        mersenneTwister0.nextBytes(byteArray11);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3292454249375386225L + "'", long2 == 3292454249375386225L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 617939122365631559L + "'", long8 == 617939122365631559L);
//        org.junit.Assert.assertNotNull(byteArray11);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        int int6 = dfp5.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.ceil(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4.9E-324d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable5, localizable6, localizable7, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray9);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.0f + "'", float1 == 7.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0L, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.tan((-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2246467991473532E-16d + "'", double1 == 1.2246467991473532E-16d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.302585092994046d, (java.lang.Number) 25, false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4058876178102596974L) + "'", long2 == (-4058876178102596974L));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2053677732) + "'", int4 == (-2053677732));
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathRuntimeException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.275957614183426E-12d + "'", double1 == 7.275957614183426E-12d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2053677732));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0536777E9f + "'", float1 == 2.0536777E9f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2.0536777E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.176670644609509E11d + "'", double1 == 1.176670644609509E11d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        double[] doubleArray4 = dfp3.toSplitDouble();
        boolean boolean6 = dfp3.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.950000000000001d + "'", double1 == 4.950000000000001d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.950000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.129055617990628d) + "'", double1 == (-4.129055617990628d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        double double15 = dfp14.toDouble();
        boolean boolean16 = dfp14.isNaN();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.dotrap(0, "org.apache.commons.math.exception.MathRuntimeException: ", dfp11, dfp14);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.4142135623730951d + "'", double15 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2053677732));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.606024476657116d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8219189826342299d + "'", double1 == 0.8219189826342299d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.add(dfp25);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-4.129055617990628d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8219189826342299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8219189826342299d + "'", double1 == 0.8219189826342299d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-8384595794609528779L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getOne();
        boolean boolean22 = dfp10.unequal(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
        mersenneTwister1.setSeed((long) (byte) 2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getOne();
        boolean boolean22 = dfp10.unequal(dfp20);
        boolean boolean23 = dfp10.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getZero();
        int int22 = dfp21.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.ceil();
        boolean boolean32 = dfp21.unequal(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp10.multiply(dfp21);
        boolean boolean34 = dfp10.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 25 + "'", int22 == 25);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.9216248644249491d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5997098309518338d) + "'", double1 == (-1.5997098309518338d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20787957635076193d + "'", double1 == 0.20787957635076193d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2, (float) (-32767));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-32767.0f) + "'", float2 == (-32767.0f));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        int[] intArray3 = new int[] { (short) 1, 16, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean6 = mersenneTwister5.nextBoolean();
//        long long7 = mersenneTwister5.nextLong();
//        boolean boolean8 = mersenneTwister5.nextBoolean();
//        int[] intArray11 = new int[] { (short) 1, 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
//        mersenneTwister5.setSeed(intArray11);
//        mersenneTwister4.setSeed(intArray11);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5849931669921551489L + "'", long7 == 5849931669921551489L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance((long) (-32767));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int5 = mersenneTwister0.nextInt(9);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1545849344166356650L + "'", long2 == 1545849344166356650L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-338813211));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-338813211L) + "'", long2 == (-338813211L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 371869261753058540L, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32768);
        mersenneTwister1.setSeed(7201608355205992341L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.floor(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) -1, (double) 25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        java.lang.String str8 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.divide(dfp14);
        double[] doubleArray18 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NaN" + "'", str8.equals("NaN"));
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3069);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-103355408));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.03355408E8d) + "'", double1 == (-1.03355408E8d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 0, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.add(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField14.newDfp((int) '#');
        int int22 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField25.setRoundingMode(roundingMode28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        boolean boolean33 = dfp32.isNaN();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField25.newDfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField25.getOne();
        boolean boolean36 = dfp23.unequal(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp11.divide(dfp23);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9440892412430648d) + "'", double1 == (-0.9440892412430648d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException10.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField8.setRoundingMode(roundingMode11);
        dfpField1.setRoundingMode(roundingMode11);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.477888730288475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9860132971832694d + "'", double1 == 0.9860132971832694d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 5958733889552323610L, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.9587338895523236E18d + "'", double2 == 5.9587338895523236E18d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 7201608355205992341L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2016083552059924E18d + "'", double1 == 7.2016083552059924E18d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-3446227290794567713L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1510478.8170271718d) + "'", double1 == (-1510478.8170271718d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-338813211));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.4161468365471424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.404985220652412d) + "'", double1 == (-0.404985220652412d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.5997098309518338d), 6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2453389241428091d) + "'", double2 == (-0.2453389241428091d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        boolean boolean11 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            boolean boolean13 = dfp8.lessThan(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.cos((-4.129055617990628d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5508091201419623d) + "'", double1 == (-0.5508091201419623d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.7536353504151265d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5508091201419623d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154129689188959d + "'", double1 == 2.154129689188959d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.9440892412430648d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        double double10 = dfp9.toDouble();
        double[] doubleArray11 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-338813211));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        boolean boolean6 = dfp5.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        double[] doubleArray6 = dfp5.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray4);
        java.lang.String str6 = mathRuntimeException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathRuntimeException5.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str6.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.2490457723982544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int5 = mersenneTwister0.nextInt();
//        double double6 = mersenneTwister0.nextGaussian();
//        double double7 = mersenneTwister0.nextGaussian();
//        boolean boolean8 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1448570770493371401L + "'", long2 == 1448570770493371401L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1451588289 + "'", int5 == 1451588289);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.545769519284294d + "'", double6 == 0.545769519284294d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.13941728087061653d) + "'", double7 == (-0.13941728087061653d));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.606024476657116d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.606024476657116d + "'", double1 == 0.606024476657116d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-4058876178102596974L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3255647457146867E20d) + "'", double1 == (-2.3255647457146867E20d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 7201608355205992341L);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        boolean boolean10 = dfp8.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp11, dfp22);
        int int25 = dfp22.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean1 = mersenneTwister0.nextBoolean();
        int int3 = mersenneTwister0.nextInt((int) (byte) 3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.232595164407831E-32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 7201608355205992341L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9461339261552633d + "'", double1 == 0.9461339261552633d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (short) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1054400403);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1420149962043422d + "'", double1 == 1.1420149962043422d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp2.multiply(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.606024476657116d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        boolean boolean20 = dfp9.lessThan(dfp16);
        boolean boolean21 = dfp9.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int5 = mersenneTwister0.nextInt();
//        double double6 = mersenneTwister0.nextGaussian();
//        int int7 = mersenneTwister0.nextInt();
//        try {
//            int int9 = mersenneTwister0.nextInt((-2053677732));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2,053,677,732 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4958966068551975410L) + "'", long2 == (-4958966068551975410L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1548631169 + "'", int5 == 1548631169);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.2598280049790196d) + "'", double6 == (-0.2598280049790196d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1522460085) + "'", int7 == (-1522460085));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1601595096);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1601595136 + "'", int1 == 1601595136);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException13.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1601595096, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1601595096L + "'", long2 == 1601595096L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        boolean boolean4 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getTwo();
        int int6 = dfp2.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0.0f, (double) 1448570770493371401L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0797821797783358d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4715204612359751d + "'", double1 == 0.4715204612359751d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32760, (java.lang.Number) (byte) 2, false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField9.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException5, localizable6, localizable7, (java.lang.Object[]) dfpArray15);
        java.lang.String str17 = mathRuntimeException5.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str17.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        double double5 = dfp4.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        double double22 = dfp21.toDouble();
        boolean boolean23 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr2Reciprocal();
        boolean boolean28 = dfp21.greaterThan(dfp27);
        boolean boolean29 = dfp27.isInfinite();
        boolean boolean30 = dfp18.greaterThan(dfp27);
        int int31 = dfp18.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1362304560964502d + "'", double1 == 1.1362304560964502d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        java.lang.String str10 = dfp9.toString();
        int int11 = dfp9.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2." + "'", str10.equals("2."));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.2246467991473532E-16d, (java.lang.Number) (-0.8813735870195429d), true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013292325585375278d) + "'", double1 == (-0.013292325585375278d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.sinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        boolean boolean3 = dfp2.isNaN();
        double double4 = dfp2.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double2 = org.apache.commons.math.util.FastMath.min(2.302585092994046d, (double) 371869261753058540L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.302585092994046d + "'", double2 == 2.302585092994046d);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        float float2 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.002578497f + "'", float2 == 0.002578497f);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NaN, (double) (-4538325550017329008L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField23.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable20, localizable21, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException31);
        java.lang.Throwable[] throwableArray33 = mathRuntimeException32.getSuppressed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField9.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException5, localizable6, localizable7, (java.lang.Object[]) dfpArray15);
        java.lang.Throwable[] throwableArray17 = mathRuntimeException16.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.7536353504151265d, (java.lang.Number) (byte) 1, false);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        mathRuntimeException16.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.7536353504151265d + "'", number22.equals(1.7536353504151265d));
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int[] intArray6 = new int[] { (short) 1, 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
//        mersenneTwister0.setSeed(intArray6);
//        int int9 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9012460050544054843L) + "'", long2 == (-9012460050544054843L));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 573371203 + "'", int9 == 573371203);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField9.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException5, localizable6, localizable7, (java.lang.Object[]) dfpArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException5.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException5);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32768);
        mersenneTwister1.setSeed((long) 1601595096);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException7.getSpecificPattern();
        java.lang.String str22 = mathRuntimeException7.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str22.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 10L);
        try {
            org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeLn(dfp9, dfp10, dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(573371203);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.2490457723982544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6918735256043334d + "'", double1 == 0.6918735256043334d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp20 = dfp5.nextAfter(dfp19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        int int6 = dfp5.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) Double.NEGATIVE_INFINITY, false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        long long2 = org.apache.commons.math.util.FastMath.max(3792034858904319064L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3792034858904319064L + "'", long2 == 3792034858904319064L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.getZero();
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.ceil();
        boolean boolean26 = dfp15.unequal(dfp25);
        double double27 = dfp15.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp15.newInstance(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp5.newInstance(dfp15);
        double[] doubleArray35 = dfp15.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        boolean boolean9 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            boolean boolean12 = dfp8.unequal(dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        long long1 = org.apache.commons.math.util.FastMath.abs(899545587248165312L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 899545587248165312L + "'", long1 == 899545587248165312L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 1.2490457723982544d, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        double double22 = dfp21.toDouble();
        boolean boolean23 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr2Reciprocal();
        boolean boolean28 = dfp21.greaterThan(dfp27);
        boolean boolean29 = dfp27.isInfinite();
        boolean boolean30 = dfp18.greaterThan(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.rint();
        boolean boolean39 = dfp18.greaterThan(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.getZero();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.getZero();
        int int50 = dfp49.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.ceil();
        boolean boolean60 = dfp49.unequal(dfp59);
        double double61 = dfp49.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField63.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp49.newInstance(dfp66);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp49.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp37.multiply(dfp69);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 25 + "'", int50 == 25);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.9461339261552633d, (java.lang.Number) (-338813211), false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.getSqr3();
        boolean boolean17 = dfp7.greaterThan(dfp16);
        int int18 = dfp16.classify();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10K(25);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) (byte) -1);
        double double3 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.02182568980423394d + "'", double3 == 0.02182568980423394d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        double double10 = dfp6.toDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.power10K((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.ceil();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.negate();
        int int23 = dfp22.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp6.nextAfter(dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.7536353504151265d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp8);
        int int11 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3792034858904319064L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3792034858904318976L + "'", long1 == 3792034858904318976L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            boolean boolean7 = dfp5.greaterThan(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.3358343618944353d) + "'", double3 == (-1.3358343618944353d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.3209711346238147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32097113462381477d + "'", double1 == 0.32097113462381477d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0797821797783358d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        boolean boolean11 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K(4);
        double double14 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.divide(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E16d + "'", double14 == 1.0E16d);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp19.multiply(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp8.subtract(dfp19);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-338813211L), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.38813211E8d) + "'", double2 == (-3.38813211E8d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.getZero();
        int int34 = dfp33.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.ceil();
        boolean boolean44 = dfp33.unequal(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp22.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp10.add(dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 25 + "'", int34 == 25);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 6.38905609893065d);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 6.389 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 6.389 is smaller than, or equal to, the minimum (0)"));
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int5 = mersenneTwister0.nextInt();
//        double double6 = mersenneTwister0.nextGaussian();
//        double double7 = mersenneTwister0.nextGaussian();
//        int int8 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5749899393128097035L + "'", long2 == 5749899393128097035L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1105171491) + "'", int5 == (-1105171491));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0189065260541812d + "'", double6 == 1.0189065260541812d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.125561652755165d + "'", double7 == 1.125561652755165d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 464420274 + "'", int8 == 464420274);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.sqrt();
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.732050807568877293527446341505872366942805253810380628055806979451933016908800037081146186757248" + "'", str11.equals("1.732050807568877293527446341505872366942805253810380628055806979451933016908800037081146186757248"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-103355408));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.03355408E8f + "'", float1 == 1.03355408E8f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 464420274, (long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double2 = org.apache.commons.math.util.FastMath.max((double) '4', 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 1.2490457723982544d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.8813735870195429d) + "'", number5.equals((-0.8813735870195429d)));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        int[] intArray3 = null;
        mersenneTwister1.setSeed(intArray3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-2.164036487299762d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 371869261753058540L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.490343004551492E15d + "'", double1 == 6.490343004551492E15d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        mersenneTwister1.setSeed((int) (short) 10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 10, (byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = null;
        dfpField1.setRoundingMode(roundingMode12);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str4 = notStrictlyPositiveException3.toString();
        java.lang.Object[] objArray5 = notStrictlyPositiveException3.getArguments();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField10.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3, localizable7, localizable8, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        double double25 = dfp24.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField27.setRoundingMode(roundingMode30);
        boolean boolean32 = dfp24.equals((java.lang.Object) dfpField27);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField27.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException19, localizable20, localizable21, (java.lang.Object[]) dfpArray33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.4142135623730951d + "'", double25 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfpArray33);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195432d + "'", double1 == 0.8813735870195432d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        boolean boolean7 = dfp6.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance(617939122365631559L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-2.164036487299762d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-123.99015743459235d) + "'", double1 == (-123.99015743459235d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField23.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable20, localizable21, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathRuntimeException31.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathRuntimeException31.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertNull(localizable33);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.000000000000002d, (java.lang.Number) 2.477888730288475d, true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-338813211L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(100);
        int int15 = dfp12.classify();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.negate();
        boolean boolean25 = dfp4.unequal(dfp12);
        try {
            org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((double) (-1.0f));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField6.newDfp((int) '#');
        int int14 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField17.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        boolean boolean25 = dfp24.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField17.newDfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField17.getOne();
        boolean boolean28 = dfp15.unequal(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp4.add(dfp27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.getSqr3();
        boolean boolean17 = dfp7.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.power10K(9);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        boolean boolean4 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(3069);
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((int) '#');
        int int20 = dfpField12.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp5.dotrap(1054400403, "", dfp10, dfp22);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField2.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.getSqr2();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 32760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getOne();
        boolean boolean39 = dfp27.unequal(dfp37);
        boolean boolean40 = dfp8.greaterThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.power10(7);
        int int43 = dfp42.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5650689658538883d, (java.lang.Number) 2.993222846126381d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32768, (float) 5958733889552323610L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32768.0f + "'", float2 == 32768.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8414709848078965d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException(throwable11, localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray15);
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException17);
        java.lang.Class<?> wildcardClass19 = mathIllegalArgumentException17.getClass();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.714348271272675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2603033481457588693L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.02182568980423394d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.884930210519303E-167d + "'", double2 == 7.884930210519303E-167d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 3);
        double double11 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        int int8 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("1.732050807568877293527446341505872366942805253810380628055806979451933016908800037081146186757248");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(100);
        int int15 = dfp12.classify();
        boolean boolean16 = dfp6.lessThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        dfpField18.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField18.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        try {
            org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp6, dfp26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int5 = mersenneTwister0.nextInt();
//        double double6 = mersenneTwister0.nextGaussian();
//        int int7 = mersenneTwister0.nextInt();
//        int int9 = mersenneTwister0.nextInt(32760);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8407567176077257616L + "'", long2 == 8407567176077257616L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-68188302) + "'", int5 == (-68188302));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9201390066396596d + "'", double6 == 0.9201390066396596d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1684856842 + "'", int7 == 1684856842);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2676 + "'", int9 == 2676);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1105171491));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1105171491 + "'", int1 == 1105171491);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfp10.remainder(dfp21);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        boolean boolean5 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0L);
//        int[] intArray11 = new int[] { 1, 1, (short) 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray11);
//        mersenneTwister0.setSeed(intArray11);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2777928502067839193L) + "'", long2 == (-2777928502067839193L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1105171491), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1545849344166356650L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        boolean boolean11 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K(4);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) 1451588289);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.03355408E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 10, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 2.993222846126381d, true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(573371203);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        long long1 = org.apache.commons.math.util.FastMath.abs(5849931669921551489L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5849931669921551489L + "'", long1 == 5849931669921551489L);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
//        int[] intArray5 = new int[] { 1, 1, (short) 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean9 = mersenneTwister8.nextBoolean();
//        long long10 = mersenneTwister8.nextLong();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int[] intArray14 = new int[] { (short) 1, 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray14);
//        mersenneTwister8.setSeed(intArray14);
//        mersenneTwister7.setSeed(intArray14);
//        mersenneTwister1.setSeed(intArray14);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8855693461035190454L + "'", long10 == 8855693461035190454L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField2.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField2.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField14.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getLn10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp21.nextAfter(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.getZero();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getOne();
        boolean boolean52 = dfp40.unequal(dfp50);
        boolean boolean53 = dfp21.greaterThan(dfp50);
        try {
            org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp12, dfp21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1560931061, 1.2490457723982544d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963259947038d + "'", double2 == 1.5707963259947038d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.ceil();
        boolean boolean20 = dfp9.unequal(dfp19);
        double double21 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp9.newInstance(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.sqrt();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp9.add(dfp35);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp19.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getLn10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.newDfp((int) '#');
        int int39 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField42.setRoundingMode(roundingMode45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        boolean boolean50 = dfp49.isNaN();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField42.newDfp(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField42.getOne();
        boolean boolean53 = dfp40.unequal(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.divide(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.getZero();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp61.getZero();
        int int65 = dfp64.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField67.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp71.ceil();
        boolean boolean75 = dfp64.unequal(dfp74);
        double double76 = dfp64.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray79 = dfpField78.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField78.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp64.newInstance(dfp81);
        int int83 = dfp64.log10K();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp52.divide(dfp64);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 25 + "'", int65 == 25);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + Double.NEGATIVE_INFINITY + "'", double76 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int[] intArray6 = new int[] { (short) 1, 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
//        mersenneTwister0.setSeed(intArray6);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
//        int int10 = mersenneTwister9.nextInt();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7384997015994266751L) + "'", long2 == (-7384997015994266751L));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 573371203 + "'", int10 == 573371203);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3069);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3069L + "'", long1 == 3069L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 10, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5958733889552323610L, (java.lang.Number) 1.232595164407831E-32d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException4.getGeneralPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6919903846336738d + "'", double1 == 0.6919903846336738d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-8510178405683385650L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2041641.8287977898d) + "'", double1 == (-2041641.8287977898d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1684856842);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6918735256043334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6379810133793075d + "'", double1 == 0.6379810133793075d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5508091201419623d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3440585709080678E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.4161468365471424d), 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4161468365471424d) + "'", double2 == (-0.4161468365471424d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int[] intArray3 = new int[] { 1, 1, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        boolean boolean6 = mersenneTwister5.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("2.");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.negate();
        boolean boolean10 = dfp5.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) -1, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.2415644752704905d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24643487272000653d) + "'", double1 == (-0.24643487272000653d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getZero();
        int int22 = dfp21.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.ceil();
        boolean boolean32 = dfp21.unequal(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp10.multiply(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField35.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getLn10();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp42.nextAfter(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getTwo();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getTwo();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.rint();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField55.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField55.getE();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp61.ceil();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp53.subtract(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField65.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField65.getLn10();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField65.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField65.newDfp((int) '#');
        int int73 = dfpField65.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField65.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray77 = dfpField76.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray78 = dfpField76.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode79 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField76.setRoundingMode(roundingMode79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getZero();
        boolean boolean84 = dfp83.isNaN();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField76.newDfp(dfp83);
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField76.getOne();
        boolean boolean87 = dfp74.unequal(dfp86);
        org.apache.commons.math.dfp.Dfp dfp88 = dfp53.divide(dfp86);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp88.negate();
        org.apache.commons.math.dfp.Dfp dfp90 = dfp21.multiply(dfp88);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 25 + "'", int22 == 25);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 16 + "'", int73 == 16);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfpArray77);
        org.junit.Assert.assertNotNull(dfpArray78);
        org.junit.Assert.assertTrue("'" + roundingMode79 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode79.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.39720770839918d + "'", double1 == 10.39720770839918d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfp6.classify();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.newDfp((int) '#');
        int int17 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp6.add(dfp20);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        int int10 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.add(dfp10);
        java.lang.String str12 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.7071067811865475244008443621048490392848359376884740365883398689953662392310535194251937671638207864" + "'", str12.equals("0.7071067811865475244008443621048490392848359376884740365883398689953662392310535194251937671638207864"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        java.lang.Class<?> wildcardClass4 = dfpArray3.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathIllegalArgumentException5.getGeneralPattern();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str6 = notStrictlyPositiveException5.toString();
        java.lang.Object[] objArray7 = notStrictlyPositiveException5.getArguments();
        notStrictlyPositiveException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField12.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, localizable10, (java.lang.Object[]) dfpArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray20);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32768);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1691302124) + "'", int2 == (-1691302124));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 10, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37293782932771496d + "'", double1 == 0.37293782932771496d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6995216443485196d + "'", double1 == 0.6995216443485196d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, (short) 0, 5.775560745114035d, '#', 8 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) -1);
        int int5 = dfp2.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((byte) -1);
        dfpField19.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.getSqr3();
        boolean boolean27 = dfp17.greaterThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp28);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 3069L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.ceil();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        double double12 = dfp11.toDouble();
        boolean boolean13 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(3069);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp7.newInstance(dfp14);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.4142135623730951d + "'", double12 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2587474957576138295L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.divide((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getLn10();
        dfpField12.setIEEEFlags((int) (byte) 100);
        boolean boolean20 = dfp10.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.sqrt();
        double double10 = dfp9.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.6487212707001282d + "'", double10 == 1.6487212707001282d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((-3.141592653589793d));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp19.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getLn10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.newDfp((int) '#');
        int int39 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField42.setRoundingMode(roundingMode45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        boolean boolean50 = dfp49.isNaN();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField42.newDfp(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField42.getOne();
        boolean boolean53 = dfp40.unequal(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.negate();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        dfpField2.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField2.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField2.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathIllegalArgumentException11.getSpecificPattern();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 371869261753058540L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 371869261753058560L + "'", long1 == 371869261753058560L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7201608355205992341L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.2016082E18f + "'", float1 == 7.2016082E18f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.ceil();
        boolean boolean20 = dfp9.unequal(dfp19);
        double double21 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp9.newInstance(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField29.newDfp((double) 3292454249375386225L);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.subtract(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getLn2Split();
        dfpField42.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField42.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.getOne();
        boolean boolean51 = dfp40.greaterThan(dfp50);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int[] intArray2 = new int[] { (short) 1, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.29984303947695473d + "'", double4 == 0.29984303947695473d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-103355408));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.getZero();
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.ceil();
        boolean boolean26 = dfp15.unequal(dfp25);
        double double27 = dfp15.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp15.newInstance(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp5.newInstance(dfp15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Number number37 = notStrictlyPositiveException36.getMin();
        java.lang.String str38 = notStrictlyPositiveException36.toString();
        boolean boolean39 = dfp5.equals((java.lang.Object) notStrictlyPositiveException36);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str38.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 7201608355205992341L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2016083552059924E18d + "'", double1 == 7.2016083552059924E18d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        boolean boolean20 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp11, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField26.setRoundingMode(roundingMode29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getZero();
        boolean boolean34 = dfp33.isNaN();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField26.newDfp(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField26.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp24.subtract(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double2 = org.apache.commons.math.util.FastMath.min(10.39720770839918d, 0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        dfpField5.setIEEEFlagsBits((-2053677732));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = null;
        org.apache.commons.math.dfp.Dfp dfp16 = dfp5.dotrap((-4), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        java.lang.Number number20 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        java.lang.Class<?> wildcardClass5 = dfp4.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        int[] intArray3 = new int[] { (short) 1, 16, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean6 = mersenneTwister5.nextBoolean();
//        long long7 = mersenneTwister5.nextLong();
//        byte[] byteArray10 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister5.nextBytes(byteArray10);
//        mersenneTwister4.nextBytes(byteArray10);
//        int int13 = mersenneTwister4.nextInt();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-6371609227641787971L) + "'", long7 == (-6371609227641787971L));
//        org.junit.Assert.assertNotNull(byteArray10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-422618737) + "'", int13 == (-422618737));
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode16);
        dfpField1.setRoundingMode(roundingMode16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("0.7071067811865475244008443621048490392848359376884740365883398689953662392310535194251937671638207864");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.getSqr3();
        boolean boolean17 = dfp7.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 1.2490457723982544d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField10.newDfp((long) 1451588289);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField10.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6, localizable7, localizable8, (java.lang.Object[]) dfpArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray24);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        double[] doubleArray6 = dfp5.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField8.getSqr2();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.4142135623730951d + "'", double17 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.606024476657116d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.5508091201419623d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp19.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getLn10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.newDfp((int) '#');
        int int39 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField42.setRoundingMode(roundingMode45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        boolean boolean50 = dfp49.isNaN();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField42.newDfp(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField42.getOne();
        boolean boolean53 = dfp40.unequal(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.divide(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.getZero();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.getOne();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray67 = dfpField66.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField66.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.getZero();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp64.nextAfter(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp74.getOne();
        org.apache.commons.math.dfp.Dfp dfp76 = org.apache.commons.math.dfp.DfpField.computeExp(dfp52, dfp74);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpArray67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5958733889552323610L, (java.lang.Number) 1.232595164407831E-32d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Number number11 = notStrictlyPositiveException10.getMin();
        java.lang.String str12 = notStrictlyPositiveException10.toString();
        notStrictlyPositiveException8.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        mathRuntimeException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int5 = mersenneTwister0.nextInt();
//        double double6 = mersenneTwister0.nextGaussian();
//        int int7 = mersenneTwister0.nextInt();
//        long long8 = mersenneTwister0.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean10 = mersenneTwister9.nextBoolean();
//        long long11 = mersenneTwister9.nextLong();
//        int int13 = mersenneTwister9.nextInt(10);
//        int int14 = mersenneTwister9.nextInt();
//        double double15 = mersenneTwister9.nextGaussian();
//        double double16 = mersenneTwister9.nextGaussian();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean18 = mersenneTwister17.nextBoolean();
//        long long19 = mersenneTwister17.nextLong();
//        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister17.nextBytes(byteArray22);
//        mersenneTwister9.nextBytes(byteArray22);
//        mersenneTwister0.nextBytes(byteArray22);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7175905622128375200L + "'", long2 == 7175905622128375200L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 761912945 + "'", int5 == 761912945);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.402627386626208d) + "'", double6 == (-0.402627386626208d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2026185229 + "'", int7 == 2026185229);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 969655484589324661L + "'", long8 == 969655484589324661L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1269910273058285850L + "'", long11 == 1269910273058285850L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 517154373 + "'", int14 == 517154373);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.4431950722849787d + "'", double15 == 1.4431950722849787d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.5862660250037799d) + "'", double16 == (-0.5862660250037799d));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-7044999342599751640L) + "'", long19 == (-7044999342599751640L));
//        org.junit.Assert.assertNotNull(byteArray22);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5958733889552323610L, (float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.958734E18f + "'", float2 == 5.958734E18f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField3.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray7);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        double double3 = dfp2.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
        double double2 = mersenneTwister1.nextGaussian();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0553194731804223d + "'", double2 == 1.0553194731804223d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1653253813890907d + "'", double3 == 0.1653253813890907d);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        int[] intArray3 = new int[] { (short) 1, 16, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean6 = mersenneTwister5.nextBoolean();
//        long long7 = mersenneTwister5.nextLong();
//        byte[] byteArray10 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister5.nextBytes(byteArray10);
//        mersenneTwister4.nextBytes(byteArray10);
//        java.lang.Class<?> wildcardClass13 = byteArray10.getClass();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-8823155510834385032L) + "'", long7 == (-8823155510834385032L));
//        org.junit.Assert.assertNotNull(byteArray10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        boolean boolean7 = dfp6.isInfinite();
        int int8 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-43.636130838093536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }
}

