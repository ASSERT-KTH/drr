import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        dfpField1.setIEEEFlags((-32767));
        dfpField1.setIEEEFlags(2);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2326303196791324d + "'", double1 == 2.2326303196791324d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.ceil();
        boolean boolean5 = dfp4.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance(0);
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.newDfp("2.");
        java.lang.Class<?> wildcardClass14 = dfpField5.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7071067811865476d + "'", double8 == 0.7071067811865476d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.20787957635076193d, (java.lang.Number) 32760, false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode6);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9860132971832694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-123.99015743459235d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        int int11 = dfp8.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2009687540817720072L);
        mersenneTwister1.setSeed(2147483647);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs(8407567176077257616L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8407567176077257616L + "'", long1 == 8407567176077257616L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.atan(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.ceil();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        double double4 = mersenneTwister0.nextDouble();
//        float float5 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7744338857346906029L + "'", long2 == 7744338857346906029L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2086242143474355d + "'", double4 == 0.2086242143474355d);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8413935f + "'", float5 == 0.8413935f);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) 100);
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp9.multiply(dfp19);
        boolean boolean22 = dfp19.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.585786437626905d), (java.lang.Number) (-1979136933844198216L), false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        int int18 = dfp17.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.util.FastMath.max(0.6919903846336738d, (double) 5958733889552323610L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.9587338895523236E18d + "'", double2 == 5.9587338895523236E18d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7853981633974483d, (double) 1054400403);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.054400403E9d + "'", double2 == 1.054400403E9d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int1 = org.apache.commons.math.util.FastMath.abs(1105171491);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1105171491 + "'", int1 == 1105171491);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int1 = org.apache.commons.math.util.FastMath.round(2.0536777E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2053677696 + "'", int1 == 2053677696);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.nextAfter(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr2();
        double double41 = dfp40.toDouble();
        boolean boolean42 = dfp40.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr2Reciprocal();
        boolean boolean47 = dfp40.greaterThan(dfp46);
        boolean boolean48 = dfp46.isInfinite();
        boolean boolean49 = dfp37.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp5.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.4142135623730951d + "'", double41 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.0f, 0.9461339261552633d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5613352698348966d + "'", double2 == 1.5613352698348966d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        java.lang.String str10 = dfp8.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3." + "'", str10.equals("3."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField15.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.ceil();
        boolean boolean46 = dfp35.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp24.multiply(dfp35);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp13.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp48);
        int int50 = dfp49.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 25 + "'", int36 == 25);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2147483647 + "'", int50 == 2147483647);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.");
        java.lang.Class<?> wildcardClass7 = dfp6.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1474605773));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.47460582E9f + "'", float1 == 1.47460582E9f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        boolean boolean20 = dfp9.lessThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.power10(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int[] intArray3 = new int[] { 1, 1, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        boolean boolean5 = mersenneTwister4.nextBoolean();
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 0 };
        mersenneTwister4.nextBytes(byteArray8);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        double double22 = dfp21.toDouble();
        boolean boolean23 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr2Reciprocal();
        boolean boolean28 = dfp21.greaterThan(dfp27);
        boolean boolean29 = dfp27.isInfinite();
        boolean boolean30 = dfp18.greaterThan(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.divide((int) (short) 1);
        boolean boolean37 = dfp18.lessThan(dfp34);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 100, (-0.2453389241428091d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5613352698348966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8384595794609528779L), (float) 899545587248165312L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.3845958E18f) + "'", float2 == (-8.3845958E18f));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-4572360398976607471L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode20);
        dfpField1.setRoundingMode(roundingMode20);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2251602784869111620L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2587474957576138295L, number2, true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        double double9 = dfp8.toDouble();
        boolean boolean10 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.getTwo();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5308176396716067d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9105644100623985d + "'", double1 == 0.9105644100623985d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-7858310631209755687L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(100);
        int int21 = dfp18.classify();
        boolean boolean22 = dfp12.lessThan(dfp18);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.divide(16);
        boolean boolean25 = dfp5.unequal(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField26 = dfp24.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfpField26);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 371869261753058540L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.71869264E17f + "'", float2 == 3.71869264E17f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        long long1 = org.apache.commons.math.util.FastMath.abs((-8510178405683385650L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8510178405683385650L + "'", long1 == 8510178405683385650L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 0);
        int int12 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.divide((int) (byte) 3);
        double double11 = dfp10.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        double[] doubleArray6 = dfp5.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField8.getSqr2();
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.4142135623730951d + "'", double17 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-68188302));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.8188302E7d + "'", double1 == 6.8188302E7d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.getSqr3();
        boolean boolean17 = dfp7.greaterThan(dfp16);
        int int18 = dfp16.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 25 + "'", int18 == 25);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 3292454249375386225L);
        java.lang.Class<?> wildcardClass12 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13235175009777303d) + "'", double1 == (-0.13235175009777303d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 969655484589324661L, (float) 3069L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.6965546E17f + "'", float2 == 9.6965546E17f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField5.setRoundingMode(roundingMode8);
        boolean boolean10 = dfp2.equals((java.lang.Object) dfpField5);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField5.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.20787957635076193d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.getZero();
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.ceil();
        boolean boolean26 = dfp15.unequal(dfp25);
        double double27 = dfp15.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp15.newInstance(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp5.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.getZero();
        int int45 = dfp44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp34.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp47.divide((int) (short) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 25 + "'", int45 == 25);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 899545587248165312L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25 + "'", int3 == 25);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.81571978190556d, (java.lang.Number) 5849931669921551489L, true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.tan((-43.636130838093536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.360690034193902d + "'", double1 == 0.360690034193902d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("hi!");
        java.lang.String str19 = dfp18.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0." + "'", str19.equals("0."));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6995216443485196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012208955882846451d + "'", double1 == 0.012208955882846451d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 761912945);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.14449004227754d + "'", double1 == 21.14449004227754d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7853981633974483d, (double) 3292454249375386225L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974484d + "'", double2 == 0.7853981633974484d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 7201608355205992341L, (java.lang.Number) (-8823155510834385032L), true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long long1 = org.apache.commons.math.util.FastMath.round(1.176670644609509E11d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 117667064461L + "'", long1 == 117667064461L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int[] intArray3 = new int[] { 1, 1, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister5.setSeed(0L);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), (-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.41032129904824216d) + "'", double2 == (-0.41032129904824216d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-10844707932354082L));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        boolean boolean5 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0L);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        int[] intArray13 = new int[] { 1, 1, (short) 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray13);
//        mersenneTwister8.setSeed(intArray13);
//        mersenneTwister0.setSeed(intArray13);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray13);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39534115623196803L + "'", long2 == 39534115623196803L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3485178487560878823L + "'", long9 == 3485178487560878823L);
//        org.junit.Assert.assertNotNull(intArray13);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, (float) (-2603033481457588693L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.60303358E18f) + "'", float2 == (-2.60303358E18f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.getZero();
        int int23 = dfp22.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.ceil();
        boolean boolean33 = dfp22.unequal(dfp32);
        double double34 = dfp22.toDouble();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp12.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp22.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 25 + "'", int23 == 25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.NEGATIVE_INFINITY + "'", double34 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode20);
        dfpField1.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField25.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp34);
        double[] doubleArray36 = dfp35.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = dfpField38.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField38.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp52 = dfp35.subtract(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField1.newDfp(dfp35);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField15.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.ceil();
        boolean boolean46 = dfp35.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp24.multiply(dfp35);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp13.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 25 + "'", int36 == 25);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-103355408), (java.lang.Number) 3699691109181415359L, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3699691109181415359L + "'", number4.equals(3699691109181415359L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.tan(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590892d + "'", double1 == 0.6483608274590892d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.606024476657116d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((int) (short) 1);
        int int14 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        double[] doubleArray9 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance((byte) 100, (byte) -1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(899545587248165312L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 32768);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32768L + "'", long1 == 32768L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2251602784869111620L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.log(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.772588722239781d + "'", double1 == 2.772588722239781d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2.0536777E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        int int6 = mersenneTwister0.nextInt(2147483647);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7168543502694205997L + "'", long2 == 7168543502694205997L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 309133981 + "'", int6 == 309133981);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.03355408E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963171195443d) + "'", double1 == (-1.5707963171195443d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int1 = org.apache.commons.math.util.FastMath.abs(573371203);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 573371203 + "'", int1 == 573371203);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp5.newInstance(1.2490457723982544d);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 7744338857346906029L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
//        boolean boolean2 = mersenneTwister1.nextBoolean();
//        long long3 = mersenneTwister1.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(2009687540817720072L);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean7 = mersenneTwister6.nextBoolean();
//        long long8 = mersenneTwister6.nextLong();
//        byte[] byteArray11 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister6.nextBytes(byteArray11);
//        mersenneTwister5.nextBytes(byteArray11);
//        mersenneTwister1.nextBytes(byteArray11);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6706035995386535327L + "'", long3 == 6706035995386535327L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-874166190212447567L) + "'", long8 == (-874166190212447567L));
//        org.junit.Assert.assertNotNull(byteArray11);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3069L, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5698188099996992d + "'", double2 == 1.5698188099996992d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((byte) 100);
        boolean boolean11 = dfp6.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp6.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(7.2016083552059924E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.683581255562423E9d + "'", double1 == 2.683581255562423E9d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField6.setRoundingMode(roundingMode9);
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(0);
        boolean boolean17 = dfp8.equals((java.lang.Object) dfp16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.606024476657116d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlagsBits((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2053677732));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2053677732 + "'", int1 == 2053677732);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-10844707932354082L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        long long4 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3610418893843469219L) + "'", long2 == (-3610418893843469219L));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7567999801727688516L + "'", long4 == 7567999801727688516L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9461339261552633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6658448026471596d + "'", double1 == 0.6658448026471596d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-3610418893843469219L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.3013697073780168E16d) + "'", double1 == (-6.3013697073780168E16d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 1601595096);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp5, dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-2.60303358E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4914283809336603E20d) + "'", double1 == (-1.4914283809336603E20d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-4058876178102596974L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
//        long long2 = mersenneTwister1.nextLong();
//        int[] intArray6 = new int[] { (short) 1, 16, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean9 = mersenneTwister8.nextBoolean();
//        long long10 = mersenneTwister8.nextLong();
//        byte[] byteArray13 = new byte[] { (byte) 100, (byte) 3 };
//        mersenneTwister8.nextBytes(byteArray13);
//        mersenneTwister7.nextBytes(byteArray13);
//        mersenneTwister1.nextBytes(byteArray13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2603033481457588693L) + "'", long2 == (-2603033481457588693L));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7622199652079269403L + "'", long10 == 7622199652079269403L);
//        org.junit.Assert.assertNotNull(byteArray13);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.ceil();
        boolean boolean20 = dfp9.unequal(dfp19);
        double double21 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp9.newInstance(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField29.newDfp((double) 3292454249375386225L);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.subtract(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp26.newInstance("0.");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 7201608355205992341L);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp((byte) -1);
        dfpField29.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.getSqr3();
        boolean boolean37 = dfp27.greaterThan(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp9.divide(dfp36);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField10.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((-0.24643487272000653d));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 6621595337308563073L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6215953373085635E18d + "'", double1 == 6.6215953373085635E18d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.newDfp(1105171491);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.nextAfter(dfp23);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        double double2 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed((long) 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.18167277758657097d) + "'", double2 == (-0.18167277758657097d));
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948963d + "'", double1 == 1.5707963267948963d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getLn10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.newDfp((byte) -1);
        dfpField23.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField23.getSqr3();
        boolean boolean31 = dfp21.greaterThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp3.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((long) 25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.74729f + "'", float1 == 0.74729f);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.newDfp((byte) 10, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp9.divide(dfp23);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 573371203);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance(2712132858523348745L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
//        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
//        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
//        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
//        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
//        dfpField1.setIEEEFlags((int) (byte) 100);
//        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-2147483648));
//        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean13 = mersenneTwister12.nextBoolean();
//        long long14 = mersenneTwister12.nextLong();
//        boolean boolean15 = mersenneTwister12.nextBoolean();
//        int[] intArray18 = new int[] { (short) 1, 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray18);
//        mersenneTwister12.setSeed(intArray18);
//        boolean boolean21 = dfp11.equals((java.lang.Object) mersenneTwister12);
//        org.junit.Assert.assertNotNull(dfpArray2);
//        org.junit.Assert.assertNotNull(dfp3);
//        org.junit.Assert.assertNotNull(dfp4);
//        org.junit.Assert.assertNotNull(dfp5);
//        org.junit.Assert.assertNotNull(dfp6);
//        org.junit.Assert.assertNotNull(dfp10);
//        org.junit.Assert.assertNotNull(dfp11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3206303072680913399L + "'", long14 == 3206303072680913399L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3069, 8407567176077257616L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8407567176077257616L + "'", long2 == 8407567176077257616L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(0L);
        int int8 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance((byte) -1);
        java.lang.String str11 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance(0L);
        int int20 = dfp17.log10K();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) -1);
        java.lang.String str23 = dfp17.toString();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp24.nextAfter(dfp36);
        int int39 = dfp24.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NaN" + "'", str11.equals("NaN"));
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NaN" + "'", str23.equals("NaN"));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Class<?> wildcardClass21 = notStrictlyPositiveException1.getClass();
        java.lang.Throwable[] throwableArray22 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double2 = org.apache.commons.math.util.FastMath.min(1.3784657903858746d, 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3784657903858746d + "'", double2 == 1.3784657903858746d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(0L);
        int int8 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance((byte) -1);
        java.lang.String str11 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance(0L);
        int int20 = dfp17.log10K();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) -1);
        java.lang.String str23 = dfp17.toString();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp5.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField26.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp24.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp45.getZero();
        int int49 = dfp48.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField51.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp55.ceil();
        boolean boolean59 = dfp48.unequal(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp36.subtract(dfp48);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NaN" + "'", str11.equals("NaN"));
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NaN" + "'", str23.equals("NaN"));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 25 + "'", int49 == 25);
        org.junit.Assert.assertNotNull(dfpArray52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 8395338105918845118L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.810174410545043E20d + "'", double1 == 4.810174410545043E20d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((byte) -1);
        dfpField19.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.getSqr3();
        boolean boolean27 = dfp17.greaterThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp8.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        double[] doubleArray4 = dfp3.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.divide(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.power10((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int2 = org.apache.commons.math.util.FastMath.min((-2053677732), 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2053677732) + "'", int2 == (-2053677732));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.54881346f + "'", float2 == 0.54881346f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        dfpField1.setIEEEFlags(1451588289);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField15.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.ceil();
        boolean boolean46 = dfp35.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp24.multiply(dfp35);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp13.add(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(100);
        int int59 = dfp56.classify();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField61.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField61.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getZero();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.add(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp48.dotrap((-32767), "hi!", dfp56, dfp72);
        int int74 = dfp72.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 25 + "'", int36 == 25);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 25 + "'", int74 == 25);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField15.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.ceil();
        boolean boolean46 = dfp35.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp24.multiply(dfp35);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp13.add(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(100);
        int int59 = dfp56.classify();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField61.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField61.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getZero();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.add(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp48.dotrap((-32767), "hi!", dfp56, dfp72);
        boolean boolean74 = dfp56.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 25 + "'", int36 == 25);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5958733889552323610L, (java.lang.Number) 1.232595164407831E-32d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        double double3 = dfp2.toDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10(1560931061);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4142135623730951d + "'", double3 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-3.141592653589793d), (java.lang.Number) 97, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.newDfp((long) 100);
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField20.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable8, localizable15, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException(throwable43, localizable44, localizable45, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField52.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField52.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException48, localizable49, localizable50, (java.lang.Object[]) dfpArray58);
        notStrictlyPositiveException42.addSuppressed((java.lang.Throwable) mathRuntimeException48);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField64.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray70 = dfpField64.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException42, localizable61, localizable62, (java.lang.Object[]) dfpArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable38, (java.lang.Object[]) dfpArray70);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfpArray70);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.add(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getOne();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.newInstance(32.0d);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField39.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.getZero();
        double double48 = dfp44.toDouble();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.power10K((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp37.multiply(dfp44);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getTwo();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp10.dotrap(2053677696, "3.", dfp51, dfp55);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int[] intArray3 = new int[] { 1, 1, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double6 = mersenneTwister5.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.636366483047421d + "'", double6 == 2.636366483047421d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.ceil();
        boolean boolean20 = dfp9.unequal(dfp19);
        double double21 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp9.newInstance(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField29.newDfp((double) 3292454249375386225L);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.subtract(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getLn2Split();
        dfpField42.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField42.newDfp();
        double[] doubleArray50 = dfp49.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp49);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.divide((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        int int8 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp5.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        double[] doubleArray22 = dfp21.toSplitDouble();
        boolean boolean23 = dfp5.lessThan(dfp21);
        java.lang.Class<?> wildcardClass24 = dfp5.getClass();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.newInstance((byte) 1, (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("0.");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-3.141592653589793d), (java.lang.Number) 97, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.newDfp((long) 100);
        dfpField20.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField20.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable8, localizable15, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable43, (java.lang.Number) 1.0d);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable43, (java.lang.Object[]) dfpArray49);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) 1.0d);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField64.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField64.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable60, (java.lang.Object[]) dfpArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable38, (java.lang.Object[]) dfpArray66);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfpArray66);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3792034858904318976L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1601595096L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25 + "'", int3 == 25);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 2009687540817720072L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0d + "'", double1 == 256.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.360690034193902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4428658570007048d) + "'", double1 == (-0.4428658570007048d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.950000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9719030694018206d) + "'", double1 == (-0.9719030694018206d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-10844707932354082L));
        java.lang.Class<?> wildcardClass11 = dfp10.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { true };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7, localizable8, localizable9, (java.lang.Object[]) dfpArray17);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathRuntimeException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2();
        double double11 = dfp10.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField13.setRoundingMode(roundingMode16);
        boolean boolean18 = dfp10.equals((java.lang.Object) dfpField13);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField21.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(4300959225443079507L);
        org.apache.commons.math.dfp.Dfp dfp31 = new org.apache.commons.math.dfp.Dfp(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp30);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2();
        double double38 = dfp37.toDouble();
        boolean boolean39 = dfp37.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getSqr2Reciprocal();
        boolean boolean44 = dfp37.greaterThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.newInstance(0.0d);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.power10((-32767));
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField50.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getLn10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.getZero();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp61.getZero();
        int int65 = dfp64.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField67.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp71.ceil();
        boolean boolean75 = dfp64.unequal(dfp74);
        double double76 = dfp64.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray79 = dfpField78.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField78.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp64.newInstance(dfp81);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp54.newInstance(dfp64);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField85.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField85.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp89.getZero();
        org.apache.commons.math.dfp.Dfp dfp92 = dfp90.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp90.getZero();
        int int94 = dfp93.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp96 = dfp93.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp97 = dfp83.newInstance(dfp96);
        org.apache.commons.math.dfp.Dfp dfp98 = dfp19.dotrap((int) '#', "2.", dfp48, dfp96);
        boolean boolean99 = dfp7.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4142135623730951d + "'", double11 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.4142135623730951d + "'", double38 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 25 + "'", int65 == 25);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + Double.NEGATIVE_INFINITY + "'", double76 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfpArray79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 25 + "'", int94 == 25);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfp97);
        org.junit.Assert.assertNotNull(dfp98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10K(100);
        int int13 = dfp10.classify();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp10.remainder(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp10.negate();
        boolean boolean23 = dfp2.unequal(dfp10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp10.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(1105171491);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) '#');
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField12.setRoundingMode(roundingMode15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField12.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.getOne();
        boolean boolean23 = dfp10.unequal(dfp22);
        int int24 = dfp10.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 515.6620156177408d + "'", double1 == 515.6620156177408d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.623014125017576d + "'", double1 == 8.623014125017576d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        java.lang.String str3 = dfp2.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str3.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) (short) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        boolean boolean20 = dfp9.lessThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.newInstance((-1.03355408E8d));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.2086242143474355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4567539976261133d + "'", double1 == 0.4567539976261133d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.37293782932771496d);
        dfpField1.setIEEEFlagsBits(1451588289);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((long) (-103355408));
//        mersenneTwister0.setSeed((-103355408));
//        boolean boolean7 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-8388175193401069744L) + "'", long1 == (-8388175193401069744L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4142937196977824791L) + "'", long2 == (-4142937196977824791L));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        int int3 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed((long) 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1560931061 + "'", int3 == 1560931061);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-8384595794609528779L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str5 = notStrictlyPositiveException4.toString();
        java.lang.Object[] objArray6 = notStrictlyPositiveException4.getArguments();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.String str12 = notStrictlyPositiveException11.toString();
        java.lang.Object[] objArray13 = notStrictlyPositiveException11.getArguments();
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp11.divide(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn10();
        dfpField20.setIEEEFlags((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.newDfp((-2147483648));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField20.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.newInstance(dfp30);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getOne();
        boolean boolean39 = dfp27.unequal(dfp37);
        boolean boolean40 = dfp8.greaterThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.power10(7);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp48.ceil();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.floor();
        java.lang.Class<?> wildcardClass54 = dfp52.getClass();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp37.add(dfp52);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1691302124));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.691302124E9d) + "'", double1 == (-1.691302124E9d));
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt(10);
//        boolean boolean5 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0L);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        int[] intArray13 = new int[] { 1, 1, (short) 100 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray13);
//        mersenneTwister8.setSeed(intArray13);
//        mersenneTwister0.setSeed(intArray13);
//        long long17 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8713361792881125928L + "'", long2 == 8713361792881125928L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 719486700854329554L + "'", long9 == 719486700854329554L);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-548645665294317768L) + "'", long17 == (-548645665294317768L));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.rint();
        boolean boolean16 = dfp3.lessThan(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp25.nextAfter(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.getZero();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getZero();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.getOne();
        boolean boolean56 = dfp44.unequal(dfp54);
        boolean boolean57 = dfp25.greaterThan(dfp54);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.power10(7);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp10.newInstance(dfp54);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(3069L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0553194731804223d + "'", double2 == 1.0553194731804223d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp((byte) -1);
        dfpField29.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.getSqr3();
        boolean boolean37 = dfp27.greaterThan(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp5.remainder(dfp38);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }
}

