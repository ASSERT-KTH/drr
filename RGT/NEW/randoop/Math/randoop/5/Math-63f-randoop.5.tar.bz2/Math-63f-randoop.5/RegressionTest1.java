import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2679097686563066d) + "'", double1 == (-2.2679097686563066d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-2147483648));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1072693248L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(207520192, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 207520192L + "'", long2 == 207520192L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.round((-0.9443504370351303d), (-2147483648));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Underflow");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03490658503988659d) + "'", double1 == (-0.03490658503988659d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.1296280268036493E17d, (java.lang.Number) 97L, 187);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 1, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, 464589906);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.360601550564472E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3152355945118412d) + "'", double1 == (-1.3152355945118412d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int2 = org.apache.commons.math.util.FastMath.max(360339393, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 360339393 + "'", int2 == 360339393);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(101.04454463255303d, 101.04454463255303d, (double) 51L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 4620L, (double) 284858279);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4620.0d + "'", double2 == 4620.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.5574077246549023d), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5574077246549023d) + "'", double2 == (-1.5574077246549023d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-35L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int1 = org.apache.commons.math.util.FastMath.abs(284858279);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 284858279 + "'", int1 == 284858279);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1072693248, 3.141592653589793d, 0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        long long1 = org.apache.commons.math.util.MathUtils.sign(101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(207520192, 360339393);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(900L, (long) (-2027411098));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1824669988200L) + "'", long2 == (-1824669988200L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.log(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0482269650408105d + "'", double1 == 5.0482269650408105d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2146959360, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146959361 + "'", int2 == 2146959361);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 101.0f + "'", float1 == 101.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 2146959360L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2146959360L + "'", long2 == 2146959360L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-49), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.5924994680212787E33d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5924994680212787E33d + "'", double1 == 4.5924994680212787E33d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.log(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-743.7469247408213d) + "'", double1 == (-743.7469247408213d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.apache.commons.math.util.FastMath.min(52, (-2027411098));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2027411098) + "'", int2 == (-2027411098));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1072693248);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 159922119900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.473814720414451d, (int) (byte) -1, 1599221199);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection13, false);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267948966d) + "'", number12.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 198.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 198.00000000000003d + "'", double1 == 198.00000000000003d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable throwable11 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.5707963267948966d) + "'", number9.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.9036922050915067d), (double) 3.0f, (double) (-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(97L, (-1824669988200L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 176992988855400L + "'", long2 == 176992988855400L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1072693248L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.072693248E9d + "'", double1 == 1.072693248E9d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10100L, 1076101121, 2146959361);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-103397965998L), 360339393);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.5574077246549023d), (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.97355719021847d + "'", double2 == 98.97355719021847d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2246467991473532E-16d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.5707963263016567d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02741556777219511d) + "'", double1 == (-0.02741556777219511d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 5729.684851727662d + "'", double63 == 5729.684851727662d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger26);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 52);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 52);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger46);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger46);
        try {
            java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, (long) (-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(360339393, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 597.4533143721499d + "'", double2 == 597.4533143721499d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5840734641020676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5256198019480943d + "'", double1 == 0.5256198019480943d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-2027411098) + "'", int23 == (-2027411098));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.rint((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-86196911) + "'", int2 == (-86196911));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.rint(15.797559753635479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double2 = org.apache.commons.math.util.FastMath.min(8.653313236643557d, 0.6108652381980153d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6108652381980153d + "'", double2 == 0.6108652381980153d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.8130227804211657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9016777586372893d + "'", double1 == 0.9016777586372893d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.log(4.230201256551786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 207520192);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 207520192L + "'", long1 == 207520192L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, 1076101121);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int1 = org.apache.commons.math.util.MathUtils.hash(8.526417023433696d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-938056529) + "'", int1 == (-938056529));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(8.653313236643557d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3701279294639708d + "'", double2 == 2.3701279294639708d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.302585092994046d, 0.0d, (-0.03490658503988659d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.587674259300095d + "'", double38 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1599221199 + "'", int40 == 1599221199);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.0d), 16.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (-1.03397965999E11d), (int) '4', orderDirection19, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection19, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-0.004 < 0.588)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', 2146959360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.2755538259844106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.733308079048062d + "'", double1 == 9.733308079048062d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.FastMath.min(187, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos(174.53292519943292d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-818408495) + "'", int2 == (-818408495));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 49L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.585071585693813d + "'", double1 == 4.585071585693813d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.61391130652238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6139113065223801d + "'", double1 == 0.6139113065223801d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (-86196911));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int2 = org.apache.commons.math.util.FastMath.max(1072693148, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693148 + "'", int2 == 1072693148);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-86196911));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 187, 5.70276521665742E-4d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.acos(15.10441284864867d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.03397965999E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0339796599899998E11d) + "'", double1 == (-1.0339796599899998E11d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.log(15.797559753635479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7598554821324757d + "'", double1 == 2.7598554821324757d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.2124676738864985E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2124676738864985E30d + "'", double1 == 2.2124676738864985E30d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray28 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray28);
        int[] intArray36 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray36);
        int[] intArray41 = new int[] { 3, (short) -1, 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray41);
        int[] intArray45 = new int[] { (short) 100, (short) 100 };
        int[] intArray48 = new int[] { 197, (byte) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray48);
        int[] intArray52 = new int[] { (short) 100, (short) 100 };
        int[] intArray55 = new int[] { 197, (byte) 10 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray55);
        int[] intArray60 = new int[] { (short) 100, (short) 100 };
        int[] intArray63 = new int[] { 197, (byte) 10 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray63);
        int[] intArray67 = new int[] { (short) 100, (short) 100 };
        int[] intArray70 = new int[] { 197, (byte) 10 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray63);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray63);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray17);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.04454463255303d + "'", double29 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 198 + "'", int42 == 198);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 132.32157798333574d + "'", double49 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 132.32157798333574d + "'", double56 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 132.32157798333574d + "'", double64 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 132.32157798333574d + "'", double71 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 132.32157798333574d + "'", double74 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 187);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1516653350344987d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.22533514313954892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22347050849198133d + "'", double1 == 0.22347050849198133d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.MathUtils.sign(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(159922119900L, (long) 9968);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 159922109932L + "'", long2 == 159922109932L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.9E-324d, 0.22347050849198133d, 197);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        int int24 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.691673596021348E41d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5729.684851727662d + "'", double11 == 5729.684851727662d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(15.797559753635479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628799.999999998d + "'", double1 == 3628799.999999998d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.2679097686563066d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1555066708254376d) + "'", double1 == (-1.1555066708254376d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.asinh(101.04454463255303d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.308733121038255d + "'", double1 == 5.308733121038255d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray10 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.5840734641020676d);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray13);
        double[] doubleArray17 = null;
        try {
            double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1599221199 + "'", int14 == 1599221199);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 207520192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207520192 + "'", int2 == 207520192);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.03397965998E11d), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.03397966E11d) + "'", double2 == (-1.03397966E11d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-938056529));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-938056512) + "'", int1 == (-938056512));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.141592653589793d, 171.88733853924697d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 10, (-49));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-39) + "'", int2 == (-39));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-35), (long) 1599221199);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int1 = org.apache.commons.math.util.MathUtils.hash(10.179083551875799d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1762048500) + "'", int1 == (-1762048500));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long1 = org.apache.commons.math.util.FastMath.abs(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-36L), 2.2540686788122044d, (double) 176992988855400L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1762048500));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9016777586372893d, 0.0d, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 97.0f, 0.0d, 1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101131, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101131 + "'", int2 == 1076101131);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(97L, (long) (-938056512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-39), 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5256198019480943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 198.0f, 5.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2146959361);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.47862886452754433d) + "'", double1 == (-0.47862886452754433d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.signum((-5.118867265355524E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8768393613128505d) + "'", double1 == (-0.8768393613128505d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1072693248);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection22, false);
        boolean boolean25 = nonMonotonousSequenceException24.getStrict();
        int int26 = nonMonotonousSequenceException24.getIndex();
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number28 = nonMonotonousSequenceException24.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException24.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection29, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection29, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-0.004 <= 0.588)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.5707963267948966d) + "'", number28.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2110908904786679E-5d + "'", double1 == 1.2110908904786679E-5d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1599221199);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', 197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-145) + "'", int2 == (-145));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.875409442231813E-18d, (-5.871356456934583E107d), 10.179083551875799d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-938056529));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.3805651E8f) + "'", float2 == (-9.3805651E8f));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7165256995489035d + "'", double1 == 0.7165256995489035d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean24 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3628800.577670083d, 1.1102230246251565E-16d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (short) 10, 1.217963665598969d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7168146928204138d + "'", double2 == 3.7168146928204138d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3628799.999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.log((-744.4400719213812d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 464589906);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 464589906 + "'", int2 == 464589906);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray66 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray72 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double[] doubleArray77 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray83 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, 0.5840734641020676d);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray66);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 5763.986698182558d + "'", double87 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-2027411098) + "'", int89 == (-2027411098));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.03397965999E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.03397966E11d) + "'", double1 == (-1.03397966E11d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 360339393);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 360339392 + "'", int1 == 360339392);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.9443504370351303d), 1.0231449225129274d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9443504370351303d) + "'", double2 == (-0.9443504370351303d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0231449225129274d, 0.0d, (double) (-103397965998L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-54.107294423447755d), (double) 360339392);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0099010138502609d, 0.49558410655746776d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(10.0d, (-5.871356456934583E107d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.871356456934583E107d) + "'", double2 == (-5.871356456934583E107d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.302585092994046d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.signum(174.53292519943292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-818408495), 207520192L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-169836288016831040L) + "'", long2 == (-169836288016831040L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 197, (long) (-2147483648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483845L + "'", long2 == 2147483845L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(360339392);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.759353443181043d + "'", double1 == 0.759353443181043d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-2147483648), (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963221382837d) + "'", double2 == (-1.5707963221382837d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8499013987228136d, (-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9036922050915067d) + "'", double2 == (-0.9036922050915067d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) 1072693248);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269325E9f + "'", float2 == 1.07269325E9f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1824669988200L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1824669988200L + "'", long1 == 1824669988200L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.sinh(174.53292519943292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1452583854692583E75d + "'", double1 == 3.1452583854692583E75d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.rint((-743.7469247408213d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-744.0d) + "'", double1 == (-744.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-86196911), 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) -1, (long) 284858279);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 284858279L + "'", long2 == 284858279L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        long long2 = org.apache.commons.math.util.FastMath.min(6324257797542248449L, 4620L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4620L + "'", long2 == 4620L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 52);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger9 = null;
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 2147483845L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(51L, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 510000L + "'", long2 == 510000L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.105427357601002E-15d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.MathUtils.sign(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.217963665598969d, (-36.7368005696771d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.util.FastMath.pow(5729.097177468362d, 3.875409442231813E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-2.0d));
        java.lang.Class<?> wildcardClass15 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection19, false);
        boolean boolean22 = nonMonotonousSequenceException21.getStrict();
        int int23 = nonMonotonousSequenceException21.getIndex();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException21.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection26, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-0.004 <= 0.588)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.5707963267948966d) + "'", number25.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3701279294639708d, 5763.986698182558d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long1 = org.apache.commons.math.util.FastMath.abs(51L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 51L + "'", long1 == 51L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 159922119900L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5706963267952299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2333494133677316d + "'", double1 == 1.2333494133677316d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-54.107294423447755d), (double) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.1296280268036493E17d, (java.lang.Number) 97L, 187);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Throwable throwable6 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(9968, 360339392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112 + "'", int2 == 112);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 9968);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706960057679458d + "'", double1 == 1.5706960057679458d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2147483845L, 1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1474838449999995E9d + "'", double2 == 2.1474838449999995E9d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1072693249L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1023.6665584189136d + "'", double1 == 1023.6665584189136d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-145), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.485587498953173d + "'", double1 == 2.485587498953173d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1076101121);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 2147483845L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52L, 103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-103397965998L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0339796599799998E11d) + "'", double1 == (-1.0339796599799998E11d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray63 = new double[] {};
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray67 = new double[] { 2146959360, 100.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray63);
        java.lang.Class<?> wildcardClass70 = doubleArray63.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1.0f), (-49));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7763568394002505E-15d) + "'", double2 == (-1.7763568394002505E-15d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.1296280268036493E17d, (java.lang.Number) 97L, 187);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5.1296280268036493E17d + "'", number5.equals(5.1296280268036493E17d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 97L + "'", number6.equals(97L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-103397965998L), 1.6260455608423314d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 284858279L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.84858279E8d + "'", double1 == 2.84858279E8d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection42, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection42, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-35 <= 5,729.578)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.22347050849198133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.803916982232952d + "'", double1 == 12.803916982232952d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int int2 = org.apache.commons.math.util.MathUtils.pow(197, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 197 + "'", int2 == 197);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1076101131);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 112, (long) (-938056512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.1452583854692583E75d, 4.585071585693813d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-938056529));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.log(1.9367397952018277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.661006041483763d + "'", double1 == 0.661006041483763d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5707467683842815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.99716051223238d + "'", double1 == 89.99716051223238d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12576469727536L + "'", long2 == 12576469727536L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(2146959360, (-938056529));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long1 = org.apache.commons.math.util.FastMath.round((-5.871356456934583E107d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.094947017729282E-13d + "'", double1 == 9.094947017729282E-13d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int2 = org.apache.commons.math.util.FastMath.min((-938056529), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-938056529) + "'", int2 == (-938056529));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.cos(1023.6665584189136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881084187153127d + "'", double1 == 0.881084187153127d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36620409622270317d + "'", double1 == 0.36620409622270317d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1072693248L, (long) (-1762048500));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Number number17 = nonMonotonousSequenceException14.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(35.0d, (double) 52, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.log(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.4638654449311756E57d, 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1076101131, (-938056512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-2027411098));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.61391130652238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8174010937150691d + "'", double1 == 0.8174010937150691d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5707467683842815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.509064433023378d + "'", double1 == 2.509064433023378d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException5.getSuppressed();
        int int25 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-8934108775301215359L), 3, (-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.1296280268036486E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.47212690861747d + "'", double1 == 41.47212690861747d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-35L), 187, 2146959361);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 207520192);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(207520192L, 49L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 5729.5779513082325d + "'", number4.equals(5729.5779513082325d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(187, 360339392);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int1 = org.apache.commons.math.util.MathUtils.hash(15.10441284864867d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-637910610) + "'", int1 == (-637910610));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 6324257797542248449L, (double) 12576469727536L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-86196911));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.6196912E7f + "'", float1 == 8.6196912E7f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        long long1 = org.apache.commons.math.util.FastMath.abs(132L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 132L + "'", long1 == 132L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray70);
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number73, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        int int77 = nonMonotonousSequenceException76.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException76.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection78, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1072693249L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.03397965998E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1076101131);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0761011310000002E9d + "'", double1 == 1.0761011310000002E9d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 101.0f, 0.6712543997367529d, 4.5924994680212787E33d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 360339393, (double) (-637910610));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5840734641020676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7642469915557847d + "'", double1 == 0.7642469915557847d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10, (-2147483648));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 207520192L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2626272556789118d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray70);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 2146959360L);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 0.5840734641020676d);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, (-2.0d));
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 5731.590243702963d + "'", double90 == 5731.590243702963d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2302012565517866d + "'", double1 == 3.2302012565517866d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1599221199);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException21.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1076101121);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.076101121E9d + "'", double1 == 1.076101121E9d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0761011310000002E9d, 32.00000000000001d, 198);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 51L, 207520192, orderDirection13, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267948966d) + "'", number12.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.84858279E8d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.84858279E8d + "'", double2 == 2.84858279E8d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray40 = null;
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.587674259300095d + "'", double38 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 97L, 2146959360);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 198, (float) 1072693248L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 198.0f + "'", float2 == 198.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 360339392, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int2 = org.apache.commons.math.util.FastMath.max((-35), 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 284858279L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.84858279E8d + "'", double1 == 2.84858279E8d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.6005459244423d + "'", double1 == 100.6005459244423d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-103397965998L), (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.NEGATIVE_INFINITY + "'", float3 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.233403117511217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.432892215913483d + "'", double1 == 2.432892215913483d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 159922119900L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5574077246549023d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 10L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0339796599799998E11d), 0.671254399736753d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.495542252526088d + "'", double1 == 7.495542252526088d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.179083551875799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17765852281583172d + "'", double1 == 0.17765852281583172d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(98.97355719021847d, 0.8941496661860572d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double2 = org.apache.commons.math.util.MathUtils.log(100.0d, (-1.5707963263016567d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 1076101131);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 6324257797542248449L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 100, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5309649148733797d) + "'", double2 == (-0.5309649148733797d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.1411200080598672d, 198.00000000000003d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.1547159111271573E-169d + "'", double2 == 4.1547159111271573E-169d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.1452583854692583E75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.26427039653892626d) + "'", double1 == (-0.26427039653892626d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1072693148);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int2 = org.apache.commons.math.util.FastMath.min((-145), 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-145) + "'", int2 == (-145));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 198.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4557519189487724d + "'", double1 == 3.4557519189487724d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(30, 2146959360);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.sin(10100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21860170830356726d + "'", double1 == 0.21860170830356726d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9989864988033521d + "'", double1 == 0.9989864988033521d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-169836288016831040L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 0.0f, (double) (-2027411098));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1072693248, (-35L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.log1p(597.4533143721499d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3943485175648d + "'", double1 == 6.3943485175648d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.7988002500903407E85d, 10, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.000000000000002d, 1.5706960057679458d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.213113347607305d + "'", double2 == 37.213113347607305d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 187);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-187) + "'", int2 == (-187));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.661006041483763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6139113065223799d + "'", double1 == 0.6139113065223799d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5405824507740068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5711292852277063d + "'", double1 == 0.5711292852277063d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-145), (float) (-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.9341087E18f) + "'", float2 == (-8.9341087E18f));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-744.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long2 = org.apache.commons.math.util.FastMath.min(12576469727536L, (long) (-145));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-145L) + "'", long2 == (-145L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.03397966E11d), 1.0726932479999999E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932455606842E9d + "'", double2 == 1.0726932455606842E9d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.7598554821324757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930430334723742d + "'", double1 == 7.930430334723742d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray16 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray22 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double[] doubleArray27 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray33 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray27);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 207520192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 207520192 + "'", int2 == 207520192);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2027411098), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-169836288016831040L), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.69836287E17f) + "'", float2 == (-1.69836287E17f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-818408495), (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 207520192);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.7642469915557847d, (double) (-1), 1.037396450599555d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray25 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        double[] doubleArray30 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray36 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray30);
        double[] doubleArray42 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray48 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray53 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray59 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray53);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray53);
        double[] doubleArray66 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray72 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray72);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray53);
        double[] doubleArray76 = new double[] {};
        try {
            double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 5962.5779513082325d + "'", double74 == 5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.017874927409903d + "'", double1 == 10.017874927409903d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 464589906);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, 1.072693148E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 284858279);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.5256198019480943d, 1.6260455608423314d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5256198019480943d + "'", double2 == 0.5256198019480943d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.5924994680212787E33d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.20287967163418d + "'", double1 == 78.20287967163418d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.1296280268036493E17d, (java.lang.Number) 97L, 187);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97L + "'", number5.equals(97L));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0726932455606842E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.486585555436466d + "'", double1 == 21.486585555436466d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-2027411098));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.min(6.691673596021348E41d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.ceil(14405.561148389881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14406.0d + "'", double1 == 14406.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        int int13 = nonMonotonousSequenceException11.getIndex();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection16, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5256198019480943d, (java.lang.Number) 1023.6665584189136d, 2, orderDirection16, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.5707963267948966d) + "'", number15.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 2146959361, 1072693248L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074266113L + "'", long2 == 1074266113L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1072693248L, 0.22347050849198133d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22347050849198133d + "'", double2 == 0.22347050849198133d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double2 = org.apache.commons.math.util.FastMath.pow(1023.6665584189136d, (double) (-2661627379775963136L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.9367397952018277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2464946689549943d + "'", double1 == 1.2464946689549943d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 12576469727536L, 187);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2576469727536E13d + "'", double2 == 1.2576469727536E13d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447362047) + "'", int2 == (-447362047));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-5.871356456934583E107d), 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.8713564569345824E107d) + "'", double2 == (-5.8713564569345824E107d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(81.5579594561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.030944549497576d + "'", double1 == 9.030944549497576d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 6324257797542248449L, 1076101121, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.86982779515445d + "'", double1 == 77.86982779515445d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1977461928657023d + "'", double1 == 1.1977461928657023d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(132L, (long) 112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.1452583854692583E75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1452583854692583E75d + "'", double1 == 3.1452583854692583E75d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-103397965998L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray5 = new double[] { 0.015603607662981848d, (byte) 10, 0.8130227804211657d, 2.2250738585072014E-308d, 1.7182818284590453d };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.6108652381980153d);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.179083551875799d + "'", double8 == 10.179083551875799d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.179083551875799d + "'", double9 == 10.179083551875799d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.MathUtils.sign(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-2027411098), 510000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 510000L + "'", long2 == 510000L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 101L, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.33791696896E11d + "'", double2 == 4.33791696896E11d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(112);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2333494133677316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1762048500));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8686709614860095d) + "'", double1 == (-0.8686709614860095d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (-938056512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int[] intArray6 = new int[] { 360339393, (-2147483648), (byte) -1, 360339392, (byte) 0, 2146959360 };
        int[] intArray9 = new int[] { (short) 100, (short) 100 };
        int[] intArray12 = new int[] { 197, (byte) 10 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray12);
        int[] intArray16 = new int[] { (short) 100, (short) 100 };
        int[] intArray19 = new int[] { 197, (byte) 10 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray19);
        int[] intArray24 = new int[] { (short) 100, (short) 100 };
        int[] intArray27 = new int[] { 197, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray27);
        int[] intArray35 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray24);
        try {
            int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 132.32157798333574d + "'", double13 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 132.32157798333574d + "'", double20 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 132.32157798333574d + "'", double28 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.04454463255303d + "'", double36 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 187 + "'", int37 == 187);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(198.0d, (-49));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.517186542012496E-13d + "'", double2 == 3.517186542012496E-13d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.floor(37.213113347607305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.0d + "'", double1 == 37.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection4, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5962.5779513082325d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.072693148E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-169836288016831040L), 2146959361);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1072693148L, (-49));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(2148794369L, (long) (-187));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray9 = new int[] { (short) 100, (short) 100 };
        int[] intArray12 = new int[] { 197, (byte) 10 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray24 = new int[] { (short) 100, (short) 100 };
        int[] intArray27 = new int[] { 197, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray20);
        int[] intArray31 = null;
        try {
            int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 132.32157798333574d + "'", double13 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 132.32157798333574d + "'", double28 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.930430334723742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.767806072394084d + "'", double1 == 2.767806072394084d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8686709614860095d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.569397566060481d + "'", double1 == 7.569397566060481d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long1 = org.apache.commons.math.util.FastMath.round(2.2124676738864985E30d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1824669988200L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray9 = new int[] { (short) 100, (short) 100 };
        int[] intArray12 = new int[] { 197, (byte) 10 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray28 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray17);
        int[] intArray33 = new int[] { (short) 100, (short) 100 };
        int[] intArray36 = new int[] { 197, (byte) 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray33);
        int[] intArray41 = new int[] { (short) 100, (short) 100 };
        int[] intArray44 = new int[] { 197, (byte) 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray44);
        int[] intArray52 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray52);
        int[] intArray60 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray60);
        int[] intArray65 = new int[] { 3, (short) -1, 100 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray65);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 132.32157798333574d + "'", double13 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.04454463255303d + "'", double29 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 187 + "'", int30 == 187);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.32157798333574d + "'", double37 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 132.32157798333574d + "'", double45 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 101.04454463255303d + "'", double53 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 3 + "'", int61 == 3);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 198 + "'", int66 == 198);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 140.03570973148243d + "'", double67 == 140.03570973148243d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1072693248, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.99499987499378d + "'", double1 == 99.99499987499378d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.9367397952018277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 2147483845L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483845L + "'", long2 == 2147483845L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(30, 1072693148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1072693118) + "'", int2 == (-1072693118));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 159922119900L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.59922127E11f + "'", float1 == 1.59922127E11f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-938056512));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.3805651E8f + "'", float1 == 9.3805651E8f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-447362047), 198);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        long long2 = org.apache.commons.math.util.FastMath.max(6324257797542248449L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6324257797542248449L + "'", long2 == 6324257797542248449L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 198);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6712543997367529d, 3.2302012565517866d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2146959361);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6525285981219316E32d + "'", double1 == 2.6525285981219316E32d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9030861493754311d, (double) 132L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 103L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 103.0f + "'", float2 == 103.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 8.6196912E7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.935491707525615d + "'", double1 == 7.935491707525615d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int1 = org.apache.commons.math.util.FastMath.abs(9968);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9968 + "'", int1 == 9968);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.ulp(10.017874927409903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        long long2 = org.apache.commons.math.util.FastMath.min((-103397965998L), (long) 360339393);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-103397965998L) + "'", long2 == (-103397965998L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 'a', (long) (-35));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3395L + "'", long2 == 3395L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-145L), (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 393877977 + "'", int1 == 393877977);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '#', 10000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(10000, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-49), (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9951L + "'", long2 == 9951L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1875197236306705E48d + "'", double1 == 2.1875197236306705E48d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray16 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray22 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double[] doubleArray27 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray33 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 0.5840734641020676d);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray36);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        double[] doubleArray64 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray70 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray70);
        double[] doubleArray75 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray81 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray75);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray75);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray75);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 5763.986698182558d + "'", double37 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 5729.097177468362d + "'", double86 == 5729.097177468362d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 112);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.4638654449311756E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.387331176959678E58d + "'", double1 == 8.387331176959678E58d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.60978210179491616E17d) + "'", double1 == (-1.60978210179491616E17d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1072693118));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7442720781323875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        java.lang.Throwable throwable4 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7642469915557847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8742122119690302d + "'", double1 == 0.8742122119690302d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-9223372036854775808L), (long) (-447362047));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 100, 197);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.875409442231813E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 'a', 8625328718985906577L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(52L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 152L + "'", long2 == 152L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 132L, 0, 360339392);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.09698324645938282d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-2.0d));
        java.lang.Class<?> wildcardClass15 = doubleArray12.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.588 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 2.84858279E8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 100.0f, (-0.5698985410143955d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

