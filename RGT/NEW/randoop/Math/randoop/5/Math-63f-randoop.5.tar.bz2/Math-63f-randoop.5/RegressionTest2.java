import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-187));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.2333494133677316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1105626562097843d + "'", double1 == 1.1105626562097843d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(284858279, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long1 = org.apache.commons.math.util.FastMath.abs(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.000000000000002d, (java.lang.Number) (byte) 1, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14813015527508458d) + "'", double1 == (-0.14813015527508458d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.NEGATIVE_INFINITY, (double) (-86196911), 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.767806072394084d, 8.693425907335698d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3082320158843422d + "'", double2 == 0.3082320158843422d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number1, (int) (short) -1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (null >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (null >= 0)"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(8.387331176959678E58d, 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.193665588479839E58d + "'", double2 == 4.193665588479839E58d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1072693249L, 1599221199);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double2 = org.apache.commons.math.util.FastMath.max(9999.999999999998d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9999.999999999998d + "'", double2 == 9999.999999999998d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.179083551875799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.179083551875799d + "'", double1 == 10.179083551875799d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-637910610));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-637910610L) + "'", long2 == (-637910610L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5711292852277063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5439113644242847d + "'", double1 == 0.5439113644242847d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1072693118));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1762048500), (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7620484999999998E9d) + "'", double2 == (-1.7620484999999998E9d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.560900024546974d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5609000245469742d + "'", double1 == 1.5609000245469742d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-938056529), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-938056528) + "'", int2 == (-938056528));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-39), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 6324257797542248449L, (double) 176992988855400L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long long1 = org.apache.commons.math.util.FastMath.abs(1072693249L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1072693249L + "'", long1 == 1072693249L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8499013987228136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2557975993373345d + "'", double1 == 1.2557975993373345d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-447362047));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 152L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0238805208462765d + "'", double1 == 5.0238805208462765d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.MathUtils.pow(30, 900L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-145));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger26);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 52);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 52);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger46);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger46);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 52);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 52);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger58);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 0L);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) 52);
        java.math.BigInteger bigInteger65 = null;
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, 0L);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) 52);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger69);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (int) (short) 1);
        java.math.BigInteger bigInteger73 = null;
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, 0L);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) 52);
        java.math.BigInteger bigInteger78 = null;
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, 0L);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger80, (long) 52);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, bigInteger82);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, bigInteger75);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger75);
        java.math.BigInteger bigInteger87 = org.apache.commons.math.util.MathUtils.pow(bigInteger85, (int) (byte) 1);
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger87);
        org.junit.Assert.assertNotNull(bigInteger88);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5962.577951308233d + "'", double1 == 5962.577951308233d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24L + "'", long1 == 24L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.3701279294639708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3332878741134955d + "'", double1 == 1.3332878741134955d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, (-1762048500));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.MathUtils.sign(10.179083551875799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-35), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) '4', (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5200L + "'", long2 == 5200L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.exp((-54.107294423447755d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1732230564395573E-24d + "'", double1 == 3.1732230564395573E-24d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-35), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.math.util.MathUtils.pow(112, (long) 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double2 = org.apache.commons.math.util.FastMath.pow(15.104412573075516d, 1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 119.80141880693274d + "'", double2 == 119.80141880693274d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.70276521665742E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 284858279);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4971714.870114621d + "'", double1 == 4971714.870114621d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2146959360, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.21860170830356726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.360601550564472E8d, 1.037396450599555d, 9968);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1072693118));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        double[] doubleArray80 = new double[] { 2.302585092994046d, 0.9999999958776927d, 51L, 194.2477796076938d, 197, 15.10441284864867d };
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray85 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray91 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, 0.5840734641020676d);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray94);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.587674259300095d + "'", double73 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 207520192 + "'", int81 == 207520192);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1599221199 + "'", int95 == 1599221199);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.587674259300095d + "'", double96 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = org.apache.commons.math.util.MathUtils.pow(464589906, 112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 52);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 52);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 52);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 1);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 52);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 52);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger31);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-145L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-5.871356456934583E107d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1076101121, (long) 112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 120523325552L + "'", long2 == 120523325552L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 9968);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 173.97441983879477d + "'", double1 == 173.97441983879477d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double2 = org.apache.commons.math.util.FastMath.atan2(97.0d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5546039655506656d + "'", double2 == 1.5546039655506656d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(464589906, (-187));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 464589719 + "'", int2 == 464589719);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int[] intArray0 = new int[] {};
        int[] intArray3 = new int[] { (short) 100, (short) 100 };
        int[] intArray6 = new int[] { 197, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray6);
        int[] intArray14 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray14);
        int[] intArray18 = new int[] { (short) 100, (short) 100 };
        int[] intArray21 = new int[] { 197, (byte) 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray21);
        int[] intArray29 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray29);
        int[] intArray37 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray37);
        int[] intArray42 = new int[] { 3, (short) -1, 100 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray42);
        int[] intArray46 = new int[] { (short) 100, (short) 100 };
        int[] intArray49 = new int[] { 197, (byte) 10 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray46);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray46);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray46);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 132.32157798333574d + "'", double7 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 101.04454463255303d + "'", double15 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 132.32157798333574d + "'", double22 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.04454463255303d + "'", double30 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 198 + "'", int43 == 198);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 132.32157798333574d + "'", double50 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-2661627379775963136L), 41.47212690861747d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.47212690861747d + "'", double2 == 41.47212690861747d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double[] doubleArray5 = new double[] { 0.015603607662981848d, (byte) 10, 0.8130227804211657d, 2.2250738585072014E-308d, 1.7182818284590453d };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.6108652381980153d);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] {};
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray13 = new double[] { 2146959360, 100.0d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray13);
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray18);
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.179083551875799d + "'", double8 == 10.179083551875799d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.146959395E9d + "'", double38 == 2.146959395E9d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1072693248, 464589906);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(9968, (-187));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2146959360);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2301171011410834E11d + "'", double1 == 1.2301171011410834E11d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double2 = org.apache.commons.math.util.MathUtils.round(1023.6665584189136d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', (-938056529));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(52, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.9999999958776927d, (-0.7250423179744454d), (double) 393877977);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(159922109932L, 152L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 159922110084L + "'", long2 == 159922110084L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray45 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 0.5840734641020676d);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (-1.03397965999E11d), (int) '4', orderDirection54, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection54, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-35 < 5,729.578)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 5763.986698182558d + "'", double49 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 5763.986698182558d + "'", double50 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0086269770352588E-185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0086269770352588E-185d + "'", double1 == 1.0086269770352588E-185d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1076101121);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 52);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (short) 1);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 52);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger53);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) 52);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger58);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger43);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) 52);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 52);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, bigInteger72);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, (int) (short) 1);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger75);
        java.math.BigInteger bigInteger77 = null;
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, 0L);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, (long) 52);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-86196911), 152L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13101930472L + "'", long2 == 13101930472L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 284858279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(11013.232920103324d, (-1.5574077246549023d), 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-187));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.223372E18f + "'", float1 == 9.223372E18f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) ' ');
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (byte) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 198.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9968285949694307d) + "'", double1 == (-0.9968285949694307d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.1622776601683795d, 393877977);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.712371641661943E142d) + "'", double2 == (-7.712371641661943E142d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.59922127E11f, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-818408495), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray40 = new double[] {};
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray44 = new double[] { 2146959360, 100.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray44);
        double[] doubleArray46 = new double[] {};
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray46);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.587674259300095d + "'", double38 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number11, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int16 = nonMonotonousSequenceException14.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5,729.578 >= null)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5729.5779513082325d + "'", number5.equals(5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.03397966E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4693.577556529526d) + "'", double1 == (-4693.577556529526d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1072693118), (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.5698985410143955d), 15.797559753635479d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray45 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray39);
        double[] doubleArray51 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray57 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray62 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray68 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray62);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray62);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray62);
        double[] doubleArray73 = null;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray73);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(49L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.146959395E9d, 198);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1072693148L, (-0.47862886452754433d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.8414709848078965d), (-1.5707963263016567d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8414709848078965d) + "'", double2 == (-0.8414709848078965d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.03397965998E11d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43389695 + "'", int1 == 43389695);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection19, false);
        boolean boolean22 = nonMonotonousSequenceException21.getStrict();
        int int23 = nonMonotonousSequenceException21.getIndex();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection26, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Class<?> wildcardClass30 = nonMonotonousSequenceException28.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.5707963267948966d) + "'", number25.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 52);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 52);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger40);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger41);
        java.math.BigInteger bigInteger43 = null;
        try {
            java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1072693248, (java.lang.Number) 0.759353443181043d, 2147483647);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.759353443181043d + "'", number4.equals(0.759353443181043d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-35), 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 260.0d + "'", double1 == 260.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5439113644242847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8162866822094207d + "'", double1 == 0.8162866822094207d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double2 = org.apache.commons.math.util.MathUtils.round(5962.5779513082325d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5963.0d + "'", double2 == 5963.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 24L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.FastMath.max(132.32157798333574d, 2.3701279294639708d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 132.32157798333574d + "'", double2 == 132.32157798333574d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(159922109932L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 159922109984L + "'", long2 == 159922109984L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.22533514313954892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22533514313954894d + "'", double1 == 0.22533514313954894d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(100L, (long) (-938056512));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray66 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray72 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double[] doubleArray77 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray83 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, 0.5840734641020676d);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray66);
        java.lang.Number number89 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException92 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number89, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        int int93 = nonMonotonousSequenceException92.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection94 = nonMonotonousSequenceException92.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection94, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 5763.986698182558d + "'", double87 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection94 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection94.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.588 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double2 = org.apache.commons.math.util.FastMath.min(1.9367397952018277d, (double) 101L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9367397952018277d + "'", double2 == 1.9367397952018277d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.653313236643557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8544115468690805d + "'", double1 == 2.8544115468690805d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 100, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.8941496661860572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9455948742384643d + "'", double1 == 0.9455948742384643d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.661006041483763d, 5.70276521665742E-4d, 0.671254399736753d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-39));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException11.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(197, (-86196911));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.7988002500903407E85d, 10, orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        int int17 = nonMonotonousSequenceException15.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.7598554821324757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5706960057679458d, 1023.6665584189136d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570696005767946d + "'", double2 == 1.570696005767946d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 52);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4620L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.cos(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9873536182198484d + "'", double1 == 0.9873536182198484d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 100, (short) 100 };
        int[] intArray6 = new int[] { 197, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray6);
        int[] intArray14 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray14);
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 132.32157798333574d + "'", double7 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 101.04454463255303d + "'", double15 == 101.04454463255303d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8623188722876839d, (java.lang.Number) 1.5609000245469742d, (-1072693118));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 284858279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 284858279 + "'", int2 == 284858279);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray9 = new int[] { (short) 100, (short) 100 };
        int[] intArray12 = new int[] { 197, (byte) 10 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray17 = new int[] { (short) 100, (short) 100 };
        int[] intArray20 = new int[] { 197, (byte) 10 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
        int[] intArray24 = new int[] { (short) 100, (short) 100 };
        int[] intArray27 = new int[] { 197, (byte) 10 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int[] intArray32 = new int[] { (short) 100, (short) 100 };
        int[] intArray35 = new int[] { 197, (byte) 10 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray35);
        int[] intArray43 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray32);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray20);
        int[] intArray49 = new int[] { (short) 100, (short) 100 };
        int[] intArray52 = new int[] { 197, (byte) 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray52);
        int[] intArray60 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray60);
        int[] intArray68 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray68);
        int[] intArray73 = new int[] { 3, (short) -1, 100 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray73);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 132.32157798333574d + "'", double13 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 132.32157798333574d + "'", double21 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 132.32157798333574d + "'", double28 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 132.32157798333574d + "'", double36 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.04454463255303d + "'", double44 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 187 + "'", int45 == 187);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 132.32157798333574d + "'", double53 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.04454463255303d + "'", double61 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 198 + "'", int74 == 198);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 205 + "'", int75 == 205);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3628799.999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(12.803916982232952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.803916982232954d + "'", double1 == 12.803916982232954d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 52);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 52);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 52);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 52);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger26);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 13101930472L, 2146959360);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) ' ', (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2146959360);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2146959360L + "'", long1 == 2146959360L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(171.88733853924697d, 173.97441983879477d, 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52L, (long) (-637910610));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33171351720L) + "'", long2 == (-33171351720L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(194.2477796076938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1473840540600647E84d + "'", double1 == 1.1473840540600647E84d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 112, 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 112L + "'", long2 == 112L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2464946689549943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4781295684270495d + "'", double1 == 3.4781295684270495d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 30);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 30L + "'", long1 == 30L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 100, (short) 100 };
        int[] intArray6 = new int[] { 197, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray6);
        int[] intArray14 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray14);
        int[] intArray22 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray26 = new int[] { (short) 100, (short) 100 };
        int[] intArray29 = new int[] { 197, (byte) 10 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray29);
        int[] intArray33 = new int[] { (short) 100, (short) 100 };
        int[] intArray36 = new int[] { 197, (byte) 10 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray36);
        int[] intArray41 = new int[] { (short) 100, (short) 100 };
        int[] intArray44 = new int[] { 197, (byte) 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray44);
        int[] intArray52 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray41);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray41);
        try {
            int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 132.32157798333574d + "'", double7 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 101.04454463255303d + "'", double15 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 132.32157798333574d + "'", double30 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.32157798333574d + "'", double37 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 132.32157798333574d + "'", double45 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 101.04454463255303d + "'", double53 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 187 + "'", int54 == 187);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.asinh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.cos(171.88733853924697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6214083129159854d) + "'", double1 == (-0.6214083129159854d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(30L, (long) (-637910610));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-19137318300L) + "'", long2 == (-19137318300L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, 1076101121);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 100, (-1.3152355945118412d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.002341686816875076d + "'", double2 == 0.002341686816875076d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double2 = org.apache.commons.math.util.FastMath.atan2(119.80141880693274d, 2.432892215913483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5504914098844438d + "'", double2 == 1.5504914098844438d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray45 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray39);
        double[] doubleArray51 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray57 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray62 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray68 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray62);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray62);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray62);
        double[] doubleArray76 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray82 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray82);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray86 = null;
        try {
            double double87 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 5733.0767045381d + "'", double84 == 5733.0767045381d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-2027411098) + "'", int85 == (-2027411098));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.cos(119.80141880693274d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9127224153601113d + "'", double1 == 0.9127224153601113d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.875409442231813E-18d, (-0.47862886452754433d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8754094422318124E-18d + "'", double2 == 3.8754094422318124E-18d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 207520192L, (java.lang.Number) 132L, (-2027411098));
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2027411098) + "'", int4 == (-2027411098));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.log10(21.486585555436466d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3321674070108178d + "'", double1 == 1.3321674070108178d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 159922109932L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7571734891002406d + "'", double1 == 0.7571734891002406d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray26 = new int[] { 3, (short) -1, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray30 = new int[] { (short) 100, (short) 100 };
        int[] intArray33 = new int[] { 197, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray33);
        int[] intArray37 = new int[] { (short) 100, (short) 100 };
        int[] intArray40 = new int[] { 197, (byte) 10 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray40);
        int[] intArray45 = new int[] { (short) 100, (short) 100 };
        int[] intArray48 = new int[] { 197, (byte) 10 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray48);
        int[] intArray52 = new int[] { (short) 100, (short) 100 };
        int[] intArray55 = new int[] { 197, (byte) 10 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray55);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray48);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray48);
        int[] intArray62 = new int[] { (short) 100, (short) 100 };
        int[] intArray65 = new int[] { 197, (byte) 10 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray65);
        int[] intArray69 = new int[] { (short) 100, (short) 100 };
        int[] intArray72 = new int[] { 197, (byte) 10 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray72);
        int[] intArray77 = new int[] { (short) 100, (short) 100 };
        int[] intArray80 = new int[] { 197, (byte) 10 };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray80);
        int[] intArray88 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray88);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray77);
        int[] intArray93 = new int[] { (short) 100, (short) 100 };
        int[] intArray96 = new int[] { 197, (byte) 10 };
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray93, intArray96);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray93);
        int int99 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray93);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198 + "'", int27 == 198);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 132.32157798333574d + "'", double34 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 132.32157798333574d + "'", double41 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 132.32157798333574d + "'", double49 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 132.32157798333574d + "'", double56 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 132.32157798333574d + "'", double59 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 132.32157798333574d + "'", double66 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 132.32157798333574d + "'", double73 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 132.32157798333574d + "'", double81 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.04454463255303d + "'", double89 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 187 + "'", int90 == 187);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertNotNull(intArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 132.32157798333574d + "'", double97 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 187 + "'", int99 == 187);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 10000L, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int14 = nonMonotonousSequenceException11.getIndex();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException11.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (10,000 >= 2.718)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-8934108775301215359L), (-744.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double2 = org.apache.commons.math.util.FastMath.max(4620.0d, 5.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4620.0d + "'", double2 == 4620.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.7250423179744454d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7250423179744454d + "'", double1 == 0.7250423179744454d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(97.0d, (-39), (-637910610));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6508801680230075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8067714472036102d + "'", double1 == 0.8067714472036102d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-938056528));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 560 + "'", int2 == 560);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray25 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        double[] doubleArray30 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray36 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray30);
        double[] doubleArray42 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray48 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray53 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray59 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray53);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray53);
        double[] doubleArray66 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray72 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray72);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray53);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-2147483648));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 5962.5779513082325d + "'", double74 == 5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2146959361);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180465607951852d + "'", double1 == 22.180465607951852d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2147483648), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483647) + "'", int2 == (-2147483647));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.FastMath.max((-103397965998L), (long) (-1072693118));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1072693118L) + "'", long2 == (-1072693118L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.70276521665742E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        long long2 = org.apache.commons.math.util.FastMath.min(5200L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray25 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        double[] doubleArray30 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray36 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray30);
        double[] doubleArray42 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray48 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray48);
        double[] doubleArray53 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray59 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray53);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray53);
        double[] doubleArray66 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray72 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray72);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray53);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 5962.5779513082325d + "'", double74 == 5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8742122119690302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05838313109537149d) + "'", double1 == (-0.05838313109537149d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8174010937150691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0661452869115475d + "'", double1 == 1.0661452869115475d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1072693148);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.072693148E9d + "'", double1 == 1.072693148E9d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 360339392);
        java.lang.Class<?> wildcardClass33 = bigInteger30.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-187));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.877157801747449d + "'", double1 == 2.877157801747449d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(8.526417023433696d, (-744.0d), 0.8130227804211657d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9127224153601113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01593001130478921d + "'", double1 == 0.01593001130478921d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 0.0d);
        double[] doubleArray44 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray50 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double[] doubleArray55 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray61 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray55);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray78);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray78);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray78);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-2027411098) + "'", int89 == (-2027411098));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1072693118L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0726931179999999E9d) + "'", double1 == (-1.0726931179999999E9d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 103L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6443908991413725d + "'", double1 == 4.6443908991413725d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(900L, 207520192L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 46692043200L + "'", long2 == 46692043200L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long1 = org.apache.commons.math.util.FastMath.round((-2.2679097686563066d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray56);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 5962.5779513082325d + "'", double58 == 5962.5779513082325d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-762742594) + "'", int59 == (-762742594));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.850312770897137E114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 264.2352765143147d + "'", double1 == 264.2352765143147d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0.0f, (double) 1.59922127E11f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 52);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-1072693118));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2146959361, (long) (-49));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-105201008689L) + "'", long2 == (-105201008689L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(51L, (long) (-938056528));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-938056477L) + "'", long2 == (-938056477L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray15 = null;
        try {
            int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 49L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9537526527594719d) + "'", double1 == (-0.9537526527594719d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.4781295684270495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.47812956842705d + "'", double1 == 3.47812956842705d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.0d, 37.213113347607305d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0000000000000004d + "'", double2 == 2.0000000000000004d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.log(3.47812956842705d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2464946689549945d + "'", double1 == 1.2464946689549945d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        long long2 = org.apache.commons.math.util.FastMath.min(46692043200L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray26 = new int[] { 3, (short) -1, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray30 = new int[] { (short) 100, (short) 100 };
        int[] intArray33 = new int[] { 197, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray33);
        int[] intArray41 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray41);
        int[] intArray49 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray49);
        int[] intArray54 = new int[] { 3, (short) -1, 100 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray54);
        int[] intArray58 = new int[] { (short) 100, (short) 100 };
        int[] intArray61 = new int[] { 197, (byte) 10 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray61);
        int[] intArray69 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray69);
        int[] intArray77 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray77);
        int[] intArray81 = new int[] { (short) 100, (short) 100 };
        int[] intArray84 = new int[] { 197, (byte) 10 };
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray84);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray30);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198 + "'", int27 == 198);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 132.32157798333574d + "'", double34 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.04454463255303d + "'", double42 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 198 + "'", int55 == 198);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 132.32157798333574d + "'", double62 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 101.04454463255303d + "'", double70 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 132.32157798333574d + "'", double85 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 132.32157798333574d + "'", double86 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 97 + "'", int87 == 97);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray4 = new double[] { 2146959360, 100.0d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray4);
        double[] doubleArray6 = new double[] {};
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray6);
        double[] doubleArray12 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray18 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray18);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 0.5840734641020676d);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1599221199 + "'", int22 == 1599221199);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.587674259300095d + "'", double23 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.587674259300095d + "'", double24 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int2 = org.apache.commons.math.util.MathUtils.pow(43389695, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-450022657) + "'", int2 == (-450022657));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.59922127E11f, 10.017874927409903d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5992212684799997E11d + "'", double2 == 1.5992212684799997E11d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1074266113L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 3, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 103L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 30, (float) 1072693148);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269312E9f + "'", float2 == 1.07269312E9f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-145), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-145.0d) + "'", double2 == (-145.0d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 3, 360339393);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 120523325552L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.20523325552E11d + "'", double1 == 1.20523325552E11d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-187));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-33171351720L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 159922110084L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.5707963263016567d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-39), (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 97L, (double) 100, (double) (-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.2246467991473532E-16d, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(560, (-39));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.1411200080598672d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14112000805986719d + "'", double2 == 0.14112000805986719d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.517186542012496E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267945448d + "'", double1 == 1.5707963267945448d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.3082320158843422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) ' ');
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 187);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 187 + "'", int1 == 187);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 4L, 0, (-637910610));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray45 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray39);
        double[] doubleArray51 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray57 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray62 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray68 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray62);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray62);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray62);
        double[] doubleArray76 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray82 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray82);
        double[] doubleArray87 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray93 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray87);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray76);
        int int97 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 5729.097177468362d + "'", double96 == 5729.097177468362d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1599221199 + "'", int97 == 1599221199);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(205);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.588 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.587674259300095d + "'", double14 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.587674259300095d + "'", double15 == 0.587674259300095d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32L, (long) (-2147483647));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-68719476704L) + "'", long2 == (-68719476704L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8686709614860095d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2147483845L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.147483845E9d + "'", double2 == 2.147483845E9d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int2 = org.apache.commons.math.util.FastMath.max((-938056528), 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        long long2 = org.apache.commons.math.util.FastMath.max((-9223372036854775808L), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        long long2 = org.apache.commons.math.util.FastMath.min((-9223372036854775808L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9223372036854775808L) + "'", long2 == (-9223372036854775808L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.930430334723742d, (-744.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1072693148, (double) 9968, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-450022657), 2.2755538259844106d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2755538259844106d + "'", double2 == 2.2755538259844106d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9745068572213815E182d + "'", double1 == 1.9745068572213815E182d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number13 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.2626272556789118d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2, 6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0000000000000004d + "'", double2 == 2.0000000000000004d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.70276521665742E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.702764598448685E-4d + "'", double1 == 5.702764598448685E-4d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4436354751788103d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1.0f), 78.20287967163418d, 9.030944549497576d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, 1072693248L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.223372036854776E18d) + "'", double1 == (-9.223372036854776E18d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.asin(15.10441284864867d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        long long2 = org.apache.commons.math.util.MathUtils.pow(132L, 199825137);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3332878741134955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1006299075696573d + "'", double1 == 1.1006299075696573d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-105201008689L), (float) (-1072693118L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.05201009E11f) + "'", float2 == (-1.05201009E11f));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number1, (int) (short) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection8, false);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        int int12 = nonMonotonousSequenceException10.getIndex();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.String str14 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.7988002500903407E85d, 10, orderDirection18, false);
        int int21 = nonMonotonousSequenceException20.getIndex();
        int int22 = nonMonotonousSequenceException20.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection28, false);
        boolean boolean31 = nonMonotonousSequenceException30.getStrict();
        int int32 = nonMonotonousSequenceException30.getIndex();
        boolean boolean33 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection37, false);
        java.lang.String str40 = nonMonotonousSequenceException39.toString();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9030861493754311d, (java.lang.Number) 1.2626272556789118d, (-938056529));
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number47, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException46.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException50);
        int int52 = nonMonotonousSequenceException50.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) (byte) 0, 197);
        nonMonotonousSequenceException50.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException56);
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException56);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str40.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        boolean boolean18 = nonMonotonousSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2146959360);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146959360 + "'", int1 == 2146959360);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2027411098), 120523325552L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2027411098L) + "'", long2 == (-2027411098L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.930430334723742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2779.623145778198d + "'", double1 == 2779.623145778198d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.FastMath.sin(9.094947017729282E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.094947017729282E-13d + "'", double1 == 9.094947017729282E-13d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.sin((-743.7469247408213d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7246553734784749d) + "'", double1 == (-0.7246553734784749d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179586d, (java.lang.Number) (-0.30561438888825215d), 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.023638496439035d + "'", double1 == 2.023638496439035d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 0, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 103L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        long long2 = org.apache.commons.math.util.FastMath.max(132L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 205);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4638654449311756E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4638654449311756E57d + "'", double1 == 1.4638654449311756E57d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.767806072394084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 158.5836064588618d + "'", double1 == 158.5836064588618d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 0.5840734641020676d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 0.0d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.588 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1076101131, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1565427057 + "'", int2 == 1565427057);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-447362047));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 9968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49840 + "'", int2 == 49840);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.floor(12.803916982232952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.3082320158843422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2574623261141158d + "'", double1 == 1.2574623261141158d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-450022657));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int1 = org.apache.commons.math.util.FastMath.abs(1076101121);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101121 + "'", int1 == 1076101121);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011872827488d + "'", double1 == 1.1752011872827488d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-8.9341087E18f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long2 = org.apache.commons.math.util.FastMath.min(4620L, 103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.36620409622270317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3580738103364471d + "'", double1 == 0.3580738103364471d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double2 = org.apache.commons.math.util.FastMath.atan2(12.803916982232952d, (-0.7250423179744454d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6273625197605843d + "'", double2 == 1.6273625197605843d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection50, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection50, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-35 <= 5,729.578)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double[] doubleArray6 = new double[] { 2.302585092994046d, 0.9999999958776927d, 51L, 194.2477796076938d, 197, 15.10441284864867d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray17 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 0.5840734641020676d);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (2.303 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 207520192 + "'", int7 == 207520192);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1599221199 + "'", int21 == 1599221199);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.587674259300095d + "'", double22 == 0.587674259300095d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-33171351720L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1824669988200L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 12576469727536L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.099558749772557d + "'", double1 == 13.099558749772557d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.7988002500903407E85d, 10, orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        int int17 = nonMonotonousSequenceException15.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection28, false);
        boolean boolean31 = nonMonotonousSequenceException30.getStrict();
        int int32 = nonMonotonousSequenceException30.getIndex();
        boolean boolean33 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection37, false);
        java.lang.String str40 = nonMonotonousSequenceException39.toString();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.473814720414451d, (java.lang.Number) 7.105427357601002E-15d, 112, orderDirection42, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 3.875409442231813E-18d, 112, orderDirection42, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str40.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5707467683842815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(32.00000000000001d, (double) 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.147483845E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483845E9d + "'", double1 == 2.147483845E9d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.283185307179587d + "'", double1 == 6.283185307179587d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(176992988855400L, 2147483845L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray50);
        double[] doubleArray73 = null;
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(10100.0f, 560, 205);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 49840);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-8.9341087E18f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-471924971) + "'", int1 == (-471924971));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2027411098));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 207520192L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.189003116534451E10d + "'", double1 == 1.189003116534451E10d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1599221199, (-1072693118));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 526528081 + "'", int2 == 526528081);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.7598554821324757d, 4971714.870114621d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.7182818284590453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-187));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.MathUtils.sign(7.495542252526088d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.4436354751788103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 0, 10.017874927409903d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 2147483647, 0.015603607662981848d, (double) (-637910610L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (long) 360339393);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 198.0f, 205);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-145), 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-145) + "'", int2 == (-145));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        int int14 = nonMonotonousSequenceException12.getIndex();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number15, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection26, false);
        boolean boolean29 = nonMonotonousSequenceException28.getStrict();
        int int30 = nonMonotonousSequenceException28.getIndex();
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException28.getSuppressed();
        java.lang.Number number32 = nonMonotonousSequenceException28.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException28.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection33, false);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.String str38 = nonMonotonousSequenceException35.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-1.5707963267948966d) + "'", number32.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not decreasing (2 < 100)" + "'", str38.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not decreasing (2 < 100)"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.49558410655746776d, (double) 9.3805651E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        long long2 = org.apache.commons.math.util.FastMath.max((-145L), 1072693248L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(49840);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 52);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger27);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 360339392);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 52);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 52);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger42);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 52);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger53);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (int) (short) 1);
        java.math.BigInteger bigInteger57 = null;
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 0L);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, (long) 52);
        java.math.BigInteger bigInteger62 = null;
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 0L);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, (long) 52);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, bigInteger66);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, bigInteger59);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger59);
        java.math.BigInteger bigInteger70 = null;
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, 0L);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, (long) 52);
        java.math.BigInteger bigInteger75 = null;
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 0L);
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, (long) 52);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, bigInteger79);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger79);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger79);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger82, 13101930472L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger84);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5706963267952299d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1195484950 + "'", int1 == 1195484950);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1076101121, 152L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 163567370392L + "'", long2 == 163567370392L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.2574623261141158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number1, (int) (short) -1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        int int13 = nonMonotonousSequenceException11.getIndex();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-637910610L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.3791059E8f + "'", float1 == 6.3791059E8f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4638654449311756E57d, 1.2333494133677316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2333494133677316d + "'", double2 == 1.2333494133677316d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2557975993373345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5106373399836213d + "'", double1 == 2.5106373399836213d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9030861493754311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.488704845292198d + "'", double1 == 1.488704845292198d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 49840);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-35), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-35.0f) + "'", float2 == (-35.0f));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.5707963267948966d) + "'", number7.equals((-1.5707963267948966d)));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        long long2 = org.apache.commons.math.util.MathUtils.pow(13101930472L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.rint(14405.561148389881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14406.0d + "'", double1 == 14406.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963267948966d, (-0.9968285949694307d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 0, (long) 464589719);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 464589719L + "'", long2 == 464589719L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3628799.999999998d, 1.0099010138502609d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707960484932504d + "'", double2 == 1.5707960484932504d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3110011563655863d + "'", double1 == 1.3110011563655863d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.1452583854692583E75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7250423179744454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6273359298413054d + "'", double1 == 0.6273359298413054d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3628799.999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 100, (short) 100 };
        int[] intArray6 = new int[] { 197, (byte) 10 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray6);
        int[] intArray10 = new int[] { (short) 100, (short) 100 };
        int[] intArray13 = new int[] { 197, (byte) 10 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray18 = new int[] { (short) 100, (short) 100 };
        int[] intArray21 = new int[] { 197, (byte) 10 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray21);
        int[] intArray29 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray29);
        int[] intArray37 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray37);
        int[] intArray41 = new int[] { (short) 100, (short) 100 };
        int[] intArray44 = new int[] { 197, (byte) 10 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray44);
        int[] intArray49 = new int[] { (short) 100, (short) 100 };
        int[] intArray52 = new int[] { 197, (byte) 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray52);
        int[] intArray60 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray60);
        int[] intArray68 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray68);
        int[] intArray72 = new int[] { (short) 100, (short) 100 };
        int[] intArray75 = new int[] { 197, (byte) 10 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray49);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray18);
        try {
            int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 132.32157798333574d + "'", double7 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 132.32157798333574d + "'", double14 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 132.32157798333574d + "'", double22 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.04454463255303d + "'", double30 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 132.32157798333574d + "'", double45 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 132.32157798333574d + "'", double46 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 132.32157798333574d + "'", double53 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.04454463255303d + "'", double61 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 132.32157798333574d + "'", double76 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 132.32157798333574d + "'", double77 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 132.32157798333574d + "'", double79 == 132.32157798333574d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4, 5.0482269650408105d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.60978210179491616E17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8464215407014188d) + "'", double1 == (-0.8464215407014188d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.22347050849198125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2273060782299728d + "'", double1 == 0.2273060782299728d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 24L, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.0d + "'", double2 == 24.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1072693248L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.030475546991784d + "'", double1 == 9.030475546991784d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(101.04454463255303d, 1.762747174039086d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-145), 0.0d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.66827237527655d + "'", double1 == 43.66827237527655d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-35.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1069449216) + "'", int1 == (-1069449216));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int[] intArray2 = new int[] { (short) 100, (short) 100 };
        int[] intArray5 = new int[] { 197, (byte) 10 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray5);
        int[] intArray13 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray13);
        int[] intArray21 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray21);
        int[] intArray25 = new int[] { (short) 100, (short) 100 };
        int[] intArray28 = new int[] { 197, (byte) 10 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray28);
        int[] intArray36 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray36);
        int[] intArray44 = new int[] { (byte) 100, 'a', (byte) 1, (-1), '#', '4' };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray44);
        int[] intArray48 = new int[] { (short) 100, (short) 100 };
        int[] intArray51 = new int[] { 197, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray51);
        int[] intArray55 = new int[] { (short) 100, (short) 100 };
        int[] intArray58 = new int[] { 197, (byte) 10 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray58);
        int[] intArray63 = new int[] { (short) 100, (short) 100 };
        int[] intArray66 = new int[] { 197, (byte) 10 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray66);
        int[] intArray74 = new int[] { 'a', (-1), (byte) 1, 'a', 10, (byte) 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray63);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray63);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.32157798333574d + "'", double6 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.04454463255303d + "'", double14 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 132.32157798333574d + "'", double29 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 101.04454463255303d + "'", double37 == 101.04454463255303d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 132.32157798333574d + "'", double52 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 132.32157798333574d + "'", double59 == 132.32157798333574d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 132.32157798333574d + "'", double67 == 132.32157798333574d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 101.04454463255303d + "'", double75 == 101.04454463255303d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 187 + "'", int76 == 187);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (-1.03397965999E11d), (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5546039655506656d, (java.lang.Number) 2.220446049250313E-16d, (-35), orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (-637910610));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 30);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6061093801777693d + "'", double1 == 1.6061093801777693d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.037396450599555d, (double) 1824669988200L, (double) 46692043200L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1195484950);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(5731.590243702963d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5869148.409551834d + "'", double2 == 5869148.409551834d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505403852131288E17d + "'", double1 == 1.505403852131288E17d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-187), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4620.0d, (java.lang.Number) 1072693248L, (-1072693118));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4620.0d + "'", number4.equals(4620.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999103740052037d) + "'", double1 == (-0.9999103740052037d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        long long1 = org.apache.commons.math.util.FastMath.abs(900L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900L + "'", long1 == 900L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 199825137);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.0726931179999999E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-2.0d));
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray26 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double[] doubleArray31 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray37 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray31);
        double[] doubleArray43 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray49 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray49);
        double[] doubleArray54 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray60 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray54);
        double[] doubleArray67 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray73 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        double[] doubleArray78 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray84 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 0.5840734641020676d);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray87);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 2146959360L);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray54);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (5,729.578 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 199825137 + "'", int15 == 199825137);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0123299393632377d + "'", double16 == 2.0123299393632377d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 5763.986698182558d + "'", double88 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 5731.590243702963d + "'", double92 == 5731.590243702963d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        boolean boolean11 = nonMonotonousSequenceException8.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection15, false);
        java.lang.String str18 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.473814720414451d, (java.lang.Number) 7.105427357601002E-15d, 112, orderDirection20, false);
        java.lang.String str23 = nonMonotonousSequenceException22.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 111 and 112 are not decreasing (0 < 0.474)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 111 and 112 are not decreasing (0 < 0.474)"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-2027411098), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4645345211029053d + "'", double2 == 0.4645345211029053d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.3321674070108178d, 10100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.332167407010818d + "'", double2 == 1.332167407010818d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-4693.577556529526d), 0.0d, (-1.03397965998E11d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection13, false);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        int int17 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267948966d) + "'", number12.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5256198019480943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5256198019480944d + "'", double1 == 0.5256198019480944d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5963.0d, 2.023638496439035d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5.70276521665742E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08292684906582685d + "'", double1 == 0.08292684906582685d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-36L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long1 = org.apache.commons.math.util.FastMath.round(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 12576469727536L, 12.803916982232954d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.803916982232954d + "'", double2 == 12.803916982232954d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10100L, (long) 560);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        float float3 = org.apache.commons.math.util.MathUtils.round(9.223372E18f, (-1074790400), 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.NEGATIVE_INFINITY + "'", float3 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.432892215913483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.233403117511217d + "'", double1 == 1.233403117511217d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.61391130652238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6532070891002518d + "'", double1 == 0.6532070891002518d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 9951L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(464589719, 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double2 = org.apache.commons.math.util.MathUtils.log(1023.6665584189136d, 9.030475546991784d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.31749511394513613d + "'", double2 == 0.31749511394513613d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        double[] doubleArray18 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray24 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray35 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray29);
        double[] doubleArray41 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray47 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray52 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray58 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray52);
        double[] doubleArray63 = new double[] {};
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray67 = new double[] { 2146959360, 100.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray63);
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, number71, (int) (short) -1);
        int int74 = nonMonotonousSequenceException73.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = nonMonotonousSequenceException73.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection75, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.588 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 5729.097177468362d + "'", double62 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 526528081, (-0.5309649148733797d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 9223372036854775807L, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 52);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 52);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 52);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 52);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        try {
            java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (-39));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection13, false);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267948966d) + "'", number12.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not decreasing (2 < 100)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not decreasing (2 < 100)"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.6214083129159854d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 273554418 + "'", int1 == 273554418);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.log(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.465735902799727d + "'", double1 == 3.465735902799727d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1733246502868709E93d, (java.lang.Number) 4.9E-324d, (int) (short) 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        int int16 = nonMonotonousSequenceException14.getIndex();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection19, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        int int24 = nonMonotonousSequenceException21.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.5707963267948966d) + "'", number18.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5609000245469742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4865266288709784d + "'", double1 == 2.4865266288709784d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray14);
        double[] doubleArray26 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray32 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray43 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray37);
        double[] doubleArray50 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray56 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray67 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.5840734641020676d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray70);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 2146959360L);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 1.7988002500903407E85d);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5763.986698182558d + "'", double71 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 273623559 + "'", int77 == 273623559);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-762742594));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(3.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-938056528));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.3805651E8f + "'", float1 == 9.3805651E8f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int1 = org.apache.commons.math.util.FastMath.abs(273554418);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 273554418 + "'", int1 == 273554418);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1072693148, 3.47812956842705d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05994653947723986d + "'", double2 == 0.05994653947723986d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-39), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-40) + "'", int2 == (-40));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 13101930472L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1076101131, 43389695);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.850312770897137E114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5840734641020676d);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1599221199 + "'", int13 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1599221199 + "'", int15 == 1599221199);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.atan(4971714.870114621d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707961256570546d + "'", double1 == 1.5707961256570546d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1), (-2027411098), 9968 };
        try {
            int int5 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection12, false);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str18 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-145), 0.5840734641020676d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.5403023058681398d, 1, 360339393);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1072693248L, (java.lang.Number) 1024.0d, 112);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.560900024546974d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 49840, (long) 284858279);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-284808439L) + "'", long2 == (-284808439L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9989864988033521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9989864988033521d + "'", double1 == 0.9989864988033521d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1599221199, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1599221199 + "'", int2 == 1599221199);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 5729.5779513082325d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection19, false);
        boolean boolean22 = nonMonotonousSequenceException21.getStrict();
        int int23 = nonMonotonousSequenceException21.getIndex();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.0d, 100, orderDirection26, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number30 = nonMonotonousSequenceException28.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.5707963267948966d) + "'", number25.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 100 + "'", number30.equals((short) 100));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.03397965999E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-26.05499830819765d) + "'", double1 == (-26.05499830819765d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.015603607662981848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000121738756024d + "'", double1 == 1.000121738756024d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.4781295684270495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5151254229872915d + "'", double1 == 1.5151254229872915d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-187));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) '4', 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        java.lang.Class<?> wildcardClass26 = doubleArray23.getClass();
        double[] doubleArray30 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray36 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 0.5840734641020676d);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        double[] doubleArray45 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray51 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        double[] doubleArray56 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray62 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray56);
        double[] doubleArray68 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray74 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray74);
        double[] doubleArray79 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray85 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray79);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray79);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray79);
        double[] doubleArray90 = new double[] {};
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray90);
        double[] doubleArray94 = new double[] { 2146959360, 100.0d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray90, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray90);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.587674259300095d + "'", double25 == 0.587674259300095d);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1599221199 + "'", int40 == 1599221199);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 5729.097177468362d + "'", double89 == 5729.097177468362d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 360339392);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int2 = org.apache.commons.math.util.MathUtils.pow(526528081, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(103L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int1 = org.apache.commons.math.util.FastMath.abs((-938056512));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 938056512 + "'", int1 == 938056512);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1072693118), 1.9367397952018277d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.944725751876831d) + "'", double2 == (-0.944725751876831d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1762048500), 1.3332878741134955d, (double) 1565427057);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-743.7469247408213d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1932168908 + "'", int1 == 1932168908);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int1 = org.apache.commons.math.util.MathUtils.hash(14406.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1087120128 + "'", int1 == 1087120128);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 1076101131);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1072693249L, 560, (-938056529));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.1006299075696573d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8007251713250538d + "'", double1 == 0.8007251713250538d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.560900024546974d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-19137318300L), (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.3332878741134955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0285522813642674d + "'", double1 == 2.0285522813642674d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-39), 273623559);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-36L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.0d) + "'", double1 == (-36.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double[] doubleArray3 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray9 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray14 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray20 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.5840734641020676d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray23);
        double[] doubleArray28 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray34 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray45 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray39);
        double[] doubleArray51 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray57 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray62 = new double[] { (-35), 5729.5779513082325d, 0.0d };
        double[] doubleArray68 = new double[] { 1.0f, 0.0f, 197, 4.9E-324d, 10 };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray62);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray62);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray62);
        double[] doubleArray73 = null;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5763.986698182558d + "'", double24 == 5763.986698182558d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-2027411098) + "'", int75 == (-2027411098));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        int int13 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.5707963267948966d) + "'", number9.equals((-1.5707963267948966d)));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (10 < -1.571)"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int int1 = org.apache.commons.math.util.FastMath.abs(1565427057);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1565427057 + "'", int1 == 1565427057);
    }
}

